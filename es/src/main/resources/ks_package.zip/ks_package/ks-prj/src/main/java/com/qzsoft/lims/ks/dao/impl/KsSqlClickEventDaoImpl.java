package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.ConfigUtil;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.dao.KsSqlClickEventDao;
import com.qzsoft.lims.ks.eum.ClickEventTypeEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;

/**
 * 列表行事件动作
 * @author zf
 *
 */
@Repository
public class KsSqlClickEventDaoImpl extends BaseDaoImpl implements KsSqlClickEventDao{
	private static final String TABLE_NAME = "ks_sql_click_event_b";
	public KsSqlClickEventDaoImpl(){
		super.tableName=TABLE_NAME;
	}

	/**
	 * 通过模板编码获取行点击动作
	 */
	@Override
	public Record getClickEventByMcode(String m_code) {
		if(StringUtils.isBlank(m_code)){
			throw new BusinessException(11003,ConfigUtil.getMessage(11003, "模板编码"));
		}
		List<Record> recordList=selectListByCustomAndSort(TABLE_NAME, "m_code", "event_order+0", false, m_code);
		if(null != recordList && recordList.size() > 0){
			Record record=recordList.get(0);
			return record;
		}
		return null;
	}

	/**
	 * 大列表保存点击事件
	 */
	@JFinalTx
	@Override
	public Boolean saveByOuter(String m_code, String click_code,String old_m_code) {
		Boolean isSucc=true;
		if(StringUtils.isBlank(m_code) || StringUtils.isBlank(click_code) || StringUtils.isBlank(old_m_code)) return isSucc;
		deleteByCustom(TABLE_NAME, "m_code", old_m_code);
		Record record=new Record();
		record.set("m_code", m_code).set("click_code", click_code).set("event_name", ClickEventTypeEnum.OUTER_INFO.getDesc()).set("event_type", ClickEventTypeEnum.OUTER_INFO.getCode())
		.set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1");
		isSucc=DbEx.save(TABLE_NAME, record);
		return isSucc;
	}
}
