package com.qzsoft.lims.ks.controller;

import java.util.Map;

import com.qzsoft.common.annotation.TagResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsTableFieldCService;
import com.qzsoft.lims.ks.vo.KsTableFieldCVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * @auther: zf
 */
@Api(value = "表结构", tags = "表结构配置,表:ks_table_field_c")
@RestController
@RequestMapping("/tableField")
@Slf4j
public class KsTableFieldCController {

    @Autowired
    KsTableFieldCService ksTableFieldCService;

    @ApiOperation(value = "列表分页查询", notes="查询条件写死，t_name：表名;field_name:字段名称;is_show:是否显示。注:字典值用带str的展示")
    @GetMapping("/getPageList")
	    @ApiImplicitParams({
		@ApiImplicitParam(name="pageNum",value="页码",required=false,dataType="Integer",paramType="query"),
		@ApiImplicitParam(name="pageSize",value="每页显示条数",required=false,dataType="Integer",paramType="query")
	})
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getPageList(KsTableFieldCVO ksTableFieldCVO,
    		@RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
			@RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
    	RequestResult<Map<String, Object>> result = null;
		try {
			result=ksTableFieldCService.getPageList(ksTableFieldCVO, pageNum, pageSize);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getPageList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getPageList()", e);
		}
		return result;
    	
    }
    
    @ApiOperation("详情查询")
	@GetMapping("/getOne")
		@ApiImplicitParam(name="tableFieldId",value="主键",required=true,dataType="Long",paramType="query")
	@ResponseAddHead
	public RequestResult<KsTableFieldCVO> getOne(@RequestParam(value="tableFieldId") Long tableFieldId) {
		RequestResult<KsTableFieldCVO> result = new RequestResult<>();
		try {
			KsTableFieldCVO vo=ksTableFieldCService.getOne(tableFieldId);
			result.setObj(vo);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOne()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOne()", e);
		}
		return result;

	}
    
    @ApiOperation(value = "修改")
    @PostMapping("/update")
	    @ResponseAddHead
    public RequestResult<Boolean> update(KsTableFieldCVO ksTableFieldCVO) {
        RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean  isUpdate=ksTableFieldCService.update(ksTableFieldCVO);
			result.setObj(isUpdate);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".update()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".update()", e);
		}
		return result;
    }
}
