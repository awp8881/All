package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

import java.util.List;
import java.util.Map;

public interface KsModelCountBDao extends BaseDao{

    List<Record> getCountConfig(String pCode);

    Boolean saveCount(List<Map<String, Object>> countConfDatas, String newMCode, String menuId);
}
