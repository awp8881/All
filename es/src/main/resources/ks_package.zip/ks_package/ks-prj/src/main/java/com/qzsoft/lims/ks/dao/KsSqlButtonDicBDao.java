package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlButtonDicBDao extends BaseDao{
	
	/**
	 * 删除后插入
	 * @param parent_code
	 * @param dicSelectList
	 * @return
	 */
	Boolean batchUpdate(String parent_code,List<Map<String,Object>> dicSelectList);

	Record getByCode( String code);

	List<Record> getChilds( String code);

	List<Record> getByChilds( List<String> dics );
}
