package com.qzsoft.lims.ks.aspect;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.NoLoginException;
import com.qzsoft.common.exception.ReqFrequentlyException;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.ThreadLocalUtil;
import com.qzsoft.common.tools.UrlMatchUtil;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.vo.KsUserInfo;
import com.qzsoft.lims.ks.constants.Constant;
import com.qzsoft.lims.ks.eum.LogRecordTypeEnum;
import com.qzsoft.lims.ks.feign.TuService;
import com.qzsoft.lims.ks.util.IpUtils;
import com.qzsoft.lims.ks.util.UserDataUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @author pjh
 * @Title: ExceptionHandleAop
 * @Description: TODO
 * @date 2018/8/30 11:56
 */
@Aspect
@Component
@Slf4j
@Order(Integer.MAX_VALUE)
public class ExceptionHandleAop {


    @Value("${outsys.lims.tu.userInfoUrl:}")
    private String userInfoUrl;
    @Autowired
    TuService tuService;

    @Pointcut("execution(* com.qzsoft.lims.ks.controller..*(..)) || execution(* com.qzsoft.lims.hlyy.controller..*(..))")
    public void handleException() {
    }
//    @Pointcut("execution(* com.qzsoft.lims.ks.controller..*(..))")
//    public void handleException() {
//    }
    @Around(value = "handleException()")
    public Object doAround(ProceedingJoinPoint pjp) throws IOException {
        Object retVal = null;
        try {
            retVal = pjp.proceed();
            return retVal;
        }catch ( ReqFrequentlyException reqFrequentlyException ){
            HttpServletResponse httpServletResponse = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
            httpServletResponse.setContentType("application/json");
            RequestResult requestResult = reqFrequentlyException.getRequestResult();
            IOUtils.write(JSON.toJSONString(requestResult) , httpServletResponse.getOutputStream());
            return requestResult;
        }
        catch (NoLoginException noLoginException){
//            String userLoginUrl = ConfigUtil.getPropertyValue("http.limsx");
//            RequestResult result = RequestResult.error( noLoginException );
//            result.setRedirectUrl( userLoginUrl );
//            String userData = LoginTokenUtil.getUserInfo(userInfoUrl, UserDataUtil.getJID());
//            Map<String, Object> objMap = JSON.parseObject(userData);
            Map<String, Object> objMap = tuService.getUserInfoByToken( UserDataUtil.getJID(), UserDataUtil.getJID() );
            String error = ((JSONObject) objMap).getString("error");
            String errorCode = ((JSONObject) objMap).getString("errorCode");
            String redirectUrl = ((JSONObject) objMap).getString("redirectUrl");
            JSONObject res = new JSONObject();
            res.put("code","-1");
            res.put("error",error );
            res.put("resultCode",errorCode );
            res.put("payload",null);
            res.put("redirectUrl",redirectUrl );
            return res;

        }catch (Throwable t) {

            RequestResult requestResult = RequestResult.error( t );
            requestResult.setObj(false);
            log.error(this.getClass().getSimpleName(),t);

            Signature signature = pjp.getSignature();
            if (signature instanceof MethodSignature) {
                MethodSignature methodSignature = (MethodSignature) signature;
                Method method = methodSignature.getMethod();
                Class<?> methodReturnType = method.getReturnType();
                if ("void".equals( methodReturnType.getName() )) {
                    HttpServletResponse httpServletResponse = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
                    httpServletResponse.setContentType("application/json");
                    IOUtils.write(JSON.toJSONString(requestResult) , httpServletResponse.getOutputStream());
                }
            }
            return requestResult;

        }
    }


    @Before(value = "handleException()")
    public void doBefore(JoinPoint joinPoint) throws Throwable{
        // 开始打印请求日志
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String url = request.getRequestURI();
        // 匹配到配置接口,执行保存日志记录
        if (UrlMatchUtil.checkPath(LogRecordTypeEnum.getList(),url)){
            Record record = new Record();
            // 打印请求入参
            Object[] args = joinPoint.getArgs();
            // 在序列化之前，将HttpServletRequest和HttpServletResponse的实现类对象剔除掉
            args = Arrays.stream(args).filter(p -> !(p instanceof HttpServletResponse || p instanceof HttpServletRequest)).toArray();
            try {
                if (ObjectUtil.isNotNull(args)){
                    // 理论上参数对象只有一个,循环是为了保证兼容性
                    for (int i = 0; i < args.length; i++) {
                        Map<String, Object> bean = BeanUtil.beanToMap(args[i]);
                        LogRecordTypeEnum typeEnum = LogRecordTypeEnum.getAllToMap().get(url);
                        if (typeEnum == null || Objects.isNull(bean.get(typeEnum.getSource()))){
                            log.info("资源配置错误");
                            continue;
                        }
                        // 动态取source字段获取表单参数
                        record.set("m_code", bean.get(typeEnum.getSource()));
                        record.set("m_type", typeEnum.getType());
                        // 获取name
                        Record mName = DbEx.findFirst("select m_name from ks_menu_model_b where 1 = 1 and (m_code = ? or info_code = ? or list_code = ?) and m_type = ?", bean.get(typeEnum.getSource()),bean.get(typeEnum.getSource()),bean.get(typeEnum.getSource()),typeEnum.getType());
                        Record menu = DbEx.findById("ks_menu_c", bean.get("menu_id"));
                        record.set("menu_id", bean.get("menu_id"));
                        record.set("menu_name", menu.get("res_na"));
                        record.set("m_name", Objects.isNull(mName) ? null:mName.getStr("m_name"));
                        record.set("create_time", DateUtil.getNowDateTimeStr());
                        KsUserInfo userInfo = ThreadLocalUtil.get(Constant.USER_INFO);
                        // 如果ks用户为空,必然是门户的超级管理员且打开了无感登录
                        record.set("create_lname", Objects.isNull(userInfo) ? CommonConstants.ADMIN : userInfo.getUser_name());
                        // 获取真实ip地址
                        record.set("ip_addr", IpUtils.getIpAddr(request));
                        DbEx.save("ks_sys_oper_log", record);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
                log.error("操作日志记录异常",e);
            }
        }
    }


}
