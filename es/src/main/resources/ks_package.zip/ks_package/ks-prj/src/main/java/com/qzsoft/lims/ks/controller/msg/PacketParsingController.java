package com.qzsoft.lims.ks.controller.msg;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.msg.PacketParsingService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * 包解析
 * @author yuanj
 */
@Api(value = "包更新和下载", tags = "包更新和下载")
@RestController
@RequestMapping("/parsing")
@Slf4j
public class PacketParsingController {

    @Autowired
    private PacketParsingService packetParsingService;


    @ApiOperation(value = "更新指定文件或者文件夹")
    @GetMapping("/updateFile")
    @ResponseAddHead
    @ApiImplicitParams({
            @ApiImplicitParam(name = "zipPath", value = "最新的zip文件路径(例如:c:/Users/qrqz/Desktop/product_logo/offlineClient.zip)", dataType = "string", paramType = "query", required = true),
            @ApiImplicitParam(name = "findFile", value = "需要更新的文件名称(例如:LcglOfflineService.jar)", dataType = "string", paramType = "query", required = true)
    })
    public RequestResult<Object> updateFile(@RequestParam(value = "zipPath") String zipPath, @RequestParam(value = "findFile") String findFile) {
            RequestResult<Object> result = new RequestResult<>();
            String bools = packetParsingService.updateFile(zipPath,findFile);
            result.setObj(bools);
            return result;
    }


    @ApiOperation(value = "下载文件到指定的文件夹")
    @GetMapping("/downLoadFile")
    @ResponseAddHead
    @ApiImplicitParams({
            @ApiImplicitParam(name = "zipPath", value = "zip文件路径(例如:c:/Users/qrqz/Desktop/product_logo/offlineClient.zip)", dataType = "string", paramType = "query", required = true),
            @ApiImplicitParam(name = "findFile", value = "需要放的目标路径(例如:c:/Users/qrqz/Desktop/product_logos)", dataType = "string", paramType = "query", required = true)
    })
    public RequestResult<Object> downLoadFile(@RequestParam(value = "zipPath") String zipPath,@RequestParam(value = "findFile") String findFile) {
        RequestResult<Object> result = new RequestResult<>();
        String bools = packetParsingService.downLoadFile(zipPath,findFile);
        result.setObj(bools);
        return result;
    }
}
