package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.TokenService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Api(tags="令牌处理器",value="令牌处理器")
@RestController
@RequestMapping("/token")
public class TokenController {

    @Autowired
    private TokenService tokenService;

    @ApiOperation("分发令牌")
    @GetMapping("/handOutToken")
    @ResponseAddHead
    @ApiImplicitParams({
            @ApiImplicitParam(name="tokenType",value="令牌类型：锁令牌传参 _L_",required=false,dataType="string",paramType="query")
    })
    public RequestResult<String> handOutToken(@RequestParam(value="tokenType",defaultValue = "_L_") String tokenType ) {
        String token = tokenService.createToken( tokenType );
        RequestResult<String> result=new RequestResult( token );
        return result;

    }

}
