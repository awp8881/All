//package com.qzsoft.lims.ks.aspect;
//
//import com.qzsoft.lims.ks.dto.OperTraceDto;
//
//import java.util.List;
//
///**
// * @author pjh
// * @Title: TraceContextHolder
// * @Description: TODO
// * @date 2018/8/15 11:04
// */
//public class TraceContextHolder {
//
//
//    private static final ThreadLocal<List<OperTraceDto>> traceHolder = new ThreadLocal<List<OperTraceDto>>();
//
//    public static List<OperTraceDto> getOperTraceDtoList(){
//        return traceHolder.get();
//    }
//
//    public static void setOperTraceDtoList( List<OperTraceDto>  operTraceDtoList ){
//        traceHolder.set( operTraceDtoList );
//    }
//
//}
