package com.qzsoft.lims.hlyy.service;

import com.qzsoft.lims.hlyy.entity.vo.HLYYGroupVo;

import java.util.Map;

public interface SamplingService {

    Map<String,Object> addGroups(HLYYGroupVo groupVo);

    Map<String, Object> addCycle(int cycle_no, String proj_id, String delSt);

    Map<String,Object> delGroups(String[] groups,int maxCycleNum,String proj_id);

    boolean updateGroupInfo(String groupId, String groupInfo);

    boolean updateCycleInfo(String cycleId, String cycleVal);

    Map<String, Object> addOrDelTypeNode(String groupId, String nd_type, String delSt);

    Map<String,Object> updateType(String groupId, String original_type, String current_type);

    Map<String, Object> delNode(String[] nodeIds,String groupId);

    boolean updateNodeVal(String nodeId, String nodeInfo);

    Map<String, Object> getProjSampInfo(String proj_id);

    Map<String, Object> getNodeInfoByClick(String groupId);

    boolean createSamples(String projId);

    boolean revoke(String projId);


    Map<String, Object> copyAndPaste(String copiedGroupId, String targetGroupId);
}
