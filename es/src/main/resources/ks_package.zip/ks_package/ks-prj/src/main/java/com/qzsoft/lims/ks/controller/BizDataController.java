package com.qzsoft.lims.ks.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.CommonService;
import com.qzsoft.lims.ks.service.configdata.BizDataService;
import com.qzsoft.lims.ks.service.dynamic.DynamicConfigService;
import com.qzsoft.lims.ks.service.dynamic.DynamicParserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 动态sql-控制器
 */
@Api(value = "业务数据接口", tags = "业务数据接口")
@RestController
@RequestMapping("/biz")
@Slf4j
public class BizDataController {

    @Autowired
    BizDataService bizDataServerice;

    @ApiOperation(value = "获取规则引擎方法参数")
    @GetMapping("/getGzyqMethods")
        @ApiImplicitParams({
            @ApiImplicitParam(name="JID",value="JID",required=false,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult getGzyqMethods( ) {
        RequestResult result = new RequestResult<>();
        List<Map<String, Object>> gzyqMethods = bizDataServerice.getGzyqMethods( );
        result.setList( gzyqMethods );
        return result;
    }

    @ApiOperation(value = "转发服务方法")
    @PostMapping("/goGzyq")
        @ApiImplicitParams({
            @ApiImplicitParam(name="JID",value="JID",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="btnCode",value="btnCode",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="jsonDataStr",value="jsonDataStr",required=false,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult goGzyq( @RequestParam("btnCode") String btnCode, @RequestParam("jsonDataStr") String  jsonDataStr ) {
        RequestResult result = new RequestResult<>();
        JSONObject jsonObject = bizDataServerice.forwardServer("gzyq-prj", btnCode, jsonDataStr);
        try{
            Boolean status = jsonObject.getBoolean("status");
            if( status!=null && !status ){
                JSONArray error = jsonObject.getJSONArray("error");
                result.setStatus(false);
                result.setError(Joiner.on(",").join( error ));
            }
        }catch (Exception e){
            result.setThrowable( e );
            result.setStatus(false);
            result.setError( e.getMessage() );
        }
        return result;
    }

    @ApiOperation(value = "获取选中字段，用逗号拼接多个key")
    @PostMapping("/filterChecked")
        @ApiImplicitParams({
            @ApiImplicitParam(name="JID",value="JID",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="jsonDataStr",value="jsonDataStr",dataType="String",paramType="query"),
            @ApiImplicitParam(name="checkedFlag",value="checkedFlag",dataType="String",paramType="query")
    })
    public RequestResult filterChecked( @RequestParam("jsonDataStr") String  jsonDataStr,
                                        @RequestParam(value = "fieldFlag",required = false) String  fieldFlag ,
                                        @RequestParam(value = "checkedFlag",required = false) String  checkedFlag ) {
        RequestResult result = new RequestResult<>();
        JSONObject jsonObject = JSON.parseObject(jsonDataStr);
        if( StringUtils.isBlank(checkedFlag) ){
            checkedFlag = "1";
        }
        if( StringUtils.isBlank(fieldFlag) ){
            fieldFlag = "@save@";
        }
        Set<String> keys = jsonObject.keySet();
        Set<String> checkdeSet = Sets.newHashSet();
        for (String key : keys) {
            if( key.endsWith( fieldFlag ) ){
                String checked = StringUtil.toString(jsonObject.get(key));
                if( checkedFlag.equals( checked ) ){
                    String replace = key.replace("@save@", "");
                    if( StringUtils.isNotBlank( replace ) ){
                        checkdeSet.add(replace);
                    }
                }
            }
        }
        Map<String,Object> checkeMap = Maps.newHashMap();
        result.setObj( checkeMap );
        if( !checkdeSet.isEmpty() ){
            checkeMap.put( "checkes", Joiner.on(",").join(checkdeSet) );
        }else{
            checkeMap.put( "checkes", "" );
        }
        return result;
    }

}
