package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.config.GlobalParamConfig;
import com.qzsoft.lims.ks.service.GlobalParamService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author pjh
 * @Title: GlobalParamController
 * @Description: TODO
 * @date 2018/12/27 15:20
 */

@Api(value = "全局参数配置", tags = "全局参数配置")
@RestController
@RequestMapping("/globalParam")
@Slf4j
@TagResource("全局参数配置")
public class GlobalParamController {

    @Autowired
    GlobalParamService globalParamService;

    @ApiOperation(value="获取系统参数数据")
    @GetMapping("/sysConfigList")
    @ResponseAddHead
        public RequestResult getSysConfigList() {
        RequestResult result = new RequestResult();
        List<GlobalParamConfig.SysConfig> sysConfigList = globalParamService.getSysConfigList();
        result.setList( sysConfigList );
        return result;
    }

    @ApiOperation(value="获取系统参数数据通编码code")
    @GetMapping("/sysConfigListByCode")
        @ApiImplicitParams({
            @ApiImplicitParam(name="selectCode",value="配置编码code",required=true,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult sysConfigByCode( @Param(value = "selectCode") String selectCode ) {
        RequestResult result = new RequestResult();
        GlobalParamConfig.SysConfig sysConfig = globalParamService.getSysConfigByCode( selectCode );
        result.setObj( sysConfig );
        return result;
    }



    @ApiOperation(value="更新系统参数数据")
    @PostMapping("/saveSysConfigList")
    @ResponseAddHead
    @TagResource("更新系统参数数据")
        @ApiImplicitParams({
            @ApiImplicitParam(name="sysConfigJsonStr",value="全局参数配置",required=true,dataType="String",paramType="query")
    })
    public RequestResult saveSysConfigList( @Param(value = "sysConfigJsonStr") String sysConfigJsonStr ) {
        RequestResult result = new RequestResult();
        boolean isSuccess = globalParamService.saveSysConfigList( sysConfigJsonStr );
        result.setObj( isSuccess );
        return result;
    }

    @ApiOperation(value="重置系统参数数据")
    @PostMapping("/resetSysConfigList")
        @ResponseAddHead
    @TagResource("重置系统参数数据")
    public RequestResult resetSysConfigList(  ) {
        RequestResult result = new RequestResult();
        globalParamService.initYmlGlobalParamConfigToRedis( true );
        result.setObj( true );
        return result;
    }
}
