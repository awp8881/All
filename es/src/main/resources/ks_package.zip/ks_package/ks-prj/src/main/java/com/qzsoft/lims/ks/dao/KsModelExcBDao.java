package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsModelExcBDao extends BaseDao{
	
	/**
	   *   删除后插入
	 * @param allExcList
	 * @param new_m_code
	 * @param old_m_code
	 * @param menu_id
	 * @return
	 */
	Boolean  batchUpdate(List<Map<String, Object>> allExcList,  String old_m_code);
	
	/**
	 *   导入去重列表
	 * @param buttonCode
	 * @return
	 */
	 Map<String,Object> getExcListByButtonCode(String buttonCode, Boolean jsonYn);

}
