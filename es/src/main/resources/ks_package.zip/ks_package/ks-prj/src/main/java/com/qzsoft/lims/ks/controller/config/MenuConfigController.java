package com.qzsoft.lims.ks.controller.config;

import com.google.common.collect.Maps;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.service.menu.MenuConfigService;
import com.qzsoft.lims.ks.vo.CommonTreeVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 单个菜单整体配置数据
 * @author zf
 */
@Api(value = "单个菜单整体配置数据", tags = "单个菜单整体配置数据")
@RestController
@RequestMapping("/menu/config")
@Slf4j
public class MenuConfigController {

    @Autowired
    private MenuConfigService menuConfigService;

    @ApiOperation(value = "按类型获取菜单的列表、详情")
    @GetMapping("/getAllCodeAndName")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getModuleByMtype(@RequestParam(value = "menuId") String menuId ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        List<Map<String, Object>> menuListInfo = menuConfigService.getMenuListInfo(menuId);
        List<Map<String, Object>> collect = menuListInfo.stream().map(objMap -> {
            Object value = objMap.get("code");
            Object label = objMap.get("m_name");
            Map<String, Object> labelMap = Maps.newHashMap();
            labelMap.put("value", value);
            labelMap.put("label", label);
            return labelMap;
        }).collect(Collectors.toList());
        result.setList(collect);
        return result;
    }


    @ApiOperation(value = "按类型获取菜单的列表、详情")
    @GetMapping("/getModuleByMtype")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getModuleByMtype(@RequestParam(value = "menuId") String menuId,
                                                               @RequestParam(value = "mType") String mType) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(menuConfigService.getModuleByMtype( menuId, mType));
        return result;
    }


    @ApiOperation(value = "后台配置通用节点树")
    @GetMapping("/getNodeTree")
    @ResponseAddHead
        public RequestResult<CommonTreeVO> getNodeTree(@RequestParam(value = "node_type") String nodeType,
                                                   @RequestParam(value = "p_value", required = false) String pValue,
                                                   @RequestParam(value = "paras", required = false) String parasStr) {
        RequestResult<CommonTreeVO> result = new RequestResult<>();
        result.setList( menuConfigService.getNodeTree(nodeType, pValue, parasStr));
        return result;
    }

    @ApiOperation(value = "单个详情数据源")
    @GetMapping("/getInfoSouce")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getInfoSouce(@RequestParam(value = "infoCode") String infoCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(menuConfigService.getInfoSouce( infoCode));
        return result;
    }

    @ApiOperation(value = "获取菜单所有的列表、详情")
    @GetMapping("/getMenuListInfoByType")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getMenuListInfoByType(@RequestParam(value = "menuId") String menuId,
                                                               @RequestParam(value = "type") String type) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(menuConfigService.getMenuListInfoByType( menuId, type));
        return result;
    }

    @ApiOperation(value = "外部组件参数")
    @GetMapping("/getExtCompPara")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getExtCompPara(@RequestParam(value = "menuId") String menuId) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(menuConfigService.getExtCompPara( menuId));
        return result;
    }

    @ApiOperation(value = "是否生效文件")
    @GetMapping("/isEffect")
    @ResponseAddHead
        public RequestResult<Boolean> isEffect(@RequestParam(value = "menuId") String menuId) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(menuConfigService.isEffect( menuId));
        return result;
    }

}
