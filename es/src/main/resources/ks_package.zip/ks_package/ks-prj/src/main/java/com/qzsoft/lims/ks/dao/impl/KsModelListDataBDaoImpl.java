package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.jdialects.springsrc.utils.ObjectUtils;
import com.qzsoft.lims.ks.dao.KsModelListDataBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 列表树格式
 * @author zf
 */
@Repository
public class KsModelListDataBDaoImpl extends BaseDaoImpl implements KsModelListDataBDao{

	private static final String TABLE_NAME = "ks_model_list_data_b";
	
	// 删除后批量插入
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> treeConfigList, String new_m_code, String old_m_code,String menu_id) {
		String old_data_code = old_m_code+"$data_code";
		String new_data_code = new_m_code+"$data_code";
		boolean isSucc = true;
		deleteByCustom(TABLE_NAME, "data_code", old_data_code);

		if (null == treeConfigList || treeConfigList.isEmpty()){
			return isSucc;
		}
		
		List<Record> recordList = DataBaseUtil.map2Record(treeConfigList);
		for(Record record : recordList){
			record.set("data_code", new_data_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1").remove("id")
			.set("menu_id", menu_id);
		}
		isSucc= saveList(TABLE_NAME, recordList);

		return isSucc;
	}


	//树结构参数
	@Override
	public List<Record> getByDataCode(String dataCode) {
		if (StringUtils.isBlank(dataCode)){
			return null;
		}
		String sql = "select * from ks_model_list_data_b where data_code=? order by level_num+0,cr_dm desc";
		List<Record> records = selectListBySql(sql , dataCode);
		return records;
	}

	@Override
	public Record getTreeNodeConf(String mCode, Integer level) {
		if (StringUtils.isBlank(mCode)){
			return null;
		}
		String sql = null;
		if (!ObjectUtils.isEmpty( level )){
			sql = "select * from ks_model_list_data_b k where exists(select id from ks_model_list_c where m_code=? and data_code = k.data_code) and level_num =?";
			return DbEx.findFirst(sql, mCode, level);
		}
		sql = "select * from ks_model_list_data_b k where exists(select id from ks_model_list_c where m_code=? and data_code = k.data_code) ";
		return DbEx.findFirst(sql, mCode);
	}

	@Override
	public int showLevel(String mCode) {
		String sql = "select count(*) as num from ks_model_list_data_b k where exists(select id from ks_model_list_c where m_code=? and data_code = k.data_code)";
		Record record = DbEx.findFirst(sql, mCode);
		if (null == record){
			return 0;
		}
		return record.getInt("num");
	}
}
