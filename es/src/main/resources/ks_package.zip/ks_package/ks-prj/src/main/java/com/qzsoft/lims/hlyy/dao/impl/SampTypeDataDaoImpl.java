package com.qzsoft.lims.hlyy.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.hlyy.dao.SampTypeDataDao;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


@Repository
public class SampTypeDataDaoImpl extends BaseDaoImpl implements SampTypeDataDao {

    private static final String TABLE_NAME = "sz_dic2_b";

    private static final String P_TYPE_CODE = "YPZL";
    @Override
    public List<Record> getAllType() {
        return DbEx.find("select code as 'key',val,remark from " + TABLE_NAME+" where parent_code = ?",P_TYPE_CODE);
    }
}
