package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.config.init.AppInit;
import com.qzsoft.lims.ks.service.synConfig.SynConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * 同步配置-控制器
 * @author zf
 */
@Api(value = "同步配置", tags = "同步配置")
@RestController
@RequestMapping("/synConfig")
@Slf4j
public class SynConfigController {

	@Autowired
	private SynConfigService synConfigService;

	@Autowired
	private AppInit appInit;


	@ApiOperation(value = "同步地址列表")
	@GetMapping("/getSynList")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getSynList( ) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList( synConfigService.getSynList());
		return result;
	}

	@ApiOperation(value = "同步地址详情")
	@GetMapping("/getSynDetail")
		@ApiImplicitParam(name="id",value="id",required=true,dataType="Long",paramType="query")
	@ResponseAddHead
	public RequestResult<Map<String, Object>> getSynDetail( @RequestParam(value="id") Long synId) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setObj( synConfigService.getSynDetail( synId ));
		return result;
	}

	@ApiOperation(value = "新增同步名称")
	@PostMapping("/saveSynNa")
		@ApiImplicitParams({
			@ApiImplicitParam(name="id",value="主键",required=false,dataType="Long",paramType="query"),
			@ApiImplicitParam(name="syn_na",value="同步名称",required=true,dataType="String",paramType="query")
	})
	@ResponseAddHead
	public RequestResult<Boolean> saveSynNa( @RequestParam(value="id", required = false) Long id , @RequestParam(value="syn_na") String synNa ) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( synConfigService.saveSynNa( id, synNa ));
		return result;
	}

	@ApiOperation(value = "新增同步地址")
	@PostMapping("/saveSyn")
		@ResponseAddHead
	public RequestResult<Boolean> saveSyn( @RequestBody Map<String, Object> synMap , HttpServletRequest request) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( synConfigService.saveSyn( synMap , request));
		return result;
	}

	@ApiOperation(value = "删除同步地址")
	@PostMapping("/deleteSyn")
		@ApiImplicitParam(name="id",value="id",required=true,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Boolean> deleteSyn( @RequestParam(value="id") Long synId ) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( synConfigService.deleteSyn( synId ));
		return result;
	}


	@ApiOperation(value = "接口连接测试")
	@GetMapping("/interfaceLink")
		@ApiImplicitParams({
			@ApiImplicitParam(name="sys_ip",value="ip",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="sys_port",value="端口",required=true,dataType="String",paramType="query")
	})
	@ResponseAddHead
	public RequestResult<Map<String, Object>> interfaceLink( @RequestParam(value="sys_ip") String sysIp,
															 @RequestParam(value="sys_port") String sysPort ) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setObj( synConfigService.interfaceLink(sysIp, sysPort));
		return result;
	}

 	@ApiOperation(value = "数据库连接测试")
    @GetMapping("/testDbLink")
	    @ResponseAddHead
	@ApiImplicitParams({
			@ApiImplicitParam(name="url",value="url",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="userName",value="用户名",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="passWord",value="密码",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="driver",value="驱动",required=true,dataType="String",paramType="query")
	})
    public RequestResult<Boolean> testDbLink(@RequestParam(value="url") String url,@RequestParam(value="userName") String userName,
											 @RequestParam(value="passWord") String passWord,@RequestParam(value="driver") String driver) {
        RequestResult<Boolean> result = new RequestResult<>();
		result.setObj(synConfigService.testDbLink(url, userName, passWord, driver));
		return result;
    }

	@ApiOperation(value = "系统级同步")
	@GetMapping("/systemSyn")
		@ResponseAddHead
	public void systemSyn(@RequestParam(value = "id") String synId,
						  @RequestParam(value = "syn_link" ) String synLink,
						  HttpServletRequest request, HttpServletResponse response ) {

		boolean isRun = true;
		try {
			synConfigService.systemSyn( synId, synLink, request, response);

		}catch (Exception e){
			log.error(e.getMessage());
			isRun = false;
		}
		if ( isRun ){
			appInit.run( null );
		}

	}

	@ApiOperation(value = "系统还原")
	@PostMapping("/systemRestore")
		@ApiImplicitParam(name="note_scr_url",value="备份地址",required=true,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Boolean> systemRestore( @RequestParam(value="note_scr_url") String noteScrUrl ) {
		RequestResult<Boolean> result = new RequestResult<>();

		boolean isSucc = synConfigService.systemRestore( noteScrUrl );
		result.setObj( isSucc );
		if ( isSucc ){
			appInit.run( null );
		}

		return result;
	}

	@ApiOperation(value = "远程调用-本地系统数据源配置信息")
	@GetMapping("/localSysConfigDatas")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> localSysConfigDatas( ) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setObj( synConfigService.localSysConfigDatas());
		return result;
	}

	@ApiOperation(value = "远程调用-ks表配置数据")
	@GetMapping("/远程调用-ks表配置数据")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> localKsTableDatas( ) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setObj( synConfigService.localKsTableDatas());
		return result;
	}

	@ApiOperation(value = "系统同步日志分页查询")
	@GetMapping("/getSynNotePageList")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getPageList(
			@RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
			@RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {

		RequestResult<Map<String, Object>> result = null;
		result = synConfigService.getSynNotePageList( pageNum, pageSize );
		return result;
	}


	@ApiOperation(value = "下载同步脚本")
	@PostMapping("/uploadSynDatas")
		@ApiImplicitParam(name="id",value="同步主键",required=true, dataType="String",paramType="query")
	@ResponseAddHead
	public void uploadSynDatas( @RequestParam(value="id") String synId,  HttpServletResponse response ) {

		Object jsonStr = synConfigService.uploadSynDatas( synId );
		response.setContentType("text/html;charset=utf-8");
		try {
			response.getWriter().write(jsonStr.toString());
		} catch (IOException e) {
			log.error("下载失败");
		}
	}

	@ApiOperation(value = "还原同步数据")
	@PostMapping("/revertSynDatas")
		@ApiImplicitParam(name="id",value="同步主键",required=true, dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Boolean> revertSynDatas( @RequestParam(value="id") String synId ) {
		RequestResult<Boolean> result = new RequestResult<>();

		boolean isSucc = synConfigService.revertSynDatas( synId );
		result.setObj( isSucc );
		if ( isSucc ){
			appInit.run( null );
		}
		return result;
	}

	@ApiOperation(value = "导入系统数据")
	@PostMapping("/importSynDatas")
		@ResponseAddHead
	public RequestResult<Boolean> importSynDatas(  @RequestParam("file") MultipartFile file ) {
		RequestResult<Boolean> result = new RequestResult<>();

		boolean isSucc = synConfigService.importSynDatas( file );
		result.setObj( isSucc );
		if ( isSucc ){
			appInit.run( null );
		}
		return result;
	}
}
