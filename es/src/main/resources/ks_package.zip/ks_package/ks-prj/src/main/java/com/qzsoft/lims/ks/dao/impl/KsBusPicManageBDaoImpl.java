package com.qzsoft.lims.ks.dao.impl;

import java.util.List;

import com.google.common.collect.Lists;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.util.TableHelper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsBusPicManageBDao;

/**
 * 照片管理-dao实现
 * @author hqp
 *
 */
@Repository
public class KsBusPicManageBDaoImpl extends BaseDaoImpl implements KsBusPicManageBDao{
	private static final String TABLE_NAME = "ks_bus_pic_manage_b";
	
	/**
	 * 新增
	 * @param record 照片管理实体
	 * @return
	 */
	@Override
	public Boolean save(Record record) {
		return super.save(TABLE_NAME,record);
	}


	/**
	 * 修改
	 * @param entity 照片管理实体
	 * @return
	 */
	@Override
	public Boolean update(Record record) {
//		return super.updateByVersionAndId(TABLE_NAME,record);
		return super.update(TABLE_NAME,record);
	}

	/**
	 * 删除
	 * @param id 主键
	 * @return
	 */
	@Override
	public Boolean delete(Long id) {
		return super.deleteById(TABLE_NAME,id);
	}
	
	/**
	 * 根据业务prn删除多条记录
	 * @param prn 业务prn
	 * @return
	 */
	@Override
	public Boolean deleteByPrn(String prn) {
		return super.deleteByCustom(TABLE_NAME, "prn", prn);
	}
	

	/**
	 * 根据业务类型查询
	 * @return
	 */
	@Override
	public List<Record> getListByBusType(String busType) {
		return DbEx.find("select * from " + TABLE_NAME+" where bus_type = ? ",busType);
	}
	
	/**
	 * 根据业务prn查询
	 * @return
	 */
	@Override
	public List<Record> getListByPrn(String prn, String showType) {
		String sql = "select * from " + TABLE_NAME+" where prn = ? ";
		if (StringUtils.isBlank(showType)){
			sql += " order by upload_tm desc";
			return DbEx.find(sql, prn);
		}
		List<String> showTypes = CommonUtil.strToList(showType, ",");
		String inSql = TableHelper.getInSql("bus_type", showTypes);
		sql += inSql+" order by upload_tm desc";

		List<String> paras = Lists.newArrayList();
		paras.add(prn);
		paras.addAll(showTypes);
		return DbEx.find(sql, paras.toArray());
	}
	
	/**
	 * 根据业务prn查询非敏感文件（bus_type不是“客户文件”）
	 * @return
	 */
	@Override
	public List<Record> getListByPrnNotSens(String prn, String showType) {
		String sql = "select * from " + TABLE_NAME+" where prn = ? and bus_type <> 'KHWJ' ";
		if (StringUtils.isBlank(showType)){
			sql += " order by upload_tm desc";
			return DbEx.find(sql, prn);
		}
		List<String> showTypes = CommonUtil.strToList(showType, ",");
		String inSql = TableHelper.getInSql("bus_type", showTypes);
		sql += inSql+" order by upload_tm desc";

		List<String> paras = Lists.newArrayList();
		paras.add(prn);
		paras.addAll(showTypes);
		return DbEx.find(sql, paras.toArray());
	}
	
	/**
	 * 根据业务prn及其他参数模糊查询
	 * @return
	 */
	@Override
	public List<Record> getListByPrnSearch(String prn,String search) {
		if(StringUtils.isEmpty(search)){
			return DbEx.find("select * from " + TABLE_NAME +" where prn = ? order by upload_tm desc",prn);
		}else{
			return DbEx.find("select * from " + TABLE_NAME+" where prn = ? and (locate(?,file_name)>0 or locate(?,busin_co)>0 or locate(?,bus_type)>0) order by upload_tm desc",prn,search,search,search);
		}
		
	}
	
	/**
	 * 根据业务prn及其他参数模糊查询非敏感文件（bus_type不是“客户文件”）
	 * @return
	 */
	@Override
	public List<Record> getListByPrnSearchNotSens(String prn,String search) {
		if(StringUtils.isEmpty(search)){
			return DbEx.find("select * from " + TABLE_NAME +" where prn = ? and bus_type <> 'KHWJ' order by upload_tm desc",prn);
		}else{
			return DbEx.find("select * from " + TABLE_NAME +" where prn = ? and bus_type <> 'KHWJ' and (locate(?,file_name)>0 or locate(?,busin_co)>0 or locate(?,bus_type)>0) order by upload_tm desc",prn,search,search,search);
		}
		
	}
	
	/**
	 * 根据文件名称、业务编号、业务类型模糊查询
	 * @return
	 */
	@Override
	public List<Record> getListBySearch(String search) {
		if(StringUtils.isEmpty(search)){
			return DbEx.find("select * from " + TABLE_NAME );
		}else{
			return DbEx.find("select * from " + TABLE_NAME+" where locate(?,file_name)>0 or locate(?,busin_co)>0 or locate(?,bus_type)>0",search,search,search);
		}
		
	}

	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	@Override
	public Record getOne(Long id) {
		return super.selectById(TABLE_NAME,id);
	}
	
	/**
	 * 根据文件全局唯一标识查询详情
	 * @param filePrn 文件全局唯一标识
	 * @return
	 */
	@Override
	public Record getOneByFilePrn(String filePrn) {
		List<Record> recs = DbEx.find("select * from " + TABLE_NAME+" where file_prn = ? ",filePrn);
		if(recs != null && recs.size() > 0){
			return recs.get(0);
		}else{
			return null;
		}	
	}
}
