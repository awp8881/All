package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 列表树格式
 * @author zf
 *
 */
public interface KsModelListDataBDao extends BaseDao{
	
	/**
	 * 删除后插入
	 * @param treeConfigList
	 * @param new_m_code
	 * @param old_m_code
	 * @return
	 */
	Boolean  batchUpdate(List<Map<String, Object>> treeConfigList, String new_m_code, String old_m_code, String menu_id);

	List<Record> getByDataCode( String dataCode);

	Record getTreeNodeConf( String mCode, Integer level);

	int showLevel(String mCode);
}
