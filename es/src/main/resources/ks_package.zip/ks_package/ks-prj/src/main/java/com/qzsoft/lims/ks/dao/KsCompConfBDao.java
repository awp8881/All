package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.lims.ks.vo.CompConfVO;

/**
 * 组件管理-dao接口
 * @author hqp
 *
 */
public interface KsCompConfBDao {
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	Boolean save(Record record);
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	
	/**
	 * 删除
	 * @param infoCode INFO编码
	 * @return
	 */
	Boolean deleteByInfoCode(String infoCode);
	
	/**
	 * 根据INFO编码查询
	 * @return
	 */
	List<Record> getListByInfoCode(String infoCode);
	
	/**
	 * 根据组件编码查询
	 * @return
	 */
	Record getOneByCompCode(String compCode);
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	Record getOne(Long id);
	
	/**
	 * 查询下一个组件编码
	 * @param infoCode INFO编码
	 * @return
	 */
	String getNextCompCode(String infoCode);


	Record getCompData( String compCode );

	Boolean saveCompData( Map<String, Object> compDatas, String mCode, String infoCode, String menuId, String compCode);
	
}
