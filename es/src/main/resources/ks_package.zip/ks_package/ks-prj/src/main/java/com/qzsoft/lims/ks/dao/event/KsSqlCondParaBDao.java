package com.qzsoft.lims.ks.dao.event;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlCondParaBDao extends BaseDao{

	/**
	 *  条件组
	 * @param pCode
	 * @return
	 */
	List<Record> getByPCode(String pCode);
	
	/**
	 * 批量保存
	 * @param allCondParaList
	 * @return
	 */
	Boolean batchUpdate(List<Map<String, Object>> allCondParaList);

	List<Record> getGroupCondParas(String pCode);

	Boolean saveGroupCondParas( List<Map<String, Object>> condParas);

	List<Record> getGroupCondsByCode( List<String> codes );

}
