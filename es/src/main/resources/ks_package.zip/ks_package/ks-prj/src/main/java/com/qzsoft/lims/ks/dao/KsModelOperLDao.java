package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

import java.util.List;

/** 
 * 系统配置：系统自动化SQL语句
 * 创建时间:2018-08-15 10:00:52 
 */ 
public interface KsModelOperLDao extends BaseDao {


    void batchSave(String tbName, List<Record> recordList);

    /**
     * 获取最大的变更顺序
     * @param info_code
     * @param t_name
     * @param t_name_key
     * @return
     */
    Record findMaxOperOrderByInfoCodeAndTNameAndTNameKey(String info_code, String t_name, String t_name_key);

    /**
     * 获取最后一批数据
     * @param info_code
     * @param t_name
     * @return
     */
    Record findMaxOperCodeByInfoCodeAndTName(String info_code, String t_name );

    /**
     * 获取最后一条留痕
     * @param info_code
     * @param t_name
     * @param field_name
     * @return
     */
    Record findTop1ByInfoCodeAndTNameAndFieldName(String m_code,String info_code, String t_name, String field_name,String t_name_key);

    /**
     * 获取最大的变更顺序
     * @param info_code
     * @param t_name
     * @param fieldName
     * @param t_name_key
     * @return
     */
    Record findMaxOperOrderByInfoCodeAndTNameAndFieldNameAndTNameKey(String info_code, String t_name, String fieldName, String t_name_key);
}
