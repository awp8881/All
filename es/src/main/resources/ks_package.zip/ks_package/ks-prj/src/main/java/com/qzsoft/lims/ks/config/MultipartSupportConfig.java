package com.qzsoft.lims.ks.config;

import com.alibaba.fastjson.JSONObject;
import com.qzsoft.common.exception.BusinessException;
import feign.Response;
import feign.Util;
import feign.codec.Decoder;
import feign.codec.Encoder;
import feign.codec.ErrorDecoder;
import feign.form.spring.SpringFormEncoder;
import feign.form.spring.converter.SpringManyMultipartFilesReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static feign.FeignException.errorStatus;

/**
 * @Author zf
 * @Description
 * @Date 2020/3/20
 */
@Configuration
@Slf4j
public class MultipartSupportConfig {
    @Autowired
    private ObjectFactory<HttpMessageConverters> messageConverters;

    @Bean
    public Encoder feignFormEncoder() {
        return new SpringFormEncoder(new SpringEncoder(messageConverters));
    }

    @Bean
    public Decoder feignDecoder() {
        List<HttpMessageConverter<?>> springConverters = messageConverters.getObject().getConverters();

        List<HttpMessageConverter<?>> decoderConverters = new ArrayList<HttpMessageConverter<?>>(
                springConverters.size() + 1);

        decoderConverters.addAll(springConverters);
        decoderConverters.add(new SpringManyMultipartFilesReader(4096));

        HttpMessageConverters httpMessageConverters = new HttpMessageConverters(decoderConverters);

        return new SpringDecoder(new ObjectFactory<HttpMessageConverters>() {
            @Override
            public HttpMessageConverters getObject() {
                return httpMessageConverters;
            }
        });
    }

    @Bean
    public ErrorDecoder feignErrorDecoder() {

        return new ErrorDecoder(){
            @Override
            public Exception decode(String methodKey, Response response) {
                String body = null;
                try {
                    body = Util.toString(response.body().asReader());
                    log.error(body);
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
                if (response.status() >= 400 && response.status() <= 500) {
                    BusinessException.throwBiz( JSONObject.parseObject( body ).getString("message") );
                }
                return errorStatus(methodKey, response);
            }
        };
    }
}
