package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;

/**
 * 组件参数定义管理-dao接口
 * @author hqp
 *
 */
public interface KsCompParaDefBDao {
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	Boolean save(Record record);
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	
	/**
	 * 删除
	 * @param compType 组件类型
	 * @return
	 */
	Boolean deleteByCompType(String compType);
	
	/**
	 * 删除
	 * @param defCode 组件编码
	 * @return
	 */
	Boolean deleteByDefCode(String defCode);
	
	
	/**
	 * 根据组件类型查询
	 * @param compType 组件类型
	 * @return
	 */
	List<Record> getListByCompType(String compType);
	
	/**
	 * 根据定义编码查询
	 * @param compType 定义编码
	 * @return
	 */
	List<Record> getListByDefCode(String defCode);
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	Record getOne(Long id);
	
	/**
	 * 删除
	 * @param id 主键
	 * @return
	 */
	Boolean deleteById(Long id);

	Map<String, List<Record>> getAllCompParas();
}
