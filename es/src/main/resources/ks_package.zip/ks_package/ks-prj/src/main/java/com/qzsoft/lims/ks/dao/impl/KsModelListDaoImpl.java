package com.qzsoft.lims.ks.dao.impl;

import com.alibaba.fastjson.JSON;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.CustomDbRecordUtil;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.conversion.ConversionHolder;
import com.qzsoft.lims.ks.dao.*;
import com.qzsoft.lims.ks.dao.info.KsSqlIconDao;
import com.qzsoft.lims.ks.eum.*;
import com.qzsoft.lims.ks.eum.groupCond.GroupCondFromEnum;
import com.qzsoft.lims.ks.service.groupCond.GroupCondService;
import com.qzsoft.lims.ks.util.CodesUtil;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.vo.SourceConfigVO;
import com.qzsoft.lims.ks.vo.SourceConfigVO.AttrVO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 模版列表
 *
 */
@Repository
public class KsModelListDaoImpl extends BaseDaoImpl implements KsModelListDao {

    private static final String TABLE_NAME_B = "ks_model_list_b";
    private static final String TABLE_NAME_C = "ks_model_list_c";

    //点击按钮权限后缀
    public static final String clickBtnSuffix = "$click_code";
    //敏感按钮后缀
    public static final String sensBtnSuffix = "$sens_code";

    @Autowired
    private KsMenuCDao ksMenuCDao;
    @Autowired
    private KsSqlRowEventBDao ksSqlRowEventBDao;
    @Autowired
    private KsSqlIconDao ksSqlIconDao;
    @Autowired
    private KsSqlSelectCSqlBDao ksSqlSelectCSqlBDao;
    @Autowired
    private KsModelListDataBDao ksModelListDataBDao;
    @Autowired
    private KsSqlButtonBDao ksSqlButtonBDao;
    @Autowired
    private KsModelListTreeLinkBDao ksModelListTreeLinkBDao;
    @Autowired
    private KsModelAttrBDao ksModelAttrBDao;
    @Autowired
    private KsSqlSelectRevBDao ksSqlSelectRevBDao;

    @Autowired
    @Lazy
    private GroupCondService groupCondService;

    @Autowired
    private KsModelCountBDao ksModelCountBDao;

    /**
     * 通过模板编码查询模板列表
     */
    @Override
    public Record getModelListByMcode(String m_code, String m_code_type) {
        String table = TABLE_NAME_B;
        if ( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)) {
            table = TABLE_NAME_C;
        }
        Record record = DbEx.findFirst("select * from " + table + "  where m_code = ?", m_code);
        return record;
    }

    /**
     * 保存
     */
    @JFinalTx
    @Override
    public Boolean save(SourceConfigVO sourceConfigVO) {
        boolean isSucc = true;
        String new_m_code = sourceConfigVO.getNew_m_code();
        String old_m_code = sourceConfigVO.getOld_m_code();
        String m_name = sourceConfigVO.getM_name();
        Integer isSaveAs = sourceConfigVO.getIsSaveAs();
        String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
        String menu_id = sourceConfigVO.getMenu_id();

        //删除联动小列表数据源条件
        deleteLinkList(old_m_code);

        AttrVO attrvo = sourceConfigVO.getAttrVO();

        String inner_code = attrvo.getInner_code();
        String data_type = attrvo.getData_type();
        String row_code = new_m_code + "$row_code";
        String icon_code = new_m_code + "$icon_code";
        String data_code = new_m_code + "$data_code";
        String new_rev_code = CodesUtil.createCommonCode(new_m_code+"$rev_code");
        String check_type = StringUtils.isBlank(attrvo.getCheck_type()) ? "0" : attrvo.getCheck_type();
        String groupField = handleGroupField(attrvo.getGroupList());
        Record record = CustomDbRecordUtil.getRecord(attrvo);
        String innerIsParaNul = attrvo.getInnerIsParaNul();
        //移除多余字段
        record.remove("select_script").remove("m_name").remove("inner_list_script").remove("attr_desc").remove("sql").remove("fieldEveCondMap")
                .remove("is_para_nul").remove("innerIsParaNul").remove("selectCode");
        //字段赋值
        record.set("m_code", new_m_code).set("list_name", m_name).set("list_type", ListTypeEnum.outer.name()).set("check_type", check_type).set("rev_code", new_rev_code).
                set("cr_dm", DateUtil.getNowDateTimeStr()).set("row_code", row_code).set("icon_code", icon_code).set("inner_code", inner_code).set("menu_id", menu_id).
                set("group_field",groupField).set("rev_check_first", attrvo.getRev_check_first()).set("count_code", null);
        if (StringUtils.isNotBlank(inner_code)) {
            record.set("info_inner_type", InfoInnerTypeEnum.list.name());
        }
        if (StringUtils.isBlank(data_type)) {
            record.set("data_type", DataTypeEnum.LIST.getCode());
        } else {
            record.set("data_code", data_code);
        }

        Object bus_code = record.get("bus_code");
        if (!ObjectUtils.isEmpty(bus_code) && !bus_code.equals("[]")) {
            Object obj = ConversionHolder.saveDataConversion(CommonConstants.LIST_INFO, bus_code);
            record.set("bus_code", obj);
        } else {
            record.set("bus_code", "");
        }

        record.set("add_row", null);
        List addRow = (List) attrvo.getAdd_row();
        if (!ObjectUtils.isEmpty(addRow) ){
            record.set("add_row", StringUtil.listTOString(addRow));
        }
        record.set("add_row_type", attrvo.getAdd_row_type());

        record.set("from_conf", null);
        List<Map<String, Object>> fromConfList = attrvo.getFromConfList();
        if (null != fromConfList && !fromConfList.isEmpty()){
            record.set("from_conf", JSON.toJSONString(fromConfList));
        }

        //保存为组件不处理
        if (!sourceConfigVO.getModuleYn()){
            List<Map<String, Object>> globalAuthDatas = attrvo.getGlobalAuthDatas();
            saveGlobalAuth(record, globalAuthDatas, new_m_code, isSaveAs, menu_id);

            handleOtherAttr(attrvo, new_m_code, menu_id, isSaveAs, old_m_code, icon_code,
                    new_rev_code, inner_code, record, innerIsParaNul);
        }


        //大列表保存敏感条件
        if (TABLE_NAME_B.equals(table)) {
            List<List<Map<String, Object>>> sensList = attrvo.getSensList();
            saveSensCond(menu_id, record.getStr("sens_script"), sensList, new_m_code, isSaveAs);
        }
        record.remove("sens_script").remove("script_list").remove("rev_script");


        Record modelListRecord = getOneByColumn(table, "m_code", old_m_code);
        if (null != modelListRecord) {//更新
            record.set("up_ver", modelListRecord.getStr("up_ver"));
            record.set("id", modelListRecord.getStr("id"));
            update(table, record);

        } else {//保存
            saveAndUpVer(table, record);
        }

        return isSucc;
    }

    private void handleOtherAttr(AttrVO attrvo, String new_m_code, String menu_id, Integer isSaveAs, String old_m_code, String icon_code,
                                 String new_rev_code, String inner_code, Record record, String innerIsParaNul){

        List<Map<String, Object>> treeLinkList = attrvo.getTreeLinkList();
        List<Map<String, Object>> treeConfigList = attrvo.getTreeConfigList();
        List<List<Map<String, Object>>> iconList = attrvo.getIconList();
        List<Map<String, Object>> innerWhereList = attrvo.getInnerWhereList();
        List<Map<String, Object>> selectList = attrvo.getSelectList();
        List<Map<String, Object>> colorList = attrvo.getColorList();
        List<Map<String, Object>> attrList = attrvo.getAttrList();
        List<List<Map<String, Object>>> selectRevList = attrvo.getSelectRevList();
        List<Map<String, Object>> fieldShowConfDatas = attrvo.getFieldShowConfDatas();

        List<Map<String, Object>> countConfDatas = attrvo.getCountConfDatas();
        handleListCount(countConfDatas, new_m_code, menu_id);

        groupCondService.saveGroupConds( selectList, attrvo.getSelectCode(), new_m_code, menu_id, attrvo.getIs_para_nul(),
                null, isSaveAs, null);

        if (null != fieldShowConfDatas && !fieldShowConfDatas.isEmpty()){
            fieldShowConfDatas.stream().forEach( map -> {
                map.put("event_type", ColorEventTypeEnum.SHOW_PROGRAM.getCode());
            });
            colorList.addAll( fieldShowConfDatas);
        }
        ksSqlRowEventBDao.batchUpdate(colorList, new_m_code, isSaveAs, old_m_code, menu_id);
        ksSqlIconDao.saveGroupConds(iconList, new_m_code, old_m_code, icon_code, menu_id);
        ksModelListDataBDao.batchUpdate(treeConfigList, new_m_code, old_m_code, menu_id);
        ksModelListTreeLinkBDao.batchUpdate(treeLinkList, new_m_code, old_m_code, menu_id);
        ksModelAttrBDao.batchUpdate(attrList, new_m_code, old_m_code, menu_id);
        ksSqlSelectRevBDao.saveGroupConds(selectRevList, new_rev_code, new_m_code, old_m_code, menu_id);

        if (StringUtils.isNotBlank(inner_code)) {//内嵌+二级联动
            String inner_list_script = attrvo.getInner_list_script();
            String newSelectCodeB = record.getStr("select_code_b");
            if (StringUtils.isBlank( newSelectCodeB )){
                newSelectCodeB = new_m_code + "$" + InnerListSelectEnum.link.getCode() + "$" + CodesUtil.createCommonCode("select_code_b");
            }
            ksSqlSelectCSqlBDao.save(newSelectCodeB, inner_list_script, null, menu_id, inner_code, new_m_code);
            groupCondService.saveGroupConds( innerWhereList, newSelectCodeB, new_m_code, menu_id, innerIsParaNul,
                    inner_code, null, null);
            record.set("select_code_b", newSelectCodeB);
        }
    }

    private void handleListCount(List<Map<String, Object>> countConfDatas, String newMCode, String menuId){
        ksModelCountBDao.saveCount( countConfDatas, newMCode, menuId);
    }

    /**
     * 拼接来自于前台的groupby字段，再db
     * @param groupList
     * @return
     */
    private String handleGroupField(List<Map<String, Object>> groupList) {
        StringBuffer sb = new StringBuffer();
        if(groupList != null && !groupList.isEmpty()){
            for (int i = 0;i < groupList.size();i++){
                sb.append(groupList.get(i).get("group_field"));
                if(i!=groupList.size()-1)
                    sb.append(",");
            }
        }
        return sb.toString();
    }


    //删除联动小列表数据源条件
    private void deleteLinkList(String old_m_code) {
        if (StringUtils.isBlank(old_m_code)){
            return;
        }
        String preSelectCodeB = old_m_code + "$" + InnerListSelectEnum.link.getCode();
        DbEx.delete("delete from ks_sql_select_c_sql_b where locate(?,select_code_b)>0  ", preSelectCodeB);
        DbEx.delete("delete from ks_sql_select_c_b where locate(?,select_code_b)>0   ", preSelectCodeB);
        DbEx.delete("delete from ks_sql_select_para_c_b where locate(?,select_code_b)>0  ", preSelectCodeB);
    }

    /**
     * 保存全局授权条件
     */
    private void saveGlobalAuth(Record record, List<Map<String, Object>> globalAuthDatas, String new_m_code, Integer isSaveAs, String menu_id) {

        String clickCode = new_m_code + clickBtnSuffix;
        record.set("click_code", clickCode);
        groupCondService.saveGroupConds( globalAuthDatas, clickCode, new_m_code, menu_id, null,
                null, isSaveAs, GroupCondFromEnum.globalAuth.getCode());
    }

    /**
     * 保存全局授权条件
     */
    private void saveSensCond(String menuId, String script, List<List<Map<String, Object>>> clickList, String new_m_code, Integer isSaveAs) {
        if (StringUtils.isBlank(menuId)) return;
        String button_code = new_m_code + sensBtnSuffix;
        Record one = ksMenuCDao.getOne(Long.parseLong(menuId));
        one.set("sens_code", button_code);
        one.set("sens_script", script);
        DbEx.update("ks_menu_c", one);
        saveListForAuthOrSens( clickList, new_m_code, button_code, isSaveAs, menuId);
    }

    /**
     * 保存综合属性中的全局授权以及敏感策略
     */
    private void saveListForAuthOrSens( List<List<Map<String, Object>>> clickParaList, String new_m_code, String button_code, Integer isSaveAs,
                                        String menuId) {
        if (null == clickParaList || clickParaList.isEmpty()){
            ksSqlButtonBDao.saveGroupConds(clickParaList, isSaveAs, button_code, null, menuId);
            return;
        }
        for (Iterator<List<Map<String, Object>>> iterator = clickParaList.iterator(); iterator.hasNext(); ) {
            List<Map<String, Object>> next =  iterator.next();

            for (Iterator<Map<String, Object>> mapIterator = next.iterator(); mapIterator.hasNext(); ) {
                Map<String, Object> map =  mapIterator.next();
                map.put("m_code", new_m_code);
                map.put("button_code", button_code);
            }

        }
        ksSqlButtonBDao.saveGroupConds(clickParaList, isSaveAs, button_code, null, menuId);

    }

    @Override
    public Record getAttrByMcode(String m_code, String m_code_type) {
        String tableName = TABLE_NAME_B;
        if(McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)) {
            tableName = TABLE_NAME_C;
        }
        String sql = "select data_type,data_code,group_field,rev_code,port_code,rev_check_first,from_conf,is_only_iter,head_json,is_iter_cond from "+tableName+" where m_code = ?";
        Record record = DbEx.findFirst(sql, m_code);
        return record;
    }


}
