package com.qzsoft.lims.hlyy.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value="yyky_cycle",description="周期表")
public class HLYYCycleEntity extends HLYYEntity {

    @ApiModelProperty(value="",dataType="Long",required=true)
    private Long id;

    @ApiModelProperty(value="周期",dataType="int",required=false)
    private Integer cyc_no;

    @ApiModelProperty(value="周期值",dataType="String",required=false)
    private String cyc_val;

    @ApiModelProperty(value="外键，关联项目",dataType="String",required=true)
    private Long proj_id;

    @ApiModelProperty(value="外键，关联分组",dataType="String",required=true)
    private Long grop_id;

}
