package com.qzsoft.lims.ks.controller;

import com.google.gson.Gson;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.dto.request.NodeTreePara;
import com.qzsoft.lims.ks.dto.request.RequestListInit;
import com.qzsoft.lims.ks.dto.request.RequestListPara;
import com.qzsoft.lims.ks.service.page.ListQueryService;
import com.qzsoft.lims.ks.service.page.QueryNoteService;
import com.qzsoft.lims.ks.service.page.QueryTreeService;
import com.qzsoft.lims.ks.util.ExObjFactory;
import com.qzsoft.lims.ks.util.GlobalDataUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @Author zf
 * @Description 前台列表查询
 * @Date 2019/10/14
 */
@Api(value = "前台列表查询", tags = "前台列表查询")
@RestController
@RequestMapping("/queryList")
@Slf4j
public class QueryListController {

    @Autowired
    protected ListQueryService listQueryService;

    @Autowired
    private QueryTreeService queryTreeService;

    @Autowired
    private QueryNoteService queryNoteService;

    @ApiOperation(value = "列表查询", notes = "初始，关键词，高级搜索，迭代")
    @PostMapping("/index")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> index( RequestListPara requestListPara ) {
        GlobalDataUtil.setMenuId( requestListPara.getMenuId() );
        RequestResult<Map<String, Object>> result = listQueryService.queryList( requestListPara );
        result.appendExObj(CommonConstants.REQ_META_PARAM,
                ExObjFactory.createReqMetaObjExObj( ListQueryService.class.getName(),
                        "queryList",
                        RequestListPara.class.getName(),
                        new Gson().toJson( requestListPara )));
        return result;
    }

    @ApiOperation(value = "获取父级数据源")
    @PostMapping("/getParentSource")
    @ResponseAddHead
        public RequestResult<String> getParentSource(@RequestParam(value = "select_code_b") String selectCodeB,
                                                 @RequestParam(value = "rev_code_b") String revCodeB,
                                                 @RequestParam(value = "reqDatasStr") String reqDatasStr,
                                                 @RequestParam(value = "judgeBusCodes") String judgeBusCodesStr) {
        RequestResult<String> result = new RequestResult<>();
        result.setList( listQueryService.getParentSource(selectCodeB, revCodeB, reqDatasStr, judgeBusCodesStr));
        return result;
    }

    @ApiOperation(value = "列表加载初始操作", notes="目前有:列显示，列表底部统计")
    @PostMapping("/init")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> init( RequestListInit requestListInit ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj( listQueryService.initOperate( requestListInit ));
        return result;
    }



    @ApiOperation(value = "全局授权处理")
    @PostMapping("/handleGlobalAuth")
    @ResponseAddHead
        public RequestResult<Boolean> handleGlobalAuth( @RequestParam(value = "click_code") String clickCode,
                                                    @RequestParam(value = "reqDatasStr") String reqDatasStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( listQueryService.handleGlobalAuth( clickCode, reqDatasStr ));
        return result;
    }

    @ApiOperation(value = "列表底部统计")
    @PostMapping("/statistics")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> statistics( RequestListInit requestListInit ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( listQueryService.statistics( requestListInit ));
        return result;
    }

    @ApiOperation(value = "树层级移动")
    @PostMapping("/levelMove")
    @ResponseAddHead
        public RequestResult<Boolean> levelMove( @RequestParam(value = "m_code") String mCode,
                                             @RequestParam(value = "moveDatas") String moveDatasStr ) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( queryTreeService.levelMove( mCode, moveDatasStr));
        return result;
    }

    @ApiOperation(value = "树联想")
    @PostMapping("/treeMatch")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> treeMatch( NodeTreePara nodeTreePara ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( listQueryService.treeMatch( nodeTreePara));
        return result;
    }

    @ApiOperation(value = "节点树")
    @PostMapping("/nodeTree")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> nodeTree( NodeTreePara nodeTreePara ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( listQueryService.nodeTree( nodeTreePara));
        return result;
    }

    @ApiOperation(value = "层级加载")
    @PostMapping("/levelLoad")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> levelLoad( NodeTreePara nodeTreePara ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( listQueryService.levelLoad( nodeTreePara));
        return result;
    }

    @ApiOperation(value = "查询记录")
    @PostMapping("/recordEnter")
    @ResponseAddHead
        public RequestResult<Long> recordEnter(@RequestParam(value = "recordDatas") String recordDatasStr ) {
        RequestResult<Long> result = new RequestResult<>();
        result.setObj( queryNoteService.recordEnter( recordDatasStr ));
        return result;
    }
}
