package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * select条件用于装载大列表时的-数据源条件
 * @author zf
 *
 */
public interface KsSqlSelectBDao extends BaseDao{


	/**
	 * 删除后批量插入
	 * @param selectList
	 * @param new_m_code
	 * @param isSaveAs
	 * @param old_m_code
	 * @return
	 */
	Boolean batchUpdate(List<Map<String, Object>> selectList, String new_m_code, Integer isSaveAs, String old_m_code, String menu_id, String isParaNul);

	List<List<Map<String, Object>>> getGroupConds( String selectCode, String m_code_type );

	Boolean saveGroupConds( List<List<Map<String, Object>>> groupConds, String newMCode,
							 Integer isSaveAs, String menuId, String isParaNul );

	Boolean deleteSelect( String oldMCode , Integer isSaveAs);
}
