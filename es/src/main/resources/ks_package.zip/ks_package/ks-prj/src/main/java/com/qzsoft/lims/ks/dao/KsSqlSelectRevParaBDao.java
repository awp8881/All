package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * select条件用于装载大列表时的-反显数据条件-参数
 * @author zlx
 * @date 2019/03/28
 */
public interface KsSqlSelectRevParaBDao extends BaseDao {
	
	/**
	 * 数据源条件参数配置列表
	 * @param rev_code
	 * @return
	 */
	List<Record> getSelectParabyRevCode(String rev_code);

	/**
	 *	根据mcode查询字典
	 * @param mCode
	 * @return
	 */
	List<Record> getSelectParaBymCode(String mCode);
	
	/**
	*参数条件保存
	 */
    boolean saveRevCodePara(List<Map<String, Object>> allDicParaList,String newCode,String oldCode,String menuId);

	Boolean saveGroupCondParas(List<Map<String, Object>> condParas,  String oldMCode);

}
