package com.qzsoft.lims.ks.dao.impl;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.comp.GroupCond;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.KsSqlRowBDao;
import com.qzsoft.lims.ks.dao.KsSqlRowParaBDao;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 列表行条件
 *
 */
@Repository
public class KsSqlRowBDaoImpl extends BaseDaoImpl implements KsSqlRowBDao{

	private static final String TABLE_NAME_B = "ks_sql_row_b";
	private static final String TABLE_NAME_C = "ks_sql_row_c";
	
	@Autowired
	private KsSqlRowParaBDao ksSqlRowParaBDao;

	@Autowired
	private KsDicBDao ksDicBDao;


	@Override
	public Map<String, Object> getGroupConds(String mCode, String mCodeType) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(mCodeType)){
			table = TABLE_NAME_C;
		}
		String code = mCode;
		String sql = "select * from "+table+" where m_code=? and (info_code is null or info_code ='' ) ";
		List<Record> rowList = DbEx.find(sql, code);
		List<Record> allDicds = ksDicBDao.getAllList();
		List<Record> rowParaList = ksSqlRowParaBDao.getRowParaList(mCode, mCodeType);
		return GroupCond.buildLogicCondList( rowList, rowParaList, allDicds, "row_code");
	}

	@JFinalTx
	@Override
	public Boolean saveGroupConds(List<List<Map<String, Object>>> groupConds, String newMCode, String oldMCode, Integer isSaveAs, String menuId) {
		boolean isSucc = true;
		String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
		String rowParaTable = isSaveAs == YnEnum.N.getCode() ? "ks_sql_row_para_b" : "ks_sql_row_para_c";

		String rowSql = "delete from "+table+" where m_code=? and (info_code is null or info_code ='' ) ";
		String rowParaSql = "delete from "+rowParaTable+" where m_code=? and (info_code is null or info_code ='' ) ";
		DbEx.delete(rowSql, oldMCode);
		DbEx.delete(rowParaSql, oldMCode);

		if (null == groupConds || groupConds.isEmpty()){
			return isSucc;
		}
		Map<String, Object> condParaMap = Maps.newHashMap();
		condParaMap.put("m_code", newMCode);
		condParaMap.put("menu_id", menuId);

		Map<String, Object> condMap = Maps.newHashMap( condParaMap );
		Set<String> relateFields = Sets.newHashSet();
		relateFields.add("row_code");

		Map<String, Object> map = GroupCond.formatGroupConds( groupConds, condMap, condParaMap, relateFields, newMCode);
		List<Map<String, Object>> conds = (List<Map<String, Object>>)map.get("conds");
		List<Map<String, Object>> condParas = (List<Map<String, Object>>)map.get("condParas");
		saveList(table, DataBaseUtil.map2Record( conds ));
		ksSqlRowParaBDao.saveGroupCondParas( condParas, isSaveAs, oldMCode);
		return isSucc;
	}
}
