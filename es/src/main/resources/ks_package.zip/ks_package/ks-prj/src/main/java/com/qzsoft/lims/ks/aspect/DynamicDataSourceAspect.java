//package com.qzsoft.lims.ks.aspect;
//import com.jfinal.plugin.activerecord.Db;
//import com.qzsoft.lims.ks.config.DataSourceHolder;
//import com.qzsoft.lims.ks.eum.TargetDataSource;
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.annotation.After;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.core.annotation.Order;
//import org.springframework.stereotype.Component;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * @author pjh
// * @Title: DynamicDataSourceAspect
// * @Description: 动态数据源切换切面
// * @date 2018/7/10 16:19
// */
////@Aspect
////@Order(-1)// 保证该AOP在@Transactional之前执行
////@Component
////public class DynamicDataSourceAspect {
////
////    private static final Logger logger = LoggerFactory.getLogger(DynamicDataSourceAspect.class);
////
////    @Before("@annotation(ds)")
////    public void changeDataSource(JoinPoint point, TargetDataSource ds) throws Throwable {
////        String dsId = ds.name();
////        if (!DataSourceHolder.containsDataSource(dsId)) {
////            logger.error("dataSource[{}]not exist，will use default dataSource > {}", ds.name(), point.getSignature());
////        } else {
////            logger.info("Use dataSource : {} dataSource when {} starting", ds.name(), point.getSignature());
////            DataSourceHolder.setDataSource(ds.name());
////            Db.use(ds.name());
////        }
////    }
////
////    @After("@annotation(ds)")
////    public void restoreDataSource(JoinPoint point, TargetDataSource ds) {
////        logger.info("Revert dataSource : {} dataSource -> {} dataSource when {} finish", ds.name(), "default" ,point.getSignature());
////        DataSourceHolder.clearDataSource();
////        Db.use("default");
////    }
////
////}
//
//
//
//
