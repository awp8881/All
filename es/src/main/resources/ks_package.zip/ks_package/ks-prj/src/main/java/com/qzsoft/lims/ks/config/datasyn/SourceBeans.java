package com.qzsoft.lims.ks.config.datasyn;


import com.qzsoft.lims.ks.plug.datasyn.CanalSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



@Slf4j
@Configuration
public class SourceBeans {


    @Value("${canal.ipaddr:}")
    String ipaddr;

    @Value("${canal.port:0}")
    int port;

    @Value("${canal.destination:}")
    String destination;


    @Bean
    @ConditionalOnProperty(prefix = "canal",name = "status",havingValue = "open")
    public CanalSource createCanalSource(){
        CanalSource canalSource = new CanalSource( ipaddr,port,destination );
        try{
            canalSource.init();
        }catch (Throwable t){
            log.error(t.getMessage(),t);
        }
        return canalSource;
    }

}
