package com.qzsoft.lims.ks.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;

/**
 * @author pjh
 * @Title: GlobalParamConfig
 * @Description: 全局参数配置
 * @date 2018/12/27 14:41
 */
@Component
@ConfigurationProperties(prefix = "ks.global-param")
@Data
public class GlobalParamConfig implements Serializable {
    private static final long serialVersionUID = 1L;

    List<SysConfig> sysConfigs;

    @Data
    public static class SysConfig implements Serializable {
        private static final long serialVersionUID = 1L;
        String code;
        String desc;
        String value[];
        String inputType;
        List<SelectList> selectList;
    }

    @Data
    public static class SelectList implements Serializable {
        private static final long serialVersionUID = 1L;
        String desc;
        String value;
    }

}
