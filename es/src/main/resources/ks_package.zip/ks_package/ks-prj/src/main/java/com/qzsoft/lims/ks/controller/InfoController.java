package com.qzsoft.lims.ks.controller;

import com.google.common.collect.Sets;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.log.OptLog;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.dto.request.RequestInfoPara;
import com.qzsoft.lims.ks.eum.BizTypeEnum;
import com.qzsoft.lims.ks.eum.LogOperateEnum;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.log.BussinessTrace;
import com.qzsoft.lims.ks.service.*;
import com.qzsoft.lims.ks.service.info.InfoService;
import com.qzsoft.lims.ks.service.module.ModuleCopyService;
import com.qzsoft.lims.ks.service.module.ModuleDataService;
import com.qzsoft.lims.ks.service.page.QueryInfoService;
import com.qzsoft.lims.ks.service.sheet.SheetRowService;
import com.qzsoft.lims.ks.util.ExObjFactory;
import com.qzsoft.lims.ks.util.UserDataUtil;
import com.qzsoft.lims.ks.vo.InfoVO;
import com.qzsoft.lims.ks.vo.SourceConfigInfoVO;
import com.qzsoft.lims.ks.vo.SourceConfigVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 详情页-控制器
 * @author zf
 * /cros处理跨域不支持此类型参数传递 content-type:application/json不支持，不能使用@RequestBody接收复杂对象
 */

@Api(value = "详情页", tags = "详情页")
@RestController
@RequestMapping("/info")
@Slf4j
public class InfoController {

	@Autowired
	private InfoService infoService;

	@Autowired
	private SheetRowService sheetRowService;

	@Autowired
	private KsTableSqlService ksTableSqlService;

	@Autowired
	private ControlConfigService controlConfigService;

	@Autowired
	private KsModelOperLService ksModelOperLService;

	@Autowired
	private ModuleCopyService moduleCopyService;

	@Autowired
	private SqlRecordCacheService sqlRecordCacheService;

	@Autowired
	private QueryInfoService queryInfoService;

	@Autowired
	private ModuleDataService moduleDataService;

	@Autowired
	private LoginService loginService;

	@ApiOperation(value="保存")
	@PostMapping("/save")
	@ResponseAddHead
	//	@BussinessTrace(value = "保存或更新详情",bizTypeEnum = BizTypeEnum.VIEW,operateEnum = LogOperateEnum.UPDATE)
	public RequestResult<Map> save(InfoVO infoVO) {
		RequestResult<Map> result = new RequestResult();
		try {
			Map<String,Object> resultMap = infoService.save(infoVO);
			result.setObj(resultMap);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".save()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".save()", e);
		}
		return result;

	}

	@ApiOperation(value="关联保存")
	@PostMapping("/link_add")
	@ResponseAddHead
		public RequestResult<Map> linkAdd(InfoVO infoVO) {
		RequestResult<Map> result = new RequestResult();
		Map<String,Object> recordMap = infoService.save(infoVO);
		result.setObj( recordMap );
		return result;

	}

	@ApiOperation(value="保存笔记留痕")
	@PostMapping("/saveOperTrace")
	@ResponseAddHead
	//	@BussinessTrace(value = "笔记留痕",bizTypeEnum = BizTypeEnum.VIEW,operateEnum = LogOperateEnum.UPDATE)
	public RequestResult<Boolean> saveOperTrace(InfoVO infoVO) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		result.setObj(true);
		return result;

	}

	@ApiOperation(value="获取留痕")
	@PostMapping("/getTrace")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="m_code",value="模块编码",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="info_code",value="详情编码",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="t_name_key",value="数据主键",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="field_str",value="类似flm_test_follow$age结构  表名$字段",required=true,dataType="String",paramType="query")
	})
	public  RequestResult<Map<String,Object>> getTrace(@RequestParam(value="m_code") String m_code,
													   @RequestParam(value="info_code") String info_code,
													   @RequestParam(value="field_str") String field_str,
													   @RequestParam(value="t_name_key") String t_name_key) {
		RequestResult<Map<String,Object>> result = new RequestResult<Map<String,Object>>();
		Map<String,Object> map = ksModelOperLService.findTop1ByInfoCodeAndTNameAndFieldName( m_code, info_code, field_str,t_name_key );
		result.setObj( map );
		return result;

	}

	@ApiOperation("加载详情页数据")
	@PostMapping("/getInfoData")
	@ResponseAddHead
		public RequestResult<Map<String,Object>> getInfoData(RequestInfoPara requestInfoPara) {
		RequestResult<Map<String,Object>> result = null;
		try {
			Map<String, Object> infoData = queryInfoService.getInfoData(requestInfoPara);
			List<String> sqlList = null==infoData ? new ArrayList<>() : (List<String>) infoData.get("completeSqlKey");
			infoData.remove("completeSqlKey");

			Object sensTableFields = infoData.getOrDefault("sensTableFields", Sets.newHashSet());
			if( sensTableFields !=null ){
				infoData.remove( "sensTableFields" );
			}
			result = new RequestResult<>(infoData);
			addCompleteSqlKeyToRequestResult(result,  sqlList);
			result.appendExObj("sensTableFields",sensTableFields);

		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoData()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoData()", e);
		}
		return result;

	}

	/**
	 * 添加完整sql到mapRequestResult中
	 * @param mapRequestResult
	 */
	private void addCompleteSqlKeyToRequestResult(RequestResult<Map<String, Object>> mapRequestResult,List<String> sqlList) {
		Map<String,Object> completeSqlKeyExObj = ExObjFactory.createCompleteSqlKeyExObj( );
		mapRequestResult.appendExObj( completeSqlKeyExObj );
		sqlRecordCacheService.saveSqlToCache( completeSqlKeyExObj.get("completeSqlKey").toString(), sqlList );
	}

	@ApiOperation("大详情页控件")
	@GetMapping("/getOutInfoData")
	@ResponseAddHead
		@ApiImplicitParam(name="info_code",value="详情编号",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getOutInfoData(@RequestParam(value="info_code") String info_code) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>( infoService.getOutInfoData( info_code ) );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOutInfoData()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOutInfoData()", e);
		}
		return result;

	}

	@ApiOperation("选择初始数据源")
	@GetMapping("/getDataSourceList")
	@ResponseAddHead
		@ApiImplicitParam(name="t_type",value="表类型：多表0，单表1，全部2",required=false,dataType="Integer",paramType="query")
	public RequestResult<Map<String,Object>> getTableSqlList(@RequestParam(value="t_type",required=false) Integer t_type) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksTableSqlService.getTableSqlList(McodeTypeEnum.CSSJY.getCode(),true,t_type));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableSqlList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableSqlList()", e);
		}
		return result;

	}

	@ApiOperation("详情页table列表")
	@GetMapping("/getInfoTableList")
	@ResponseAddHead
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getInfoTableList(@RequestParam(value="menu_id") Long menu_id) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(infoService.getInfoTableList(menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoTableList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoTableList()", e);
		}
		return result;

	}

	@ApiOperation("详情页下拉选择列表")
	@GetMapping("/getInfoSelectList")
	@ResponseAddHead
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="Integer",paramType="query")
	public RequestResult<Map<String,Object>> getInfoSelectList(@RequestParam(value="menu_id") Long menu_id) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(infoService.getInfoSelectList(menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoSelectList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoSelectList()", e);
		}
		return result;

	}

	@ApiOperation("创建列表页")
	@GetMapping("/addPage")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="menu_id",value="菜单ID",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="m_name",value="页面名字",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="m_type",value="页面类型，取值：outer_info,inner_list,inner_info",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="p_info_code",value="父详情",required=false,dataType="String",paramType="query"),
			@ApiImplicitParam(name="m_order",value="排序字段，负数表示在此之前，正数表示在此之后",required=false,dataType="Integer",paramType="query")
	})
	public RequestResult<Map<String,Object>> addPage(@RequestParam(value="menu_id") Long menu_id,
													 @RequestParam(value="m_name") String m_name,
													 @RequestParam(value="m_type") String m_type,
													 @RequestParam(value="p_info_code",required = false) String p_info_code,
													 @RequestParam(value="m_order",required = false) Integer m_order,
													 @RequestParam(value="is_load_show",required = false) String isLoadShow) {
		RequestResult<Map<String,Object>> result = null;
		try {
			infoService.addPage( menu_id, m_name, m_type, p_info_code, m_order, isLoadShow );
			result=new RequestResult<>( infoService.getInfoTableList(menu_id) );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".addPage()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".addPage()", e);
		}
		return result;
	}

	@ApiOperation("更新列表页")
	@PostMapping("/updatePage")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="menu_id",value="菜单ID",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="menu_model_id",value="menu_model_idID",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="m_name",value="页面名字",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="m_type",value="页面类型，取值：outer_info,inner_info",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="info_code",value="详情编码",required=false,dataType="String",paramType="query"),
			@ApiImplicitParam(name="list_code",value="列表编码",required=false,dataType="String",paramType="query"),
			@ApiImplicitParam(name="m_order",value="排序字段，负数表示在order_data之前，正数表示在order_data之后",required=false,dataType="Integer",paramType="query"),
			@ApiImplicitParam(name="ch_info_code",value="排序的ch_info_code",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> updatePage(@RequestParam(value="menu_id") Long menu_id,
														@RequestParam(value="id",required = false) Long menu_model_id,
			                                         @RequestParam(value="m_name") String m_name,
													 @RequestParam(value="m_type") String m_type,
													 @RequestParam(value="info_code",required = false) String info_code,
													 @RequestParam(value="m_order",required = false) Integer m_order,
													 @RequestParam(value="list_code",required = false) String list_code,
													 @RequestParam(value="ch_info_code") String ch_info_code,
														@RequestParam(value="is_load_show",required = false) String isLoadShow) {
		RequestResult<Map<String,Object>> result = null;
		try {
			infoService.updatePage( menu_id, menu_model_id, m_name, m_type, info_code,list_code,  m_order,ch_info_code, isLoadShow );
			result=new RequestResult<>( infoService.getInfoTableList(menu_id) );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".updatePage()", e);
		}catch (Exception e) {
			e.printStackTrace();
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".updatePage()", e);
		}
		return result;
	}

	@ApiOperation("获取同级页面")
	@GetMapping("/getSameLevelPage")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="menu_id",value="菜单ID",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="m_type",value="页面类型，取值：outer_info,inner_list,inner_info",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getSameLevelPage(@RequestParam(value="menu_id") Long menu_id,
													 @RequestParam(value="m_type") String m_type) {
		RequestResult<Map<String,Object>> result = null;
		try {
			List<Map<String, Object>> mapList = infoService.getSameLevelPage( menu_id, m_type );
			result=new RequestResult<>( mapList );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".addPage()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".addPage()", e);
		}
		return result;
	}

	@ApiOperation(value="数据源关联表的字段",notes="创建组获取字段也用这个接口")
	@GetMapping("/getFieldList")
	@ResponseAddHead
		@ApiImplicitParam(name="sql_rev",value="表名,多个逗号隔开:tableA,tableB",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getFieldList(@RequestParam(value="sql_rev") String sql_rev) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(infoService.getFieldList(sql_rev));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getFieldList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getFieldList()", e);
		}
		return result;

	}

	@ApiOperation(value="详情页配置保存")
	@PostMapping("/saveInfoConfig")
	@ResponseAddHead
		@OptLog(module = "outer_info_save",remark = "大详情保存")
	public RequestResult<Boolean> saveInfoConfig(SourceConfigInfoVO sourceConfigInfoVO) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			boolean isSucc = infoService.saveInfoConfig(sourceConfigInfoVO);
			result.setObj(isSucc);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveInfoConfig()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveInfoConfig()", e);
		}
		return result;

	}

	@ApiOperation(value="详情页所有数据源关联的字段")
	@GetMapping("/getInfoFields")
	@ResponseAddHead
	    @ApiImplicitParams({
            @ApiImplicitParam(name="sql_rev",value="表名,多个逗号隔开:tableA,tableB",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="info_code",value="info_code",required=false,dataType="String",paramType="query")
    })
	public RequestResult<Map<String,Object>> getInfoFields(@RequestParam(value="sql_rev") String sql_rev,
                                                           @RequestParam(value="info_code",required = false) String info_code) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(infoService.getInfoFields(sql_rev,info_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoFields()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoFields()", e);
		}
		return result;

	}

	@ApiOperation("组件小列表数据源")
	@GetMapping("/getAssemblySourceList")
	@ResponseAddHead
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getAssemblySourceList(@RequestParam(value="menu_id") String menu_id) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result = new RequestResult<>(moduleDataService.getModuleListSource( menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getAssemblySourceList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getAssemblySourceList()", e);
		}
		return result;

	}

	@ApiOperation("模糊查询组件数据源")
	@GetMapping("/getAssemblySourceSearchList")
	@ResponseAddHead
		@ApiImplicitParams({
    	@ApiImplicitParam(name="search",value="查询字符",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getAssemblySourceSearchList(@RequestParam(value="search") String search) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksTableSqlService.getTableSqlSearchList(McodeTypeEnum.ZJSJY.getCode(),search,false));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getAssemblySourceSearchList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getAssemblySourceSearchList()", e);
		}
		return result;

	}

	@ApiOperation(value="小列表保存")
	@PostMapping("/saveInnerList")
	@ResponseAddHead
		@OptLog(module = "inner_list_save",remark = "小列表保存")
	public RequestResult<Boolean> saveInnerList(SourceConfigVO sourceConfigVO) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {

			String JID = UserDataUtil.getJID();
			loginService.validateSuperManager(JID);

			Boolean isSucc=controlConfigService.saveInnerList(sourceConfigVO);
			result.setObj(isSucc);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveInnerList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveInnerList()", e);
		}
		return result;

	}

	@ApiOperation(value="小列表数据加载")
	@GetMapping("/getInnerList")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="list_code",value="小列表编码",required=false,dataType="String",paramType="query"),
			@ApiImplicitParam(name="p_info_code",value="父编码",dataType="String",paramType="query")
	})

	public RequestResult<Map<String,Object>> getInnerList(@RequestParam(value="list_code",required=false) String list_code,
														  @RequestParam(value="p_info_code") String p_info_code) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setObj(controlConfigService.getInnerList(list_code, p_info_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInnerList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInnerList()", e);
		}
		return result;

	}

	@ApiOperation(value="小详情数据加载")
	@GetMapping("/getInnerInfo")
	@ResponseAddHead
		@ApiImplicitParam(name="list_code",value="小列表编码",required=false,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getInnerInfo(@RequestParam(value="list_code",required=false) String list_code) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setObj(infoService.getOutInfoData(list_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInnerInfo()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInnerInfo()", e);
		}
		return result;

	}

	@ApiOperation(value="小详情保存")
	@PostMapping("/saveInnerInfo")
	@ResponseAddHead
		@OptLog(module = "inner_info_save",remark = "小详情保存")
	public RequestResult<Boolean> saveInnerInfo(SourceConfigInfoVO sourceConfigInfoVO) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isSucc=infoService.saveInfoConfig(sourceConfigInfoVO);
			result.setObj(isSucc);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveInnerInfo()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveInnerInfo()", e);
		}
		return result;

	}

	@ApiOperation(value="组件的字段加载条件")
	@GetMapping("/getControlData")
	@ResponseAddHead
		@ApiImplicitParam(name="m_code",value="组件编码",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getControlData(@RequestParam(value="m_code") String m_code) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setObj(infoService.getControlData(m_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getControlData()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getControlData()", e);
		}
		return result;

	}

	@ApiOperation(value="组件小详情列表")
	@GetMapping("/getInnerInfoList")
	@ResponseAddHead
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getInnerInfoList(@RequestParam(value="menu_id") String menu_id ) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(moduleDataService.getModuleInfoSource(menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInnerInfoList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInnerInfoList()", e);
		}
		return result;

	}

	@ApiOperation(value="选择详情列表")
	@GetMapping("/getInfoList")
	@ResponseAddHead
		@ApiImplicitParams({
    	@ApiImplicitParam(name="info_type",value="详情类型",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getInfoList(@RequestParam(value="info_type") String info_type) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(infoService.getInfoList(info_type));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getInfoList()", e);
		}
		return result;

	}


	@ApiOperation(value="大详情数据加载")
	@GetMapping("/getOutInfo")
	@ResponseAddHead
		@ApiImplicitParam(name="m_code",value="模板编码",required=false,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getOutInfo(@RequestParam(value="m_code",required=false) String m_code) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setObj(infoService.getOutInfoData(m_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOutInfo()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOutInfo()", e);
		}
		return result;

	}


	@ApiOperation(value = "详情复制")
    @PostMapping("/infoCopy")
    @ResponseAddHead
	    public RequestResult<Boolean> infoCopy(@RequestParam("mType") String mType,
											 @RequestParam("infoCode") String newInfoCode,
											 @RequestParam("searchInfoCode") String searchInfoCode,
											 @RequestParam("isCopyInner") Boolean isCopyInner) {
        RequestResult<Boolean> result = new RequestResult<Boolean>();

        //临时注释
		boolean isSucc = moduleCopyService.infoCopy(mType, newInfoCode, searchInfoCode, isCopyInner);
		result.setObj(isSucc);
		return result;
    }

	@ApiOperation(value="从菜单组成表中获取大详情列表")
	@GetMapping("/getOuterInfoListFromMenuModel")
	@ResponseAddHead
		public RequestResult<Map<String,Object>> getOuterInfoListFromMenuModel() {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result=new RequestResult<>(infoService.getOuterInfoListFromMenuModel());
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOuterInfoListFromMenuModel()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOuterInfoListFromMenuModel()", e);
		}
		return result;

	}

	@ApiOperation(value="根据菜单号从菜单组成表中获取大详情列表")
	@GetMapping("/getOuterInfoListFromMenuModelByMenuId")
	@ApiImplicitParam(name="menu_id",value="菜单ID",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<Map<String,Object>> getOuterInfoListFromMenuModelByMenuId(@RequestParam(value="menu_id") String menu_id) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result=new RequestResult<>(infoService.getOuterInfoListFromMenuModelByMenuId(menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOuterInfoListFromMenuModelByMenuId()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOuterInfoListFromMenuModelByMenuId()", e);
		}
		return result;

	}

	@ApiOperation(value="获取菜单配置列表")
	@GetMapping("/getMenuListFromMenuC")
	@ResponseAddHead
		public RequestResult<Map<String,Object>> getMenuListFromMenuC() {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result=new RequestResult<>(infoService.getMenuListFromMenuC());
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListFromMenuC()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListFromMenuC()", e);
		}
		return result;

	}

	@ApiOperation(value="删除大详情小详情小列表")
	@PostMapping("/deleteConfig")
	@ResponseAddHead
		@ApiImplicitParams({
    	@ApiImplicitParam(name="code",value="详情编码：大详情是info_code,小详情、小列表是list_code",required=false,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="m_type",value="类型",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="p_info_code",value="父编码",required=false,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="m_order",value="序号",required=false,dataType="String",paramType="query")
	})
	public RequestResult<Boolean> deleteConfig(@RequestParam(value="code",required=false) String code,@RequestParam(value="m_type") String m_type,
			@RequestParam(value="p_info_code",required=false) String p_info_code,@RequestParam(value="m_order",required=false) String m_order) {
		RequestResult<Boolean> result = new RequestResult<>();
		boolean isSucc = infoService.deleteConfig(m_type,code,p_info_code,m_order);
		result.setObj(isSucc);
		return result;

	}

	@ApiOperation(value="详情列表编码列表")
	@GetMapping("/getMcodeList")
	@ResponseAddHead
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getMcodeList(@RequestParam(value="menu_id") String menu_id) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(infoService.getMcodeList(menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMcodeList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMcodeList()", e);
		}
		return result;
	}

	@ApiOperation(value="通用删除")
	@PostMapping("/cancel")
	@ResponseAddHead
		@ApiImplicitParams({
    	@ApiImplicitParam(name="m_code",value="列表编码",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="fields_list",value="多行字段json字符串",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Boolean> cancel(@RequestParam(value="m_code") String m_code,@RequestParam(value="fields_list") String fields_list ) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			Boolean isCancel=infoService.cancel(m_code, fields_list);
			result.setObj(isCancel);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".cancel()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".cancel()", e);
		}
		return result;

	}

	@ApiOperation(value="级联删除")
	@PostMapping("/cascadeDelete")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="m_code",value="列表编码",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="fields_list",value="多行字段json字符串",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Boolean> cascadeDelete(@RequestParam(value="m_code") String m_code,@RequestParam(value="fields_list") String fields_list,@RequestParam(value="button_code") String button_code ) {
		RequestResult<Boolean> result = new RequestResult<>();
		Boolean isCancel=sheetRowService.cascadeDelete(m_code, button_code, fields_list);
		result.setObj(isCancel);
		return result;

	}


	@ApiOperation(value="详情编码獲取字段")
	@GetMapping("/getFieldsByInfoCode")
	@ResponseAddHead
		@ApiImplicitParam(name="info_code",value="详情编码：大详情为info_code,小详情为list_code",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getFieldsByInfoCode(@RequestParam(value="info_code") String info_code) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(infoService.getFieldsByInfoCode(info_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getFieldsByInfoCode()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getFieldsByInfoCode()", e);
		}
		return result;
	}
}
