package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsOptConfErrGDao extends BaseDao{
	
	Page<Record> getPageList(Integer pageNum, Integer pageSize,String cr_dm);
}
