package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.TagResource;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsDicBSerivce;
import com.qzsoft.lims.ks.vo.KsDicBVO;
import com.qzsoft.lims.ks.vo.PageVO.DiCdItems;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

/**
 * 字典-控制器
 * @author zf
 *
 */
@Api(value = "字典", tags = "字典")
@RestController
@TagResource("字典")
@RequestMapping("/dic")
@Slf4j
public class KsDicBController {

	@Autowired
	private KsDicBSerivce ksDicBSerivce;

	@ApiOperation("字典树列表查询")
	@GetMapping("/getTreeList")
	@ResponseAddHead
		public RequestResult<KsDicBVO> getTreeList() {
		RequestResult<KsDicBVO> result = null;
		try {
			result= new RequestResult<>(ksDicBSerivce.getTreeList());
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTreeList()", e);
		}
		return result;

	}

	@ApiOperation("配置页面初始加载字典列表")
	@GetMapping("/getDicdList")
	@ResponseAddHead
		public RequestResult<DiCdItems> getDicdList() {
		RequestResult<DiCdItems> result = null;
		try {
			result= new RequestResult<>(ksDicBSerivce.getDicdList());
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getDicdList()", e);
		}
		return result;

	}

	@ApiOperation("获取字典源列表")
	@GetMapping("/getDicdSourceList")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getDicdSourceList( ) {
		RequestResult<Map<String, Object>> result = null;
		try {
			result= new RequestResult<Map<String, Object>>( ksDicBSerivce.getDicdSourceList( ) );
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".addDicdListBySpecificTable()", e);
		}
		return result;

	}

	@ApiOperation("通过特定字典表增加字典列表")
	@GetMapping("/addDicdListBySpecificTable")
	@ResponseAddHead
	@TagResource("通过特定字典表增加字典列表")
		@ApiImplicitParams({
			@ApiImplicitParam(name="specificTable",value="特定的表，表结构必须包含parent_code，code，val,st,level字段",required=true,dataType="String",paramType="query"),
	})
	public RequestResult<Map<String, Object>> addDicdListBySpecificTable( @RequestParam(value = "specificTable") String specificTable ) {
		RequestResult<Map<String, Object>> result = null;
		try {
			result= new RequestResult<Map<String, Object>>(ksDicBSerivce.addDicdListBySpecificTable( specificTable ));
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".addDicdListBySpecificTable()", e);
		}
		return result;

	}

	@ApiOperation("删除字典表")
	@GetMapping("/delDicdListByTbName")
	@ResponseAddHead
	@TagResource("删除字典表")
		@ApiImplicitParams({
			@ApiImplicitParam(name="tbName",value="要删的表名",required=true,dataType="String",paramType="query"),
	})
	public RequestResult<Map<String, Object>> delDicdListByTbName( @RequestParam(value = "tbName") String tbName ) {
		RequestResult<Map<String, Object>> result = null;
		try {
			result= new RequestResult<Map<String, Object>>(ksDicBSerivce.delDicdListByTbName( tbName ));
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".addDicdListBySpecificTable()", e);
		}
		return result;

	}

	@ApiOperation("刷新字典列表")
	@GetMapping("/refreshDicdListToCache")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> refreshDicdList() {
		RequestResult<Map<String, Object>> result = null;
		try {
			result= new RequestResult<Map<String, Object>>(ksDicBSerivce.refreshDicdListToCache());
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".refreshDicdList()", e);
		}
		return result;

	}

	@ApiOperation("字典异常记录列表")
	@GetMapping("/dicConfigErrPageList")
	@ResponseAddHead
	    @ApiImplicitParams({
    	@ApiImplicitParam(name="cr_dm",value="创建时间",required=false,dataType="String",paramType="query"),
		@ApiImplicitParam(name="pageNum",value="页码",required=false,dataType="Integer",paramType="query"),
		@ApiImplicitParam(name="pageSize",value="每页显示条数",required=false,dataType="Integer",paramType="query")
	})
	public RequestResult<Map<String,Object>> dicConfigErrPageList(
			@RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
			@RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize,
			@RequestParam(value = "cr_dm", required = false) String cr_dm) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=ksDicBSerivce.dicConfigErrPageList(pageNum,pageSize,cr_dm);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".dicConfigErrPageList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".dicConfigErrPageList()", e);
		}
		return result;

	}

	@ApiOperation("字典分类下的字典值")
	@GetMapping("/getDicdByParent")
	@ApiImplicitParam(name="parentId",value="字典分类",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getDicdByParent(@RequestParam(value = "parentId") String parentId) {
		RequestResult<Map<String, Object>> result =  new RequestResult<>();
		List<Map<String, Object>> list = ksDicBSerivce.getDicdByParent( parentId );
		result.setList( list );
		return result;

	}

	@ApiOperation("获取动态字典")
	@PostMapping("/getDynDicList")
		@ApiImplicitParams({
			@ApiImplicitParam(name = "combFinds", value = "组合查询参数", required = true, dataType = "String", paramType = "query"),
			@ApiImplicitParam(name = "JID", value = "JID", required = true, dataType = "String", paramType = "query"),
	})
	@ResponseAddHead
	public RequestResult<String> getDynDicList(@RequestParam(value = "combFinds")String combFinds) {
		RequestResult<String> result =  new RequestResult<>();
		String newCombFinds = ksDicBSerivce.transCombFindsForDynDic( combFinds );
		result.setObj( newCombFinds );
		return result;

	}

	@ApiOperation("获取自定义全局自定的动态sql数据源字典")
	@PostMapping("/getGlobalDynDicList")
		@ApiImplicitParams({
			@ApiImplicitParam(name = "but_di_cd", value = "全局字典父级code", required = true, dataType = "String", paramType = "query"),
			@ApiImplicitParam(name = "but_di_cd_code", value = "全局字典默认选中字典code", required = true, dataType = "String", paramType = "query"),
			@ApiImplicitParam(name = "JID", value = "JID", required = true, dataType = "String", paramType = "query"),
	})
	@ResponseAddHead
	public RequestResult<Map<String, Object>> getGlobalDynDicList(@RequestParam(value = "but_di_cd")String but_di_cd,
																  @RequestParam(value = "but_di_cd_code")String but_di_cd_code,
																  @RequestParam(value = "paramReloadConfs",required = false)String paramReloadConfs) {
		RequestResult<Map<String, Object>> result =  new RequestResult<>();
		List<Map<String, Object>> globalDynDicList = ksDicBSerivce.getGlobalDynSqlDicList( but_di_cd, but_di_cd_code,paramReloadConfs );
		result.setList( globalDynDicList );
		return result;

	}
}
