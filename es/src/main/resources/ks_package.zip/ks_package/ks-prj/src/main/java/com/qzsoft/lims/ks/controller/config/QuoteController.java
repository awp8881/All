package com.qzsoft.lims.ks.controller.config;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.service.module.KsModelQuoteBService;
import com.qzsoft.lims.ks.service.module.ModuleDataService;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 列表详情引用-控制器
 * @author zf
 */
@Api(value = "列表详情引用", tags = "列表详情引用")
@RestController
@RequestMapping("/quote")
@Slf4j
public class QuoteController {

    @Autowired
    private KsModelQuoteBService ksModelQuoteBService;

    @Autowired
    private ModuleDataService moduleDataService;


    @ApiOperation(value = "引用列表")
    @GetMapping("/getQuoteList")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getQuoteList(@RequestParam(value = "selfCode") String selfCode ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        List<Record> records = ksModelQuoteBService.getQuoteList( selfCode );
        result.setList(DataBaseUtil.record2Map( records ));
        return result;
    }

    @ApiOperation(value = "引用保存")
    @PostMapping("/saveQuote")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getStepConfigMenuList(@RequestBody Map<String, Object> map) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        Map<String, Object> quoteMap = ksModelQuoteBService.saveQuote(map);
        result.setObj( quoteMap);
        return result;
    }

    @ApiOperation(value = "引用删除")
    @PostMapping("/deleteQuote")
    @ResponseAddHead
        public RequestResult<Boolean> deleteQuote(@RequestParam(value = "quoteCode") String quoteCode, @RequestParam(value = "mType") String mType) {
        RequestResult<Boolean> result = new RequestResult<>();
        boolean succYn = ksModelQuoteBService.deleteQuote(quoteCode, mType);
        result.setObj( succYn);
        return result;
    }

    @ApiOperation(value = "引用详情单表数据源")
    @GetMapping("/getQuoteInfoOneSouce")
    @ResponseAddHead
        public RequestResult<Object> getQuoteInfoOneSouce(@RequestParam(value = "where_code") String whereCode) {
        RequestResult<Object> result = new RequestResult<>( );
        result.setObj(moduleDataService.getQuoteInfoOneSouce( whereCode ));
        return result;
    }

    @ApiOperation(value = "引用详情单表数据源保存")
    @PostMapping("/saveQuoteInfoOneSouce")
    @ResponseAddHead
        public RequestResult<Boolean> saveQuoteInfoOneSouce(@RequestParam(value = "where_code") String whereCode,
                                                        @RequestParam(value = "souceDatas") String souceDatasStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        boolean succYn = moduleDataService.saveQuoteInfoOneSouce(whereCode, souceDatasStr);
        result.setObj( succYn);
        return result;
    }

}
