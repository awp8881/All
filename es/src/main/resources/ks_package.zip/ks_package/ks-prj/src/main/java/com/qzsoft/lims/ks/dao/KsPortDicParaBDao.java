package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.dao.BaseDao;

/**
 * 后端动作参数
 * @author zf
 * */
public interface KsPortDicParaBDao extends BaseDao{
	
	/**
	 * 获取后端动作参数列表
	 * @param action_type_code
	 * @param action_code
	 * @return
	 */
	List<Map<String,Object>> getActionParamsList(String action_type_code,String action_code);

	/**
	 * 获取临时常量
	 */
	List<Map<String,Object>> getTmpConstantList(String m_code, String info_code);
}
