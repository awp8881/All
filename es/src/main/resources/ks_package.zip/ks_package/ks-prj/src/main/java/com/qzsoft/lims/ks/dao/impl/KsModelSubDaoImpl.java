package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.dao.KsModelSubDao;
import com.qzsoft.lims.ks.util.CodesUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

/**
 * @Author zf
 * @Description  列表模块被引用关系
 * @Date 2019/7/1
 */
@Repository
public class KsModelSubDaoImpl extends BaseDaoImpl implements KsModelSubDao {

    private static final String TABLE_NAME = "ks_model_sub";

    /**
     * 保存列表引用
     * @param pCode
     * @param mCode
     * @param subMcode
     * @param menuId
     * @return
     */
    @Override
    public Boolean saveModelSub(String pCode, String mCode, String subMcode, String menuId) {
        Record record = new Record();
        record.set("p_code", pCode).set("m_code", mCode).set("sub_m_code", subMcode).set("menu_id", menuId)
                .set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1");
        return save( TABLE_NAME, record);
    }


    /**
     * 是否已存在该列表的引用
     * @param subMcode
     * @return
     */
    @Override
    public Boolean isExistsModelSub(String subMcode) {
        if (StringUtils.isBlank( subMcode)){
            return false;
        }
        Record record = getOneByColumn(TABLE_NAME, "sub_m_code", subMcode);
        return null == record ? false : true ;
    }

    @Override
    public String handleModelSub( String pCode, String mCode, String menuId){
        String subMcode = CodesUtil.createCommonCode("m_code");
        saveModelSub( pCode, mCode, subMcode, menuId);
        return subMcode;
    }

    @Override
    public Record getBySubMcode(String subMcode) {
        return getOneByColumn(TABLE_NAME, "sub_m_code", subMcode);
    }
}
