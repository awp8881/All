package com.qzsoft.lims.ks.controller;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsConfVerGService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 菜单配置-控制器
 * @author zf
 *
 */
@Api(value = "配置记录备份", tags = "配置记录，表：ks_conf_ver_g")
@RestController
@RequestMapping("/bak")
@Slf4j
public class KsConfVerGController {
	
	@Autowired
	private KsConfVerGService ksConfVerGService;
	
 	@ApiOperation(value = "生成版本信息记录")
	@GetMapping("/addVerG")
	@ResponseAddHead
		public RequestResult<String> addVerG() {
		RequestResult<String> result=new RequestResult<>();
		try {
			result.setStatus(ksConfVerGService.addVerG());

		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".addVerG() {}", e);
		}
		return result;
	}

	@ApiOperation(value = "获取版本信息记录")
	@GetMapping("/getVerG")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="menu_id",value="菜单Id,不传获取全部备份版本",required=false,dataType="String",paramType="query"),
	})
	public RequestResult<List<Map<String, String>>> getVerG( @RequestParam(value="menu_id",required = false) String menu_id ) {
		RequestResult<List<Map<String, String>>> result = null;
		try {
			List<Map<String, String>> mapList = ksConfVerGService.getVerG( menu_id );
			result=new RequestResult<List<Map<String, String>>>( mapList );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getVerG()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getVerG()", e);
		}
		return result;
	}


	@ApiOperation(value = "根据版本号还原系统配置数据")
	@GetMapping("/restoreConfToKsTables")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="ver_no",value="版本号",required=true,dataType="String",paramType="query"),
	})
	public RequestResult<Boolean> restoreConfToKsTables( @RequestParam(value="ver_no") String ver_no ) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean success = ksConfVerGService.restoreConfVerGToKsTables( ver_no );
			result.setStatus( success );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getVerG()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getVerG()", e);
		}
		return result;
	}

	@ApiOperation(value = "备份系统配置数据")
	@GetMapping("/ksTableBak")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="menu_id",value="菜单ID",required=false,dataType="String",paramType="query"),
			@ApiImplicitParam(name="var_name",value="备份名字",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="remark",value="备份备注",required=true,dataType="String",paramType="query"),
	})
	public RequestResult<Boolean> ksTableBak( @RequestParam(value="menu_id",required = false) Long menu_id,
											  @RequestParam(value="var_name")String var_name,
											  @RequestParam(value="remark")String remark ) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean success = ksConfVerGService.ksTableBak( menu_id,var_name,remark );
			result.setStatus( success );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getVerG()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getVerG()", e);
		}
		return result;
	}

	
}
