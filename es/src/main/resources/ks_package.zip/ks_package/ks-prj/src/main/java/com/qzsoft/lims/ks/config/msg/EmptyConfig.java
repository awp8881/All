package com.qzsoft.lims.ks.config.msg;

/**
 * 空配置
 *
 * @author yuanj
 * @since 2021/12/29
 **/
public class EmptyConfig extends Config {
    private static final long serialVersionUID = -1315340868492609432L;
}
