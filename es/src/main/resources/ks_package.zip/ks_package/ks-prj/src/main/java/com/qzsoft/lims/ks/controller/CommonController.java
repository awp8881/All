package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.ConfigUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.tools.UIDGenerator;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.CommonService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 共用接口-控制器
 * @author zf
 */
@Api(value = "共用接口", tags = "共用接口")
@RestController
@RequestMapping("/common")
@Slf4j
public class CommonController {

	@Autowired
	private CommonService commonService;
	
 	@ApiOperation(value = "获取所有业务表信息")
    @GetMapping("/getTablesList")
    @ResponseAddHead
	    public RequestResult<Map<String, Object>> getTablesList() {
        RequestResult<Map<String, Object>> result = null;
		try {
			result=new RequestResult<>(commonService.getTablesInfoList());
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTablesList()", e);
		}
		return result;
    }
 	
 	@ApiOperation(value = "通过表名获取表字段信息")
    @GetMapping("/getTableFieldInfo")
    @ResponseAddHead
	    @ApiImplicitParam(name="tableName",value="表名",required=true,dataType="String",paramType="query")
    public RequestResult<Map<String, Object>> getTableFieldInfo(@RequestParam(value="tableName") String tableName) {
        RequestResult<Map<String, Object>> result = null;
		try {
			result=new RequestResult<>(commonService.getTableFieldInfo(tableName));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableFieldInfo()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableFieldInfo()", e);
		}
		return result;
    }
 	
 	
	@ApiOperation(value = "分组条件的校验")
	@PostMapping("/validateCondition")
	@ResponseAddHead
		public RequestResult<Boolean> validateCondition( @RequestParam(value="conditionStr") String conditionStr,
													 @RequestParam(value="condFrom") String condFrom) {
		RequestResult<Boolean> result = new RequestResult<>();
		boolean isSucc = commonService.validateConditionHandle( conditionStr, condFrom );
		result.setObj( isSucc);
		return result;
	}

	@ApiOperation(value = "业务表字段树")
	@GetMapping("/getBusFieldsTree")
	@ResponseAddHead
		@ApiImplicitParam(name="tables",value="表名逗号分隔",required=false,dataType="String",paramType="query")
	public RequestResult<Map<String, Object>> getBusFieldsTree( @RequestParam(value="tables", required = false) String tables) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList( commonService.getBusFieldsTreeByTables(tables) );
		return result;
	}

	@ApiOperation(value = "后台生成唯一标识")
	@GetMapping("/generateUID")
	@ResponseAddHead
		public RequestResult<String> generateUID() {
		RequestResult<String> result = new RequestResult<>();
		result.setObj(StringUtil.toString(UIDGenerator.getUID()) );
		return result;
	}


}
