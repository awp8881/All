//package com.qzsoft.lims.ks.aspect;
//
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONArray;
//import com.jfinal.plugin.activerecord.Record;
//import com.qzsoft.common.activerecord.DbEx;
//import com.qzsoft.common.tools.DateUtil;
//import com.qzsoft.common.tools.StringUtil;
//import com.qzsoft.lims.ks.constants.Constant;
//import com.qzsoft.lims.ks.dto.OperTraceDto;
//import com.qzsoft.lims.ks.eum.EnvEnum;
//import com.qzsoft.lims.ks.eum.LogOperateEnum;
//import com.qzsoft.lims.ks.log.BussinessTrace;
//import com.qzsoft.lims.ks.service.CacheDataService;
//import com.qzsoft.lims.ks.service.KsModelOperLService;
//import com.qzsoft.lims.ks.service.info.InfoService;
//import com.qzsoft.lims.ks.util.DataBaseUtil;
//import org.apache.commons.lang3.StringUtils;
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.Signature;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.reflect.MethodSignature;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.annotation.Order;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.stereotype.Component;
//import org.springframework.util.ObjectUtils;
//import org.springframework.web.context.request.RequestAttributes;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.servlet.http.HttpServletRequest;
//import java.lang.reflect.Method;
//import java.util.*;
//
///**
// * @author pjh
// * @Title: BussinessTraceAspect
// * @Description: 业务操作痕迹拦截切面
// * @date 2018/8/14 17:05
// */
//@Aspect
//@Order(100)
//@Component
//public class BussinessTraceAspect {
//
//    protected final Logger log = LoggerFactory.getLogger( getClass() );
//
//    @Autowired
//    private RedisTemplate<Object, Object> redisTemplate;
//
//    @Autowired
//    private KsModelOperLService ksModelOperLService;
//
//    @Autowired
//    private CacheDataService cacheDataService;
//
//    @Autowired
//    private InfoService infoService;
//
//
//    @Around("@annotation(com.qzsoft.lims.ks.log.BussinessTrace)")
//    public Object caching(ProceedingJoinPoint point) throws Throwable {
//        Signature signature = point.getSignature();
//        MethodSignature methodSignature = (MethodSignature) signature;
//        Method targetMethod = methodSignature.getMethod();
//        BussinessTrace bizTrace = targetMethod.getAnnotation(BussinessTrace.class);
//        if( null==bizTrace ){
//            return point.proceed();
//        }
//
//        //从request中获取JID
//        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
//        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
//        HttpServletRequest request = sra.getRequest();
//        String JID = request.getParameter("JID");
//        if(StringUtils.isBlank( JID )){
//            log.error( "不能获取到JID,无法记录留痕" );
//            return point.proceed();
//        }
//
//        //获取用户基本信息
//        Map<String, Object> envMap = cacheDataService.findEnvMap(JID);
//        if( null == envMap || envMap.isEmpty() ){
//            log.error( "不能获取到用户数据,无法记录留痕" );
//            return point.proceed();
//        }
//
//        //执行调用方法
//        Object obj = point.proceed();
//        if( true ){
//            return obj;
//        }
//
//        String fields_str = request.getParameter("fields_str");
//        Map<String,Object> map=JSON.parseObject(fields_str);
//        Map<String,Object> talbeMap=infoService.buildTableMap(map);
////        if( !infoService.isUpdateOpt(talbeMap) ){
////            return obj;
////        }
//
//        List<OperTraceDto> operTraceDtoList = getOperTraceDtoList(request,bizTrace);
//        for( OperTraceDto operTraceDto : operTraceDtoList ){
//            List<Map<String, Object>> oldColumns = recordList2MapList( operTraceDto.getRecordsValueOld() );
//            List<Map<String, Object>> nowColumns = recordList2MapList(operTraceDto.getRecordsValueNew());
//            if( LogOperateEnum.INSERT.type.equals( operTraceDto.getOper_type() ) ){
//                //TODO 新增不记录插入
//                //addNewTrace(bizTrace, envMap, operTraceDto);
//                log.info( "插入数据，不记录留痕" );
//                continue;
//            }
//            if( LogOperateEnum.DELETE.type.equals( operTraceDto.getOper_type() ) ){
//                //TODO 删除不记录插入
//                log.info( "删除数据，不记录留痕" );
//                continue;
//            }
//            if( nowColumns.size()!= oldColumns.size() ){
//                log.error("无法记录留痕，新值{}跟老值{}数量不一致",nowColumns,oldColumns);
//                return obj;
//            }
//            Map<String, Object> flatMap = getFlatColumnsMap( operTraceDto.getT_name(),operTraceDto.getRecordsValueOld() );
//            if( LogOperateEnum.UPDATE.type.equals( operTraceDto.getOper_type() ) ){
//                List<Record> newTraceRecordList = new ArrayList<>();
//                String info_code = operTraceDto.getInfo_code();
//                String t_name = operTraceDto.getT_name();
//                Long newBatchNo = getaBatchNo(info_code, t_name);
//                for( Map<String, Object> nowColumnMap : nowColumns ){
//                    if( null==nowColumnMap.get("id") ){
//                        log.error("无法记录留痕，id不存在");
//                        return obj;
//                    }
//                    String id = nowColumnMap.get("id").toString();
//
//                    Set<Map.Entry<String, Object>> entrySet = nowColumnMap.entrySet();
//                    for( Map.Entry<String, Object> entry : entrySet ){
//                        Object oldValue = flatMap.get(operTraceDto.getT_name() + entry.getKey() + "$$" + id);
//                        if( isChangeableValue( entry.getValue(), oldValue) ){
//                            String fieldName = entry.getKey();
//                            //查询到系统变化痕迹
//                            Record newTraceRecord = getTraceRecord(bizTrace, envMap, operTraceDto, id, info_code, t_name, newBatchNo, entry, oldValue, fieldName);
//                            newTraceRecordList.add( newTraceRecord );
//                        }
//                    }
//                }
//                ksModelOperLService.saveKsModelOperLList( newTraceRecordList );
//            }
//
//        }
//
//        return obj;
//    }
//
//    /**
//     * 获取新的批次号
//     * @param info_code
//     * @param t_name
//     * @return
//     */
//    private Long getaBatchNo(String info_code, String t_name) {
//        Record maxOperCode = ksModelOperLService.findMaxOperCodeByInfoCodeAndTName( info_code, t_name );
//        Long newOrderNum = 1L;
//        String oper_code = "";
//        if( null!=maxOperCode ){
//            oper_code = maxOperCode.getStr("oper_code");
//            String orderNum = oper_code.replace( info_code+"$oper_code$","" );
//            newOrderNum = Long.parseLong( orderNum )+1;
//
//        }
//        return newOrderNum;
//    }
//
//    private Record getTraceRecord(BussinessTrace bizTrace, Map<String, Object> envMap, OperTraceDto operTraceDto, String t_name_key,
//                                  String info_code, String t_name, Long newBatchNo, Map.Entry<String, Object> entry, Object oldValue, String fieldName) {
//
//        Record newTraceRecord = ksModelOperLService.findMaxOperOrderByInfoCodeAndTNameAndFieldNameAndTNameKey( info_code, t_name ,fieldName,t_name_key );
//        if( null==newTraceRecord ){
//            newTraceRecord = new Record();
//        }else{
//            newTraceRecord = DataBaseUtil.recordClone( newTraceRecord );
//            newTraceRecord.remove("id");
//        }
//
//        String oper_mark = newTraceRecord.getStr("oper_mark");
//        oper_mark = StringUtils.isBlank( oper_mark ) ? "[]" : oper_mark;
//        String up_ver = newTraceRecord.getStr("up_ver");
//        up_ver = StringUtils.isBlank( up_ver ) ? "0" : up_ver;
//        String oper_order = newTraceRecord.getStr("oper_order");
//        oper_order = StringUtils.isBlank( oper_order ) ? "0" : oper_order;
//
//        setCommonKsModelOperLRecord(operTraceDto,bizTrace,newTraceRecord,envMap);
//        newTraceRecord.set( "t_name_key", t_name_key );
//        newTraceRecord.set( "field_name", entry.getKey() );
//        Map<String,String> raaceMap = new HashMap<>();
//        raaceMap.put("field_name",entry.getKey() );
//        raaceMap.put("change_val",entry.getValue().toString() );
//        raaceMap.put("change_time",DateUtil.getNowDateTimeStr());
////        raaceMap.put("oper_type",operTraceDto.getOper_type() );
//        raaceMap.put("login_na",envMap.get(EnvEnum.USER_NAME.getCode()) == null ? "" : envMap.get(EnvEnum.USER_NAME.getCode()).toString());
//        raaceMap.put("remark", operTraceDto.getFieldRemarkMap().get( operTraceDto.getT_name()+"$"+entry.getKey() ));
//
//        JSONArray jsonArray = JSON.parseArray(oper_mark);
//        if( jsonArray.isEmpty() ){
//            Map<String,String> tMap = new HashMap<>();
//            tMap.put("field_name",entry.getKey() );
//            tMap.put("change_val",StringUtil.toString( oldValue ) );
//            tMap.put("change_time","1979-01-01 00:00:00");
////        raaceMap.put("oper_type",operTraceDto.getOper_type() );
//            tMap.put("login_na","");
//            tMap.put("remark", "");
//            jsonArray.add( tMap );
//        }
//        jsonArray.add( raaceMap );
//        newTraceRecord.set( "field_val", entry.getValue().toString() );
//        newTraceRecord.set( "oper_mark", jsonArray.toJSONString() );
//        newTraceRecord.set( "up_ver",(Long.parseLong( up_ver ) + 1)+"" );
//        newTraceRecord.set("oper_code",info_code+"$oper_code$"+newBatchNo);
//        newTraceRecord.set( "oper_order",(Long.parseLong( oper_order ) + 1)+"");
//        newTraceRecord.set("remark",operTraceDto.getFieldRemarkMap().get( operTraceDto.getT_name()+"$"+entry.getValue() ));
//
//        return newTraceRecord;
//    }
//
//    private List<OperTraceDto> getOperTraceDtoList(HttpServletRequest request,BussinessTrace bizTrace) {
//        String m_code = request.getParameter("m_code");
//        String info_code = request.getParameter("info_code");
//        String fields_str = request.getParameter("fields_str");
//        String fields_str_old = request.getParameter("fields_str_old");
//        String fields_remark = request.getParameter("fields_remark");
//        if( StringUtils.isBlank( m_code ) || StringUtils.isBlank( info_code ) ||
//                StringUtils.isBlank( fields_str ) || StringUtils.isBlank( fields_str_old ) ){
//            return Collections.EMPTY_LIST;
//        }
//
//        List<OperTraceDto> operTraceDtoList = new ArrayList<>();
//        //需要更新的值
//        Map<String,Object> fieldsStrMap=JSON.parseObject(fields_str);
//        Map<String,Object> talbeMap=infoService.buildTableMap(fieldsStrMap);
//        //要更新前旧的值
//        Map<String,Object> fieldsStrMapOld=JSON.parseObject(fields_str_old);
//        Map<String,Object> talbeMapOld=infoService.buildTableMap(fieldsStrMapOld);
//        talbeMap.remove(Constant.TMP_CONS_TABLE);
//        for(String table : talbeMap.keySet()){
//            //需要更新的值
//            Map<String,Object> fieldMap=(Map<String, Object>) talbeMap.get(table);
//            Record record=DataBaseUtil.map2Record(fieldMap);
//            //要更新前旧的值
//            Map<String,Object> fieldMapOld=(Map<String, Object>) talbeMapOld.get(table);
//            Record recordOld=DataBaseUtil.map2Record(fieldMapOld);
//            if( null != record && null!=recordOld ){
//                OperTraceDto operTraceDto = getOperTraceDto( m_code, info_code, table, record,recordOld, fields_remark, bizTrace.operateEnum());
//                operTraceDtoList.add( operTraceDto );
//            }
//        }
//        return operTraceDtoList;
//    }
//
//    private OperTraceDto getOperTraceDto( String m_code, String info_code, String tableName,Record record,
//                                          Record recordOld,String fields_remark,LogOperateEnum logOperateEnum ) {
//
//        OperTraceDto operTraceDto = new OperTraceDto();
//        operTraceDto.setM_code( m_code );
//        operTraceDto.setInfo_code( info_code );
//        operTraceDto.setT_name( tableName );
//        record = DataBaseUtil.recordClone( record );
//        Map<String,String> fieldRemarkMap = new HashMap<>();
//
//        if( StringUtils.isNotBlank( fields_remark ) ){
//            Map<String,Object> map = JSON.parseObject(fields_remark);
//            for ( Map.Entry<String, Object> entry : map.entrySet()) {
//                fieldRemarkMap.put( entry.getKey(), StringUtil.toString( entry.getValue() ) );
//            }
//        }
//        operTraceDto.setFieldRemarkMap( fieldRemarkMap );
//        ArrayList<Record> recordsValueOld = new ArrayList<>();
//        recordsValueOld.add( recordOld );
//        operTraceDto.setRecordsValueOld( recordsValueOld );
//
//        ArrayList<Record> recordsValueNew = new ArrayList<>();
//        recordsValueNew.add( record );
//        operTraceDto.setRecordsValueNew(recordsValueNew);
//        operTraceDto.setOper_type( logOperateEnum.type );
//        return operTraceDto;
//    }
//
//
//
//    private boolean isChangeableValue(Object newObj, Object oldObj) {
//
//        if( null==oldObj && null==newObj ){
//            return false;
//        }
//        if( (null==oldObj && null!=newObj) || (null!=oldObj && null==newObj) ){
//            return true;
//        }
//        return !newObj.toString().equals( oldObj.toString() );
//    }
//
//    /**
//     * 将所有Record变为map  map的key结构=字段名+$$+ID拼成新key
//     * @param recordsValue
//     * @return
//     */
//    private Map<String, Object> getFlatColumnsMap(String t_name,List<Record> recordsValue) {
//
//        Map<String, Object> flatMap = new HashMap<>();
//        for (Record record : recordsValue) {
//            Map<String, Object> temp = record.getColumns();
//            String id = record.get("id").toString();
//
//            Set<Map.Entry<String, Object>> entries = temp.entrySet();
//            Iterator<Map.Entry<String, Object>> iterator = entries.iterator();
//            while ( iterator.hasNext() ){
//                Map.Entry<String, Object> objectEntry = iterator.next();
//                flatMap.put( t_name+objectEntry.getKey() +"$$"+ id , objectEntry.getValue());//字段名+$$+ID拼成新key
//            }
//
//
//        }
//        return flatMap;
//
//    }
//
//    /**
//     * 新增留痕
//     * @param bizTrace
//     * @param envMap
//     * @param operTraceDto
//     */
//    private void addNewTrace(BussinessTrace bizTrace, Map<String, Object> envMap, OperTraceDto operTraceDto) {
//        //如果是新增  直接插入操作留痕
//        List<Record> recordsValueNew = operTraceDto.getRecordsValueNew();
//        List<Record> ksModelOperLRecordList = new ArrayList<>();
//        for( Record record : recordsValueNew ){
//            String t_name_key = record.get("id").toString();
//            String[] columnNames = record.getColumnNames();
//            for( int i=0;i<columnNames.length;i++ ){
//                String columnName = columnNames[i];
//                Record ksModelOperLRecord = new Record();
//                ksModelOperLRecord.set( "t_name_key", t_name_key );
//                ksModelOperLRecord.set( "field_name", columnName );
//                String fieldValue = record.get(columnName).toString();
//                ksModelOperLRecord.set( "field_val", fieldValue );
//                List<Map> arrayList = new ArrayList<>();
//                Map<String,String> raaceMap = new HashMap<>();
//                raaceMap.put("field_name",columnName);
//                raaceMap.put("change_val",fieldValue);
//                raaceMap.put("change_time",DateUtil.getNowDateTimeStr());
//                raaceMap.put("oper_type",operTraceDto.getOper_type() );
//                raaceMap.put("login_na",envMap.get(EnvEnum.USER_NAME.getCode()) == null ? "" : envMap.get(EnvEnum.USER_NAME.getCode()).toString());
//                raaceMap.put("remark", operTraceDto.getFieldRemarkMap().get( operTraceDto.getT_name()+"$"+columnName ));
//                arrayList.add( raaceMap );
//                ksModelOperLRecord.set( "oper_mark", JSON.toJSON( arrayList ).toString());
//                ksModelOperLRecord.set( "oper_code", operTraceDto.getInfo_code()+"$oper_code$1" );
//                ksModelOperLRecord.set( "oper_order", 1 );
//                ksModelOperLRecord.set( "up_ver", "1" );
//                setCommonKsModelOperLRecord(operTraceDto,bizTrace,ksModelOperLRecord,envMap);
//                ksModelOperLRecord.set("remark",operTraceDto.getFieldRemarkMap().get( operTraceDto.getT_name()+"$"+columnName ));
//                ksModelOperLRecordList.add( ksModelOperLRecord );
//
//            }
//        }
//        ksModelOperLService.saveKsModelOperLList( ksModelOperLRecordList );
//    }
//
//    void setCommonKsModelOperLRecord( OperTraceDto operTraceDto ,BussinessTrace bizTrace, Record ksModelOperLRecord,Map<String, Object> envMap ){
//
//        String m_code = operTraceDto.getM_code();
//        String info_code = operTraceDto.getInfo_code();
//        String t_name = operTraceDto.getT_name();
//        String oper_type = operTraceDto.getOper_type();
//        String biz_Type = bizTrace.bizTypeEnum().type;
//        String biz_name = bizTrace.value();
//
//        ksModelOperLRecord.set("m_code",m_code);
//        ksModelOperLRecord.set("info_code",info_code);
//        ksModelOperLRecord.set("t_name",t_name);
//        ksModelOperLRecord.set("oper_type",oper_type);
//        ksModelOperLRecord.set("biz_type",biz_Type);
//        ksModelOperLRecord.set("biz_name",biz_name);
//        ksModelOperLRecord.set("cr_dm",DateUtil.getNowDateTimeStr());
//
//        String userId = envMap.get(EnvEnum.USER_ID.getCode()) == null ? "" : envMap.get(EnvEnum.USER_ID.getCode()).toString();
//        String userName = envMap.get(EnvEnum.USER_NAME.getCode()) == null ? "" : envMap.get(EnvEnum.USER_NAME.getCode()).toString();
//        String loginNa = envMap.get(EnvEnum.LOGIN_NA.getCode()) == null ? "" : envMap.get(EnvEnum.LOGIN_NA.getCode()).toString();
//        ksModelOperLRecord.set("us_id",userId);
//        ksModelOperLRecord.set("login_na",userName);
//        ksModelOperLRecord.set("us_na",loginNa);
//    }
//
//    /**
//     *
//     * @param recordsValue
//     * @return
//     */
//    private List<Map<String, Object>> recordList2MapList(List<Record> recordsValue) {
//        List<Map<String, Object>> result = new ArrayList<>();
//        if( null==recordsValue ){
//            return result;
//        }
//        for (Record record : recordsValue) {
//            Map<String, Object> oldColumns = new HashMap<>();
//            Map<String, Object> temp = record.getColumns();
//            Set<Map.Entry<String, Object>> entries = temp.entrySet();
//            Iterator<Map.Entry<String, Object>> iterator = entries.iterator();
//            while ( iterator.hasNext() ){
//                Map.Entry<String, Object> objectEntry = iterator.next();
//                oldColumns.put( objectEntry.getKey() , objectEntry.getValue() );
//            }
//
//            result.add( oldColumns );
//        }
//        return result;
//    }
//
//}
