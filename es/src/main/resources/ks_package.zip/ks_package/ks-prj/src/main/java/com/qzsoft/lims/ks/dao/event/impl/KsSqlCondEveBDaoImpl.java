package com.qzsoft.lims.ks.dao.event.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.jdialects.springsrc.utils.ObjectUtils;
import com.qzsoft.lims.ks.dao.KsSqlPortCDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondBDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondEveBDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondFieldValBDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondScriptBDao;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.eum.event.CondTypeEnum;
import com.qzsoft.lims.ks.eum.event.EveFieldValTypeEnum;
import com.qzsoft.lims.ks.eum.event.EveTypeEnum;
import com.qzsoft.lims.ks.util.CodesUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class KsSqlCondEveBDaoImpl extends BaseDaoImpl implements KsSqlCondEveBDao{
	
	private static final String TABLE_NAME = "ks_sql_cond_eve_b";

	@Autowired
	private KsSqlCondBDao ksSqlCondBDao;
	
	@Autowired
	private KsSqlCondScriptBDao ksSqlCondScriptBDao;
	
	@Autowired
	private KsSqlCondFieldValBDao ksSqlCondFieldValBDao;
	
	@Autowired
	private KsSqlPortCDao ksSqlPortCDao;

	/**
	 * 事件流列表
	 */
	@Override
	public Record getByPCode(String pCode, Boolean jsonYn, String condType) {
		Record record = new Record();
		record.set(condType, new HashMap<>());
		if (StringUtils.isBlank(pCode)) {
			return record;
		}
		String eveSql = "select * from "+TABLE_NAME+" where p_code=? and cond_type=? and gro_cond_code is not null order by eve_group_no+0,eve_order+0";
		List<Record> eveList = selectListBySql(eveSql, pCode, condType);
		
		if (null == eveList || eveList.isEmpty()) {
			return record;
		}
		List<Record> eveFieldNameList = DataBaseUtil.removeDuplicate(eveList, "cond_type_val");
		List<Record> eveGroCondList = DataBaseUtil.removeDuplicate(eveList, "gro_cond_code");
		Map<String, Object> condList = ksSqlCondBDao.getGroupConds(pCode,  jsonYn);
		List<Record> condScriptList = ksSqlCondScriptBDao.getByPCode(pCode);
		List<Record> fieldVaList = ksSqlCondFieldValBDao.getByPCode(pCode, jsonYn);
		
		List<Record> eveCondScriptList = buildEventAndCondAndScript(eveGroCondList, eveList, condList, condScriptList, fieldVaList);
		Record dataRecord = buildEventGroup(eveFieldNameList, eveCondScriptList);
		record.set(condType, DataBaseUtil.record2Map(dataRecord));
		return record;
	}
	
	/**
	 * 事件组
	 * */
	private Record buildEventGroup(List<Record> eveFieldNameList, List<Record> eveGroCondList) {
		
		Record newRecord = new Record();
		
		for (Iterator<Record> fieldIter = eveFieldNameList.iterator(); fieldIter.hasNext();) { 
			
			Record fieldRecord =  fieldIter.next();
			String condTypeVal = fieldRecord.getStr("cond_type_val");
			
			List<Record> newEveGroCondList = new ArrayList<>();
			for (Iterator<Record> eveGroCondIter = eveGroCondList.iterator(); eveGroCondIter.hasNext();) { 
				Record eveGroCondRecord =  eveGroCondIter.next();
				String eveCondTypeVal = eveGroCondRecord.getStr("cond_type_val");
				if (condTypeVal.equals(eveCondTypeVal)) {
					newEveGroCondList.add(eveGroCondRecord);
				}
			}
			newRecord.set(condTypeVal, DataBaseUtil.record2Map(newEveGroCondList));
		}
		return newRecord;
	}
	
	/**
	 * 事件+条件+脚本
	 * */
	private List<Record> buildEventAndCondAndScript(List<Record> eveGroCondList, List<Record> eveList, Map<String, Object> condList, List<Record> condScriptList,
			List<Record> fieldVaList){
		
		List<Record> list = new ArrayList<>();
		for (Iterator<Record> eventGroupIter = eveGroCondList.iterator(); eventGroupIter.hasNext();) {
			Record record = new Record();
			Record eveGroupRecord =  eventGroupIter.next();
			String groCondCode = eveGroupRecord.getStr("gro_cond_code");
			record.set("cond_type_val", eveGroupRecord.getStr("cond_type_val"));
			record.set("eve_group_no", eveGroupRecord.getStr("eve_group_no"));
			int revOnOff = StringUtil.toInt(eveGroupRecord.getStr("rev_on_off"));
			record.set("rev_on_off", YnEnum.getYnByCode(revOnOff));

			record.set("gro_cond_code", groCondCode);
			
			List<Record> newEveList = buildByGroCondCode(groCondCode, eveList, fieldVaList); // 事件
			newEveList = buildChildEve( newEveList );
			record.set("eveList", DataBaseUtil.record2Map(newEveList));

			List<List<Map<String, Object>>> newCondList = buildGroupConds(groCondCode, condList); // 条件
			record.set("condList", newCondList);
			
			List<Record> scriptList = buildByGroCondCode(groCondCode, condScriptList, null);// 脚本
			record.set("scriptMap", new HashMap<>());
			if(!scriptList.isEmpty()) {
				record.set("scriptMap", DataBaseUtil.record2Map(scriptList.get(0)));
			}
			
			
			list.add(record);
		}
		
		return list;
	}

	private List<Record> buildChildEve( List<Record> eveList ){
		if (null == eveList){
			return Lists.newArrayList();
		}
		List<Record> list = Lists.newArrayList();
		for (Record record : eveList) {
			String parentCode = record.getStr("parent_code");
			if (StringUtils.isBlank( parentCode )){
				list.add( record );
			}
		}
		for (Iterator<Record> iterator = list.iterator(); iterator.hasNext(); ) {
			Record record =  iterator.next();
			setChild(record, eveList);
		}
		return list;
	}

	private void setChild(Record record, List<Record> eveList){
		String curCode = record.getStr("cur_code");
		if (StringUtils.isBlank( curCode )){
			record.set("childList",  Lists.newArrayList() );
			return;
		}
		for (Iterator<Record> iterator = eveList.iterator(); iterator.hasNext(); ) {
			Record eveRecord =  iterator.next();
			String parentCode = eveRecord.getStr("parent_code");
			List<Map<String, Object>> childList = record.get("childList");
			if(null == childList){
				childList = Lists.newArrayList();
				record.set("childList",  childList );
			}
			if(curCode.equals( parentCode )){
				childList.add( DataBaseUtil.record2Map( eveRecord ));
				setChild(eveRecord, eveList);
			}
		}

	}

	private List<List<Map<String, Object>>> buildGroupConds( String groCondCode, Map<String, Object> condList){
		if (null == condList || condList.isEmpty()){
			return Lists.newArrayList();
		}
		List<List<Map<String, Object>>> groupConds = (List<List<Map<String, Object>>>)condList.get(groCondCode);
		if ( null == groupConds || groupConds.isEmpty()){
			return Lists.newArrayList();
		}
		return groupConds;
	}
	
	private List<Record> buildByGroCondCode(String groCondCode, List<Record> list, List<Record> fieldVaList){
		List<Record> resultList = new ArrayList<>();
		if (null == list || list.isEmpty()) {
			return resultList;
		}
		for (Iterator<Record> iter = list.iterator(); iter.hasNext();) { 
			Record record =  iter.next();
			String code = record.getStr("gro_cond_code");

			if (!groCondCode.equals(code)){
				continue;
			}

			String jsonVal = record.getStr("json_val");
			record.set("json_val", Maps.newHashMap());
			if (StringUtils.isNotBlank( jsonVal )){
				Map<String, Object> jsonValMap = JSON.parseObject( jsonVal );
				record.set("json_val", jsonValMap);
			}

			String condFieldCode = record.getStr("cond_field_code");
			if (StringUtils.isBlank(condFieldCode) || null == fieldVaList || fieldVaList.isEmpty()) {
				resultList.add(record);
				continue;
			}
				
			for (Iterator<Record> fieldValIterator = fieldVaList.iterator(); fieldValIterator.hasNext();) {
				Record fieldValRecord =  fieldValIterator.next();
				String fieldValCode = fieldValRecord.getStr("cond_field_code");
				if (condFieldCode.equals(fieldValCode)) {
					record.set("para_m_code", fieldValRecord.getStr("para_m_code")).set("para_name", fieldValRecord.getStr("para_name"))
					.set("para_val", fieldValRecord.getStr("para_val")).set("para_type", fieldValRecord.getStr("para_type"))
					.set("di_cd", fieldValRecord.getStr("di_cd")).set("di_cd_str", fieldValRecord.getStr("di_cd_str"))
					.set("dicParas", fieldValRecord.get("dicParas")).set("dicParasStr", fieldValRecord.get("dicParasStr")).set("portVO", fieldValRecord.get("portVO"))
					.set("expBusCode", fieldValRecord.get("expBusCode"));
					break;
				}
				
			}
			
			resultList.add(record);
		}
		return resultList;
	}

	/**
	 * 删除后插入
	 * */
	@JFinalTx
	@Override
	public Boolean batchUpdate(Map<String,Object> fieldEveCondMap, String pCode , String menu_id) {
		boolean succYn = true;
//		deleteEve( pCode );
		if(null == fieldEveCondMap || fieldEveCondMap.isEmpty()) {
			return succYn;
		}
		CondTypeEnum[] codeTypeArr = CondTypeEnum.values();
		for (CondTypeEnum condTypeEnum : codeTypeArr) {
			String codeType = condTypeEnum.name();
			Map<String,Object> fieldsMap = (Map<String, Object>) fieldEveCondMap.get( codeType);
			List<Map<String, Object>> fiedsEveCondList = formatData(fieldsMap, codeType, pCode);
			saveEveAndCondAndScript(fiedsEveCondList, pCode ,  menu_id, codeType);
		}

		return succYn;
	}
	
	/**
	 * 格式化所有事件
	 * */
	private List<Map<String, Object>> formatData(Map<String,Object> fieldEveCondMap, String condType, String pCode) {
		
		List<Map<String, Object>> allEveCondList = new ArrayList<>();
		if (null == fieldEveCondMap || fieldEveCondMap.isEmpty()) {
			return allEveCondList;
		}
		
		Iterator<Map.Entry<String, Object>> iter = fieldEveCondMap.entrySet().iterator();
		while(iter.hasNext()) {
			Map.Entry<String, Object> entry = iter.next();
			String condTypeVal = StringUtil.toString(entry.getKey());
			if (StringUtils.isBlank(condTypeVal)) {
				continue;
			}
			
			List<Map<String,Object>> eveCondList = (List<Map<String, Object>>) entry.getValue();
			if (null == eveCondList || eveCondList.isEmpty()) {
				continue;
			}
			int count = 1;
			for (Iterator<Map<String, Object>> eveCondIter = eveCondList.iterator(); eveCondIter.hasNext();) {
				Map<String, Object> eveConMap = eveCondIter.next();
				eveConMap.put("cond_type", condType);
				eveConMap.put("cond_type_val", condTypeVal);
				eveConMap.put("eve_group_no", count);
				eveConMap.put("gro_cond_code", CodesUtil.createCommonCode(pCode+"$gro_cond_code"));
				count++;
			}
			allEveCondList.addAll(eveCondList);
		}
			
		return allEveCondList;
	}
	
	/**
	 * 保存  事件+条件+脚本    
	 * */
	private void saveEveAndCondAndScript(List<Map<String, Object>> allEveCondList, String pCode , String menu_id, String codeType){
		if (null == allEveCondList || allEveCondList.isEmpty()) {
			return ;
		}
		List<Map<String, Object>> allEveList = Lists.newArrayList();
		List<List<Map<String, Object>>> allCondList = Lists.newArrayList();
		List<Map<String, Object>> allCondScriptList = Lists.newArrayList();
		List<Map<String, Object>> allFieldValList = Lists.newArrayList();
		List<Map<String, Object>> allPortsList = Lists.newArrayList();
		
		for (Iterator<Map<String, Object>> iterator = allEveCondList.iterator(); iterator.hasNext();) {
			Map<String, Object> map = iterator.next();
			Object condCype = map.get("cond_type");
			Object condTypeVal = map.get("cond_type_val");
			Object groCondCode = map.get("gro_cond_code");
			Object eveGroupNo = map.get("eve_group_no");

			Object revOnOff = map.get("rev_on_off");
			if (ObjectUtils.isEmpty(revOnOff)) {
				revOnOff = YnEnum.N.getCode();
			}else{
				boolean revOnOffYn = StringUtil.toBoolean(revOnOff);
				revOnOff = YnEnum.getCodeByYn(revOnOffYn);
			}

			
			List<Map<String,Object>> oldEveList = (List<Map<String, Object>>) map.get("eveList"); //事件
			formatEve(allEveList, allFieldValList, allPortsList, oldEveList, pCode, condCype,  condTypeVal, groCondCode, menu_id, eveGroupNo,  revOnOff);

			List<List<Map<String, Object>>> oldCondList = (List<List<Map<String, Object>>>) map.get("condList"); //条件
			formatCond(allCondList, oldCondList, groCondCode);
			
			Map<String,Object> oldScriptMap = (Map<String, Object>) map.get("scriptMap"); //脚本
			formatScript(allCondScriptList, oldScriptMap, groCondCode, menu_id, pCode);
			
		}
		if ( !allEveList.isEmpty()){
			saveList(TABLE_NAME, DataBaseUtil.map2Record(allEveList));
		}
		ksSqlCondBDao.saveGroupConds( allCondList, pCode, menu_id );
		ksSqlCondScriptBDao.batchUpdate(allCondScriptList);
		ksSqlCondFieldValBDao.batchUpdate(allFieldValList);
		ksSqlPortCDao.batchUpdate(allPortsList, YnEnum.N.getCode(),  pCode+"$"+codeType+"$eve", null , menu_id);
		
	}
	
	
	private void formatEve(List<Map<String, Object>> allEveList , List<Map<String, Object>> allFieldValList , List<Map<String, Object>> allPortsList, 
			List<Map<String,Object>> oldEveList, String pCode, Object condType, Object condTypeVal, Object groCondCode, String menu_id, Object eveGroupNo,
			Object revOnOff) {
		
		if (null == oldEveList || oldEveList.isEmpty()) {
			return;
		}
		oldEveList = handleChildList( oldEveList, pCode );

		int count = 1;
		for (Map<String, Object> eveMap : oldEveList) {
			Map<String, Object> newEveMap = new HashMap<>();
			String eveType = StringUtil.toString(eveMap.get("eve_type"));
			newEveMap.put("cur_code", eveMap.get("cur_code"));
			newEveMap.put("parent_code", eveMap.get("parent_code"));
			newEveMap.put("p_code", pCode);
			newEveMap.put("cond_type", condType);
			newEveMap.put("cond_type_val", condTypeVal);
			newEveMap.put("gro_cond_code", groCondCode);
			newEveMap.put("eve_m_code", eveMap.get("eve_m_code"));
			newEveMap.put("eve_type", eveType);
			newEveMap.put("targ_val", eveMap.get("targ_val"));
			newEveMap.put("eve_order", count);
			newEveMap.put("eve_group_no", eveGroupNo);
			newEveMap.put("rev_on_off", revOnOff);
			newEveMap.put("cr_dm", DateUtil.getNowDateTimeStr());
			newEveMap.put("up_ver", "1");
			newEveMap.put("menu_id", menu_id);
			newEveMap.put("tip_type", eveMap.get("tip_type"));
			newEveMap.put("jump_sty", eveMap.get("jump_sty"));
			newEveMap.put("jump_type", eveMap.get("jump_type"));
			Map<String, Object> jsonValMap = (Map<String, Object>)eveMap.get("json_val");
			if (null != jsonValMap && !jsonValMap.isEmpty()){
				newEveMap.put("json_val", JSON.toJSONString( jsonValMap ));
			}

			String condFieldCode = null;
			if (EveTypeEnum.isSetValue( eveType)) { //字段赋值或接口调用或字段字典项(变更)
				condFieldCode = CodesUtil.createCommonCode( pCode+"$cond_field_code");
				String paraType = StringUtil.toString(eveMap.get("para_type"));
				String paraVal = StringUtil.toString(eveMap.get("para_val"));
				String button_port_code = null;
				if (EveTypeEnum.port.getCode().equals(eveType) ) {
					paraType = EveFieldValTypeEnum.JK.getCode();

					Map portVO = (Map) eveMap.get("portVO");
					String portCode = StringUtil.toString(portVO.get("port_code"));
					if (StringUtils.isNotBlank(portCode) && !portCode.equals(portVO.get("dic_port_code"))){
						button_port_code = portCode;
					}else {
						button_port_code = CodesUtil.createCommonCode(pCode+"$"+condType+"$eve");
					}
					Map<String, Object> newPortMap = new HashMap<>();
					newPortMap.put("button_port_code", button_port_code);
					newPortMap.put("portVOStr", eveMap.get("portVO"));
					allPortsList.add(newPortMap);
					
				}
				if (EveFieldValTypeEnum.ZDJ.getCode().equals(paraType) || EveFieldValTypeEnum.GLOBAL_DIC.getCode().equals(paraType)) {
					List<String> dicParas = (List<String>) eveMap.get("dicParas");
					paraVal = StringUtil.listTOString(dicParas);
				}
				Map<String, Object> newFieldValMap = new HashMap<>();
				newFieldValMap.put("cond_field_code", condFieldCode);
				newFieldValMap.put("para_m_code", eveMap.get("para_m_code"));
				newFieldValMap.put("para_name", eveMap.get("para_name"));
				newFieldValMap.put("para_val", paraVal);
				newFieldValMap.put("para_type", paraType);
				newFieldValMap.put("port_code", button_port_code);
				newFieldValMap.put("di_cd", eveMap.get("di_cd"));
				newFieldValMap.put("menu_id", menu_id);
				newFieldValMap.put("p_code", pCode);
				allFieldValList.add( newFieldValMap);
			}
			newEveMap.put("cond_field_code", condFieldCode);
			allEveList.add(newEveMap);
			count++;
		}
		
	}

	private List<Map<String,Object>> handleChildList( List<Map<String,Object>> oldEveList, String pCode ){
		List<Map<String,Object>> allOldEveList = Lists.newArrayList();

		for (Iterator<Map<String, Object>> iterator = oldEveList.iterator(); iterator.hasNext(); ) {
			Map<String, Object> map =  iterator.next();
			String curCode = CodesUtil.createCommonCode(pCode);
			map.put("cur_code", curCode);

			List<Map<String,Object>> childList = (List<Map<String,Object>>)map.get("childList");
			map.remove("childList");

			allOldEveList.add( map);
			processChildList( curCode, pCode, childList, allOldEveList );

		}
		return allOldEveList;

	}

	private void processChildList( String parentCode, String pCode, List<Map<String, Object>> childList,
							   List<Map<String,Object>> allOldEveList ){

		if (null == childList || childList.isEmpty()){
			return;
		}
		for (Iterator<Map<String, Object>> mapIterator = childList.iterator(); mapIterator.hasNext(); ) {
			Map<String, Object> childMap =  mapIterator.next();
			String curCode = CodesUtil.createCommonCode(pCode);
			childMap.put("cur_code", curCode);
			childMap.put("parent_code", parentCode);

			allOldEveList.add( childMap );

			List<Map<String,Object>> list = (List<Map<String,Object>>)childMap.get("childList");

			processChildList( curCode, pCode, list, allOldEveList );


		}
	}


	private void formatCond(List<List<Map<String, Object>>> allCondList, List<List<Map<String, Object>>> oldCondList, Object groCondCode) {
		
		if (null == oldCondList || oldCondList.isEmpty()) {
			return;
		}
		for (Iterator<List<Map<String, Object>>> iterator = oldCondList.iterator(); iterator.hasNext(); ) {
			List<Map<String, Object>> next =  iterator.next();

			for (Iterator<Map<String, Object>> mapIterator = next.iterator(); mapIterator.hasNext(); ) {
				Map<String, Object> map =  mapIterator.next();
				map.put("gro_cond_code", groCondCode);
				map.remove("leftExpBusCodes");
				map.remove("rightExpBusCodes");
				map.remove("leftDynCodes");
			}
		}
		allCondList.addAll( oldCondList );
	}
	
	private void formatScript(List<Map<String, Object>> allCondScriptList, Map<String,Object> oldScriptMap, Object groCondCode, 
			String menu_id, String info_code) {
		
		if (null == oldScriptMap || oldScriptMap.isEmpty()) {
			return;
		}
		oldScriptMap.put("gro_cond_code", groCondCode);
		oldScriptMap.put("menu_id", menu_id);
		oldScriptMap.put("p_code", info_code);
		allCondScriptList.add(oldScriptMap);
	}

	/**
	 * 删除事件流
	 *
	 * @param pCode
	 * @returnwer
	 */
	@JFinalTx
	@Override
	public void deleteEve(String pCode) {
		deleteByCustom("ks_sql_cond_eve_b", "p_code", pCode);
		deleteByCustom("ks_sql_cond_b", "p_code", pCode);
		deleteByCustom("ks_sql_cond_para_b", "p_code", pCode);
		deleteByCustom("ks_sql_cond_script_b", "p_code", pCode);
		deleteByCustom("ks_sql_cond_field_val_b", "p_code", pCode);
	}

}
