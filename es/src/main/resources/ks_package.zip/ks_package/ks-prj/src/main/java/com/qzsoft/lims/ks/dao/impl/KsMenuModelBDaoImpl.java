package com.qzsoft.lims.ks.dao.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.ConfigUtil;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.dao.KsMenuModelBDao;
import com.qzsoft.lims.ks.eum.InfoInnerTypeEnum;
import com.qzsoft.lims.ks.eum.MTypeEnum;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.eum.logic.LogicReqParaEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.util.QzAssert;
import com.qzsoft.lims.ks.vo.SourceConfigVO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;

import javax.xml.crypto.Data;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 菜单组成表  大列表+详情
 */
@Repository
public class KsMenuModelBDaoImpl extends BaseDaoImpl implements KsMenuModelBDao {

    private static final String TABLE_NAME_B = "ks_menu_model_b";

    public KsMenuModelBDaoImpl() {
        super.tableName = TABLE_NAME_B;
    }

    /**
     * 保存菜单  大列表
     */
    @JFinalTx
    @Override
    public Boolean save(SourceConfigVO sourceConfigVO, String new_m_code) {
        String menu_id = sourceConfigVO.getMenu_id();
        String old_m_code = sourceConfigVO.getOld_m_code();
        Integer isSaveAs = sourceConfigVO.getIsSaveAs() == null ? 0 : sourceConfigVO.getIsSaveAs();//是否保存为组件
        String m_code_type = isSaveAs == YnEnum.N.getCode() ? sourceConfigVO.getM_code_type() : McodeTypeEnum.YMSJY.getCode();
        Record record = new Record();
        record.set("menu_id", menu_id).set("m_name", sourceConfigVO.getM_name())
                .set("m_code", new_m_code).set("m_code_type", m_code_type).set("m_type", sourceConfigVO.getM_type()).set("cr_dm", DateUtil.getNowDateTimeStr())
                .set("up_ver", 1);
        List<Record> recordList = selectListByCustom(TABLE_NAME_B, "menu_id,p_info_code", menu_id, old_m_code);
        if (null != recordList && recordList.size() > 0) {
            for (Record menuModel : recordList) {
                menuModel.set("m_code", new_m_code).set("p_info_code", new_m_code);
            }
            updateList(TABLE_NAME_B, recordList);
        }
        return DbEx.save(TABLE_NAME_B, record);
    }

    /**
     * 获取详情页table列表
     */
    @Override
    public List<Map<String, Object>> getInfoTableList(Long menuId) {
        QzAssert.notEmpty( menuId, BusinessException.buildBiz("菜单主键不能为空") );

        String outerSql = "select * from "+TABLE_NAME_B+" where menu_id=? and m_type in(?,?)";
        List<Record> list = DbEx.find(outerSql, menuId, MTypeEnum.OUTER_LIST.getCode(), MTypeEnum.GUIDE_PAGE.getCode());
        if (null == list || list.isEmpty()){
            return Collections.emptyList();
        }
        String sql = "select * from "+TABLE_NAME_B+" where menu_id=? and m_type not in(?,?) and (is_comp != '1' or is_comp is null ) order by m_order+0";
        List<Record> models = DbEx.find( sql, menuId, MTypeEnum.OUTER_LIST.getCode(), MTypeEnum.GUIDE_PAGE.getCode());
        if (null == models || models.isEmpty()){
            return DataBaseUtil.record2Map( list);
        }
        List<Record> roots = models.stream().filter( model -> StringUtils.isBlank( model.getStr("p_info_code"))).collect(Collectors.toList());
        if (null != roots && !roots.isEmpty()){
            list.addAll( roots);
        }
        Map<String, List<Record>> parentDatas = models.stream().filter(model -> StringUtils.isNotBlank( model.getStr("p_info_code")))
                .collect(Collectors.groupingBy(e -> e.getStr("p_info_code")));

        list.stream().forEach( record -> {
            String mType = record.getStr("m_type");
            String code = record.getStr("m_code");

            if (MTypeEnum.OUTER_INFO.getCode().equals( mType)){
                code = record.getStr("info_code");
            }
            record.set("code", code);
            List<Record> childs = parentDatas.get(code);
            if (null == childs || childs.isEmpty()){
                record.set("infoInner", Collections.emptyList());
                return;
            }
            childs.stream().forEach( child -> {
                child.set("code", child.getStr("list_code"));
            });
            record.set("infoInner", DataBaseUtil.record2Map( childs));
        });
        return DataBaseUtil.record2Map( list);
    }

    @Override
    public List<Record> selectInfoCodeGroupList(String m_code, MTypeEnum outerInfo) {

        String infoCodeGroupSql = "select info_code from ks_menu_model_b where m_code=? and  m_type=? group by info_code";
        return selectListBySql(infoCodeGroupSql, m_code, outerInfo.getCode());
    }

    @Override
    public Record getNameByCode(String code) {
        String sql = "select m_name from ks_menu_model_b where m_code = ? and m_type=?";
        Record record = selectFirstOneBySql(sql, code, MTypeEnum.OUTER_LIST.getCode());
        if (null != record) {//大列表
            return record;
        }
        sql = "select m_name from ks_menu_model_b where  info_code=? or list_code=?";
        record = selectFirstOneBySql(sql, code, code);
        return record;
    }

    /**
     * 所有详情列表
     */
    @Override
    public List<Record> getAllListInfo(String menuId) {
        String sql = null;
        List<Record> records = null;
        if (StringUtils.isNotBlank(menuId)) {
            sql = "select menu_id,m_name,m_code,info_code,list_code,m_type,is_load_show,m_order from " + TABLE_NAME_B + "  where menu_id = ? order by m_order+0";
            records = selectListBySql(sql, menuId);

        } else {
            sql = "select menu_id,m_name,m_code,info_code,list_code,m_type,is_load_show,m_order from " + TABLE_NAME_B + " order by m_order+0";
            records = selectListBySqlNoParas(sql);
        }

        if (null == records || records.isEmpty()) {
            return Collections.emptyList();
        }
        List<Record> resultList = Lists.newArrayList();
        for (Iterator iterator = records.iterator(); iterator.hasNext(); ) {
            Record record = (Record) iterator.next();
            String mType = record.getStr("m_type");
            Record newRecord = new Record();
            newRecord.set("menu_id", record.getStr("menu_id")).set("m_name", record.getStr("m_name")).set("m_type", record.getStr("m_type"))
                    .set("is_load_show", record.getStr("is_load_show")).set("m_order", record.getStr("m_order"));

            if (MTypeEnum.OUTER_LIST.getCode().equals(mType) || MTypeEnum.IFRAME.getCode().equals(mType) || MTypeEnum.GUIDE_PAGE.getCode().equals(mType) ) {
                newRecord.set("code", record.getStr("m_code"));

            } else if (MTypeEnum.OUTER_INFO.getCode().equals(mType) ) {
                newRecord.set("code", record.getStr("info_code"));

            } else {
                newRecord.set("code", record.getStr("list_code"));
            }
            resultList.add(newRecord);
        }
        return resultList;
    }

    @JFinalTx
    @Override
    public boolean saveByIframe(SourceConfigVO sourceConfigVO) {

        deleteByCustom("ks_menu_model_b", "menu_id", sourceConfigVO.getMenu_id());
        Record record = new Record();
        record.set("menu_id", sourceConfigVO.getMenu_id()).set("m_code", sourceConfigVO.getNew_m_code()).set("m_type", sourceConfigVO.getM_type())
                .set("iframe_url", sourceConfigVO.getIframe_url()).set("iframe_code", sourceConfigVO.getIframe_code())
                .set("m_name", sourceConfigVO.getM_name()).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1");
        save(TABLE_NAME_B, record);
        return true;
    }

    @Override
    public Record getByMtype(String menuId, String mType) {
        String sql = "select m_code,m_type,iframe_url,iframe_code from ks_menu_model_b where menu_id=? and m_type=?";
        Record model = selectFirstOneBySql(sql, menuId, mType);
        return model;
    }

    /**
     * 小列表父级数据源
     */
    @Override
    public boolean updateBusCode(String menuId, String mCode, Set<String> codeList) {
        if (null == codeList || codeList.isEmpty()) {
            return true;
        }
        codeList.remove(mCode);
        Record record = getOneByColumn(TABLE_NAME_B, "menu_id,list_code", menuId, mCode);
        if (null == record) {//组件数据源
            record = new Record();
            String codeStr = StringUtil.listTOString(Lists.newArrayList(codeList));
            record.set("menu_id", menuId).set("list_code", mCode).set("bus_code", codeStr)
                    .set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1");
            return save(TABLE_NAME_B, record);
        }
        String oldCodeStr = StringUtil.toString(record.getStr("bus_code"));
        if (oldCodeStr.equals("NULL")) {
            oldCodeStr = null;
        }
        Set<String> oldCodes = Sets.newHashSet(StringUtil.strToList(oldCodeStr));
        Set<String> newCodes = Sets.newHashSet();
        newCodes.addAll(codeList);
        newCodes.addAll(oldCodes);
        String newCodeStr = StringUtil.listTOString(Lists.newArrayList(newCodes));
        record.set("bus_code", newCodeStr);
        return update(record);
    }

    //清除小列表父级数据源
    @JFinalTx
    @Override
    public boolean deleteBusCode(String code) {
        if (StringUtils.isBlank(code)){
            return true;
        }
        String sql = "select * from " + TABLE_NAME_B + " where locate(?,bus_code)>0 ";
        List<Record> records = selectListBySql(sql, code);
        if (null == records || records.isEmpty()) {
            return true;
        }
        for (Record record : records) {
            String oldCodeStr = record.getStr("bus_code");
            Set<String> oldCodes = Sets.newHashSet(StringUtil.strToList(oldCodeStr));
            oldCodes.remove(code);
            String newCodeStr = StringUtil.listTOString(Lists.newArrayList(oldCodes));
            record.set("bus_code", newCodeStr);
        }
        return updateList(TABLE_NAME_B, records);
    }

    //详情列表版本号
    @Override
    public String getMenuModelVer(Map<String, Object> map, String mType) {
        String sql = "select up_ver from " + TABLE_NAME_B;
        Record record = null;
        if (MTypeEnum.OUTER_INFO.getCode().equals(mType) || MTypeEnum.INNER_INFO.getCode().equals(mType)) {
            String infoCode = StringUtil.toString(map.get("info_code"));
            sql += " where info_code=? or list_code=? ";
            record = selectFirstOneBySql(sql, infoCode, infoCode);

        } else {
            String pInfoCode = StringUtil.toString(map.get("p_info_code"));
            String listCode = StringUtil.toString(map.get("list_code"));
            sql += " where p_info_code=? and list_code=?";
            record = selectFirstOneBySql(sql, pInfoCode, listCode);

        }
        if (null != record) {
            return record.getStr("up_ver");
        }
        return null;
    }

    /**
     * 获取列表包含信息
     *
     * @param menu_id
     * @return
     */
    @Override
    public List<Map<String, Object>> getMenuListTree(String menu_id) {

        String sql = "select id,menu_id,m_name,m_code,m_type,info_code,list_code from " + TABLE_NAME_B + " where menu_id=?";
        List<Record> records = selectListBySql(sql, menu_id);
        return DataBaseUtil.record2Map(records);

    }

    /**
     * 更新菜单名称
     * @param menuId
     * @param menuName
     * @return
     */
    @Override
    public boolean updateMenuName(String menuId, String menuName) {
        String sql = "update "+TABLE_NAME_B+" set m_name=? where menu_id =? and m_type in (?,?,?)";
        return DbEx.update(sql, menuName, menuId, MTypeEnum.OUTER_LIST.getCode(), MTypeEnum.GUIDE_PAGE.getCode(), MTypeEnum.IFRAME.getCode()) > 0;
    }

    @Override
    public List<Record> getByListInfo(String menuId, String type) {
        String sql = null;
        List<Record> records = null;
        if (InfoInnerTypeEnum.list.name().equals( type)){
            sql = "select m_code,m_type,list_code,m_name from "+TABLE_NAME_B+" where menu_id=? and m_type in (?,?)";
            records = DbEx.find(sql, menuId, MTypeEnum.OUTER_LIST.getCode(), MTypeEnum.INNER_LIST.getCode());

        }else{
            sql = "select info_code,m_type,list_code,m_name from "+TABLE_NAME_B+" where menu_id=? and m_type in (?,?)";
            records = DbEx.find(sql, menuId, MTypeEnum.OUTER_INFO.getCode(), MTypeEnum.INNER_INFO.getCode());
        }

        if (null == records || records.isEmpty()){
            return records;
        }
        List<Record> list = Lists.newArrayList();
        records.stream().forEach( record -> {
            Record menu = new Record();
            menu.set("label", record.getStr("m_name"));
            menu.set("m_type", record.getStr("m_type"));
            String mType = record.getStr("m_type");
            if (MTypeEnum.OUTER_LIST.getCode().equals( mType)){
                menu.set("value", record.getStr("m_code"));

            }else if (MTypeEnum.OUTER_INFO.getCode().equals( mType)){
                menu.set("value", record.getStr("info_code"));
            }else {
                menu.set("value", record.getStr("list_code"));
            }
            list.add( menu);
        });
        return list;
    }
}
