package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.SourceConfigVO.AttrVO;

public interface KsModelAttrBDao extends BaseDao{

	/**
	 * 删除后插入 字段排序
	 * @param attrList
	 * @param new_m_code
	 * @param old_m_code
	 * @return
	 */
	Boolean  batchUpdate(List<Map<String, Object>> attrList, String new_m_code,String old_m_code,String menu_id);
	
	/**
	 * 排序列表
	 * @param attrVO
	 * @param m_code
	 */
	void getAttrList(AttrVO attrVO, String m_code);

	List<Record> getByMcode( String mCode);
	
}
