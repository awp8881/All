package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * select条件用于装载大列表时的-数据源条件-参数
 * @author zf
 *
 */
public interface KsSqlSelectParaBDao extends BaseDao{
	/**
	 * 数据源条件参数配置列表
	 * @param selectCode
	 * @param m_code_type
	 * @return
	 */
	List<Record> getSelectParaList(String selectCode, String m_code_type);
	
	/**
	 * 删除后批量插入
	 * @param allParaList
	 * @param isSaveAs
	 * @param old_m_code
	 * @return
	 */
	Boolean batchUpdate(List<Map<String, Object>> allParaList, Integer isSaveAs, String old_m_code, String menu_id);

	/**
	 * 保存分组条件的参数
	 * @param condParas
	 * @param isSaveAs
	 * @return
	 */
	Boolean saveGroupCondParas( List<Map<String, Object>> condParas, Integer isSaveAs);
}
