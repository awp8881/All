package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsModelListFieldDao;
import com.qzsoft.lims.ks.eum.MTypeEnum;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.util.TableHelper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * 列表字段属性-dao实现
 *
 */
@Repository
public class KsModelListFieldDaoImpl extends BaseDaoImpl implements KsModelListFieldDao{
	
	private static final String TABLE_NAME_B = "ks_model_list_field_b";
	private static final String TABLE_NAME_C = "ks_model_list_field_c";
	
	public KsModelListFieldDaoImpl(){
		super.tableName=TABLE_NAME_B;
	}

	/**
	 * 模板编码集合获取
	 */
	@Override
	public List<Record> getFieldListByMcodeList(List<String> mCodeList, String m_code_type) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		if(null == mCodeList || mCodeList.size() == 0) return null;
		String inSql = TableHelper.getInSql("m_code", mCodeList);
		String sql = "select * from "+table+" where 1=1 "+inSql;
		List<Record> recordList = DbEx.find(sql,mCodeList.toArray());
		return recordList;
	}

	/**
	 * 通过模板编码获取列表字段
	 * @param m_code
	 * @return
	 */
	@Override
	public List<Record> getFieldByMCode(String m_code,String m_code_type) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		List<Record> recordList = DbEx.find("select * from "+table+"  where m_code = ? order by is_show desc,field_order+0",m_code);
		return recordList;
	}

	/**
	 * 列表字段树结构
	 */
	@Override
	public List<Record> getFieldsTreeByList(String mCode, String mType) {
		List<Record> recordList = new ArrayList<>();
		String mCodeType = McodeTypeEnum.YMSJY.getCode();
		if(StringUtils.isNotBlank(mType) && MTypeEnum.INNER_LIST.getCode().equals(mType)){
			mCodeType = McodeTypeEnum.ZJSJY.getCode();
		}
		List<Record> records = getFieldByMCode(mCode, mCodeType);
		if (null == records || records.isEmpty()) {
			return recordList;
		}
		Record newRecord = null;
		String field_name = null;
		String desc = null;
		String para_val = null;
		for(Record record : records){
			newRecord = new Record();
			field_name = DataBaseUtil.buildFieldName(record.getStr("field_name"));
			String fieldDesc = record.getStr("field_desc");
			desc = field_name;
			if(StringUtils.isNotBlank(fieldDesc)){
				desc = fieldDesc+"$"+field_name;
			}
			para_val = record.getStr("field_name");
			
			newRecord.set("label", desc).set("value", para_val).set("field_type", record.getStr("field_type")).set("code", mCode).set("t_name", record.getStr("t_name"));
			recordList.add(newRecord);
		}
		return recordList;
	}

	@Override
	public List<Record> getFeildIsShow(String mcode, String mType) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(mType)){
			table = TABLE_NAME_C;
		}
		String sql = "select field_name from "+table +" where m_code = ? and is_show =? ";
		return DbEx.find(sql,mcode, "1");
	}

	@Override
	public List<Record> getFieldIsShow(String mcode) {
		String sql = "select t_name,field_order,field_desc ,field_name ,def_width from "+TABLE_NAME_B +" where is_show =? and m_code = ? order by field_order";
		return DbEx.find(sql,"1",mcode);
	}

	@Override
	public List<Record> getFieldIsLoad(String mCode, String mCodeType) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(mCodeType)){
			table = TABLE_NAME_C;
		}
		String sql = "select field_name,di_cd,field_type from "+table +" where m_code = ? and is_load =?  ";
		return DbEx.find(sql, mCode, "1");
	}
}
