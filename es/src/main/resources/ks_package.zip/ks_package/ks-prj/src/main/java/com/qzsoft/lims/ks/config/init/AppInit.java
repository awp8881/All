package com.qzsoft.lims.ks.config.init;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.lims.ks.dto.CodeInfo;
import com.qzsoft.lims.ks.eum.SysModeEnum;
import com.qzsoft.lims.ks.flow.core.bean.ProcessInstanceBean;
import com.qzsoft.lims.ks.flow.core.run.QueueDbService;
import com.qzsoft.lims.ks.flow.core.run.queue.QueueCache;
import com.qzsoft.lims.ks.flow.core.run.queue.QueueTaskConsume;
import com.qzsoft.lims.ks.plug.datasyn.SynHolder;
import com.qzsoft.lims.ks.plug.no.core.RuleNoTask;
import com.qzsoft.lims.ks.scheduler.admin.JobHandler;
import com.qzsoft.lims.ks.service.*;
import com.qzsoft.lims.ks.service.configdata.KsModelInfoFieldBDataService;
import com.qzsoft.lims.ks.service.info.ChangelogAuditService;
import com.qzsoft.lims.ks.service.info.FormNoteService;
import com.qzsoft.lims.ks.service.info.QzBlockingQueue;
import com.qzsoft.lims.ks.service.info.bo.InfoLableUnionBlock;
import com.qzsoft.lims.ks.service.info.bo.ListLableBlock;
import com.qzsoft.lims.ks.service.logic.KsLogicParserService;
import com.qzsoft.lims.ks.service.meta.BizTableOrderService;
import com.qzsoft.lims.ks.service.meta.KsCodeTypeService;
import com.qzsoft.lims.ks.service.meta.KsTableFieldService;
import com.qzsoft.lims.ks.service.meta.KsTableService;
import com.qzsoft.lims.ks.service.page.SourceHandleService;
import com.qzsoft.lims.ks.service.user.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class AppInit implements ApplicationRunner {

    @Value("${ks.sysParam.sysMode:}")
    public String sysMode;

    @Autowired
    private DataCleanInitializer dataCleanInitializer;

    @Autowired
    private KsMsgService ksMsgService;

    @Autowired
    KsCodeTypeService ksCodeTypeService;

    @Autowired
    KsTableService ksTableService;

    @Autowired
    KsReportTemplateService ksReportTemplateService;

    @Autowired
    private GlobalParamService globalParamService;

    @Autowired
    private InitService initService;

    @Autowired
    KsLogicParserService ksLogicParserService;

    @Autowired
    private SourceHandleService sourceHandleService;

    @Autowired
    private KsTableFieldService ksTableFieldService;

    @Autowired
    private BizTableOrderService bizTableOrderService;

    @Autowired
    private CacheDataService cacheDataService;

    @Autowired
    private KsModelInfoFieldBDataService ksModelInfoFieldBDataService;

    @Autowired
    private QzBlockingQueue qzBlockingQueue;

    @Autowired
    private ChangelogAuditService changelogAuditService;

    @Autowired
    private KsDicBSerivce ksDicBSerivce;

    @Autowired
    private FormNoteService formNoteService;

    @Autowired
    private JobHandler jobHandler;

    @Autowired
    private QueueDbService queueDbService;

    @Autowired
    private QueueTaskConsume queueTaskConsume;

    @Autowired
    private QueueCache queueCache;


    @Autowired
    private SynHolder synHolder;

    @Autowired
    private RuleNoTask ruleNoTask;

    @Autowired
    private UserService userService;

    @Override
    public void run(ApplicationArguments args) {
        DbEx.initOptLogService();
        log.info("DataSourceInitScript do action!!!!!");

        globalParamService.initYmlGlobalParamConfigToRedis( false );

        synHolder.start();

        //开发模式不清除
        if( !SysModeEnum.dev.name().equals( sysMode ) ){
            //清除admin登录数据
            //dataCleanInitializer.cleanLoginUserJIDData();
        }
        initMsgHandlers();
        initService.initDatas();
//        loginService.loadConfigsVer();
        ksLogicParserService.loadLogicConfData();
        bizTableOrderService.loadBizTableDispOr();
        jobHandler.initJob();

        queueCache.clearQueue();
        queueTaskConsume.init();
        loadUndoQueueTask();
        ruleNoTask.init();
        userService.initAllUrl();

        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.execute(() ->{
            while (true){
                log.info("执行审计日志");
                Object take = null;
                try{
                    take = qzBlockingQueue.take(QzBlockingQueue.B_AUDIT_MSG, 3, TimeUnit.SECONDS);
                    if( take!=null ){
                        if( take instanceof InfoLableUnionBlock ){
                            changelogAuditService.recordChangeLog((InfoLableUnionBlock) take);
                        }else if( take instanceof ListLableBlock){
                            changelogAuditService.recordChangeLog( (ListLableBlock)take );
                        }
                    }else{
                        TimeUnit.SECONDS.sleep(10);
                    }
                }catch (Throwable e){
                    log.error(e.getMessage(),e);
                    //可能是redis异常
                    if( take!=null ){
                        log.error( "exception:{}   参数:{}", e.getMessage(), JSON.toJSONString( take ) );
                    }
                }
                exeFormNote();
            }
        });


    }

    private void exeFormNote(){
        try{
            Object take = qzBlockingQueue.take(QzBlockingQueue.B_FORM_NOTE_MSG, 3, TimeUnit.SECONDS);
            if( null != take){
                log.info("执行表单input框日志");
                Map<String, Object> formDatas = (Map<String, Object>) take;
                formNoteService.formHistoryNote( formDatas );
            }
        }catch (Throwable e){
            log.error("表单input框日志记录："+e.getMessage(),e);
        }
    }

    void loadUndoQueueTask(){

        List<Record> queueTasks = queueDbService.getUndoneQueueData();
        if (null == queueTasks){
            return;
        }
        //同批次的队列任务加入同一队列
        Set<String> queueIds = Sets.newHashSet();
        queueTasks.stream().forEach(queueTask -> {
            queueIds.add(queueTask.getStr("opt_id"));
        });

        queueIds.stream().forEach(queueId -> {

            List<ProcessInstanceBean> processInstanceBeans = Lists.newArrayList();
            queueTasks.stream().forEach(queueTask -> {
                if (!queueId.equals(queueTask.getStr("opt_id"))){
                    return;
                }
                String optJson = queueTask.getStr("opt_json");
                Gson gson = new Gson();
                ProcessInstanceBean processInstanceBean = null;
                try{
                    processInstanceBean = gson.fromJson(optJson, new TypeToken<ProcessInstanceBean>() {
                    }.getType());
                }catch (Exception e){
                    log.error(e.getMessage(), e);
                }
                if (null == processInstanceBean){
                    return;
                }
                processInstanceBean.setQueueId(queueTask.getStr("opt_id"));
                processInstanceBean.setQueueTaskId(queueTask.getStr("id_code"));
                processInstanceBeans.add(processInstanceBean);
            });
            queueTaskConsume.addQueue(processInstanceBeans);
        });

    }

    /**
     * 初始化消息处理器
     */
    void initMsgHandlers(){
        ksMsgService.registMsgHandler( KsMsgService.MsgEnum.effectConf, new DefaultTemplHandler() );
        ksMsgService.registMsgHandler( KsMsgService.MsgEnum.effectConf, new ResetCodeInfosHandler() );
        ksMsgService.registMsgHandler( KsMsgService.MsgEnum.effectConf, new CleanConfigHandler() );
        ksMsgService.registMsgHandler( KsMsgService.MsgEnum.productAutoData, new CleanConfigHandler() );
        ksMsgService.registMsgHandler( KsMsgService.MsgEnum.productAutoData, new ResetBizTableOrderHandler() );
        ksMsgService.registMsgHandler( KsMsgService.MsgEnum.productAutoData, new CleanBusTableFieldsHandler() );
        ksMsgService.registMsgHandler( KsMsgService.MsgEnum.saveLogicConf, new ResetLogicConfHandler() );
        ksMsgService.registMsgHandler( KsMsgService.MsgEnum.updateConfig, new CleanInfoTablesHandler() );
    }


    //重置逻辑编排配置
    class ResetLogicConfHandler implements KsMsgService.MsgHandler{
        @Override
        public void handMsg(Object msgObj) {
            if (msgObj == null) {
                return;
            }
            String logicCode=msgObj.toString();
            ksLogicParserService.updateLogicConfDataByLogicCode( logicCode );
        }
    }


    //默认模板处理
    class CleanConfigHandler implements KsMsgService.MsgHandler{
        @Override
        public void handMsg(Object msgObj) {
            ksDicBSerivce.cleanFieldUseDic();
            ksModelInfoFieldBDataService.cleanConfIgnoreTables();
            ksModelInfoFieldBDataService.cleanModelInfoFieldBByInfoCodeTName();
            sourceHandleService.handleSourceSqlCleanCache();
        }
    }

    //默认模板处理
    class DefaultTemplHandler implements KsMsgService.MsgHandler{
        @Override
        public void handMsg(Object msgObj) {
            if (msgObj == null) {
                return;
            }
            String menuId=msgObj.toString();
            ksReportTemplateService.saveDefaultTempl( menuId );
        }
    }

    //清除缓存
    class CleanInfoTablesHandler implements KsMsgService.MsgHandler{
        @Override
        public void handMsg(Object msgObj) {
            ksDicBSerivce.cleanFieldUseDic();
            if (msgObj == null) {
                return;
            }
            String menuId=msgObj.toString();
            List<CodeInfo> codeInfos = ksCodeTypeService.getCodeInfosByMenuId(menuId);
            for (CodeInfo codeInfo : codeInfos) {
                //根据菜单Id获取菜单所有的大列表 小列表 小详情  大详情code TODO清除缓存
                ksTableService.cleanInfoTables( codeInfo.getCode() );
            }
        }
    }

    //清除缓存
    class ResetCodeInfosHandler implements KsMsgService.MsgHandler{
        @Override
        public void handMsg(Object msgObj) {
            if (msgObj == null) {
                return;
            }
            ksCodeTypeService.resetCodeInfos( );
        }
    }

    //清除缓存
    class CleanBusTableFieldsHandler implements KsMsgService.MsgHandler{
        @Override
        public void handMsg(Object msgObj) {

            ksTableService.cleanBusTableFields();
            ksTableService.cleanBusTables();
            ksTableService.getBusTables();
            ksTableService.cleanAllTables();
            cacheDataService.resetDbFieldDefaultValForInsert();
            cacheDataService.resetDbNotNullCheckField();
            ksTableFieldService.clearFieldSetByTable( );
            ksTableFieldService.cleanNotEmptyFieldSet();
            ksTableFieldService.cleanTableFieldType();

        }
    }

    //清除缓存
    class ResetBizTableOrderHandler implements KsMsgService.MsgHandler{
        @Override
        public void handMsg(Object msgObj) {
            bizTableOrderService.loadBizTableDispOr();
        }
    }

//    @Bean
//    public DataSourceInitializer getDataSourceInitializer(){
//      return new  DataSourceInitializer();
//    }
}
