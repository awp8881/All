package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.dao.KsTableCDao;
import com.qzsoft.lims.ks.service.KsTableCService;
import com.qzsoft.lims.ks.service.dataSource.DataSourceService;
import com.qzsoft.lims.ks.vo.CommonTreeVO;
import com.qzsoft.lims.ks.vo.KsTableCVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @auther: zf
 * @description: 表关系管理-控制器
 */
@Api(value = "表关系管理", tags = "表关系管理,表:ks_table_c")
@RestController
@RequestMapping("/tablec")
@Slf4j
@TagResource("表关系管理")
public class KsTableCController {

    @Autowired
    private KsTableCService ksTableCService;

    @Autowired
    private KsTableCDao ksTableCDao;

    @Autowired
	private DataSourceService dataSourceService;

    @ApiOperation(value = "列表分页查询",notes="查询条件写死，t_par_name：主表名;t_type:类型-主表 main，从表follow;t_fol_name:关联表名")
    @GetMapping("/getPageList")
	    @ApiImplicitParams({
		@ApiImplicitParam(name="pageNum",value="页码",required=false,dataType="Integer",paramType="query"),
		@ApiImplicitParam(name="pageSize",value="每页显示条数",required=false,dataType="Integer",paramType="query")
	})
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getPageList(
    		KsTableCVO ksTableCVO,
    		@RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
			@RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
        RequestResult<Map<String, Object>> result = null;
		try {
			result = ksTableCService.getPageList(ksTableCVO,pageNum,pageSize);

		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getPageList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getPageList()", e);
		}
		return result;
    }

    /**
     * 删除
     */
    @ApiOperation(value = "删除")
    @PostMapping("/delete")
	@TagResource("删除")
	    @ApiImplicitParam(name="tableCId",value="主键",required=true,dataType="Long",paramType="query")
    @ResponseAddHead
    public RequestResult<Boolean> delete(@RequestParam(value="tableCId") Long tableCId) {
    	RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			boolean isDelete = ksTableCService.delete(tableCId);
			result.setObj(isDelete);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}
		return result;
    }


    @ApiOperation(value = "新增")
    @PostMapping("/add")
	    @ResponseAddHead
	@TagResource("新增")
    public RequestResult<Boolean> add(KsTableCVO ksTableCVO) {
        RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			boolean isSave = ksTableCService.add(ksTableCVO);
			result.setObj(isSave);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".add()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".add()", e);
		}
		return result;
    }
    

    @ApiOperation(value = "根据主表查找子表")
    @PostMapping("/getFellowTable")
    @ResponseAddHead
	    @ApiImplicitParam(name="tableName",value="主表名称",required=true,dataType="String",paramType="query")
    public RequestResult<Map<String, Object>> getFellowTable(@RequestParam("tableName") String tableName) {
    	RequestResult<Map<String, Object>> result = null;
		try {
			result = new RequestResult<>(ksTableCService.getFellowTable(tableName));
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getFellowTable()", e);
		}
		return result;
    }
    
    @ApiOperation(value = "查看详情数据")
    @GetMapping("/getOne")
	    @ApiImplicitParam(name="tableCId",value="主键",required=true,dataType="Integer",paramType="query")
    @ResponseAddHead
    public RequestResult<Map<String,Object>> getOne(@RequestParam("tableCId") Long tableCId) {
        RequestResult<Map<String,Object>> result = null;
		try {
			result = new RequestResult<>(ksTableCDao.getOne(tableCId));

		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOne()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOne()", e);
		}
		return result;
    }
    
    @ApiOperation(value = "关系多表语句列表")
    @GetMapping("/getSqlNameList")
	    @ApiImplicitParams({
    	@ApiImplicitParam(name="t_par_name",value="主表",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="t_fol_name",value="待关联表名",required=true,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Map<String,Object>> getSqlNameList(@RequestParam("t_par_name") String t_par_name,
    		@RequestParam("t_fol_name") String t_fol_name) {
        RequestResult<Map<String,Object>> result = null;
		try {
			result = new RequestResult<>(ksTableCService.getSqlNameList(t_par_name, t_fol_name));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getSqlNameList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getSqlNameList()", e);
		}
		return result;
    }
    
    @ApiOperation(value = "修改表关系")
    @PostMapping("/update")
	    @ResponseAddHead
	@TagResource("修改表关系")
    public RequestResult<Boolean> update( KsTableCVO ksTableCVO ) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean updateYn = ksTableCService.update( ksTableCVO);
    	result.setObj(updateYn);
		return result;
    }

	@ApiOperation(value = "关联详情")
	@GetMapping("/getLinkDetail")
		@ApiImplicitParam(name="sql_prn",value="关联prn",required=true,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Map<String,Object>> getLinkDetail(@RequestParam("sql_prn") String sqlPrn) {

		RequestResult<Map<String,Object>> result = new RequestResult<>();
		result.setObj( ksTableCService.getBySqlPrn( sqlPrn ) );
		return result;

	}

	@ApiOperation(value = "关联新增")
	@PostMapping("/linkSave")
		@ResponseAddHead
	@TagResource("关联新增")
	public RequestResult<Boolean> linkSave( @RequestBody Map<String, Object> map) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( ksTableCService.linkSave( map ) );
		return result;
	}

	@ApiOperation(value = "动态sql新增")
	@PostMapping("/dynSqlSave")
	@ResponseAddHead
	@TagResource("动态sql新增")
		@ApiImplicitParams({
			@ApiImplicitParam(name="dynSqlConf",value="JSON对象{ \"dyn_sql\":obj, \"dynParasList\":obj }",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Boolean> dynSqlSave( @RequestBody Map<String, Object> dynSqlConf) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( ksTableCService.dynSqlSave( dynSqlConf ) );
		return result;
	}

	@ApiOperation(value = "数据源引用菜单")
	@GetMapping("/getDataSourceQuote")
		@ResponseAddHead
	public RequestResult<CommonTreeVO> getDataSourceQuote(@RequestParam("sqlName") String sqlName) {

		RequestResult<CommonTreeVO> result = new RequestResult<>();
		result.setList( dataSourceService.getDataSourceQuote( sqlName ) );
		return result;

	}

	@ApiOperation(value = "数据源占位符")
	@GetMapping("/getSourceMark")
		@ResponseAddHead
	public RequestResult<Map<String, Object>> getSourceMark(@RequestParam("sql_prn") String sqlPrn) {

		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList( ksTableCService.getSourceMark( sqlPrn ) );
		return result;

	}

}