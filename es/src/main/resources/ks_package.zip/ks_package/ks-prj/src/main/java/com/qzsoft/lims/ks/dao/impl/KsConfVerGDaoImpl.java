package com.qzsoft.lims.ks.dao.impl;

import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsConfVerGDao;

/** 
 * 
 * 创建时间:2018-07-03 13:42:06 
 */ 
@Repository
public class KsConfVerGDaoImpl  extends BaseDaoImpl implements KsConfVerGDao {
	public static final String TABLE_NAME = "ks_conf_ver_g";

	public KsConfVerGDaoImpl(){
		super.tableName=TABLE_NAME;
	}
	
	@Override
	public Boolean saveVerG(Record record) {
		return this.save(record);
	}


}
