package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.dao.KsModelListTreeLinkBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;

@Repository
public class KsModelListTreeLinkBDaoImpl extends BaseDaoImpl implements KsModelListTreeLinkBDao{
	private static final String TABLE_NAME = "ks_model_list_tree_link_b";
	
	/**
	 * 删除后批量插入
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> treeLinkList, String new_m_code, String old_m_code,String menu_id) {
		String old_data_code = old_m_code+"$data_code";
		String new_data_code = new_m_code+"$data_code";
		boolean isSucc = true;
		deleteByCustom(TABLE_NAME, "data_code", old_data_code);
		if(null == treeLinkList || treeLinkList.isEmpty()){
			return isSucc;
		}

		List<Record> recordList = DataBaseUtil.map2Record(treeLinkList);
		for(Record record : recordList){
			record.set("data_code", new_data_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1").remove("id")
			.set("menu_id", menu_id);
		}
		isSucc = saveList(TABLE_NAME, recordList);

		return isSucc;
	}

	/**
	 * 详情弹窗赋值批量操作
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdateInfo(List<Map<String, Object>> popupConfigList, String data_code) {
		boolean isSucc=true;
		deleteByCustom(TABLE_NAME, "data_code", data_code);
		if(null != popupConfigList && !popupConfigList.isEmpty()){
			List<Record> recordList=DataBaseUtil.map2Record(popupConfigList);
			for(Record record : recordList){
				record.set("data_code", data_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1").remove("id");
			}
			isSucc= saveList(TABLE_NAME, recordList);
		}
		
		return isSucc;
	}

	@Override
	public List<Record> getByDataCode(String dataCode) {
		String sql = "select control_code,field_name,link_field_name,disp_or from ks_model_list_tree_link_b where data_code=? order by disp_or+0";
		return selectListBySql(sql , dataCode);
	}
}
