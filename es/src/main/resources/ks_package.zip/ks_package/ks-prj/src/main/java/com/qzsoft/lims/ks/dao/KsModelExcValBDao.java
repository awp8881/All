package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsModelExcValBDao extends BaseDao {
	
	/**
	   *   删除后插入
	 * @param allExcValList
	 * @param old_m_code
	 * @return
	 */
	Boolean  batchUpdate(List<Record> allExcValList,  String old_m_code);
	
	/**
	 * 导入字段配置
	 * @param buttonCode
	 * @return
	 */
	List<Record> getExcValListByButtonCode(String buttonCode, Boolean jsonYn);
}
