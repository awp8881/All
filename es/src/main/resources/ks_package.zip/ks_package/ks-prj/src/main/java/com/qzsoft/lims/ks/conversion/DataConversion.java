package com.qzsoft.lims.ks.conversion;

public interface DataConversion {

    Object conversion(Object originalObj);
}
