package com.qzsoft.lims.ks.constants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Constant {

	/**
	 * 数据库表 > 列名 > 状态（是否可用） 多用于逻辑删除
	 */
	public static final String TABLE_COLUMN_STATUS_NAME = "st";

	public static final String ENTITY_STATUS_ABLE = "1";

	public static final String ENTITY_STATUS_ENABLE = "2";

	/**
	 * 分隔符 逗号（,）
	 */
	public static final String SEPARATOR_COMMA = ",";

	/**
	 * 分隔符 逗号（|）
	 */
	public static final String SEPARATOR_VERTICAL = "|";

	/**
	 * 分隔符 斜杠（/）
	 */
	public static final String SEPARATOR_SLASH = "/";

	/**
	 * 分隔符 （/*）
	 */
	public static final String SEPARATOR_SLASHWITH = "/*";

	public static final Integer pageNum=1;

	public static final Integer pageSize=10;
	//临时常量表
	public static String TMP_CONS_TABLE = "ks_tmp_b";

//	public static final Integer exportDefaultPageSize=400;
	public static final Integer exportDefaultPageSize=800;

	public static final Integer EXCLE_MAX_ROW=65500;

	public static String DB_KEY_NAME = "id";

	public static String BIZ_KEY_NAME = "prn";
	//业务排序字段
	public static String BIZ_ORDER_FIELD = "disp_or";

	//字段额外添加标记
	//审计
	public static final String AUDIT_SIGN = "@audit@";

	/**
	 * 字典表根节点
	 * */
	public static final String DICD_ROOT="ROOT";

	public static String KS_MENU_CONFIG_TOPIC = "KS_MENU_CONFIG_TOPIC";
	@Value("${message.channel.ksMenu}")
	public void set(String topic){
		KS_MENU_CONFIG_TOPIC = topic;
	}

	public static String ONE_STR = "1";

	public static String NOW_OPT_DATA_KEY = "now_opt_data";
	public static String RUN_TIME_PARAM_BEAN_KEY = "run_time_param_bean";

	public static String PAGE_KEY = "page";
	public static String PAGE_NUM_KEY = "pageNum";
	public static String PAGE_SIZE_KEY = "pageSize";

	//通用的有效值
	public static String COMMON_VALID = "1";
	//通用的无效值
	public static String COMMON_INVALID = "0";

	//系统配置常量
	public static final String SYS_CONF_TYPE_SPECIAL_CHAR="specialChar";

	public static String KS_FILE_DIR = "ksFile";

	public static String EXP_VAR = "ksExpVar_";

	public static final String JWT_KEY_USER_ID = "user_id";

	public static final String JWT_KEY_USER_NAME = "user_name";

	/**
	 * 登录缓存命名空间
	 */
	public static final String USER_LOGIN_TOKEN = "user:";

	/**
	 * 全局参数配置
	 */
	public static final String KS_SYS_CONF_B = "ks_sys_conf_b:";

	/**
	 * 管理员无感登录开关常量
	 */
	public static final String ADMINISTRATORSWITCH = "administratorSwitch";



	public static final String USER_RES_TREE = "USER_RES_TREE";

	/**
	 * 登录返回存入ThreadLocal键值对
	 */
	public static final String USER_INFO = "ksUserInfo";

	/**
	 * 用户信息token过期时间毫秒 2h
	 */
	public static final Long TOKEN_EXPIRE_TIME = 7200L;

	/**
	 * 用户信息REFRES时间毫秒
	 */
	public static final Long TOKEN_REFRESH_TIME = 7200L/3;

	/**
	 * 权限 header token 的key
	 */
	public static final String AUTHORIZATION_TOKEN_KEY = "token";

	//通用的有效值
	public static final int COMMON_ONE = 1;
	//通用的无效值
	public static final int COMMON_ZERO = 0;

	/**
	 * 资源类型判断 1L == 父级顶点
	 */
	public static final Long COMMON_LONG_ONE = 1L;

}
