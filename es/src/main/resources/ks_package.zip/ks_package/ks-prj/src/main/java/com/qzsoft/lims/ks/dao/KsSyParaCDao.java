package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.dao.BaseDao;

/**
 * 系统环境变量参数
 * @author zf
 *
 */
public interface KsSyParaCDao extends BaseDao{
	
	/**
	 * 获取所有环境变量
	 * @return
	 */
	List<Map<String,Object>> getList();

}
