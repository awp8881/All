package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.RequestLimit;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.plug.mh.MhService;
import com.qzsoft.lims.ks.plug.mh.SysTypeEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Api(value = "门户", tags = "门户")
@RestController
@RequestMapping("/mh")
@Slf4j
public class MhController {

    @Autowired
    private MhService mhService;

    @ApiOperation(value = "登录页")
    @PostMapping("/loginPage")
    @ResponseAddHead
    @RequestLimit(count = 10,time = 1000)//幂等控制
        public RequestResult<Map> loginPage() {
        RequestResult<Map> result = new RequestResult<>();
        result.setObj(mhService.getSysParaByType(SysTypeEnum.SYS_CSLX_LOGIN.getCode()));
        return result;
    }

}
