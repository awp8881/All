package com.qzsoft.lims.ks.config.datasyn;

import com.qzsoft.lims.ks.plug.datasyn.Canal2LocalDbSyn;
import com.qzsoft.lims.ks.plug.datasyn.CanalSource;
import com.qzsoft.lims.ks.plug.datasyn.LocalDbDest;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SynBeans {

    @Bean
    @ConditionalOnProperty(prefix = "canal",name = "status",havingValue = "open")
    public Canal2LocalDbSyn createCanal2LocalDbSyn(CanalSource canalSource, LocalDbDest localDbDest){
        Canal2LocalDbSyn canal2LocalDbSyn = new Canal2LocalDbSyn(canalSource, localDbDest);
        return canal2LocalDbSyn;
    }

}
