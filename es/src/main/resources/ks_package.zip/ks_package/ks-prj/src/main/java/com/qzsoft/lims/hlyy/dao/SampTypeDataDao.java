package com.qzsoft.lims.hlyy.dao;

import com.jfinal.plugin.activerecord.Record;

import java.util.List;
import java.util.Map;

public interface SampTypeDataDao {
    List<Record> getAllType();
}
