package com.qzsoft.lims.ks.base;

import com.qzsoft.lims.ks.entity.TableEntity;

import java.io.Serializable;
import java.util.List;

/**
 * @author : yuanj
 * @date : 2022/03/09
 * @desc :
 */
public class Module implements Serializable,Cloneable {
    private String defKey;          //表代码
    private String defName;         //表名称
    private List<TableEntity> entities;
    private List<View> views;
    private List<Dict> dicts;
    private List<Diagram> diagrams;
    private String name;          //表代码
    private String code; //文件名称---yj

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDefKey() {
        return defKey;
    }

    public void setDefKey(String defKey) {
        this.defKey = defKey;
    }

    public String getDefName() {
        return defName;
    }

    public void setDefName(String defName) {
        this.defName = defName;
    }

    public List<TableEntity> getEntities() {
        return entities;
    }

    public void setEntities(List<TableEntity> entities) {
        this.entities = entities;
    }

    public List<View> getViews() {
        return views;
    }

    public void setViews(List<View> views) {
        this.views = views;
    }

    public List<Dict> getDicts() {
        return dicts;
    }

    public void setDicts(List<Dict> dicts) {
        this.dicts = dicts;
    }

    public List<Diagram> getDiagrams() {
        return diagrams;
    }

    public void setDiagrams(List<Diagram> diagrams) {
        this.diagrams = diagrams;
    }
    public void fillEntitiesRowNo(){
        if(entities == null){
            return;
        }
        for(int i=1;i<=entities.size();i++){
            TableEntity entity = entities.get(i-1);
            if(entity==null){
                continue;
            }
            entity.setRowNo(i);
        }
    }
    public void fillDictsRowNo(){
        if(dicts == null){
            return;
        }
        for(int i=1;i<=dicts.size();i++){
            Dict dict = dicts.get(i-1);
            if(dict==null){
                continue;
            }
            List<DictItem> items = dict.getItems();
            for(int j=1;j<=items.size();j++){
                DictItem item = items.get(j-1);
                if(item==null){
                    continue;
                }
                item.setRowNo(j);
            }
        }
    }

    public boolean isEmpty(){
        if((entities == null || entities.size() == 0)
        &&(diagrams == null || diagrams.size() == 0)
        &&(dicts == null || dicts.size() == 0)){
            return true;
        }else{
            return false;
        }

    }
}
