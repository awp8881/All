package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlButtonSelectBDao extends BaseDao{

	/**
	 * 字典值配置条件
	 * @param down_code
	 * @return
	 */
	List<Record> getButtonSelectList(String down_code);
	
	/**
	 * 删除后插入
	 * @param parent_code
	 * @param allSelectList
	 * @return
	 */
	Boolean batchUpdate(String parent_code, List<Map<String,Object>> allSelectList);

	List<List<Map<String, Object>>> getGroupConds(String downCode);

	Boolean saveGroupConds( List<List<Map<String, Object>>> groupConds);

	Boolean isDynGlobalDic( String dicCode);
}
