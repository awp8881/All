package com.qzsoft.lims.ks.dao.event;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlCondScriptBDao extends BaseDao{
	
	/**
	 * 条件脚本
	 * @param pCode
	 * @return
	 */
	List<Record> getByPCode(String pCode);
	
	/**
	 * 批量保存
	 * @param allCondScriptList
	 * @return
	 */
	Boolean batchUpdate(List<Map<String, Object>> allCondScriptList);

}
