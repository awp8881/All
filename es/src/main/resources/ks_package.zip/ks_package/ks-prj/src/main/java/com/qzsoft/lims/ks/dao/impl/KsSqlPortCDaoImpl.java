package com.qzsoft.lims.ks.dao.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.constants.TableBCEnum;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.CustomDbRecordUtil;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.tools.VOUtils;
import com.qzsoft.lims.ks.dao.KsSqlPortCDao;
import com.qzsoft.lims.ks.dao.KsSqlPortParaCDao;
import com.qzsoft.lims.ks.dao.info.KsSqlPortReturnDao;
import com.qzsoft.lims.ks.eum.*;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.util.QzAssert;
import com.qzsoft.lims.ks.vo.SourceConfigVO.PortVO;
import com.qzsoft.lims.ks.vo.page.PageCommonVO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * 接口请求地址
 * @author zf
 * */
@Repository
public class KsSqlPortCDaoImpl extends BaseDaoImpl implements KsSqlPortCDao{

	private static final String TABLE_NAME_B = "ks_sql_port_b";
	private static final String TABLE_NAME_C = "ks_sql_port_c";

	@Autowired
	private KsSqlPortParaCDao ksSqlPortParaCDao;

	@Autowired
	private KsSqlPortReturnDao ksSqlPortReturnDao;

	@Autowired
	private RedisTemplate<Object, Object> redisTemplate;

	/**
	 * 通过接口编码获取某一接口
	 */
	@Override
	public Record getListByPortCode(String port_code,String m_code_type) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		if(StringUtils.isNotBlank(port_code)){
			String sql="SELECT k1.port_type,k1.sy_id,k1.logic_url,k1.url_type,k1.sy_type,k1.port_code,k1.logic_code,k1.is_forw," +
					" k2.action_desc,k2.port_code as dic_port_code,k2.action_type_code,k2.action_type_desc from "+table+" k1 "
					+ " LEFT JOIN ks_port_dic_b k2 ON k1.dic_port_code = k2.port_code WHERE k1.port_code = ?";
			Record record = DbEx.findFirst(sql,port_code);
			return record;
		}
		return null;
	}

	/**
	 * 删除后插入
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> allPortsList, Integer isSaveAs, String code, String otherCode, String menu_id) {
		String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
		String portParaTable = isSaveAs == YnEnum.N.getCode()  ? "ks_sql_port_para_b" : "ks_sql_port_para_c";
		String portReturnTable = isSaveAs == YnEnum.N.getCode()  ? "ks_sql_port_return_b" : "ks_sql_port_return_c";

		if(StringUtils.isNotBlank(code)){
			deletePort(table, portParaTable, portReturnTable, code);
		}

		if(StringUtils.isNotBlank(otherCode)){
			deletePort(table, portParaTable, portReturnTable, otherCode);
		}
		if(null == allPortsList || allPortsList.isEmpty()){
			return true;
		}
		List<String> portCodeList = Lists.newArrayList();
		List<PortVO> portVOList = Lists.newArrayList();
		for(Map<String, Object> map : allPortsList){
			String button_port_code = StringUtil.toString(map.get("button_port_code"));
			String portVOStr = StringUtil.toString(map.get("portVOStr"));
			if (StringUtils.isBlank(portVOStr) || portVOStr.equals("{}")) {
				continue;
			}
			JSONObject object = JSON.parseObject(portVOStr);
			PortVO portvo = VOUtils.po2vo(object, PortVO.class);
			portvo.setButton_port_code(button_port_code);
			portVOList.add(portvo);
			portCodeList.add(button_port_code);

		}

		List<Record> portList = Lists.newArrayList();//接口地址
		List<Record> allPortParasList = Lists.newArrayList();//接口参数
		List<Record> allPortReturnList = Lists.newArrayList();//接口返回参数
		buildPortParaReturn(portVOList, portList, allPortParasList, allPortReturnList, menu_id);

		if (!portList.isEmpty()){
			saveList(table, portList);
		}
		ksSqlPortParaCDao.batchUpdate(portCodeList, allPortParasList,isSaveAs,menu_id);
		ksSqlPortReturnDao.batchUpdate(portCodeList, allPortReturnList,menu_id, isSaveAs);

		return true;
	}

	private void deletePort(String portTable, String portParaTable, String portReturnTable, String code) {
		if (StringUtils.isBlank(code)){
			return;
		}
		DbEx.delete("delete from "+portTable+" where locate(?,port_code)>0 ",code);
		DbEx.delete("delete from "+portParaTable+" where locate(?,port_code)>0 ",code);
		DbEx.delete("delete from "+portReturnTable+" where locate(?,port_code)>0 ",code);
	}

	/**
	 * 接口参数及返回参数
	 * */
    @Override
	public void buildPortParaReturn(List<PortVO> portVOList,List<Record> portList,List<Record> allPortParasList,List<Record> allPortReturnList,String menu_id){

		for(PortVO portvo : portVOList){
			String button_port_code = portvo.getButton_port_code();
			String port_name = portvo.getAction_desc();
			String syId = portvo.getSy_id();
			String dicPortCode = portvo.getDic_port_code();
			String syType = portvo.getSy_type();
			String logicCode = portvo.getLogic_code();
			if (StringUtils.isNotBlank( syId )){
				String urlType = portvo.getUrl_type();
				Object logicUrl = portvo.getLogic_url();
				Record record = new Record();
				record.set("logic_url", logicUrl);
				if (UrlTypeEnum.FIELD_URL.getCode().equals(urlType) ){
					if ("[]".equals(portvo.getLogic_url())){
						record.set("logic_url", null);
					}else {
						logicUrl = StringUtil.listTOString((List<String>)JSON.parse(StringUtil.toString(portvo.getLogic_url())));
						record.set("logic_url", logicUrl);
					}
				}
				record.set("port_type", portvo.getPort_type()).set("port_name", port_name).set("port_code", button_port_code)
						.set("dic_port_code", dicPortCode).set("port_desc", portvo.getAction_desc())
						.set("sy_id", portvo.getSy_id()).set("cr_dm", DateUtil.getNowDateTimeStr())
						.set("up_dm", DateUtil.getNowDateTimeStr()).set("up_ver", 1).set("menu_id", menu_id).set("url_type", portvo.getUrl_type())
						.set("sy_type", syType).set("logic_code", logicCode).set("is_forw", portvo.getIs_forw());
				portList.add(record);

				if (SyTypeEnum.REMOTE.getCode().equals( syType ) ){
					validatePort(dicPortCode, portvo.getPort_type(), logicUrl, port_name);
				}
			}

			List<Map<String,Object>> portParaList = portvo.getPortParaList();// 请求参数
			if(null != portParaList && !portParaList.isEmpty()){
				int count = 1;
				for(Map<String,Object> map : portParaList){
					Record paraRecord = DataBaseUtil.map2Record(map);

					if (SyTypeEnum.REMOTE.getCode().equals( syType ) ){
						validatePortPara(dicPortCode, port_name, paraRecord.getStr("para_name"), paraRecord.getStr("para_type"));
					}

					String para_resou_type = paraRecord.getStr("para_resou_type");
					if(ButtonParaTypeEnum.HJBL.getCode().equals( para_resou_type )){
						paraRecord.set("para_val", map.get("redis_key"));
					}

					paraRecord.set("port_code", button_port_code).set("port_name", port_name).set("cr_dm", DateUtil.getNowDateTimeStr())
					.set("up_dm", DateUtil.getNowDateTimeStr()).set("up_ver", 1).set("para_order", count);
					allPortParasList.add(paraRecord);
					count++;
				}
			}

			List<Map<String,Object>> portReturnList = portvo.getPortReturnList();//返回参数
			if (null == portReturnList || portReturnList.isEmpty()) {
				continue;
			}
			if (SyTypeEnum.LOCAL.getCode().equals( syType ) || SyTypeEnum.LOCAL_SHOW.getCode().equals( syType)
					|| SyTypeEnum.LOCAL_DOWNLOAD.getCode().equals( syType)){
				dicPortCode = logicCode;
			}
			if (StringUtils.isBlank( dicPortCode)){
				BusinessException.throwBiz("接口标识不能为空");
			}
			for(Map<String,Object> returnMap : portReturnList){
				Record returnRecord = DataBaseUtil.map2Record(returnMap);
				String field_name_set = StringUtil.toString(returnRecord.getStr("field_name_set"));
				returnRecord.set("port_code", button_port_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1").set("field_name_set", field_name_set)
				.set("dic_port_code", dicPortCode);
				allPortReturnList.add(returnRecord);
			}

		}
	}

	private void validatePort(String dicPortCode, String portType, Object logicUrl, String portName){
		Record record = DbEx.findFirst("select id from ks_port_dic_b where port_code=? and port_type=? and logic_url=?", dicPortCode, portType, logicUrl);
		QzAssert.notEmpty(record, BusinessException.buildBiz("接口["+portName+"]被修改或被删除，请重新加载页面后操作或打开接口弹窗点击确定再保存"));
	}

	private void validatePortPara(String dicPortCode, String portName, String paraName, String paraType){
		Record record = DbEx.findFirst("select id from ks_port_dic_para_b where port_code=? and para_name=? and para_type=?", dicPortCode, paraName, paraType);
		QzAssert.notEmpty(record, BusinessException.buildBiz("接口["+portName+"]参数被修改或被删除，请重新加载页面后操作或打开接口弹窗点击确定再保存"));
	}


	/**
	 * 接口配置修改--引用接口修改
	 */
    @JFinalTx
	@Override
	public Boolean updateByPortConfig(String dic_port_code, String port_type, String port_name, String logic_url, String url_type) {
		boolean isSucc = true;
		if(StringUtils.isBlank(dic_port_code)){
			return isSucc;
		}
		List<Record> portBList = selectListByCustom(TABLE_NAME_B, "dic_port_code", dic_port_code);
		if(null != portBList && !portBList.isEmpty()){
			for(Record record : portBList){
				record.set("port_type", port_type).set("port_name", port_name).set("port_desc", port_name).set("logic_url", logic_url)
				.set("up_dm", DateUtil.getNowDateTimeStr()).set("url_type", url_type);
			}
			updateList(TABLE_NAME_B, portBList);
		}
		List<Record> portCList = selectListByCustom(TABLE_NAME_C, "dic_port_code", dic_port_code);
		if(null != portCList && !portCList.isEmpty()){
			for(Record record : portCList){
				record.set("port_type", port_type).set("port_name", port_name).set("port_desc", port_name).set("logic_url", logic_url)
				.set("up_dm", DateUtil.getNowDateTimeStr());
			}
			updateList(TABLE_NAME_C, portCList);
		}
		cleanConfigCache();
		return isSucc;
	}

	private void cleanConfigCache(){
		Set<Object> set = redisTemplate.keys(CommonConstants.KS_CONFIG_DATAS+"*");
		if(null != set && !set.isEmpty()){
			redisTemplate.delete(set);
		}
	}

	/**
	 * 接口配置删除
	 */
    @JFinalTx
	@Override
	public Boolean deleteByPortConfig(List<String> dicPortCodeList) {
		boolean isSucc = true;
		if(null == dicPortCodeList || dicPortCodeList.isEmpty()){
			return isSucc;
		}
		List<Record> portBList = getByColumnList(TABLE_NAME_B, "dic_port_code", dicPortCodeList);
		List<Record> portCList = getByColumnList(TABLE_NAME_C, "dic_port_code", dicPortCodeList);
		List<String> portbs = DataBaseUtil.record2String(portBList, "port_code");
		List<String> portcs = DataBaseUtil.record2String(portCList, "port_code");
		batchDelete("ks_sql_port_para_b", "port_code", portbs);
		batchDelete("ks_sql_port_para_c", "port_code", portcs);
		batchDelete(TABLE_NAME_B, "dic_port_code", dicPortCodeList);
		batchDelete(TABLE_NAME_C, "dic_port_code", dicPortCodeList);
		return isSucc;
	}

	/**
	 * 获取接口所有信息
	 */
	@Override
	public PortVO getPortAndParaAndReturn(String port_code, String m_code_type) {
		PortVO portVO = new PortVO();
		if(StringUtils.isBlank(port_code)) {
			return portVO;
		}

		Record portRecord = getListByPortCode(port_code, m_code_type);
		List<Record> portParaList = new ArrayList<>();
		if(null != portRecord){
			portVO = CustomDbRecordUtil.converModel(portVO.getClass(), portRecord);
			String urlType = portRecord.getStr("url_type");
			if (UrlTypeEnum.FIELD_URL.getCode().equals( urlType)){
				portVO.setLogic_url( CommonUtil.strToList( portRecord.getStr("logic_url"), ","));
			}
			portParaList = ksSqlPortParaCDao.getParaListByPortCode(port_code, m_code_type);
		}
		portVO.setPortParaList(DataBaseUtil.record2Map(portParaList));

		List<Record> portReturnList = ksSqlPortReturnDao.getListByPortCode(port_code, m_code_type);
		portVO.setPortReturnList(DataBaseUtil.record2Map(portReturnList));

		return portVO;
	}

	@Override
	public Map<String, Object> getPortToMap(String port_code, String m_code_type) {

		Map<String,Object> map = new HashMap<>();
		if(StringUtils.isBlank(port_code)) {
			return map;
		}
		Record portRecord = getListByPortCode(port_code, m_code_type);
		map = DataBaseUtil.record2Map(portRecord);

		String urlType = StringUtil.toString(map.get("url_type"));
		if (UrlTypeEnum.FIELD_URL.getCode().equals( urlType)){
			map.put("logic_url", CommonUtil.strToList( portRecord.getStr("logic_url"), ",")) ;
		}

		List<Record> portParaList = new ArrayList<>();
		if(null != portRecord){
			portParaList = ksSqlPortParaCDao.getParaListByPortCode(port_code,m_code_type);
		}
		map.put("portParaList", DataBaseUtil.record2Map(portParaList));

		List<Record> portReturnList = ksSqlPortReturnDao.getListByPortCode(port_code , m_code_type);
		map.put("portReturnList", DataBaseUtil.record2Map(portReturnList));
		return map;
	}

	//json文件的接口数据
	@Override
	public PageCommonVO.PortData getPortToJson(String portCode, String tableBC) {
		PageCommonVO.PortData portData = new PageCommonVO.PortData();
		if (StringUtils.isBlank(portCode)) {
			portData.setIsHavePort( false);
			return portData;
		}
		String mCodeType = McodeTypeEnum.YMSJY.getCode();
		if(tableBC.equals(TableBCEnum.c.name())){
			mCodeType = McodeTypeEnum.ZJSJY.getCode();
		}
		Record portRecord = getListByPortCode(portCode, mCodeType);  //接口
		if (null == portRecord || StringUtils.isBlank( portRecord.getStr("sy_id"))) {
			portData.setIsHavePort( false);
			return portData;
		}
		portData = CustomDbRecordUtil.converModel(portData.getClass(), portRecord);
		String logic_code = portRecord.getStr("logic_code");
		if( StringUtils.isNotBlank(logic_code) ){
			//如果不为空  查询是否具有分页
			String existPagingSql = "select sql_b.page_size from ks_model_logic_resp_b resp join ks_model_dyn_sql_b sql_b on resp.para_val=sql_b.dyn_code where logic_code=? and is_paging='1'";
			List<Record> recordList = DbEx.find(existPagingSql, logic_code);
			portData.setNeed_paging( recordList.isEmpty() ? "0":"1" );
			portData.setPage_size( recordList.isEmpty() ? "15" : recordList.get(0).getStr("page_size") );
		}
		portData.setIsHavePort( true);

		String urlType = StringUtil.toString(portRecord.getStr("url_type"));
		if(UrlTypeEnum.FIELD_URL.getCode().equals(urlType)){
			String logicUrl = DataBaseUtil.buildFieldName(portRecord.getStr("logic_url"));
			List<String> urls = CommonUtil.strToList(logicUrl, ",");
			portData.setLogic_url(urls);
		}

		List<PageCommonVO.PortParas> params = Lists.newArrayList();
		Set<String> busCodes = Sets.newHashSet();
		List<Record> paramsList = ksSqlPortParaCDao.getParaListByPortCode(portCode, mCodeType);//接口请求参数
		if(null != paramsList && !paramsList.isEmpty()){
			for(Record param : paramsList){
				PageCommonVO.PortParas infoFieldClickParams = new PageCommonVO.PortParas();
				infoFieldClickParams = CustomDbRecordUtil.converModel(infoFieldClickParams.getClass(), param);
				String paraResourceType = infoFieldClickParams.getPara_resou_type();
				if (!ButtonParaTypeEnum.FZ.getCode().equals(paraResourceType)) {
					infoFieldClickParams.setPara_val(DataBaseUtil.transformPoint2Dao(infoFieldClickParams.getPara_val()));
				}
				params.add(infoFieldClickParams);

				String busCode = param.getStr("para_m_code");
				if (StringUtils.isNotBlank( busCode)){
					busCodes.add( busCode);
				}
			}
		}
		portData.setPortBusCode( busCodes);
		portData.setParams(params);

		List<PageCommonVO.PortResult> fieldList = Lists.newArrayList(); //接口返回赋值
		List<Record> returnFieldList = ksSqlPortReturnDao.getListByPortCode(portCode, mCodeType);
		if(null != returnFieldList && !returnFieldList.isEmpty()){
			for(Record returnField : returnFieldList){
				PageCommonVO.PortResult portResult = new PageCommonVO.PortResult();
				portResult = CustomDbRecordUtil.converModel(portResult.getClass(), returnField);
				String field_name_set = DataBaseUtil.buildFieldName(portResult.getField_name_set());
				portResult.setField_name_set(field_name_set);
				fieldList.add(portResult);
			}
		}
		portData.setField_list(fieldList);
		return portData;
	}

	@Override
	public Record getPortInfo(String portCode) {
		String sql = "select k.*,(select url from ks_sy_c where id = k.sy_id ) as host from "+TABLE_NAME_B+" k where port_code=? ";
		Record record = DbEx.findFirst(sql, portCode);
		if (null == record){
			sql = "select k.*,(select url from ks_sy_c where id = k.sy_id ) as host from "+TABLE_NAME_C+" k where port_code=? ";
			record = DbEx.findFirst(sql, portCode);
		}
		return record;
	}
}
