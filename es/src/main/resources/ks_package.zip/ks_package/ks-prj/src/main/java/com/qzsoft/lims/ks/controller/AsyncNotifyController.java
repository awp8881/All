package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.page.PageCompProcessor;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import javax.servlet.http.HttpServletResponse;

/**
 * @Author zf
 * @Description  异步通知
 * @Date 2020/12/4
 */
@Api(value = "异步通知", tags = "异步通知")
@RestController
@RequestMapping("/async")
@Slf4j
public class AsyncNotifyController {


    @Autowired
    private PageCompProcessor pageCompProcessor;

    @ApiOperation("开启异步通知")
    @GetMapping("/startAsyncNotify")
    @ResponseAddHead
        public SseEmitter startAsyncNotify(HttpServletResponse response, @RequestParam("key") String key) {
        SseEmitter sseEmitter = pageCompProcessor.startAsyncNotify(response, key);
        return sseEmitter;
    }

    @ApiOperation("添加异步通知消息")
    @PostMapping("/addAsyncNotify")
    @ResponseAddHead
        public RequestResult<Boolean> addAsyncNotify(@RequestParam("pageKey") String pageKey, @RequestParam(value = "keys") String keys) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( pageCompProcessor.addAsyncNotify(pageKey, keys) );
        return result;
    }

    @ApiOperation("推送异步通知消息")
    @PostMapping("/sendAsyncNotify")
    @ResponseAddHead
        public RequestResult<Boolean> sendAsyncNotify(@RequestParam("key") String key) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( pageCompProcessor.sendAsyncNotify(key) );
        return result;
    }
}
