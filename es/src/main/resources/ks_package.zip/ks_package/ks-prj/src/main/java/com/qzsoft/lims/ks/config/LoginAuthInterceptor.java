//package com.qzsoft.lims.ks.config;
//
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
//import com.qzsoft.common.exception.NoLoginException;
//import com.qzsoft.common.tools.LoginTokenUtil;
//import com.qzsoft.lims.ks.eum.SysModeEnum;
//import com.qzsoft.lims.ks.service.LoginService;
//import com.qzsoft.lims.ks.service.TokenService;
//import com.qzsoft.common.tools.ThreadLocalUtil;
//import com.qzsoft.lims.ks.util.UserDataUtil;
//import lombok.extern.java.Log;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.servlet.ModelAndView;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.HashSet;
//import java.util.Map;
//import java.util.Set;
//
///**
// * @author pjh
// * @Title: LoginAuthInterceptor
// * @Description: TODO
// * @date 2018/8/6 14:56
// */
//@Log
//@Component
//public class LoginAuthInterceptor implements HandlerInterceptor {
//
//    @Value("${ks.sysParam.sysMode:}")
//    public String sysMode;
//
//    @Value("${ks.sysParam.devJID:}")
//    public String devJID;
//
//
//    @Value("${outsys.lims.tu.userInfoUrl:}")
//    private String userInfoUrl;
//
//    @Autowired
//    TokenService tokenService;
//
//    @Autowired
//    private LoginService loginService;
//
//    private static final Set<String> noNeedCheckSet = new HashSet();
//    {
//        noNeedCheckSet.add("/cptfile/.*");
//        noNeedCheckSet.add("/swagger-resources/.*");
//        noNeedCheckSet.add("/v2/api-docs/.*");
//        noNeedCheckSet.add("/synConfig/localSysConfigDatas");
//        noNeedCheckSet.add("/synConfig/localKsTableDatas");
//    }
//
//    public String splitString(String str, String temp) {
//        String result = null;
//        if (str.indexOf(temp) != -1) {
//            if (str.substring(str.indexOf(temp)).indexOf("&") != -1) {
//                result = str.substring(str.indexOf(temp)).substring(str.substring(str.indexOf(temp)).indexOf("=") + 1,
//                        str.substring(str.indexOf(temp)).indexOf("&"));
//            } else {
//                result = str.substring(str.indexOf(temp)).substring(str.substring(str.indexOf(temp)).indexOf("=") + 1);
//
//            }
//        }
//        return result;
//    }
//
//    @Override
//    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
//
//        //开发模式  取开发模式jid 直接返回true
//        if( SysModeEnum.dev.name().equals( sysMode ) ){
//            LoginTokenUtil.getUserInfo(userInfoUrl, devJID);
//            ThreadLocalUtil.set( "JID", devJID );
//            UserDataUtil.setLoginNa( "admin" );
//            UserDataUtil.setUserName(  "admin" );
//            UserDataUtil.setUsId( 1L );
//            return true;
//        }
//
//        String JID= request.getParameter("JID");
//        String userData = getUserDataFromRemote(JID);
//        if( StringUtils.isBlank(userData) ){
//            NoLoginException.throwBiz(10002);
//        }
//        String requestURI = request.getServletPath();
//        for( String noNeedCheck: noNeedCheckSet ){
//        	if( requestURI.matches(  noNeedCheck ) ){
//                ThreadLocalUtil.set( "JID", JID );
//        		return true;
//        	}
//        }
//
//        Map<String, Object> objMap = JSON.parseObject(userData);
//        if( objMap==null || !objMap.get("resultCode").equals("SUCCESS")){
//            String error = ((JSONObject) objMap).getString("error");
//            String errorCode = ((JSONObject) objMap).getString("errorCode");
//            String redirectUrl = ((JSONObject) objMap).getString("redirectUrl");
//            return noAuthRespose( request, response,error,errorCode,redirectUrl );
//        }
//        ThreadLocalUtil.set( "JID", JID );
//        return true;
//    }
//
//    private String getUserDataFromRemote(String JID) {
//        //有jid去刷新jid有效期
////            userInfoUrl= "http://192.168.2.24:33604/tu-prj/cu/getUserInfoByToken";
//        String userData = LoginTokenUtil.getUserInfo(userInfoUrl, JID );
//        if( StringUtils.isBlank(userData) ){
//            return null;
//        }
//        JSONObject userInfo = JSONObject.parseObject(userData);
//        String loginNa = userInfo.getString("loginNa");
//        String usNa = userInfo.getString("usNa");
//        UserDataUtil.setLoginNa( loginNa );
//        UserDataUtil.setUserName(  usNa );
//        UserDataUtil.setUsId( userInfo.getLong( "id" ) );
////            Map<String,Object> resultMap = loginService.findEnvMap(JID);
////            System.out.println( resultMap );
////            MycatDispatchChannel.setDispatchChannel( "/*!mycat:schema=lims_0001*/" );
//        return userData;
//    }
//
//    private boolean noAuthRespose(HttpServletRequest request, HttpServletResponse response,String error,String errorCode,String redirectUrl) throws IOException {
////        String userLoginUrl = ConfigUtil.getPropertyValue("http.limsx");
//        String accessToken= request.getParameter("accessTokenLock");
//        if(StringUtils.isNotBlank( accessToken )){
//            tokenService.recoverToken( accessToken );
//        }
//        JSONObject res = new JSONObject();
//        res.put("code","-1");
//        res.put("error",error );
//        res.put("resultCode",errorCode );
//        res.put("payload",null);
//        res.put("redirectUrl",redirectUrl );
//        response.setHeader("Access-Control-Allow-Origin", "*");
//        response.setCharacterEncoding("UTF-8");
//        response.setContentType("application/json; charset=utf-8");
//        PrintWriter out = response.getWriter();
//        out.append(res.toString());
//        return false;
//    }
//
//    @Override
//    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) {
//
//    }
//
//    @Override
//    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
//
//    }
//
//}
