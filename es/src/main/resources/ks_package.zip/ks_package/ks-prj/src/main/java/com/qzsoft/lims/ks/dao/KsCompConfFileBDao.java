package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
/**
 * 组件文件管理-dao接口
 * @author hqp
 *
 */
public interface KsCompConfFileBDao {
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	Boolean save(Record record);
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	
	/**
	 * 删除
	 * @param infoCode INFO编码
	 * @return
	 */
	Boolean deleteByInfoCode(String infoCode);
	
	/**
	 * 根据INFO编码查询
	 * @return
	 */
	List<Record> getListByInfoCode(String infoCode);
	
	/**
	 * 根据组件编码查询
	 * @return
	 */
	Record getOneByCompCode(String compCode);
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	Record getOne(Long id);
}
