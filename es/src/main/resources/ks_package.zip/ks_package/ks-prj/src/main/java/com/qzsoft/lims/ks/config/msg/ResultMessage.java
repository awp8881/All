package com.qzsoft.lims.ks.config.msg;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResultMessage implements Serializable {
    private int code;
    private String message = "";
    private Object data;

    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return this.data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public ResultMessage(int code) {
        this.code = code;
    }

    protected ResultMessage(int code, String message) {
        this.code = code;
        this.message = message;
    }

    protected ResultMessage(int code, String message, Object data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public boolean isOK() {
        return this.getCode() == 1;
    }

    public static ResultMessage buildOK() {
        return new ResultMessage(1);
    }

    public static ResultMessage buildOK(Object data) {
        return new ResultMessage(1, "", data);
    }

    public static ResultMessage buildError(String msg) {
        return new ResultMessage(0, msg);
    }

    public static ResultMessage buildError(int code, String msg) {
        return new ResultMessage(code, msg);
    }

    public static ResultMessage buildError(int code, String msg, Object data) {
        return new ResultMessage(code, msg, data);
    }
}

