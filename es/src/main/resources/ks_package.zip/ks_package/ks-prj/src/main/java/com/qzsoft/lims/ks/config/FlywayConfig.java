package com.qzsoft.lims.ks.config;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DataSourceHolder;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.UIDGenerator;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.util.TableHelper;
import lombok.extern.slf4j.Slf4j;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import javax.annotation.PostConstruct;
import java.util.*;

/**
 * date: 2021-08-20
 * author: lzy
 * use: flyway加载脚本
 */
@Slf4j
@Configuration
@DependsOn("activeRecordPluginConfig")
@AutoConfigureOrder()
public class FlywayConfig {

    private final String SQLSERVER_SQL_PATH ="classpath:db/migration/sqlserver";
    private static String SQL_PATH = "classpath:db/migration/mysql";

    @Autowired
    ActiveRecordPluginConfig activeRecordPluginConfig;

    private static  final  Map<String,Object> datasourcePropertyMaps = Maps.newHashMap();
    public static Map<String, Object> getDatasourcePropertyMaps() {
        return datasourcePropertyMaps;
    }
    /**
     * 执行flyway
     */
    @PostConstruct
    public void migrate( ){
        Map<String,Object> datasourcePropertyMap = DataSourceHolder.getDbProperty();
        datasourcePropertyMaps.putAll(datasourcePropertyMap);
        //暂不开放mysql和sqlserver外的其他数据库
        if(!isMysql(datasourcePropertyMap) && !isSqlserver(datasourcePropertyMap)) return;
//        if(isSqlserver(datasourcePropertyMap)) SQL_PATH = SQLSERVER_SQL_PATH;
        if(isSqlserver(datasourcePropertyMap)) return;
        preRebuildBaseData();
        Flyway flyway = Flyway.configure()
                .dataSource((String) datasourcePropertyMap.get("url"), (String) datasourcePropertyMap.get("username"),(String) datasourcePropertyMap.get("password"))
                .locations(SQL_PATH)
                .baselineOnMigrate(true)
                .cleanDisabled(true)
                .load();

        try {
            flyway.migrate();
        } catch (final Exception e) { //如果migrate失败，则可以尝试进行repair
            log.error("异常：Flyway migration failed, doing a repair and retrying ...{}",e.toString());
            flyway.repair();
            flyway.migrate();
        }finally {
            flyway.repair();
        }
    }

    /**
     * 清空外部组件表，通过flyway脚本重新初始化,保证配置信息保存最新
     */
    private void preRebuildBaseData(){
        try {
            Db.delete("delete from ks_table_self_a" );
            Db.delete("delete from ks_comp_b" );
            Db.delete("delete from ks_comp_act_b" );
            Db.delete("delete from ks_comp_para_def_b" );
            Db.delete("delete from ks_sys_mana_c" );
            Db.delete("delete from flyway_schema_history" );
        } catch (Exception e) {
            log.warn("不存在flyway_schema_history表");
        }
        // 删除过程创建的废表
        doDropTable("ks_opt_log_diff_g");
        doDropTable("ks_model_info_field_c");
        doDropTable("ks_menu_model_c");
        doDropTable("ks_menu_logic_info_c");
        doDropTable("ks_info_search_c");
        doDropTable("ks_dic_c");
        doDropTable("ks_sys_syn_c");
        doDropTable("ks_sys_syn_note_c");

        handleKsTableSelf("ks_");
        handleKsTableSelf("cu_");
        handleKsTableSelf("kb_");
        handleKsTableSelf("sz_");
    }

    private void doDropTable(String tableName) {
        try {
            Db.delete("drop table "+tableName );
        } catch (Exception e) {
            log.warn("删除多余表，{}表不存在",tableName);
        }
    }

    /**
     * 扫描表结构字段，初始化入ks_table_self_a表
     * @param preStr
     */
    private static void handleKsTableSelf(String preStr){
        LinkedHashMap<String,String> map = TableHelper.getTableInfoByNotStartAs(preStr, YnEnum.Y.name());
        Set<Map.Entry<String,String>> set = map.entrySet();
        List<Record> records = Lists.newArrayList();
        for(Map.Entry<String,String> entry : set){
            String table = entry.getKey();

            List<Record> columns =  DbEx.getColMetaByTableName(table );
            for (Iterator<Record> iterator = columns.iterator(); iterator.hasNext(); ) {
                Record next =  iterator.next();
                Record record = new Record();
                record.set("t_name", table).set("field_name", next.getStr("Field"))
                        .set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1").set("id", UIDGenerator.getUID() );

                records.add(record);
            }
        }
        Db.batchSave("ks_table_self_a", records, records.size());
    }

    /**
     * flyway自动执行脚本对mysql开放
     * @param datasourcePropertyMap
     * @return
     */
    private boolean isMysql(Map<String, Object> datasourcePropertyMap) {
        String driverClassName = (String)datasourcePropertyMap.get("driverClassName");
        return driverClassName.contains("mysql");
    }

    /**
     * flyway自动执行脚本对sqlserver开放
     * @param datasourcePropertyMap
     * @return
     */
    public static boolean isSqlserver(Map<String, Object> datasourcePropertyMap ){
        String driverClassName = (String)datasourcePropertyMap.get("driverClassName");
        return driverClassName.contains("sqlserver");
    }
}
