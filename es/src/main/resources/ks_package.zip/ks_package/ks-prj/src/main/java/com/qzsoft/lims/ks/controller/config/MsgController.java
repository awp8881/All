package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.msg.conf.MsgConfService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Api(value = "消息", tags = "消息")
@RestController
@RequestMapping("/msg")
@Slf4j
public class MsgController {

    @Autowired
    private MsgConfService msgConfService;

    @ApiOperation(value = "消息配置列表")
    @GetMapping("/getPageList")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getPageList(
            @RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
            @RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {

        RequestResult<Map<String, Object>> result = msgConfService.getPageList(pageNum, pageSize);
        return result;
    }

    @ApiOperation(value = "消息详情")
    @GetMapping("/getMsg")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getMsg(@RequestParam(value = "id") Long id) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj(msgConfService.getMsg( id ));
        return result;
    }

    @ApiOperation(value = "消息保存")
    @PostMapping("/saveMsg")
    @ResponseAddHead
        public RequestResult<Boolean> saveMsg(@RequestParam(value = "msgData") String msgDataStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(msgConfService.saveMsg( msgDataStr ));
        return result;
    }

    @ApiOperation(value = "删除")
    @PostMapping("/delete")
    @ResponseAddHead
        public RequestResult<Boolean> delete(@RequestParam(value = "id") Long id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(msgConfService.deleteMsg( id ));
        return result;
    }
}
