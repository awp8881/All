package com.qzsoft.lims.ks.controller;


import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.project.SysParaBService;
import com.qzsoft.lims.ks.vo.KsSysParamBVO;
import com.qzsoft.lims.ks.vo.ProjectParamTreeVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "系统参数", tags = "系统参数，表：sys_para_b")
@RestController
@RequestMapping("/projectParam")
@Slf4j
public class KsSysParaBController {

    @Autowired
    SysParaBService sysParaBService;

    @ApiOperation(value = "获取工程列表")
    @GetMapping("/listProject")
        @ResponseAddHead
    public RequestResult<KsSysParamBVO> listProject( ){
        List<KsSysParamBVO> ksSysParamBVOList = sysParaBService.listProject();
        RequestResult<KsSysParamBVO> requestResult = new RequestResult<>( );
        requestResult.setList( ksSysParamBVOList );
        return requestResult;
    }

    @ApiOperation(value = "根据id获取工程列表")
    @GetMapping("/getProject")
        @ResponseAddHead
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="配置id",required=false,dataType="long",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID",required=false,dataType="string",paramType="query")
    })
    public RequestResult<KsSysParamBVO> getProject( Long id ){
        KsSysParamBVO ksSysParamBVO = sysParaBService.getProject( id );
        RequestResult<KsSysParamBVO> requestResult = new RequestResult<>( );
        requestResult.setObj( ksSysParamBVO );
        return requestResult;
    }

    @ApiOperation(value = "保存工程  id值不为空表示更新   为空表示新增")
    @PostMapping("/saveProject")
        @ResponseAddHead
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="配置id",required=false,dataType="long",paramType="query"),
            @ApiImplicitParam(name="conf_type",value="配置类型",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="conf_val",value="配置值",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="remark",value="配置备注",required=false,dataType="string",paramType="query")
    })
    public RequestResult<KsSysParamBVO> saveProject( KsSysParamBVO ksSysParamBVO ){
        KsSysParamBVO newKsSysParamBVO = sysParaBService.saveProject( ksSysParamBVO );
        RequestResult<KsSysParamBVO> requestResult = new RequestResult<>( );
        requestResult.setObj( newKsSysParamBVO );
        return requestResult;
    }

    @ApiOperation(value = "删除工程")
    @PostMapping("/delProject")
    @ResponseAddHead
        @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="项目id",required=true,dataType="long",paramType="query")
    })
    public RequestResult<Boolean> delProject( @RequestParam(value = "id") Long id ){
        Boolean success =  sysParaBService.delProject( id );
        RequestResult<Boolean> requestResult = new RequestResult<>( );
        requestResult.setObj( success );
        return requestResult;
    }

    @ApiOperation(value = "获取可用菜单")
    @GetMapping("/canableItem")
    @ResponseAddHead
        @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="项目id",required=true,dataType="long",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query")
    })
    public RequestResult<ProjectParamTreeVO> canableItem(@RequestParam(value = "id") Long id ){
        List<ProjectParamTreeVO> projectParamTreeVOLisst = sysParaBService.canableItem( id );
        RequestResult<ProjectParamTreeVO> requestResult = new RequestResult<>( );
        requestResult.setList( projectParamTreeVOLisst );
        return requestResult;
    }

}
