package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsSqlButtonParaBDao;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 按钮激活条件参数配置列表
 */
@Repository
public class KsSqlButtonParaBDaoImpl extends BaseDaoImpl implements KsSqlButtonParaBDao{
	private static final String TABLE_NAME_B = "ks_sql_button_para_b";
	private static final String TABLE_NAME_C = "ks_sql_button_para_c";
	/**
	 * 按钮激活条件参数配置列表
	 */
	@Override
	public List<Record> getButtonParaList(String button_code, String m_code_type) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		String sql="select * from "+table+" where button_code=? order by para_order+0";
		List<Record> recordList = DbEx.find(sql,button_code);
		return recordList;
	}
	
	@Override
	public List<Record> getButtonParaList(String m_code,String info_code,String m_code_type) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		String sql = "select * from "+table+" where 1=1 ";
		List<String> list = new ArrayList<>();
		if(StringUtils.isNotBlank(m_code)){
			sql+=" and m_code=? and (info_code is null or info_code ='') ";
			list.add(m_code);
		} 
		if(StringUtils.isNotBlank(info_code)){
			sql+=" and info_code=? ";
			list.add(info_code);
		}
		sql+=" order by para_order+0";
		List<Record> recordList = DbEx.find(sql,list.toArray());
		return recordList;
	}

	/**
	 * 删除后批量插入
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> allParaList,Integer isSaveAs,String old_m_code,String info_code,String menu_id) {
		boolean isSucc=true;
		String table= isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
		String code = StringUtils.isNotBlank(info_code) ? info_code : old_m_code;
		if (StringUtils.isBlank(code)){
			return isSucc;
		}
		String buttonParaSql="delete from "+table+" where locate(?,button_code)>0 ";
		DbEx.delete(buttonParaSql,code);
		if (null == allParaList || allParaList.isEmpty()){
			return  isSucc;
		}
		List<Record> recordList=DataBaseUtil.map2Record(allParaList);
		for(Record record : recordList){
			record.set("menu_id", menu_id);
		}
		isSucc= super.saveList(table, recordList);
		return isSucc;
	}

	@JFinalTx
	@Override
	public Boolean saveGroupCondParas(List<Map<String, Object>> condParas, Integer isSaveAs, String pMCode, String infoCode) {
		boolean isSucc = true;
		String table= isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
		String code = StringUtils.isNotBlank(infoCode) ? infoCode : pMCode;

		if (StringUtils.isBlank(code)){
			return isSucc;
		}
		String buttonParaSql = "delete from "+table+" where locate(?,button_code)>0 ";
		DbEx.delete(buttonParaSql,code);
		if (null == condParas || condParas.isEmpty()){
			return  isSucc;
		}
		List<Record> recordList = DataBaseUtil.map2Record(condParas);
		return super.saveList(table, recordList);
	}
}
