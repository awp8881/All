package com.qzsoft.lims.ks.config;


import com.qzsoft.common.exception.BusinessException;
import lombok.Data;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "ks")
@Data
public class BaseDomainsConfig {

    private List<BaseDomain> baseDomains;
    private static Map<String, BaseDomain> baseDomainsMap;

    @Data
    public static class BaseDomain {
        String domainId;
        String domainServer;
    }

    public String getDomain(String domainId) {
        if (baseDomains == null||baseDomains.isEmpty()) {
            BusinessException.throwBiz(" 请在yml文件中{ks.baseDomains}配置数据域 ");
        }
        if (baseDomainsMap == null) {
            synchronized (BaseDomainsConfig.class) {
                if (baseDomainsMap == null) {
                    baseDomainsMap = new HashMap<>();
                    for (BaseDomain baseDomain : baseDomains) {
                        baseDomainsMap.put(baseDomain.getDomainId(), baseDomain);
                    }
                }
            }
        }
        BaseDomain baseDomain = baseDomainsMap.get(domainId);
        if (baseDomain != null) {
            return baseDomain.getDomainServer();
        }
        //如果不存在返回默认域
        return baseDomains.get(0).domainServer;
    }


}
