package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;

import java.util.List;
import java.util.Map;

public interface KsModelDynSqlParaBDao {

    //动态sql参数
    List<Record> getByPCode(String pCode);

    //保存动态sql参数
    boolean saveDynSql(List<Map<String,Object>> allDynParaList, String pCode);

    boolean saveDynPara(List<Map<String,Object>> allDynParaList, String dynCode);

    List<Record> getByDynCode(String dynCode);
}
