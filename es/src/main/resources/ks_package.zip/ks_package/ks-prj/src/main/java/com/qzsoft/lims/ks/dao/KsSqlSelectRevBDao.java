package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.logic.KsLogicConfigVO;

/**
 * select条件用于装载大列表时的-反显数据条件
 * @author zlx
 * @date 2019/03/28
 */
public interface KsSqlSelectRevBDao extends BaseDao {
	
	/**
	 * 反显条件列表
	 * @param rev_code
	 * @return
	 */
	List<Map<String, Object>>  getByRevCode(String rev_code);

	/**
	 * 根据mcode查询信息
	 * @param mCode
	 * @return
	 */
	List<Map<String, Object>> getBymCode(String mCode);

	/**
	 * 条件保存
	 */
    boolean saveRevCond(List<Map<String, Object>> allSqlCondList, String newRevCode, String newCode, String oldCode, String menuId);

	List<List<Map<String, Object>>> getGroupConds( String mCode );

	Boolean saveGroupConds( List<List<Map<String, Object>>> groupConds, String newRevCode, String newMCode,
							String oldMCode, String menuId);

}
