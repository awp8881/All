package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.dao.port.KsPortReturnDao;
import com.qzsoft.lims.ks.service.PortConfigService;
import com.qzsoft.lims.ks.vo.KsPortDicBVO;
import com.qzsoft.lims.ks.vo.KsPortDicParaBVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * 接口管理配置-控制器
 * @author zf
 */

@Api(value = "接口管理配置", tags = "接口管理配置")
@RestController
@RequestMapping("/portConfig")
@Slf4j
@TagResource("接口管理配置")
public class PortConfigController {
	
	@Autowired
	private PortConfigService portConfigService;

	@Autowired
	private KsPortReturnDao ksPortReturnDao;
	
	@ApiOperation(value="动作保存")
	@PostMapping("/saveAction")
	@ResponseAddHead
	@TagResource("动作保存")
		public RequestResult<Map<String,Object>> saveAction(KsPortDicBVO ksPortDicBVO) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setObj(portConfigService.saveAction(ksPortDicBVO));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveAction()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveAction()", e);
		}
		return result;

	}
	
	@ApiOperation(value="动作参数保存")
	@PostMapping("/saveActionPara")
	@ResponseAddHead
	@TagResource("动作参数保存")
		public RequestResult<Map<String,Object>> saveActionPara(KsPortDicParaBVO ksPortDicParaBVO) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setObj(portConfigService.saveActionPara(ksPortDicParaBVO));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveActionPara()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveActionPara()", e);
		}
		return result;

	}
	
	@ApiOperation(value="动作类型删除")
	@PostMapping("/batchDeleteActionType")
	@ResponseAddHead
	@TagResource("动作类型删除")
		@ApiImplicitParam(name="ids",value="主键多个逗号隔开:1,2",required=true,dataType="String",paramType="query")
	public RequestResult<Boolean> batchDeleteActionType(@RequestParam(value="ids") String ids) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			result.setObj(portConfigService.batchDeleteActionType(ids));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".batchDeleteActionType()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".batchDeleteActionType()", e);
		}
		return result;

	}
	
	@ApiOperation(value="动作删除")
	@PostMapping("/batchDeleteAction")
	@ResponseAddHead
	@TagResource("动作删除")
		@ApiImplicitParam(name="ids",value="主键多个逗号隔开:1,2",required=true,dataType="String",paramType="query")
	public RequestResult<Boolean> batchDeleteAction(@RequestParam(value="ids") String ids) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			result.setObj(portConfigService.batchDeleteAction(ids));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".batchDeleteAction()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".batchDeleteAction()", e);
		}
		return result;

	}
	
	@ApiOperation(value="动作参数删除")
	@PostMapping("/batchDeleteParam")
	@ResponseAddHead
	@TagResource("动作参数删除")
		@ApiImplicitParam(name="ids",value="主键多个逗号隔开:1,2",required=true,dataType="String",paramType="query")
	public RequestResult<Boolean> batchDeleteParam(@RequestParam(value="ids") String ids) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			result.setObj(portConfigService.batchDeleteParam(ids));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".batchDeleteParam()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".batchDeleteParam()", e);
		}
		return result;

	}

	@ApiOperation(value = "接口返回参数模板")
	@GetMapping("/getPortReturnTemp")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getPortReturnTemp(@RequestParam(value="dicPortCode") String dicPortCode) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList( ksPortReturnDao.getPortReturnTemp( dicPortCode ));
		return result;
	}

	@ApiOperation("接口配置导出")
	@PostMapping("/exportPortConfig")
	@ResponseAddHead
	@TagResource("接口配置导出")
		public void exportPortConfig(@RequestParam(value="ids") String ids, HttpServletResponse response) {

		try {
			String portDatas = portConfigService.exportPortConfig(ids);

			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write( portDatas);
		} catch (IOException e) {
			log.error( e.getMessage());
		}
	}

	@ApiOperation(value = "接口配置导入")
	@PostMapping("/importPortConfig")
	@ResponseAddHead
		public RequestResult<Boolean> importMenuJson(@RequestParam("file") MultipartFile file, @RequestParam(value="id") Long id) {
		RequestResult<Boolean> result = new RequestResult<>();
		boolean importYn = portConfigService.importPortConfig( file, id );
		result.setObj(importYn);
		return result;
	}

	@ApiOperation(value = "接口获取")
	@GetMapping("/getPortData")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getPortData(@RequestParam(value="portCode" , required = false) String portCode,
													  @RequestParam(value="mCodeType") String mCodeType) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setObj( portConfigService.getPortData( portCode, mCodeType ));
		return result;
	}

	@ApiOperation(value = "接口保存")
	@PostMapping("/savePortData")
	@ResponseAddHead
	@TagResource("接口保存")
		public RequestResult<String> savePortData(@RequestParam(value="portCode", required = false) String portCode,
											  @RequestParam(value="mCodeType") String mCodeType,
											  @RequestParam(value="portDataStr") String portDataStr,
											  @RequestParam(value="menuId") String menuId) {
		RequestResult<String> result = new RequestResult<>();
		result.setObj( portConfigService.savePortData( portCode, mCodeType, portDataStr, menuId ));
		return result;
	}

	@ApiOperation(value = "清除")
	@PostMapping("/clear")
	@ResponseAddHead
	@TagResource("清除")
		public RequestResult<Boolean> clear() {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( portConfigService.clear());
		return result;
	}

	@ApiOperation(value = "校验接口参数")
	@PostMapping("/validatePort")
	@ResponseAddHead
		public RequestResult<Boolean> validatePort(@RequestParam(value="portDataStr") String portDataStr) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( portConfigService.validatePort( portDataStr ));
		return result;
	}
}
