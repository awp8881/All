package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.KsTableCVO;

/**
 * @auther: puzhiqiang
 * @date: 2018/5/19 15:51
 * @description:
 */
public interface KsTableCDao extends BaseDao{
	
	/**
	 * 列表分页查询
	 * @param ksTableCVO
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	Page<Record> getPageList(KsTableCVO ksTableCVO,Integer pageNum,Integer pageSize);
	
	/**
	 * 获取详情
	 * @param tableCId
	 * @return
	 */
	Map<String,Object> getOne(Long tableCId);
	
	List<Map<String, Object>> getList(KsTableCVO ksTableCVO);

	/**
	 * 关联保存表关系
	 * @param tParName
	 * @param tParDesc
	 * @return
	 */
	Boolean saveByLink( String tParName, String tParDesc, String sqlPrn, String sqlName, Boolean isEdit);

}
