package com.qzsoft.lims.ks.dao;

import com.qzsoft.common.dao.BaseDao;

/** 
 * 系统配置：系统自动化SQL语句
 * 创建时间:2018-09-13 15:01:00 
 */ 
public interface KsModelInfoFieldValBDao  extends BaseDao {



}
