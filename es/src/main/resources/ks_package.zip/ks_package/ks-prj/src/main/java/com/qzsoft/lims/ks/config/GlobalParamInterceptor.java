package com.qzsoft.lims.ks.config;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.KsVerifyException;
import com.qzsoft.common.tools.ThreadLocalUtil;
import com.qzsoft.common.vo.KsUserInfo;
import com.qzsoft.lims.ks.constants.Constant;
import com.qzsoft.lims.ks.eum.GroupTypeEnum;
import com.qzsoft.lims.ks.eum.SysModeEnum;
import com.qzsoft.lims.ks.service.TokenService;
import com.qzsoft.lims.ks.util.GlobalDataUtil;
import com.qzsoft.lims.ks.util.JWTUtil;
import com.qzsoft.lims.ks.util.UserDataUtil;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.BoundValueOperations;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author pjh
 * @Title: LoginAuthInterceptor
 * @Description: TODO
 * @date 2018/8/6 14:56
 */
@Slf4j
@Component
public class GlobalParamInterceptor implements HandlerInterceptor {

    @Value("${ks.sysParam.sysMode:}")
    public String sysMode;

    @Value("${ks.sysParam.devJID:}")
    public String devJID;


    @Value("${outsys.lims.tu.userInfoUrl:}")
    private String userInfoUrl;

    @Autowired
    TokenService tokenService;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    private final static String USER_ROLES = "cu_us_ro_s";


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o){
        if (checkPermission(request,o)){
            KsVerifyException.throwBiz(-10012,"该功能禁止访问");
        }

        //开发模式  取开发模式jid 直接返回true
        if( SysModeEnum.dev.name().equals( sysMode ) ){
            ThreadLocalUtil.set( "JID", devJID );
            UserDataUtil.setLoginNa( "admin" );
            UserDataUtil.setUserName(  "admin" );
            UserDataUtil.setUsId( 1L );
            return true;
        }
        String jid =  StringUtils.isBlank( request.getHeader("JID") ) ? request.getParameter("JID") : request.getHeader("JID");
        log.debug("JID参数：{}", jid);
        ThreadLocalUtil.set( "JID", jid );
        String menuId = request.getHeader("ksMenuId");
        if (StringUtils.isNotBlank( menuId)){
            GlobalDataUtil.setMenuId( menuId );
        }

        if(JWTUtil.validJWT( jid )){
            Claims claims = JWTUtil.parseJWT(jid);
            UserDataUtil.setLoginNa( JWTUtil.getLoginNa(claims) );
            UserDataUtil.setUserName( JWTUtil.getUserName( claims ) );
            UserDataUtil.setUsId( Long.parseLong( JWTUtil.getUserId( claims ) )  );
//            String tenantId = JWTUtil.getTenantId(claims);
//            String dispatchChannel = MycatDispatchChannel.buildDispatchChannel( () -> {
//                if(StringUtils.isNotBlank( tenantId )){
//                    return "/*!mycat:schema=tenant_"+tenantId+"*/";
//                }else{
//                    return "";
//                }
//            } );
//            log.info("构建选择通道:{}", dispatchChannel);
        }
        return true;
    }

    /**
     * 校验权限接口,反向验证是否勾选禁止访问
     * 由于该功能颗粒度在接口层且需要开发者加上注解
     * @param request
     * @return
     */
    private boolean checkPermission(HttpServletRequest request,Object obj){
        String res = request.getRequestURI();
        KsUserInfo userInfo = new KsUserInfo();
        String token =  StringUtils.isBlank( request.getHeader("token") ) ? request.getParameter("token") : request.getHeader("token");

        // 1 仅拦截被注解标记的接口
        if (obj instanceof HandlerMethod){
            HandlerMethod handlerMethod = (HandlerMethod) obj;
            Method method = handlerMethod.getMethod();
            // 在无感登录校验前判断是否登录ks,如果登录先存储进缓存
            if (StringUtils.isNotBlank(token)){
                String userInfoStr = (String) redisTemplate.opsForValue().get(Constant.USER_LOGIN_TOKEN + token);
                userInfo = JSON.parseObject(userInfoStr, KsUserInfo.class);
                if (Objects.nonNull(userInfo) && StringUtils.isNotBlank(userInfo.getUser_name())){
                    userInfo.setRequestURI(res);
                    ThreadLocalUtil.set(Constant.USER_INFO,userInfo);
                }
            }
            // 检查权限标记接口，没有则跳过认证
            if (!method.isAnnotationPresent(TagResource.class)) {
                return false;
            }
        } else {
            // 非HandlerMethod类型则是静态页等,跳过
            return false;
        }

        // 2.获取当前JID封装角色为管理员，跳过检查
        String jid =  StringUtils.isBlank( request.getHeader("JID") ) ? request.getParameter("JID") : request.getHeader("JID");
        if (JWTUtil.validJWT(jid)) {
            Claims claims = JWTUtil.parseJWT(jid);
            // 获取角色信息
            String loginNa = JWTUtil.getLoginNa(claims);
            if (CommonConstants.ADMIN.equals(loginNa)) {
                ThreadLocalUtil.set(CommonConstants.ADMIN, true);
                // 打开无感登录开关,直接返回
                if (getConfByRedis()) {
                    return false;
                }
            }
        }
        AtomicBoolean flag = new AtomicBoolean(false);
        //3.获取请求接口名和token
        if (StringUtils.isBlank(token)){
            KsVerifyException.throwBiz(-11013,"用户登录数据过时，请重新登录");
        }
        // 3.1解析token中的用户数据
        // 检查上方是否构造完成
        if (ObjectUtil.isNull(userInfo)){
            String userInfoStr = (String) redisTemplate.opsForValue().get(Constant.USER_LOGIN_TOKEN + token);
            userInfo = JSON.parseObject(userInfoStr, KsUserInfo.class);
        }
        if (ObjectUtil.isNull(userInfo)){
            KsVerifyException.throwBiz(-11013,"用户登录数据过时，请重新登录");
        }
        userInfo.setRequestURI(res);
        ThreadLocalUtil.set(Constant.USER_INFO,userInfo);
        // 刷新token时长
        refreshToken(token);
        // 3.2 标记用户类型
        // 标记用户是否是超级管理员权限，为了配置资源页是否展示 (这里没有放入userInfo是因为需要在入口处判断jid然后标记，此时userinfo暂无数据)
        ThreadLocalUtil.set(CommonConstants.ADMIN, String.valueOf(GroupTypeEnum.SUPERADMIN.getCode()).equals(userInfo.getGroup_type()));
        // 3.3 判断用户资源,匹配到资源禁止访问
        List<String> resUrl = userInfo.getRes_url();
        if (CollUtil.isNotEmpty(resUrl)){
            for (String url : resUrl) {
                if (isMatch(url,res)){
                    flag.set(true);
                    break;
                }
            }
        }
        return flag.get();
    }


    /**
     * token续签时长方法判断
     * @param token
     */
    private void refreshToken(String token){
        BoundValueOperations<Object, Object> ops = redisTemplate.boundValueOps(Constant.USER_LOGIN_TOKEN + token);
        Long expire = ops.getExpire();
        // 当时长小于1/3时自动续期
        if (expire < Constant.TOKEN_REFRESH_TIME){
            ops.expire(Constant.TOKEN_EXPIRE_TIME, TimeUnit.SECONDS);
        }
    }

    /**
     *
     * @return
     */
    private Boolean getConfByRedis() {
        try {
            Record record;
            record = (Record) redisTemplate.boundValueOps(Constant.KS_SYS_CONF_B + Constant.ADMINISTRATORSWITCH).get();
            if (Objects.isNull(record)) {
                // 查询系统参数配置 为管理员无需登录
                record = DbEx.findFirst("select conf_val from ks_sys_conf_b where conf_type = ?",Constant.ADMINISTRATORSWITCH);
                // 此处必定有值，如果没有那么就每次从db取
                redisTemplate.boundValueOps(Constant.KS_SYS_CONF_B + Constant.ADMINISTRATORSWITCH).set(record);
            }
            if (Objects.nonNull(record)){
                String confVal = record.getStr("conf_val");
                if (StringUtils.isNotBlank(confVal)){
                    JSONObject js = JSONObject.parseObject(StringEscapeUtils.unescapeJson(confVal));
                    String value = (String) js.getJSONArray("value").get(Constant.COMMON_ZERO);
                    if (StringUtils.isNotBlank(value) && value.equals(Constant.COMMON_VALID)) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            log.error("获取redis数据出错");
        }
        return false;
    }

    /**
     * 判断url是否与规则配置:
     * ? 表示单个字符
     * * 表示一层路径内的任意字符串，不可跨层级
     * ** 表示任意层路径
     * @param url     匹配规则
     * @param urlPath 需要匹配的url
     * @return
     */
    public static boolean isMatch(String url, String urlPath) {
        AntPathMatcher matcher = new AntPathMatcher();
        return matcher.match(url, urlPath);
    }


//    private boolean noAuthRespose(HttpServletRequest request, HttpServletResponse response,String error,String errorCode,String redirectUrl) throws IOException {
////        String userLoginUrl = ConfigUtil.getPropertyValue("http.limsx");
//        String accessToken= request.getParameter("accessTokenLock");
//        if(StringUtils.isNotBlank( accessToken )){
//            tokenService.recoverToken( accessToken );
//        }
//        JSONObject res = new JSONObject();
//        res.put("code","-1");
//        res.put("error",error );
//        res.put("resultCode",errorCode );
//        res.put("payload",null);
//        res.put("redirectUrl",redirectUrl );
//        response.setHeader("Access-Control-Allow-Origin", "*");
//        response.setCharacterEncoding("UTF-8");
//        response.setContentType("application/json; charset=utf-8");
//        PrintWriter out = response.getWriter();
//        out.append(res.toString());
//        return false;
//    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        ThreadLocalUtil.remove();
    }

}
