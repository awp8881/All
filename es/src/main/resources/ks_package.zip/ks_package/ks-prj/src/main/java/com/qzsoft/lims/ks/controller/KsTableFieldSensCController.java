package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsTableFieldSensCService;
import com.qzsoft.lims.ks.vo.KsTableCVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * @author pjh
 * @Title: KsTableFieldSensCController
 * @Description: TODO
 * @date 2018/10/27 10:12
 */
@Api(value = "敏感表配置", tags = "敏感表配置")
@RestController
@RequestMapping("/sens")
@Slf4j
public class KsTableFieldSensCController {

    @Autowired
    KsTableFieldSensCService ksTableFieldSensCService;

    @ApiOperation(value = "获取敏感表配置列表",notes="获取敏感表配置列表")
    @GetMapping("/findSensConfAllList")
    @ResponseAddHead
        public RequestResult<List> findSensConfList( ) {

        RequestResult<List> result = new RequestResult<>();
        List<Map<String, Object>> sensConfList = ksTableFieldSensCService.findSensConfList();
        result.setObj( sensConfList );
        return result;
    }

    @ApiOperation(value = "获取敏感表配置",notes="获取敏感表配置")
    @GetMapping("/findSensConfList")
    @ResponseAddHead
        public RequestResult<List> findSensConf( @RequestParam("t_name")String t_name ) {

        RequestResult<List> result = new RequestResult<>();
        List<Map<String, Object>> sensConfList = ksTableFieldSensCService.findSensConf( t_name );
        result.setObj( sensConfList );
        return result;
    }

    @ApiOperation(value = "保存敏感表配置",notes="保存敏感表配置")
    @RequestMapping("/saveSensConf")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> saveSensConf( @RequestParam(value = "id",required = false)Long id,
                                                            @RequestParam("t_name")String t_name,
                                                            @RequestParam("field_name_s")String field_name_s) {
        RequestResult<Map<String, Object>> result = new RequestResult<Map<String, Object>>();
        Map<String, Object> newObj = ksTableFieldSensCService.saveSensConf(id, t_name, field_name_s);
        result.setObj( newObj );
        return result;
    }


    @ApiOperation(value = "删除敏感表配置",notes="删除敏感表配置")
    @GetMapping("/delSensConf")
        @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="敏感数据配置id",dataType="Integer",paramType="query"),
    })
    @ResponseAddHead
    public RequestResult<Boolean> delSensConf( @RequestParam("id") String ids ) {
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        Boolean success = ksTableFieldSensCService.delSensConf(ids);
        result.setObj( success );
        return result;
    }


}
