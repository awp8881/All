package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
/**
 * 组件参数管理-dao接口
 * @author hqp
 *
 */
public interface KsCompConfParaBDao {
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	Boolean save(Record record);
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	
	/**
	 * 删除
	 * @param compCode 组件编码
	 * @return
	 */
	Boolean deleteByCompCode(String compCode);
	
	
	/**
	 * 根据组件编码查询
	 * @return
	 */
	List<Record> getListByCompCode(String compCode);
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	Record getOne(Long id);

	Boolean saveCompData(List<Map<String, Object>> compParas, String compCode, String menuId);
}
