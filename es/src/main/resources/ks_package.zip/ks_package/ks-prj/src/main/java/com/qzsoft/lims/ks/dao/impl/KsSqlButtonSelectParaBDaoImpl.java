package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsSqlButtonSelectParaBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;

@Repository
public class KsSqlButtonSelectParaBDaoImpl extends BaseDaoImpl implements KsSqlButtonSelectParaBDao{
	private static final String TABLE_NAME = "ks_sql_button_select_para_b";
	
	/**
	 * 字典值配置条件参数
	 */
	@Override
	public List<Record> getButtonSelectParaList(String down_code) {
		String sql = "select * from "+TABLE_NAME+" where down_code=?  order by para_order+0";
		List<Record> recordList = DbEx.find(sql,down_code);
		return recordList;
	}

	/**
	 * 删除后插入
	 * */
	@JFinalTx
	@Override
	public Boolean batchUpdate(String parent_code, List<Map<String, Object>> allParaList) {
		boolean isSucc=true;
		if (StringUtils.isBlank(parent_code)){
			return isSucc;
		}
		parent_code=parent_code+"$";
		DbEx.delete("delete from "+TABLE_NAME+" where locate(?,down_code)>0 ",parent_code);
		if(null == allParaList || allParaList.isEmpty()){
			return isSucc;
		}
		List<Record> recordList=DataBaseUtil.map2Record(allParaList);
		isSucc= super.saveList(TABLE_NAME, recordList);
		return isSucc;
	}

	@JFinalTx
	@Override
	public Boolean saveGroupCondParas(List<Map<String, Object>> condParas) {
		boolean isSucc = true;
		if(null == condParas || condParas.isEmpty()){
			return isSucc;
		}
		List<Record> recordList = DataBaseUtil.map2Record(condParas);
		return super.saveList(TABLE_NAME, recordList);
	}
}
