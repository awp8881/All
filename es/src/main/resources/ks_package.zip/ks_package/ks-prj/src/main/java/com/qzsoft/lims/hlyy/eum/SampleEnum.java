package com.qzsoft.lims.hlyy.eum;

public enum SampleEnum {


    BLOOD("BLOOD", "血液"),
    PLASMA("PLASMA", "血浆"),
    TISSUES("TISSUES", "组织"),
    URN("URN", "尿液"),
    ;

    private String code;
    private String desc;

    SampleEnum(String code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
