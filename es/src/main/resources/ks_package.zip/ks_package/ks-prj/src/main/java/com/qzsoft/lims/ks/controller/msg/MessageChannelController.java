package com.qzsoft.lims.ks.controller.msg;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.qzsoft.common.annotation.RequestLimit;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.config.msg.Config;
import com.qzsoft.lims.ks.dto.msg.PlatformDTO;
import com.qzsoft.lims.ks.eum.msg.MessagePlatformEnum;
import com.qzsoft.lims.ks.service.msg.IRpushPlatformConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 渠道协议
 * @author yuanj
 */
@Api(value = "渠道协议", tags = "渠道协议")
@RestController
@TagResource("渠道协议")
@RequestMapping("/message")
@Slf4j
public class MessageChannelController {

    @Autowired
    private IRpushPlatformConfigService rpushPlatformConfigService;


    @ApiOperation(value = "获取渠道类型")
    @GetMapping("/getChannelType")
    @ResponseAddHead
    public RequestResult<Object> getChannelType(@RequestParam(value = "keyword",required = false)String keyword) {
        RequestResult<Object> result = new RequestResult<>();
        List<Object> platforms = new ArrayList<>();
        for (MessagePlatformEnum platformEnum : MessagePlatformEnum.values()) {
            if (!platformEnum.isEnable()) {
                continue;
            }
            String name = platformEnum.getName();
            if (StringUtils.isNotBlank(keyword) && !name.contains(keyword)) {
                continue;
            }
            try {
                platforms.add(PlatformDTO.builder()
                        .id(platformEnum.name())
                        .name(platformEnum.getName())
                        .description(platformEnum.getDescription())
                        .validateReg(platformEnum.getValidateReg())
                        //加入SerializerFeature,指定序列化配置,解决封装类字段转json为空的问题----yuanj
                        .jsonTemplate(JSON.toJSONString((Config)platformEnum.getConfigType().newInstance(), SerializerFeature.WriteMapNullValue))
                        .build());
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        result.setList(platforms);

        return  result;
    }


    @ApiOperation(value = "保存或者更新渠道协议")
    @PostMapping("/saveChannelAgreement")
    @ResponseAddHead
    @TagResource("保存或者更新渠道协议")
    @RequestLimit(count = 1,time = 2000)//幂等控制
    public RequestResult<Object> saveChannelAgreement(@RequestParam(value = "channelData") String channelData) {
        RequestResult<Object> result = new RequestResult<>();
        try {
            String returnId = rpushPlatformConfigService.saveAndUpdateChannel(channelData);
            //返回主表id
            result.setObj(returnId);
        }catch (Exception e){
            result.setStatus(false);
            result.setError(e.getMessage());
        }
        return result;
    }

    @ApiOperation(value = "获取渠道协议内容")
    @GetMapping("/getChannelMsg")
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="单条查询id",dataType="string", paramType = "query",required = false),
            @ApiImplicitParam(name="name",value="渠道协议类型名称",dataType="string", paramType = "query",required = false)})
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getChannelMsg(@RequestParam(value = "id",required = false) String id,@RequestParam(value = "name",required = false) String name) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        List<Map<String, Object>> stringLists = rpushPlatformConfigService.findChannelMsgById(id,name);
        result.setList(stringLists);
        return result;
    }

    @ApiOperation(value = "删除渠道协议内容")
    @GetMapping("/deleteChannelMsg")
    @ResponseAddHead
    @TagResource("删除渠道协议内容")
    public RequestResult<Object> deleteChannelMsg(@RequestParam(value = "id") String id) {
        RequestResult<Object> result = new RequestResult<>();
        Boolean bools = rpushPlatformConfigService.deleteChannelMsg(id);
        result.setObj(bools);
        return result;
    }
}
