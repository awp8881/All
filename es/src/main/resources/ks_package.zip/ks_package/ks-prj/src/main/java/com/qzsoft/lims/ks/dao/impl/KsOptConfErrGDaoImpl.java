package com.qzsoft.lims.ks.dao.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsOptConfErrGDao;

@Repository
public class KsOptConfErrGDaoImpl extends BaseDaoImpl implements KsOptConfErrGDao{
	private static final String TABLE_NAME = "ks_opt_conf_err_g";
	
	/**
	 * 列表分页查询
	 */
	@Override
	public Page<Record> getPageList( Integer pageNum, Integer pageSize,String cr_dm) {
		String whereSql=" from "+TABLE_NAME+" where 1=1 ";
		Page<Record> recordPage =null;
		if(StringUtils.isNotBlank(cr_dm)){
			whereSql+=" and date(cr_dm)=? order by cr_dm desc";
			recordPage = DbEx.paginate(pageNum, pageSize, "select * " , whereSql,cr_dm);
		}else{
			whereSql+=" order by cr_dm desc";
			recordPage = DbEx.paginate(pageNum, pageSize, "select * " , whereSql);
		}
		
		return recordPage;
	}
}
