package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.CommonService;
import com.qzsoft.lims.ks.service.dynamic.DynamicConfigService;
import com.qzsoft.lims.ks.service.dynamic.DynamicParserService;
import com.qzsoft.lims.ks.service.logic.KsLogicConfService;
import com.qzsoft.lims.ks.vo.logic.KsLogicConfigVO;
import com.qzsoft.lims.ks.vo.logic.KsModelLogicMenuBVO;
import com.qzsoft.lims.ks.vo.logic.LogicBasTmpVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 动态sql-控制器
 */
@Api(value = "动态sql", tags = "动态sql")
@RestController
@RequestMapping("/dynamic")
@Slf4j
public class DynamicController {

	@Autowired
	private DynamicConfigService dynamicConfigService;

	@Autowired
    private DynamicParserService dynamicParserService;

    @Autowired
    private CommonService commonService;


    @ApiOperation(value = "动态sql字段树")
    @GetMapping("/getDynamicFieldsTree")
        @ApiImplicitParams({
            @ApiImplicitParam(name="dynamicSource",value="动态sql来源",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="menu_id",value="菜单主键",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="logicCode",value="逻辑编码",required=false,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Map<String,Object>> getDynamicFieldsTree( @RequestParam(value="dynamicSource",required = false) String dynamicSource,
                                                                   @RequestParam(value="menu_id",required = false) String menuId,
                                                                   @RequestParam(value="logicCode",required = false) String logicCode) {
        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = dynamicConfigService.getFieldsBySource(  dynamicSource, menuId, logicCode);
        result.setList( maps );
        return result;
    }

    @ApiOperation(value = "动态sql列名")
    @GetMapping("/getDynamicColumnsTree")
        @ResponseAddHead
    public RequestResult<Map<String,Object>> getDynamicColumnsTree( ) {
        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = commonService.getFieldsTree();
        result.setList( maps );
        return result;
    }

    @ApiOperation(value = "保存动态sql")
    @PostMapping("/saveDynSql")
        @ResponseAddHead
    public RequestResult<String> saveDynSql( @RequestParam(value = "dynData") String dynDataStr,
                                             @RequestParam(value = "quoteId") String quoteId,
                                             @RequestParam(value = "quoteType") String quoteType,
                                             @RequestParam(value = "setCode",required = false) String setCode,
                                             @RequestParam(value = "butDiCdCode",required = false) String butDiCdCode,
                                             @RequestParam(value = "menuId",required = false) String menuId) {
        RequestResult<String> result = new RequestResult<>();
        result.setObj(dynamicConfigService.saveDynSql( dynDataStr, quoteId, quoteType,setCode,butDiCdCode,menuId) );

        return result;
    }


    @ApiOperation(value = "动态sql预览")
    @PostMapping("/previewDynamicSql")
        @ResponseAddHead
    public RequestResult<String> previewDynamicSql( @RequestBody Map<String, Object> dynMap ) {
        RequestResult<String> result = new RequestResult<>();
        result.setObj(dynamicParserService.previewDynamicSql( dynMap) );

        return result;
    }

    @ApiOperation(value = "动态sql详情")
    @GetMapping("/getDyn")
        @ResponseAddHead
    public RequestResult<Map<String, Object>> getDyn( @RequestParam(value = "dynCode") String dynCode,
                                                      @RequestParam(value = "setCode",required = false) String setCode,
                                                      @RequestParam(value = "butDiCdCode",required = false) String butDiCdCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj(dynamicConfigService.getDyn( dynCode, setCode, butDiCdCode ) );

        return result;
    }
}
