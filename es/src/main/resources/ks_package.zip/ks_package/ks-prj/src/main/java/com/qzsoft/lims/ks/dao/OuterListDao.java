package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 大列表页面-dao接口
 * @author zf
 *
 */
public interface OuterListDao extends BaseDao{
	
	/**
	 * 获取updateButton
	 * @param m_code
	 * @param tableBC
	 * @return
	 */
	List<Record> getMenuLogic(String m_code, String tableBC);

	String getQuerySelfSelectCode( String m_code, String tableBC);
	
	/**
	 * 获取列表字段属性
	 * @param m_code
	 * @return
	 */
	List<Record> getModelListField(String m_code,String tableBC);
	
	/**
	 * 获取模版列表
	 * @return
	 */
	Record getModelList(String m_code, String tableBC);
	
	/**
	 * 获取分组条件
	 * @param m_code
	 * @param tableBC
	 * @return
	 */
	List<Record> getHighSearchField(String m_code, String tableBC);
	
	/**
	 * 获取菜单信息
	 * @param menu_id
	 * @return
	 */
	Record getMenuInfo(String menu_id);
	
	/**
	 * 获取按钮接口参数
	 * @param port_code
	 * @param tableBC
	 * @return
	 */
	List<Record> getSqlPortPara(String port_code,String tableBC);
	
	/**
	 * 获取按钮接口
	 * @param port_code
	 * @param tableBC
	 * @return
	 */
	Record getSqlPort(String port_code,String tableBC);
	
	/**
	 * 通过逻辑名称获取
	 * @param button_code
	 * @param tableBC
	 * @return
	 */
	Record getLogicContent(String button_code,String tableBC);


	List<Record> getShowFieldsByMCode(String m_code);
	
	/**
	 * 通过模板编码获取大列表初始条件
	 * @param m_code
	 * @return
	 */
	List<Record> getOuterInitByMCode(String m_code);
	
	/**
	 * 通过模板编码获取大列表所有字段
	 * @param m_code
	 * @return
	 */
	List<Record> getOuterFieldByMCode(String m_code);
	
	/**
	 * 通过模板编码获取初始加载条件
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	Record getInitSqlByMCode(String m_code, String m_code_type);

}
