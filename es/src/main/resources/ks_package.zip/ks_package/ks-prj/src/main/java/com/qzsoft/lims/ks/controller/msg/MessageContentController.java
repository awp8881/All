package com.qzsoft.lims.ks.controller.msg;

import com.qzsoft.common.annotation.RequestLimit;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.msg.MessageContentService;
import com.qzsoft.lims.ks.vo.CommonTreeVO;
import com.qzsoft.lims.ks.vo.MsgInformVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 消息内容
 * @author yuanj
 *
 */
@Api(value = "消息内容", tags = "消息内容")
@RestController
@TagResource("消息内容")
@RequestMapping("/message")
@Slf4j
public class MessageContentController {

    @Autowired
    private MessageContentService messageContentService;

    @ApiOperation(value = "保存或者更新消息内容")
    @PostMapping("/sauMessageContent")
    @ResponseAddHead
    @TagResource("保存或者更新消息内容")
    @RequestLimit(count = 1,time = 2000)//幂等控制
    public RequestResult<Object> sauMessageContent(@RequestParam(value = "messageContentData") String messageContentData) {
        RequestResult<Object> result = new RequestResult<>();
        try {
            String returnId = messageContentService.saveMessageContent(messageContentData);
            //返回主表id
            result.setObj(returnId);
        }catch (Exception e){
            result.setStatus(false);
            result.setError(e.getMessage());
        }
        return result;
    }

    @ApiOperation(value = "获取消息内容")
    @GetMapping("/getMessageContent")
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="单条查询id",dataType="string", paramType = "query",required = false),
            @ApiImplicitParam(name="temp_na",value="名称",dataType="string", paramType = "query",required = false),
            @ApiImplicitParam(name="temp_st",value="启用状态",dataType="string", paramType = "query",required = false),
            @ApiImplicitParam(name="bus_type",value="业务类型",dataType="string", paramType = "query",required = false),
            @ApiImplicitParam(name="pageNum",value="页码",required=false,dataType="Integer",paramType="query"),
            @ApiImplicitParam(name="pageSize",value="每页显示条数",required=false,dataType="Integer",paramType="query")})
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getMessageContent(@RequestParam(value = "id" , required = false) String id,
                                                                @RequestParam(value = "temp_na",required = false) String temp_na,
                                                                @RequestParam(value = "temp_st", required = false) String temp_st,
                                                                @RequestParam(value = "bus_type" ,required = false) String bus_type,
                                                                @RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
                                                                @RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
        RequestResult<Map<String,Object>> result = null;
        try {
            result = messageContentService.getMessageContent(id,temp_na,temp_st,bus_type,pageNum,pageSize);
        }catch (BusinessException e) {
            result = RequestResult.error(e);
            log.error(this.getClass().getSimpleName() + ".dicConfigErrPageList()", e);
        }catch (Exception e) {
            result = RequestResult.error(e);
            log.error(this.getClass().getSimpleName() + ".dicConfigErrPageList()", e);
        }
        return result;
    }

    @ApiOperation(value = "删除消息内容")
    @GetMapping("/deleteMessageContent")
    @ResponseAddHead
    @TagResource("删除消息内容")
    public RequestResult<Object> deleteMessageContent(@RequestParam(value = "id") String id) {
        RequestResult<Object> result = new RequestResult<>();
        Boolean bools = messageContentService.deleteMessageContent(id);
        result.setObj(bools);
        return result;
    }


    @ApiOperation(value = "获取业务类型")
    @GetMapping("/getBusType")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getBusType() {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        List<Map<String, Object>> stringLists = messageContentService.getBusType();
        result.setList(stringLists);
        return result;
    }


    @ApiOperation(value = "获取传参配置")
    @GetMapping("/getparamConfig")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getparamConfig(@RequestParam(value = "id",required = false) String id) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        List<Map<String, Object>> stringLists = messageContentService.getparamConfig(id);
        result.setList(stringLists);
        return result;
    }


    @ApiOperation(value = "获取消息通知树结构")
    @GetMapping("/getMsgTree")
    @ResponseAddHead
    public RequestResult<MsgInformVO> getMsgTree() {
        RequestResult<MsgInformVO> result = new RequestResult<>();
        List<MsgInformVO> stringLists = messageContentService.getMsgTree();
        result.setList(stringLists);
        return result;
    }

}
