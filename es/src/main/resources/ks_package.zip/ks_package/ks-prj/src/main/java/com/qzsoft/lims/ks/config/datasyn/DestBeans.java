package com.qzsoft.lims.ks.config.datasyn;

import com.qzsoft.lims.ks.plug.datasyn.LocalDbDest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DestBeans {

    @Bean
    public LocalDbDest createLocalDbDest(){

        return new LocalDbDest();
    }

}
