package com.qzsoft.lims.ks.controller;

import com.google.gson.Gson;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsSyCService;
import com.qzsoft.lims.ks.vo.KsSyCVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * 菜单所属系统配置-控制器
 * @author zf
 *
 */
@Api(value = "菜单所属系统配置", tags = "菜单所属系统配置，表：ks_sy_c")
@RestController
@RequestMapping("/sy")
@Slf4j
@TagResource("菜单所属系统配置")
public class KsSyCController {

	@Autowired
	private KsSyCService ksSyCService;


	@ApiOperation(value="保存",notes="true-保存成功，false-保存失败")
	@PostMapping("/save")
	@ResponseAddHead
	@TagResource("保存")
		public RequestResult<KsSyCVO> update(KsSyCVO ksSyCVO) {
		RequestResult<KsSyCVO> result = new RequestResult<KsSyCVO>();
		if( ksSyCVO.getId()==null ){
			ksSyCVO = ksSyCService.save(ksSyCVO);
		}else{
			ksSyCVO = ksSyCService.update(ksSyCVO);
		}
		result.setObj(ksSyCVO);
		return result;

	}

	@ApiOperation(value="删除",notes="true-删除成功，false-删除失败")
	@ApiImplicitParam(name="syIds",value="主键,多个以逗号分隔",required=true,dataType="string",paramType="query")
	@PostMapping("/delete")
	@ResponseAddHead
	@TagResource("删除")
		public RequestResult<Boolean> delete(@RequestParam(value="syIds") String syIds) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		Boolean isDelete = ksSyCService.delete(syIds);
		result.setObj(isDelete);
		return result;
	}

	@ApiOperation(value="列表查询",notes="没有分页")
	@GetMapping("/getList")
	@ResponseAddHead
		public RequestResult<String> getList() {
		RequestResult<String> result = new RequestResult<>();
		try {

			List<KsSyCVO> list = ksSyCService.getList();
			String KsSyCVOListStr = new Gson().toJson( list );
			String base64KsSyCVOListStr = Base64.encodeBase64String(KsSyCVOListStr.getBytes(StandardCharsets.UTF_8));
			result.setObj(base64KsSyCVOListStr);

//			List<KsSyCVO> list = ksSyCService.getList();
//			String KsSyCVOListStr = new Gson().toJson( list );
//			String base64KsSyCVOListStr = Base64.encodeBase64String(KsSyCVOListStr.getBytes(StandardCharsets.UTF_8));
//			result.setList(Lists.newArrayList( base64KsSyCVOListStr ));

//			List<String> baseVo = Lists.newArrayList();
//			List<KsSyCVO> list = ksSyCService.getList();
//			for (KsSyCVO ksSyCVO : list) {
//				String KsSyCVOStr = new Gson().toJson( ksSyCVO );
//				String base64KsSyCVOStr = Base64.encodeBase64String(KsSyCVOStr.getBytes(StandardCharsets.UTF_8));
//				baseVo.add( base64KsSyCVOStr );
//			}
//			result.setList(baseVo);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getList()", e);
		}
		return result;

	}

	@ApiOperation("详情查询")
	@GetMapping("/getOne")
		@ApiImplicitParam(name="syId",value="主键",required=true,dataType="Long",paramType="query")
	@ResponseAddHead
	public RequestResult<KsSyCVO> getOne(@RequestParam(value="syId") Long syId) {
		RequestResult<KsSyCVO> result = new RequestResult<>();
		try {
			result=new RequestResult<>(ksSyCService.getOne(syId));
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOne()", e);
		}
		return result;

	}

	@ApiOperation(value="一键修正系统路径配置",notes="true-保存成功，false-保存失败")
	@PostMapping("/correctUrl")
		@ResponseAddHead
	@TagResource("一键修正系统路径配置")
	public RequestResult<Boolean> correctUrl() {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		Boolean isCorrect = ksSyCService.correctUrl();
		result.setObj(isCorrect);
		return result;
	}
}
