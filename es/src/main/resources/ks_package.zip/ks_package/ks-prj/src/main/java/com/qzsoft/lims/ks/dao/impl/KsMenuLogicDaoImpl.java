package com.qzsoft.lims.ks.dao.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.tools.UIDGenerator;
import com.qzsoft.lims.ks.comp.GroupCond;
import com.qzsoft.lims.ks.conversion.ConversionHolder;
import com.qzsoft.lims.ks.dao.*;
import com.qzsoft.lims.ks.dao.info.KsModelInfoDao;
import com.qzsoft.lims.ks.dao.info.KsModelValsBDao;
import com.qzsoft.lims.ks.eum.*;
import com.qzsoft.lims.ks.eum.contQuote.ContTypeEnum;
import com.qzsoft.lims.ks.eum.dynamic.DynamicParaTypeEnum;
import com.qzsoft.lims.ks.eum.groupCond.GroupCondRightEnum;
import com.qzsoft.lims.ks.service.KsDicBSerivce;
import com.qzsoft.lims.ks.service.groupCond.GroupCondService;
import com.qzsoft.lims.ks.service.page.AppendSourceSqlService;
import com.qzsoft.lims.ks.util.CodesUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.util.QzAssert;
import com.qzsoft.lims.ks.vo.SourceConfigVO;
import com.qzsoft.lims.ks.vo.SourceConfigVO.AttrVO;
import com.qzsoft.lims.ks.vo.SourceConfigVO.PortVO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;

import java.util.*;
import java.util.regex.Pattern;

/**
 * 页面属性dao实现
 *
 * @author zf
 */
@Repository
public class KsMenuLogicDaoImpl extends BaseDaoImpl implements KsMenuLogicDao {

    private static final String TABLE_NAME_C = "ks_menu_logic_c";
    private static final String TABLE_NAME_B = "ks_menu_logic_b";

    @Autowired
    private KsSqlButtonBDao ksSqlButtonBDao;
    @Autowired
    private KsMenuLogicContentBDao ksMenuLogicContentBDao;
    @Autowired
    private KsSqlPortCDao ksSqlPortCDao;
    @Autowired
    private KsModelDao ksModelDao;
    @Autowired
    private KsSqlSelectCBDao ksSqlSelectCBDao;
    @Autowired
    private KsSqlSelectCSqlBDao ksSqlSelectCSqlBDao;
    @Autowired
    private KsMenuLogicMultBDao ksMenuLogicMultBDao;
    @Autowired
    private KsModelInfoDao ksModelInfoDao;
    @Autowired
    private KsModelValsBDao ksModelValsBDao;
    @Autowired
    private KsModelExcBDao ksModelExcBDao;

    @Autowired
    private AppendSourceSqlService appendSourceSqlService;

    @Autowired
    @Lazy
    private GroupCondService groupCondService;

    @Autowired
    private KsDicBSerivce ksDicBSerivce;

    /**
     * 删除后批量插入
     */
    @JFinalTx
    @Override
    public Boolean batchUpdate(SourceConfigVO sourceConfigVO) {
        boolean isSucc = true;
        String toolsListStr = sourceConfigVO.getToolsListStr();
        String new_m_code = sourceConfigVO.getNew_m_code();
        String old_m_code = sourceConfigVO.getOld_m_code();
        String menu_id = sourceConfigVO.getMenu_id();
        Integer isSaveAs = sourceConfigVO.getIsSaveAs() == null ? 0 : sourceConfigVO.getIsSaveAs();//是否保存为组件
        String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
        String m_code_type = isSaveAs == YnEnum.N.getCode() ? sourceConfigVO.getM_code_type() : McodeTypeEnum.YMSJY.getCode();
        List<Record> recordList = Lists.newArrayList();
        List<List<Map<String, Object>>> allButtonList = Lists.newArrayList();
        List<Record> logicContentList = Lists.newArrayList();
        List<Map<String, Object>> allPortsList = Lists.newArrayList();
        List<Map<String, Object>> allFollowList = Lists.newArrayList();

        //删除按钮小列表数据源条件
        String p_m_code = old_m_code + "$button_code";
        deleteListButton(p_m_code, old_m_code, isSaveAs);

        List<Map<String, Object>> allExcList = Lists.newArrayList();
        List<Map<String, Object>> allValsList = Lists.newArrayList();
        if (StringUtils.isNotBlank(toolsListStr)) {
            List<Map<String, Object>> toolsList = (List<Map<String, Object>>) JSON.parse(toolsListStr);

            for (Map<String, Object> map : toolsList) {
                List<List<Map<String, Object>>> activeConds = (List<List<Map<String, Object>>>) map.get("activeConds");
                String oldButtonCode = StringUtil.toString(map.get("button_code"));
                String button_code = oldButtonCode;
                if (StringUtils.isBlank(oldButtonCode) || !button_code.contains(new_m_code)) {//编辑button_code不变
                    button_code = new_m_code + "$" + CodesUtil.createCommonCode("button_code");
                }
                String port_code = button_code + "$port_code";

                if (null == map.get("button_type") || StringUtils.isBlank(map.get("button_type").toString())) {
                    map.put("button_type", ButtonTypeEnum.UPDATE.getCode());
                } else {
                    map.put("button_type", map.get("button_type"));
                }

                Object butDicds = map.get("but_di_cd_code");
                if(!ObjectUtils.isEmpty(butDicds)){
                    butDicds = ConversionHolder.saveDataConversion(FieldStyleEnum.multiSelect.name() , butDicds );
                    map.put("but_di_cd_code", butDicds);
                }else{
                    map.put("but_di_cd_code","");
                }
                if(  map.get("load_cond")!=null && (map.get("load_cond") instanceof List || map.get("load_cond") instanceof JSONArray) ){
                    map.put( "load_cond",   ConversionHolder.saveDataConversion(FieldStyleEnum.multiSelect.name() , map.get("load_cond") ) );
                }

                map.put("button_code", button_code);
                map.put("port_code", port_code);

                handleIterFields( map);

                formatListButton(allButtonList, activeConds, new_m_code, button_code);

                saveMenuLogicContent(logicContentList, map, new_m_code, button_code, allPortsList, allFollowList, port_code, menu_id);//按钮点击脚本

                List<Map<String, Object>> valsList = (List<Map<String, Object>>) map.get("valsList");
                ksModelValsBDao.setModelVals(valsList, new_m_code, null, button_code, menu_id);
                if (null != valsList && !valsList.isEmpty()) {
                    allValsList.addAll(valsList);
                }
                Map<String, Object> excVal = (Map<String, Object>) map.get("excVal");
                if (null != excVal && !excVal.isEmpty()) {
                    excVal.put("button_code", button_code);
                    excVal.put("menu_id", menu_id);
                    allExcList.add(excVal);
                }

                if (ControlStyleEnum.fieldLinkPort.name().equals(StringUtil.toString(map.get("control_style")))) {
                    map.put("is_active", YnEnum.N.getCode());
                }
                map.put("m_code", new_m_code);
                map.put("cr_dm", DateUtil.getNowDateTimeStr());
                map.put("up_dm", DateUtil.getNowDateTimeStr());
                map.put("up_ver", "1");
                map.put("m_code_type", m_code_type);
                map.put("control_type", ControlTypeEnum.updateButton.name());
                map.put("menu_id", menu_id);
                map.remove("preEvent");
                map.remove("actionEvent");
                map.remove("afterEvent");
                map.remove("followEvent");
                map.remove("portVO");
                map.remove("logic_script");
                map.remove("valsList");
                map.remove("excVal");
                map.remove("dynMap");
                map.remove("activeConds");
                map.remove("audit_param");
                Object btn_attr_exp = map.remove("btn_attr_exp");
                String control_style = map.get("control_style").toString();
                String button_type = map.get("button_type").toString();
                saveBtnAttrExp( menu_id, new_m_code, button_code, control_style,button_type, btn_attr_exp );
            }
            recordList = DataBaseUtil.map2Record(toolsList);
        }

        super.deleteByCustom(table, "m_code,control_type", old_m_code, ControlTypeEnum.updateButton.name());
        if (null != recordList && !recordList.isEmpty()) {//页面属性
            isSucc = super.saveList(table, recordList);
        }

        ksSqlButtonBDao.saveGroupConds(allButtonList, isSaveAs, p_m_code, null, menu_id);
        ksMenuLogicContentBDao.batchUpdate(logicContentList, isSaveAs, old_m_code, null, menu_id);
        ksSqlPortCDao.batchUpdate(allPortsList, isSaveAs, p_m_code, null, menu_id);
        ksMenuLogicMultBDao.batchUpdate(allFollowList, old_m_code, null, menu_id);
        ksModelValsBDao.batchUpdate(allValsList, old_m_code, null);
        ksModelExcBDao.batchUpdate(allExcList, old_m_code);
        return isSucc;
    }

    /**
     *  保存按钮扩展属性数据   对应到工具栏的加载条件
     * @param m_code
     * @param control_style
     * @param btn_attr_exp
     * @date 2019-10-11
     */
    private void saveBtnAttrExp( String menu_id, String m_code, String button_code, String control_style, String button_type, Object btn_attr_exp) {

        DbEx.delete("delete from ks_sql_vals_b where m_code=? and button_code=?", m_code, button_code);
        if( btn_attr_exp == null || ( btn_attr_exp instanceof JSONObject && ((JSONObject) btn_attr_exp).isEmpty() )  ){
            return;
        }
        //处理按钮是组合查询（自定义查询）的扩展配置数据
        if( ControlStyleEnum.comb_find.name().equals(control_style) && !ButtonTypeEnum.GROUP_QUERY.getCode().equals(button_type) ){
            handleCombFindSave(menu_id, m_code, button_code, btn_attr_exp);
        }
        //按钮分组
        if( ControlStyleEnum.buttonGroup.name().equals(control_style) && !ButtonTypeEnum.GROUP_QUERY.getCode().equals(button_type) ){
            handleCombBtnSave(menu_id, m_code, button_code, btn_attr_exp);
        }
        //按钮查询   不要凌乱    控件类型 跟控件属性都能有扩展属性配置
        if( ButtonTypeEnum.GROUP_QUERY.getCode().equals(button_type) ){
            handleBtnFindAttr(menu_id, m_code, button_code, btn_attr_exp);
        }

    }

    private void handleBtnFindAttr(String menu_id, String m_code, String button_code, Object btn_attr_exp) {

        List<Object> btnAttrExpList = (List<Object>) btn_attr_exp;
        List<Record> ksModelValsBRecordList = Lists.newArrayList();
        for (Object btnAttrExp : btnAttrExpList) {
            Map<String,Object> btnAttrExpMap = (Map<String, Object>) btnAttrExp;
            Record ksModelValsBRecord = new Record();
            ksModelValsBRecordList.add(ksModelValsBRecord);
            ksModelValsBRecord.set("m_code", m_code );
            ksModelValsBRecord.set("disp_or", ksModelValsBRecordList.size() );
            ksModelValsBRecord.set("button_code", button_code );
            ksModelValsBRecord.set("up_ver",1 );
            ksModelValsBRecord.set("menu_id", menu_id);
            ksModelValsBRecord.set("cr_dm", DateUtil.getNowDateTimeStr() );
            ksModelValsBRecord.set("vals_type", btnAttrExpMap.get("type"));
            btnAttrExp = btnAttrExpMap.get("data");
            Map<String,String> attrMap = (Map<String, String>) btnAttrExp;
            ksModelValsBRecord.set("attr_code", StringUtil.toString( attrMap.get("fieldName") ).trim()  );
            ksModelValsBRecord.set("attr_name", attrMap.get("fieldNick"));
            ksModelValsBRecord.set("val_select_type", attrMap.get("val_select_type"));
            ksModelValsBRecord.set("attr_type", attrMap.get("operator"));
            ksModelValsBRecord.set("def_type", attrMap.get("def_type"));
            ksModelValsBRecord.set("def_code", attrMap.get("def_code"));
        }
        DbEx.batchSave( "ks_sql_vals_b", ksModelValsBRecordList, ksModelValsBRecordList.size() );

    }

    private void handleCombBtnSave(String menu_id, String m_code, String button_code, Object btn_attr_exp) {

        List<Object> btnAttrExpList = (List<Object>) btn_attr_exp;
        List<Record> ksModelValsBRecordList = Lists.newArrayList();
        for (Object btnAttrExp : btnAttrExpList) {
            Record ksModelValsBRecord = new Record();
            ksModelValsBRecordList.add(ksModelValsBRecord);
            ksModelValsBRecord.set("m_code", m_code );
            ksModelValsBRecord.set("disp_or", ksModelValsBRecordList.size() );
            ksModelValsBRecord.set("button_code", button_code );
            ksModelValsBRecord.set("up_ver",1 );
            ksModelValsBRecord.set("menu_id", menu_id);
            ksModelValsBRecord.set("cr_dm", DateUtil.getNowDateTimeStr() );
            ksModelValsBRecord.set("vals_type", ControlStyleEnum.buttonGroup.name() );
            ksModelValsBRecord.set("attr_code", btnAttrExp  );
            ksModelValsBRecord.set("attr_type", ControlStyleEnum.buttonGroup.name() );
        }
        if( !ksModelValsBRecordList.isEmpty() ){
            DbEx.batchSave( "ks_sql_vals_b", ksModelValsBRecordList, ksModelValsBRecordList.size() );
        }
    }

    private void handleCombFindSave(String menu_id, String m_code, String button_code, Object btn_attr_exp) {

        List<Object> btnAttrExpList = (List<Object>) btn_attr_exp;
        List<Record> ksModelValsBRecordList = Lists.newArrayList();
        for (Object btnAttrExp : btnAttrExpList) {
            Map<String,Object> btnAttrExpMap = (Map<String, Object>) btnAttrExp;
            Record ksModelValsBRecord = new Record();
            ksModelValsBRecordList.add(ksModelValsBRecord);
            ksModelValsBRecord.set("m_code", m_code );
            ksModelValsBRecord.set("disp_or", ksModelValsBRecordList.size() );
            ksModelValsBRecord.set("button_code", button_code );
            ksModelValsBRecord.set("up_ver",1 );
            ksModelValsBRecord.set("menu_id", menu_id);
            ksModelValsBRecord.set("cr_dm", DateUtil.getNowDateTimeStr() );
            ksModelValsBRecord.set("vals_type", btnAttrExpMap.get("type"));

            btnAttrExp = btnAttrExpMap.get("data");

            //处理组
            if( btnAttrExp instanceof List ){
                List<Object> attrGroup = (List<Object>) btnAttrExp;
//                    attr_code  attr_name        attr_type       第一组
                for (int i = 0; i < attrGroup.size(); i++) {
                    Map<String,String> attrMap = (Map<String, String>) attrGroup.get(i);
                    if( i==0 ){
                        ksModelValsBRecord.set("attr_code", attrMap.get("fieldName"));
                        ksModelValsBRecord.set("attr_name", attrMap.get("fieldNick"));
                        ksModelValsBRecord.set("attr_type", attrMap.get("operator"));
                    }else{
//                    val_code   val_attr_name    val_attr_type   第二组
                        ksModelValsBRecord.set("val_code", attrMap.get("fieldName"));
                        ksModelValsBRecord.set("val_attr_name", attrMap.get("fieldNick"));
                        ksModelValsBRecord.set("val_attr_type", attrMap.get("operator"));
                    }
                    ksModelValsBRecord.set("def_type", attrMap.get("def_type"));
                    ksModelValsBRecord.set("def_code", attrMap.get("def_code"));
                }
            }else{
                Map<String,Object> attrMap = (Map<String, Object>) btnAttrExp;
                ksModelValsBRecord.set("val_select_type", attrMap.get("val_select_type"));
                String val_select_code = StringUtil.toString ( attrMap.get("val_select_code") );
                if( StringUtils.isBlank(val_select_code) ){
                    val_select_code = UIDGenerator.getUID()+"";
                }
                ksModelValsBRecord.set("val_select_code", val_select_code );
                ksModelValsBRecord.set("attr_type_exp", attrMap.get("operator_expend"));
                //处理非组
                ksModelValsBRecord.set("attr_code", StringUtil.toString( attrMap.get("fieldName") ).trim()  );
                ksModelValsBRecord.set("attr_name", attrMap.get("fieldNick"));
                ksModelValsBRecord.set("attr_type", attrMap.get("operator"));
                ksModelValsBRecord.set("def_type", attrMap.get("def_type"));
                ksModelValsBRecord.set("def_code", attrMap.get("def_code"));
                ksModelValsBRecord.set("but_di_cd", attrMap.get("but_di_cd"));
                //2021-12-01 yuanj 增加扩展列
                if(null != attrMap.get("query_column") && !isInteger(attrMap.get("query_column").toString(),true)){
                    throw new BusinessException("必须为正整数!");
                }else {
                    ksModelValsBRecord.set("query_column", attrMap.get("query_column"));
                }
                Object butDicds = attrMap.get("but_di_cd_code");
                if(!ObjectUtils.isEmpty(butDicds)){
                    butDicds = ConversionHolder.saveDataConversion(FieldStyleEnum.multiSelect.name() , butDicds );
                }else{
                    butDicds = null;
                }
                ksModelValsBRecord.set("but_di_cd_code", butDicds);
            }
        }
        DbEx.batchSave( "ks_sql_vals_b", ksModelValsBRecordList, ksModelValsBRecordList.size() );
    }

    private void handleIterFields( Map<String, Object> map){
         String controlStyle = StringUtil.toString(map.get("control_style"));
         if (ControlStyleEnum.iterSearch.name().equals( controlStyle ) || ControlStyleEnum.iterSearchScope.name().equals(controlStyle)){
             Object logicName = map.get("logic_name");
             logicName = ConversionHolder.saveDataConversion(FieldStyleEnum.multiSelect.name(), logicName);
             map.put("logic_name", logicName);
             return;
         }
        map.put("logic_name", null);
    }

    private void setDynSql(Record record, String buttonCode){
        if (ContTypeEnum.dyn.getCode().equals(record.getStr("cont_type"))
                && StringUtils.isBlank(record.getStr("load_cond"))){
               record.set("load_cond", buttonCode);
        }

    }

    private void deleteListButton(String p_m_code, String old_m_code, Integer isSaveAs) {
        if (StringUtils.isBlank(p_m_code)){
            return;
        }
//        String preSelectCodeB = old_m_code + "$" + InnerListSelectEnum.button.getCode();
        String portTable = isSaveAs == YnEnum.N.getCode() ? "ks_sql_port_b" : "ks_sql_port_c";
        String portParaTable = isSaveAs == YnEnum.N.getCode() ? "ks_sql_port_para_b" : "ks_sql_port_para_c";

//        DbEx.delete("delete from ks_sql_select_c_sql_b where locate(?,select_code_b)>0  ", preSelectCodeB);
//        DbEx.delete("delete from ks_sql_select_c_b where locate(?,select_code_b)>0   ", preSelectCodeB);
//        DbEx.delete("delete from ks_sql_select_para_c_b where locate(?,select_code_b)>0  ", preSelectCodeB);
        DbEx.delete("delete from " + portTable + " where locate(?,port_code)>0 ", p_m_code);
        DbEx.delete("delete from " + portParaTable + " where locate(?,port_code)>0 ", p_m_code);
    }

    private void formatListButton(List<List<Map<String, Object>>> allButtonList, List<List<Map<String, Object>>> buttonList, String new_m_code, String button_code) {
        if (null == buttonList || buttonList.isEmpty()) {
            return;
        }

        for (Iterator<List<Map<String, Object>>> iterator = buttonList.iterator(); iterator.hasNext(); ) {
            List<Map<String, Object>> next =  iterator.next();

            for (Iterator<Map<String, Object>> mapIterator = next.iterator(); mapIterator.hasNext(); ) {
                Map<String, Object> map =  mapIterator.next();
                map.put("m_code", new_m_code);
                map.put("button_code", button_code);
            }

        }
        allButtonList.addAll(buttonList);
    }

    /**
     * 保存组装按钮事件
     */
    private void saveMenuLogicContent(List<Record> logicContentList, Map<String, Object> map, String new_m_code, String button_code,
                                      List<Map<String, Object>> allPortsList, List<Map<String, Object>> allFollowList, String port_code, String menu_id) {

        String logic_script = StringUtil.toString(map.get("logic_script"));
        formatActive(logic_script, new_m_code, button_code, logicContentList); //按钮激活脚本

        Map<String, Object> preEvent = (Map<String, Object>) JSON.parse(StringUtil.toString(map.get("preEvent")));//按钮前置脚本
        formatPre(preEvent, new_m_code, button_code, allPortsList, logicContentList);

        Map<String, Object> afterEvent = (Map<String, Object>) JSON.parse(StringUtil.toString(map.get("afterEvent")));//按钮后置脚本
        formatAfter(afterEvent, map, new_m_code, button_code, allPortsList, logicContentList);

        Map<String, Object> actionEvent = (Map<String, Object>) JSON.parse(StringUtil.toString(map.get("actionEvent")));//按钮动作脚本
        formatEvent(actionEvent, map, port_code, allPortsList, new_m_code, button_code, logicContentList, menu_id);

        Map<String, Object> followEvent = (Map<String, Object>) JSON.parse(StringUtil.toString(map.get("followEvent")));//按钮跟随动作
        formatFollow(followEvent, button_code, new_m_code, logicContentList, allFollowList);
    }

    //按钮激活
    private void formatActive(String logic_script, String new_m_code, String button_code, List<Record> logicContentList) {
        if (StringUtils.isBlank(logic_script)) {
            return;
        }
        Record activeRecord = new Record();
        activeRecord.set("m_code", new_m_code).set("button_code", button_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", 1)
                .set("logic_name", LogicTypeEnum.ACTIVE.getDesc()).set("logic_type", LogicTypeEnum.ACTIVE.getCode())
                .set("logic_script", logic_script).remove("id");
        logicContentList.add(activeRecord);
    }

    //按钮前置动作
    private void formatPre(Map<String, Object> preEvent, String new_m_code, String button_code, List<Map<String, Object>> allPortsList,
                           List<Record> logicContentList) {
        if (null == preEvent || preEvent.isEmpty()) {
            return;
        }
        Record preRecord = DataBaseUtil.map2Record(preEvent);
        String pre_type = preRecord.getStr("pre_type");
        if (StringUtils.isBlank(pre_type)) {
            return;
        }
        preRecord.set("logic_name", LogicTypeEnum.PRE.getDesc()).set("logic_type", LogicTypeEnum.PRE.getCode())
                .set("m_code", new_m_code).set("button_code", button_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", 1).remove("id").remove("portVO");

        savePort(pre_type, null, button_code, preEvent, null, allPortsList, preRecord);
        logicContentList.add(preRecord);

    }

    //按钮后置动作
    private void formatAfter(Map<String, Object> afterEvent, Map<String, Object> map, String new_m_code, String button_code,
                             List<Map<String, Object>> allPortsList, List<Record> logicContentList) {
        if (null == afterEvent || afterEvent.isEmpty()) {
            return;
        }
        Record afterRecord = DataBaseUtil.map2Record(afterEvent);
        afterRecord.set("after_val", "");
        String after_type = afterRecord.getStr("after_type");
        Object after_val = afterEvent.get("after_val");
        if (StringUtils.isBlank(after_type)) {
            return;
        }
        if (AfterTypeEventEnum.oper_trace.getCode().equals(after_type)) {
            map.put("button_type", ButtonTypeEnum.OPER_TRACE.getCode());

        } else if (AfterTypeEventEnum.refresh_control.getCode().equals(after_type) || AfterTypeEventEnum.success_close.getCode().equals(after_type) ||
                AfterTypeEventEnum.details_close.getCode().equals(after_type)) {
            if (!ObjectUtils.isEmpty(after_val) && !after_val.equals("[]")) {
                Object obj = ConversionHolder.saveDataConversion(after_type, after_val);
                afterRecord.set("after_val", obj);
            }
        }
        afterRecord.set("logic_name", LogicTypeEnum.AFTER.getDesc()).set("logic_type", LogicTypeEnum.AFTER.getCode())
                .set("m_code", new_m_code).set("button_code", button_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", 1).remove("id").remove("portVO");

        savePort(null, after_type, button_code, null, afterEvent, allPortsList, afterRecord);
        logicContentList.add(afterRecord);

    }

    //按钮动作中事件
    private void formatEvent(Map<String, Object> actionEvent, Map<String, Object> map, String port_code, List<Map<String, Object>> allPortsList,
                             String new_m_code, String button_code, List<Record> logicContentList, String menu_id) {
        if (null == actionEvent || actionEvent.isEmpty()) {
            return;
        }
        String event_type = StringUtil.toString(actionEvent.get("event_type"));
        if (StringUtils.isBlank(event_type)) {
            return;
        }
        String portVOStr = StringUtil.toString(map.get("portVO"));
        if (StringUtils.isNotBlank(portVOStr) && !portVOStr.equals("{}")) {//接口地址参数
            Map<String, Object> portParaMap = new HashMap<>();
            portParaMap.put("button_port_code", port_code);
            portParaMap.put("portVOStr", portVOStr);
            allPortsList.add(portParaMap);
        }
        Record actionRecord = DataBaseUtil.map2Record(actionEvent);
        Object obj = actionEvent.get("event_val");
        String event_val = null;
        if (ClickEventTypeEnum.SAVE_IGNORE.getCode().equals(event_type) && !ObjectUtils.isEmpty(obj)) {
            obj = ConversionHolder.saveDataConversion(ClickEventTypeEnum.SAVE_IGNORE.getCode(), obj);
            actionRecord.set("event_val", obj);

        } else {
            event_val = StringUtils.isNotBlank(actionRecord.getStr("event_val")) ? actionRecord.getStr("event_val") : "";
            actionRecord.set("event_val", event_val);
        }

        if (ClickEventTypeEnum.CENTER_LIST.getCode().equals(event_type)) {//弹窗列表

            String select_script = StringUtil.toString(actionEvent.get("select_script"));
            List<Map<String, Object>> groupConds = (List<Map<String, Object>>) actionEvent.get("selectList");
            String newSelectCodeB = new_m_code + "$" + InnerListSelectEnum.button.getCode() + "$" + CodesUtil.createCommonCode("select_code_b");

            ksSqlSelectCSqlBDao.save(newSelectCodeB, select_script, null, menu_id, event_val, new_m_code);
            groupCondService.saveGroupConds( groupConds, newSelectCodeB, new_m_code, menu_id, actionRecord.getStr("is_para_nul"),
                    event_val, null, null);
            actionRecord.set("select_code_b", newSelectCodeB);

            String revScript = StringUtil.toString(actionEvent.get("revScript"));
            List<List<Map<String, Object>>> revList = (List<List<Map<String, Object>>>) actionEvent.get("revList");

            String newRevCodeB = actionRecord.getStr("rev_code_b");
            if (StringUtils.isBlank( newRevCodeB )){
                newRevCodeB = new_m_code + "$" + InnerListSelectEnum.button.getCode() + "$" + CodesUtil.createCommonCode("rev_code_b");
            }
            ksSqlSelectCSqlBDao.save(newRevCodeB, revScript, null, menu_id, event_val, new_m_code);
            ksSqlSelectCBDao.saveGroupConds(revList, newRevCodeB, menu_id, event_val, new_m_code, null);
            actionRecord.set("rev_code_b", newRevCodeB);

        }
        actionRecord.set("logic_name", LogicTypeEnum.EVENT.getDesc()).set("logic_type", LogicTypeEnum.EVENT.getCode())
                .set("m_code", new_m_code).set("button_code", button_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", 1)
                .remove("id").remove("m_name").remove("selectList").remove("select_script").remove("sql")
                .remove("revSql").remove("revScript").remove("revList").remove("is_para_nul");
        logicContentList.add(actionRecord);

    }


    //按钮跟随动作
    private void formatFollow(Map<String, Object> followEvent, String button_code, String new_m_code, List<Record> logicContentList,
                              List<Map<String, Object>> allFollowList) {
        if (null == followEvent || followEvent.isEmpty()) {
            return;
        }
        Record followRecord = new Record();
        Object after_follow_type = followEvent.get("after_follow_type");
        Object after_follow_val = followEvent.get("after_follow_val");
        if (ObjectUtils.isEmpty(after_follow_type)) {
            return;
        }

        if (AfterFollowTypeEnum.but_active.getCode().equals(after_follow_type)) {
            after_follow_val = button_code + "$follow";

        } else if (AfterFollowTypeEnum.refresh_control.getCode().equals(after_follow_type)) {
            after_follow_val = ConversionHolder.saveDataConversion(AfterFollowTypeEnum.refresh_control.getCode(), after_follow_val);

        } else {
            after_follow_val = "";
        }
        followRecord.set("logic_name", LogicTypeEnum.FOLLOW.getDesc()).set("logic_type", LogicTypeEnum.FOLLOW.getCode())
                .set("m_code", new_m_code).set("button_code", button_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", 1)
                .set("after_follow_type", after_follow_type).set("after_follow_val", after_follow_val);
        logicContentList.add(followRecord);

        List<Map<String, Object>> followList = (List<Map<String, Object>>) followEvent.get("followList");
        saveFollowList(allFollowList, followList, StringUtil.toString(after_follow_val));

    }

    private void saveFollowList(List<Map<String, Object>> allFollowList, List<Map<String, Object>> followList, String val_code) {
        if (null == followList || followList.isEmpty()) return;
        int i = 1;
        Object val_code_s = null;
        for (Map<String, Object> map : followList) {
            map.put("val_code", val_code);
            map.put("cr_dm", DateUtil.getNowDateTimeStr());
            map.put("up_ver", "1");
            map.put("disp_or", i);
            val_code_s = map.get("val_code_s");
            Object obj = ConversionHolder.saveDataConversion(AfterFollowTypeEnum.but_active.getCode(), val_code_s);
            map.put("val_code_s", obj);
            i++;
        }
        allFollowList.addAll(followList);
    }

    private void savePort(String pre_type, String after_type, String button_code, Map<String, Object> preEvent,
                          Map<String, Object> afterEvent, List<Map<String, Object>> allPortsList, Record record) {

        String port_code = null;
        String portVOStr = null;
        if (null != preEvent) {
            if (StringUtils.isBlank(pre_type) || !PreTypeEnum.PORT_AUTH.getCode().equals(pre_type)) return;
            port_code = button_code + "$pre$port_code";
            record.set("pre_val", port_code);
            portVOStr = StringUtil.toString(preEvent.get("portVO"));
        }
        if (null != afterEvent) {
            if (AfterTypeEventEnum.redirect.getCode().equals(after_type) || AfterTypeEventEnum.redirect_follow.getCode().equals(after_type)) {
                port_code = button_code + "$after$port_code";
                record.set("after_val", port_code);
                portVOStr = StringUtil.toString(afterEvent.get("portVO"));
            }

        }
        if (StringUtils.isNotBlank(portVOStr) && !portVOStr.equals("{}")) {//接口地址参数
            Map<String, Object> portParaMap = new HashMap<>();
            portParaMap.put("button_port_code", port_code);
            portParaMap.put("portVOStr", portVOStr);
            allPortsList.add(portParaMap);
        }

    }

    /**
     * 通过数据源类型获取工具栏信息
     */
    @Override
    public List<Record> getLogicByMcodeType(String m_code, String m_code_type) {
        String table = TABLE_NAME_B;
        if (McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)) {
            table = TABLE_NAME_C;
        }
        List<Record> recordList = DbEx.find("select * from " + table + " where m_code = ? and control_type=? order by control_order+0",
                m_code, ControlTypeEnum.updateButton.name());
        if (null == recordList || recordList.isEmpty()){
            return recordList;
        }
        Map<String, Object> conds = ksSqlButtonBDao.getGroupConds(m_code, null, m_code_type);
        List<Record> eventRecordList = ksMenuLogicContentBDao.getLogicContentByMcode(m_code, null, m_code_type);
        List<Record> allValsList = ksModelValsBDao.getList(m_code, null);
        for (Record record : recordList) {
            String but_color_type = record.getStr("but_color_type");//兼容版本默认值为1-->新增绿
            if (but_color_type == null || "".equals(but_color_type)) {
                record.set("but_color_type", "1");
            }
            String control_order = record.getStr("control_order");
            String button_code = record.getStr("button_code");
            List<Map<String, Object>> activeConds = (List<Map<String, Object>>)conds.get( button_code );
            if (null ==  activeConds){
                activeConds = Lists.newArrayList();
            }
            record.set("activeConds", activeConds);

            Object butDicds = record.get("but_di_cd_code");
            record.set("but_di_cd_code", Lists.newArrayList());
            if(!ObjectUtils.isEmpty(butDicds)){
                butDicds = ConversionHolder.selectDataConversion(FieldStyleEnum.multiSelect.name(), butDicds);
                record.set("but_di_cd_code", butDicds);
            }
            String load_cond = record.getStr("load_cond");
            if( "cascade_delete".equals( StringUtil.toString( record.getStr("button_type") ) ) ){
                record.set( "load_cond",   ConversionHolder.selectDataConversion(FieldStyleEnum.multiSelect.name() , load_cond ) );
            }

            String contType = record.getStr("cont_type");
            if (ControlStyleEnum.countField.name().equals(record.getStr("control_style")) && StringUtils.isBlank( contType)){
                record.set("cont_type", ContTypeEnum.dyn.getCode());
            }
            setDynSql( record,  button_code);

            setIterFields( record );

            List<Record> valsList = ksModelValsBDao.getListByButtonCode(button_code, allValsList);
            record.set("valsList", DataBaseUtil.record2Map(valsList));

            String port_code = record.getStr("port_code");//动作中接口参数
            buildPort(record, null, port_code, m_code_type, null, null);
            buildModelExc(record, button_code);

            Object expAttr = buildExpBtnAttr( m_code, button_code, record.getStr("control_style") , record.getStr("button_type"));
            record.set("btn_attr_exp", expAttr);

            Map<String, Object> preEvent = new HashMap<>();
            Map<String, Object> actionEvent = new HashMap<>();
            Map<String, Object> afterEvent = new HashMap<>();
            Map<String, Object> followEvent = new HashMap<>();

            if (null == eventRecordList || eventRecordList.isEmpty()){
                record.set("preEvent", preEvent).set("actionEvent", actionEvent).set("afterEvent", afterEvent).set("followEvent", followEvent);
                continue;
            }

            //按钮事件
            for (Record event : eventRecordList) {
                String logic_type = event.getStr("logic_type");
                String eventButtonCode = event.getStr("button_code");
                if (StringUtils.isBlank(eventButtonCode) || !eventButtonCode.equals(button_code) || StringUtils.isBlank(logic_type))
                    continue;

                if (logic_type.equals(LogicTypeEnum.PRE.getCode())) {
                    preEvent = DataBaseUtil.record2Map(event);
                    buildPort(record, logic_type, event.getStr("pre_val"), m_code_type, preEvent, null);

                } else if (logic_type.equals(LogicTypeEnum.EVENT.getCode())) {
                    actionEvent = DataBaseUtil.record2Map(event);
                    buildButtonClick(actionEvent, event, control_order, button_code, m_code);

                } else if (logic_type.equals(LogicTypeEnum.AFTER.getCode())) {
                    buildAfterEvent(event.getStr("after_type"), event.getStr("after_val"), event);
                    afterEvent = DataBaseUtil.record2Map(event);
                    buildPort(record, logic_type, event.getStr("after_val"), m_code_type, null, afterEvent);

                } else if (logic_type.equals(LogicTypeEnum.ACTIVE.getCode())) {
                    record.set("logic_script", event.getStr("logic_script"));

                } else if (logic_type.equals(LogicTypeEnum.FOLLOW.getCode())) {
                    String after_follow_type = event.getStr("after_follow_type");
                    String after_follow_val = event.getStr("after_follow_val");
                    followEvent.put("after_follow_type", after_follow_type);
                    followEvent.put("after_follow_val", after_follow_val);
                    buildFollowEvent(followEvent, after_follow_type, after_follow_val);
                }
            }
            record.set("preEvent", preEvent).set("actionEvent", actionEvent).set("afterEvent", afterEvent).set("followEvent", followEvent);

        }
        return recordList;
    }

    @Override
    public Object buildExpBtnAttr(String m_code, String button_code, String control_style, String button_type) {
        Object btnAttrExp = Lists.newArrayList();
        if( ControlStyleEnum.comb_find.name().equals( control_style ) ){
           return buildBtnCombFindAttr( m_code, button_code );
        }
        if( ControlStyleEnum.buttonGroup.name().equals( control_style ) ){
           return buildCombBtnAttr( m_code, button_code );
        }
        //按钮查询   不要凌乱    控件类型 跟控件属性都能有扩展属性配置
        if( ButtonTypeEnum.GROUP_QUERY.getCode().equals(button_type) ){
            return buildBtnFindAttr( m_code, button_code );
        }
        return btnAttrExp;
    }

    private List buildBtnFindAttr(String m_code, String button_code) {

        List<Record> fieldRecordList = findListFieldRecord(m_code);
        Map<String, String> fieldStyleMap = buildFieldStyleMap(fieldRecordList);
        Map<String, String> fieldTypeMap = buildFieldTypeMap(fieldRecordList);

        List<Object> btnCombAttrList = Lists.newArrayList();
        List<Record> recordList = DbEx.find("select * from ks_sql_vals_b where m_code=? and button_code=? order by disp_or+0 asc", m_code, button_code);
        for (Record record : recordList) {
            Map<String,Object> dataMap = Maps.newHashMap();
            Map<String,Object> attrMap = Maps.newHashMap();
            dataMap.put( "type",record.getStr("vals_type") );
            dataMap.put( "data",attrMap );
            String attr_code = record.getStr("attr_code");
            String attr_type = record.getStr("attr_type");
            attrMap.put("def_type", record.getStr("def_type"));
            attrMap.put("def_code", record.getStr("def_code"));
            attrMap.put("operator", attr_type);
            attrMap.put("fieldName", attr_code);
            attrMap.put("fieldNick", record.getStr("attr_name"));
            attrMap.put("fieldStyle",  StringUtil.toString( fieldStyleMap.get(attr_code) ) );
            attrMap.put("val_select_type", record.getStr("val_select_type"));
            attrMap.put("fieldType", StringUtil.toString( fieldTypeMap.get(attr_code) )  );
            btnCombAttrList.add( dataMap );
        }
        return btnCombAttrList;

    }

    private Object buildCombBtnAttr(String m_code, String button_code) {

        List<Object> btnCombAttrList = Lists.newArrayList();
        List<Record> recordList = DbEx.find("select * from ks_sql_vals_b where m_code=? and button_code=? order by disp_or+0 asc", m_code, button_code);
        for (Record record : recordList) {
            String attr_code = record.getStr("attr_code");
            btnCombAttrList.add( attr_code );
        }
        return btnCombAttrList;

    }


    @Override
    public List buildBtnCombFindAttr(String m_code, String button_code) {

        //根据m_code获取到动态sql参数
        List<Record> tableSqlList = DbEx.find("select m_code,sql_name from ks_table_sql_b where m_code=?", m_code);
        if( tableSqlList.isEmpty() ){
            tableSqlList = DbEx.find("select m_code,sql_name from ks_table_sql_c where m_code=?", m_code);
            if( tableSqlList.isEmpty() ){
                return Lists.newArrayList();
            }
        }
        Map<String,Record> orderAsKeyMap = Maps.newHashMap();
        String sql_name = tableSqlList.get(0).getStr("sql_name");
        String sql = "select para.* from ks_model_dyn_sql_b k join ks_model_dyn_sql_para_b para on k.dyn_code=para.dyn_code where k.p_code=? order by para_order+0  asc ";
        List<Record> sqlDicParamRecordList = DbEx.find(sql, sql_name );

        // 动态sql数据源    分组查询：新增    新增组          新增标记
        if( !sqlDicParamRecordList.isEmpty() ){
            Map<String,Record> ZWFAsKeyMap = Maps.newHashMap();
            for (Record record : sqlDicParamRecordList) {
                //  para_order  di_cd  para_type  para_val
                orderAsKeyMap.put( record.getStr("para_order"), record );
                String para_type = record.getStr("para_type");
                if( DynamicParaTypeEnum.ZWF.getCode().equals( para_type ) ){
                    ZWFAsKeyMap.put( record.getStr("para_val"), record );
                }
            }
            return buildBtnCombAttrListForCustomerDBSource(m_code, button_code, orderAsKeyMap, ZWFAsKeyMap, sql_name);
        }else{
            // 配置化数据源     分组查询：新增    新增组（无）    新增标记（无）
            return buildBtnCombAttrListForConfigDBSource(m_code, button_code);
        }


    }

    private List buildBtnCombAttrListForCustomerDBSource(String m_code, String button_code, Map<String, Record> orderAsKeyMap,
                                                         Map<String,Record> ZWFAsKeyMap ,String sql_name ) {

        //dynCode
        List<Record> dynRecord = DbEx.find("select dyn_code from ks_model_dyn_sql_b where p_code=?", sql_name);
        if( dynRecord.isEmpty() ){
            return Lists.newArrayList();
        }
        String dynCode = dynRecord.get(0).getStr( "dyn_code" );
        //通过m_code 获取列表字段类型
        List<Record> fieldRecordList = findListFieldRecord(m_code);
        Map<String, String> fieldStyleMap = buildFieldStyleMap(fieldRecordList);
        Map<String, String> fieldTypeMap = buildFieldTypeMap(fieldRecordList);
        Map<String, Record> fieldRecordMap = buildFieldRecordMap(fieldRecordList);
        List<Object> btnCombAttrList = Lists.newArrayList();
        List<Record> recordList = DbEx.find("select * from ks_sql_vals_b where m_code=? and button_code=? order by disp_or+0 asc", m_code, button_code);
        for (Record record : recordList) {
            String vals_type = record.getStr("vals_type");
            Map<String,Object> dataMap = Maps.newHashMap();
            dataMap.put("type", vals_type );
            // attr_code  attr_name        attr_type       第一组
            Map<String,Object> attrMap = Maps.newHashMap();
            String attr_code = record.getStr("attr_code");
            String attr_type = record.getStr("attr_type");
            attrMap.put("def_type", record.getStr("def_type"));
            attrMap.put("def_code", record.getStr("def_code"));
            attrMap.put("operator", attr_type);
            attrMap.put("fieldName", attr_code);
            attrMap.put("fieldNick", record.getStr("attr_name"));
            attrMap.put("dynCode", dynCode );
            attrMap.put("val_select_type", record.getStr("val_select_type"));
            attrMap.put("val_select_code", record.getStr("val_select_code"));
            attrMap.put("operator_expend", record.getStr("attr_type_exp"));
            if( CombFindType.group.name().equals( vals_type ) || CombFindType.single.name().equals( vals_type ) || StringUtils.isBlank( vals_type ) ){
                //添加分组跟单个 组合查询条件
                addCombFindDataForGroupOrSingleInAttrMap(fieldStyleMap, fieldTypeMap, fieldRecordMap, attrMap, attr_code);
                //判断val_select_type 值是否为空且不能是null（导库可能导致null字符串存在）  不为空的话 fieldStyle值以  val_select_type 为主
                if ( StringUtils.isNotBlank( record.getStr("val_select_type") ) && !record.getStr("val_select_type").equalsIgnoreCase("null") ) {
                    attrMap.put("fieldStyle", record.getStr("val_select_type"));
                }
            }else{
                //添加占位符 组合查询条件
                addCombFindDataForMarkInAttrMap(orderAsKeyMap, ZWFAsKeyMap, attr_type, attrMap, m_code, button_code);
            }
            String val_attr_type = record.getStr("val_attr_type");
            if( StringUtils.isNotBlank(val_attr_type) ){
                // val_code   val_attr_name    val_attr_type   第二组
                List<Map<String,Object>> groupAttrList = Lists.newArrayList();
                Map<String,Object> nextAttrMap = Maps.newHashMap();
                String val_code = record.getStr("val_code");
                nextAttrMap.put("fieldName", val_code);
                nextAttrMap.put("fieldStyle", StringUtil.toString( fieldStyleMap.get(attr_code) )  );
                nextAttrMap.put("fieldType", StringUtil.toString( fieldTypeMap.get(val_code) )  );
                nextAttrMap.put("fieldNick", record.getStr("val_attr_name"));
                nextAttrMap.put("operator", record.getStr("val_attr_type"));
                nextAttrMap.put("dynCode", dynCode );
                groupAttrList.add(attrMap);
                groupAttrList.add(nextAttrMap);
                dataMap.put( "data",groupAttrList );
                btnCombAttrList.add(dataMap);
                continue;
            }
            dataMap.put( "data",attrMap );
            btnCombAttrList.add( dataMap );
        }
        return btnCombAttrList;
    }

    /**
     * 配置型的数据源  按钮扩展属性
     * @param m_code
     * @param button_code
     * @return
     */
    private List buildBtnCombAttrListForConfigDBSource(String m_code, String button_code) {
        //通过m_code 获取列表字段类型
        List<Record> fieldRecordList = findListFieldRecord(m_code);
        Map<String, String> fieldStyleMap = buildFieldStyleMap(fieldRecordList);
        Map<String, String> fieldTypeMap = buildFieldTypeMap(fieldRecordList);
        Map<String, Record> fieldRecordMap = buildFieldRecordMap(fieldRecordList);
        List<Object> btnCombAttrList = Lists.newArrayList();
        List<Record> recordList = DbEx.find("select * from ks_sql_vals_b where m_code=? and button_code=? order by disp_or+0 asc", m_code, button_code);
        for (Record record : recordList) {
            String vals_type = record.getStr("vals_type");
            Map<String,Object> dataMap = Maps.newHashMap();
            dataMap.put("type", vals_type );
            // attr_code  attr_name        attr_type       第一组
            Map<String,Object> attrMap = Maps.newHashMap();
            String attr_code = record.getStr("attr_code");
            String attr_type = record.getStr("attr_type");
            attrMap.put("def_type", record.getStr("def_type"));
            attrMap.put("def_code", record.getStr("def_code"));
            attrMap.put("operator", attr_type);
            attrMap.put("fieldName", attr_code);
            attrMap.put("fieldNick", record.getStr("attr_name"));
            attrMap.put("dynCode", "" );
            attrMap.put("val_select_type", record.getStr("val_select_type"));
            attrMap.put("val_select_code", record.getStr("val_select_code"));
            attrMap.put("operator_expend", record.getStr("attr_type_exp"));
            // modify 2021-12-01 yuanj 增加分组查询按钮宽度查询
            attrMap.put("query_column", record.getStr("query_column"));
            if( CombFindType.group.name().equals( vals_type ) || CombFindType.single.name().equals( vals_type ) || StringUtils.isBlank( vals_type ) ){
                //添加分组跟单个 组合查询条件
                addCombFindDataForGroupOrSingleInAttrMap(fieldStyleMap, fieldTypeMap, fieldRecordMap, attrMap, attr_code);
                //判断val_select_type 值是否为空且不能是null（导库可能导致null字符串存在）  不为空的话 fieldStyle值以  val_select_type 为主
                if ( StringUtils.isNotBlank( record.getStr("val_select_type") ) && !record.getStr("val_select_type").equalsIgnoreCase("null") ) {
                    attrMap.put("fieldStyle", record.getStr("val_select_type"));
                    attrMap.put("fieldType", record.getStr("val_select_type"));
                }
            }
            String but_di_cd = record.getStr("but_di_cd");
            attrMap.put("but_di_cd", but_di_cd);

            if( StringUtils.isNotBlank(but_di_cd) ){
                List<Record> dynSqlRecordList = DbEx.find("select dic_b.parent_code,dic_b.code,dic_b.val from ks_sql_button_dic_b dic_b join ks_sql_button_select_b sel_b on dic_b.code=sel_b.down_code \n" +
                        "where dic_b.parent_code=? and para_type=? order by sel_b.group_no+0 asc, sel_b.group_order+0 asc", but_di_cd, GroupCondRightEnum.DICSQL.getCode());
                //判断是否重新加载
                attrMap.put("but_di_cd_is_reload", dynSqlRecordList.isEmpty() ? "0":"1");
            }

            Object butDicds = record.getStr("but_di_cd_code");
            if(!ObjectUtils.isEmpty(butDicds)){
                butDicds = ConversionHolder.selectDataConversion(FieldStyleEnum.multiSelect.name() , butDicds );
            }
            attrMap.put("but_di_cd_code", butDicds);

            if( CombFindType.group.name().equals( vals_type ) ){
                // val_code   val_attr_name    val_attr_type   第二组
                List<Map<String,Object>> groupAttrList = Lists.newArrayList();
                Map<String,Object> nextAttrMap = Maps.newHashMap();
                String val_code = record.getStr("val_code");
                nextAttrMap.put("fieldName", val_code);
                nextAttrMap.put("fieldStyle", StringUtil.toString( fieldStyleMap.get(attr_code) )  );
                nextAttrMap.put("fieldType", StringUtil.toString( fieldTypeMap.get(val_code) )  );
                nextAttrMap.put("fieldNick", record.getStr("val_attr_name"));
                nextAttrMap.put("operator", record.getStr("val_attr_type"));
                nextAttrMap.put("dynCode", "" );
                groupAttrList.add(attrMap);
                groupAttrList.add(nextAttrMap);
                dataMap.put( "data",groupAttrList );
                btnCombAttrList.add(dataMap);
                continue;
            }

            dataMap.put( "data",attrMap );
            btnCombAttrList.add( dataMap );
        }
        return btnCombAttrList;
    }

    /**
     * 添加占位符 组合查询条件
     * @param orderAsKeyMap
     * @param attrMap
     */
    private void addCombFindDataForMarkInAttrMap(Map<String, Record> orderAsKeyMap,Map<String,Record> ZWFAsKeyMap, String attr_type,  Map<String, Object> attrMap,String m_code, String button_code) {
        CombFindMarkType combFindMarkType = CombFindMarkType.getCombFindMarkTypeByName(attr_type);
        attrMap.put("fieldStyle", combFindMarkType.name()  );
        attrMap.put("fieldType", combFindMarkType.name() );
        Record dicSqlParamRecord = orderAsKeyMap.get(attrMap.get("fieldName"));
        if( CombFindMarkType.dicSelect.equals( combFindMarkType ) ){
            if( dicSqlParamRecord==null ){
                dicSqlParamRecord = ZWFAsKeyMap.get( attrMap.get("fieldName") );
            }
            //如果是字典下拉  根据attrMap.get("fieldName") 查找相关字典
            QzAssert.notEmpty( dicSqlParamRecord, BusinessException.buildBiz("字段{}未找到相关字典配置", attrMap.get("fieldName") ) );
            String di_cd = dicSqlParamRecord.getStr("di_cd");
            String para_val = dicSqlParamRecord.getStr("para_val");
//                    构建字典  di_cd_items  Map
            List<Map<String,Object>> diCdItems = buildDiCdItems( di_cd, para_val );
            attrMap.put("di_cd_items", diCdItems);
        }
        if( CombFindMarkType.sqlDicSelect.equals( combFindMarkType ) ){
            QzAssert.notEmpty( dicSqlParamRecord, BusinessException.buildBiz("字段{}未找到相关字典配置", attrMap.get("fieldName") ) );
            attrMap.put("dynCode", dicSqlParamRecord.getStr("dyn_code") );
            String sqlPrn = dicSqlParamRecord.getStr("para_val");
            // 查询  ks_table_sql_a 获取  sql_name  再查ks_model_dyn_sql_b  获取dyn_code
            List<Record> recordList = DbEx.find("select dyn_code from ks_table_sql_a t_sql join ks_model_dyn_sql_b dyn_sql on t_sql.sql_name=dyn_sql.p_code where sql_prn=?", sqlPrn);
            QzAssert.notEmpty( recordList, BusinessException.buildBiz("未找到关联动态sql数据源 通过sqlprn{}", sqlPrn  ) );
            attrMap.put("dynCode", recordList.get(0).getStr("dyn_code") );
            attrMap.put("di_cd_items", Lists.newArrayList());

        }
    }

    /**
     * 添加分组跟单个 组合查询条件
     * @param fieldStyleMap
     * @param fieldTypeMap
     * @param fieldRecordMap
     * @param attrMap
     * @param tablePointFieldName
     */
    private void addCombFindDataForGroupOrSingleInAttrMap(Map<String, String> fieldStyleMap, Map<String, String> fieldTypeMap,
                                                 Map<String, Record> fieldRecordMap, Map<String, Object> attrMap, String tablePointFieldName) {
        String fieldStyle = StringUtil.toString(fieldStyleMap.get(tablePointFieldName));
        attrMap.put("fieldStyle", fieldStyle);
        String fieldType = StringUtil.toString(fieldTypeMap.get(tablePointFieldName));
        attrMap.put("fieldType", fieldType);
        if(  FieldStyleEnum.signSelect.name().equals( fieldStyle ) && fieldRecordMap.get(tablePointFieldName)!=null ){
            attrMap.put("fieldStyle", CombFindMarkType.dicSelect.name());
            attrMap.put("fieldType", CombFindMarkType.dicSelect.name());
            Record fieldRecord = fieldRecordMap.get(tablePointFieldName);
            String di_cd = fieldRecord.getStr("di_cd");
            String di_cd_code = fieldRecord.getStr("di_cd_code");
            List<Map<String,Object>> diCdItems = buildDiCdItems( di_cd, di_cd_code );
            attrMap.put("di_cd_items", diCdItems);
        }
    }


    /**
     *
     * @param di_cd
     * @param para_val  范围空间  如果有值 查出的结果必须在 para_val内
     * @return
     */
    private List<Map<String,Object>> buildDiCdItems(String di_cd, String para_val) {
        List<Map<String,Object>> diCdItems = Lists.newArrayList();
        if( StringUtils.isBlank(di_cd) ){
            return diCdItems;
        }
        List<Record> dicRecordList = DbEx.find("select * from ks_dic_b where code=?", di_cd);
        if( dicRecordList.isEmpty() ){
            return diCdItems;
        }
        Set<String> dicCodes = Sets.newHashSet();
        if( StringUtils.isNotBlank( para_val ) ){
            dicCodes = Sets.newHashSet( Splitter.on(",").splitToList( para_val ) );
        }
        List<Map<String,Object>> select_items = Lists.newArrayList();
        Map<String, String> code2ValLinkMap = ksDicBSerivce.findCode2ValLinkMapByParentCode(di_cd);
        Iterator<Map.Entry<String, String>> iterator = code2ValLinkMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> next = iterator.next();
            String code = next.getKey();
            String value = next.getValue();
            //如果不是空 按照指定的code填充子项
            if( !dicCodes.isEmpty() ){
                if( dicCodes.contains( code ) ){
                    Map<String, Object> select_item = Maps.newHashMap();
                    select_item.put("label",value );
                    select_item.put("value",code );
                    select_items.add(select_item);
                }
                continue;
            }
            Map<String, Object> select_item = Maps.newHashMap();
            select_item.put("label",value );
            select_item.put("value",code );
            select_items.add(select_item);
        }
        return select_items;
    }

    private Map<String, Record> buildFieldRecordMap(List<Record> fieldRecordList) {
        Map<String,Record> fieldTypeMap = Maps.newHashMap();
        for (Record record : fieldRecordList) {
            fieldTypeMap.put( record.getStr("field_name"), record );
        }
        return fieldTypeMap;
    }

    private Map<String, String> buildFieldStyleMap(List<Record> fieldRecordList) {
        Map<String,String> fieldTypeMap = Maps.newHashMap();
        for (Record record : fieldRecordList) {
            fieldTypeMap.put( record.getStr("field_name"), record.getStr("field_style") );
        }
        return fieldTypeMap;
    }
    private Map<String, String> buildFieldTypeMap(List<Record> fieldRecordList) {
        Map<String,String> fieldTypeMap = Maps.newHashMap();
        for (Record record : fieldRecordList) {
            fieldTypeMap.put( record.getStr("field_name"), record.getStr("field_type") );
        }
        return fieldTypeMap;
    }

    private List<Record> findListFieldRecord(String m_code) {
        List<Record> fieldRecordList= Lists.newArrayList();
        List<Record> fieldRecordBList = DbEx.find("select field_name,field_style,field_type,di_cd,di_cd_code from ks_model_list_field_b where m_code=?", m_code);
        List<Record> fieldRecordCList = DbEx.find("select field_name,field_style,field_type,di_cd,di_cd_code from ks_model_list_field_c where m_code=?", m_code);
        fieldRecordList.addAll(fieldRecordBList);
        fieldRecordList.addAll(fieldRecordCList);
        return fieldRecordList;
    }

    private void setIterFields( Record record ){
        String controlStyle = record.getStr("control_style");
        if (ControlStyleEnum.iterSearch.name().equals( controlStyle) || ControlStyleEnum.iterSearchScope.name().equals( controlStyle)){
            Object logicName = record.get("logic_name");
            logicName = ConversionHolder.selectDataConversion( FieldStyleEnum.multiSelect.name(), logicName);
            record.set("logic_name", logicName);
        }

    }

    private void buildModelExc(Record record, String button_code) {
        Map<String, Object> excMap = ksModelExcBDao.getExcListByButtonCode(button_code, false);
        record.set("excVal", excMap);
    }

    private void buildFollowEvent(Map<String, Object> followEvent, String after_follow_type, String after_follow_val) {
        if (StringUtils.isBlank(after_follow_val)){
            return;
        }
        if (AfterFollowTypeEnum.refresh_control.getCode().equals(after_follow_type)) {
            Object obj = ConversionHolder.selectDataConversion(AfterFollowTypeEnum.refresh_control.getCode(), after_follow_val);
            followEvent.put("after_follow_val", obj);
            return;
        }

        String sql = "select val_code,control_code,val_code_s,is_active,disp_or from ks_menu_logic_mult_b where val_code=? order by disp_or+0";
        List<Record> recordList = ksMenuLogicMultBDao.selectListBySql(sql, after_follow_val);
        if ( null == recordList || recordList.isEmpty()){
            followEvent.put("followList", DataBaseUtil.record2Map(recordList));
            return;
        }
        Object val_code_s = null;
        for (Record record : recordList) {
            val_code_s = record.get("val_code_s");
            if (!ObjectUtils.isEmpty(val_code_s)) {
                Object obj = ConversionHolder.selectDataConversion(AfterFollowTypeEnum.but_active.getCode(), record.get("val_code_s"));
                record.set("val_code_s", obj);
            }
        }
        followEvent.put("followList", DataBaseUtil.record2Map(recordList));
    }

    private void buildAfterEvent(String after_type, String after_val, Record event) {
        if (StringUtils.isBlank(after_type) || StringUtils.isBlank(after_val)) return;
        if (AfterTypeEventEnum.refresh_control.getCode().equals(after_type) || AfterTypeEventEnum.success_close.getCode().equals(after_type)
                || AfterTypeEventEnum.details_close.getCode().equals(after_type)) {
            Object obj = ConversionHolder.selectDataConversion(after_type, after_val);
            event.set("after_val", obj);
        }

    }

    /**
     * 组装动作前后接口事件
     */
    private void buildPort(Record record, String logic_type, String port_code, String m_code_type, Map<String, Object> preEvent, Map<String, Object> afterEvent) {
        if (StringUtils.isBlank(port_code)) {
            return;
        }
        PortVO portVO = ksSqlPortCDao.getPortAndParaAndReturn(port_code, m_code_type);

        if (StringUtils.isBlank(logic_type)) {
            record.set("portVO", portVO);
        } else {
            if (null != preEvent) {
                preEvent.put("portVO", portVO);
            } else {
                afterEvent.put("portVO", portVO);
            }

        }
    }


    /**
     * 组装按钮弹窗数据源条件
     */
    private void buildButtonClick(Map<String, Object> actionEvent, Record event, String control_order, String button_code, String m_code) {
        String event_type = event.getStr("event_type");
        if (StringUtils.isBlank(event_type)) {
            return;
        }

        String event_val = event.getStr("event_val");
        Object obj = event.get("event_val");
        if (event_type.equals(ClickEventTypeEnum.CENTER_LIST.getCode())) {//弹窗小列表
            String selectCodeB = event.getStr("select_code_b");
            String mName = null;
            List<Map<String, Object>> selectList = Lists.newArrayList();
            if (StringUtils.isNotBlank(event_val)) {//兼容以前配置

                selectList = groupCondService.getQuoteGroupConds( selectCodeB, button_code, event_val,
                        ClickEventTypeEnum.CENTER_LIST.getCode(), control_order, false );
                Record model = ksModelDao.selectFirstOneBySql("select m_name from ks_model_c where m_code=?", event_val);
                if (null != model) {
                    mName = model.getStr("m_name");
                }
            }
            String isParaNul = GroupCond.getParaNull( selectList );
            actionEvent.put("selectList", selectList);
            actionEvent.put("m_name", mName);
            actionEvent.put("is_para_nul", isParaNul);

            buildRev(event.getStr("rev_code_b"), actionEvent);

        } else if (event_type.equals(ClickEventTypeEnum.CENTER_INFO.getCode()) && StringUtils.isNotBlank(event_val)) {//弹窗小详情

            Record menuModel = ksModelInfoDao.selectFirstOneBySql("select info_name from ks_model_info_b where info_code=?", event_val);
            if (null != menuModel) actionEvent.put("m_name", menuModel.getStr("info_name"));

        } else if (event_type.equals(ClickEventTypeEnum.SAVE_IGNORE.getCode()) && !ObjectUtils.isEmpty(obj)) {
            obj = ConversionHolder.selectDataConversion(ClickEventTypeEnum.SAVE_IGNORE.getCode(), obj);
            actionEvent.put("event_val", obj);
        }

    }


    //数据返显条件
    private void buildRev(String revCodeB, Map<String, Object> actionEvent) {
        if (StringUtils.isBlank(revCodeB)) {
            actionEvent.put("revSql", null);
            actionEvent.put("revList", Lists.newArrayList());
            actionEvent.put("revScript", null);
            return;
        }
        List<List<Map<String, Object>>> revList = ksSqlSelectCBDao.getGroupConds(null, null, null, null, revCodeB);
        String revScript = null;
        Record revSqlRecord = ksSqlSelectCSqlBDao.getScriptAndSqlOther(null, null, null, null, revCodeB);
        if (null != revSqlRecord) {
            revScript = revSqlRecord.getStr("select_script");
        }
        List<Map<String, Object>> list = GroupCond.formatTileConds( revList );
        Map<String, Object> condMap = appendSourceSqlService.appendSourceSql(DataBaseUtil.map2Record(list), null, null,
                false, false);
        actionEvent.put("revSql", condMap.get("whereSql"));
        actionEvent.put("revList", revList);
        actionEvent.put("revScript", revScript);
    }

    /**
     * 通过类型获取页面属性
     */
    @Override
    public Record getLogicByControlType(String m_code, String control_type, String m_code_type) {
        String table = TABLE_NAME_B;
        if ( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)) {
            table = TABLE_NAME_C;
        }
        String sql = "select select_code,select_script from " + table + " where 1=1 ";
        List<String> list = new ArrayList<>();
        if (StringUtils.isNotBlank(m_code)) {
            sql += " and m_code=? ";
            list.add(m_code);
        }
        if (StringUtils.isNotBlank(control_type)) {
            sql += " and control_type=? ";
            list.add(control_type);
        }
        Record record = DbEx.findFirst(sql, list.toArray());
        return record;
    }

    /**
     * 保存加载列表时 loadList,关键词selectField,分组selectButton
     */
    @Override
    @JFinalTx
    public Boolean saveToControlType(SourceConfigVO sourceConfigVO) {
        String new_m_code = sourceConfigVO.getNew_m_code();
        String old_m_code = sourceConfigVO.getOld_m_code();
        String menu_id = sourceConfigVO.getMenu_id();
        String m_code_type = sourceConfigVO.getM_code_type();
        Integer isSaveAs = sourceConfigVO.getIsSaveAs();
        String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
        AttrVO attrvo = sourceConfigVO.getAttrVO();

        ControlTypeEnum[] typeArr = ControlTypeEnum.values();
        for (int i = 0; i < typeArr.length; i++) {
            ControlTypeEnum type = typeArr[i];
            String control_type = type.name();
            if (control_type.equals(ControlTypeEnum.updateButton.name())) {
                continue;
            }

            boolean isExists = false;
            Record logic = getOneByColumn(table, "m_code,control_type", old_m_code, control_type);
            if (null != logic) {
                isExists = true;

            } else {
                logic = new Record();
            }
            logic.set("m_code", new_m_code).set("m_code_type", m_code_type).set("control_type", type.name())
                    .set("port_code", control_type).set("menu_id", menu_id);

            if (control_type.equals(ControlTypeEnum.loadList.name())) {

                String select_script = attrvo.getSelect_script();
                logic.set("select_script", select_script);
                logic.set("select_code", attrvo.getSelectCode());

            } else if (control_type.equals(ControlTypeEnum.selectButton.name())) {
                logic.set("where_code", new_m_code + "$where_add");
            }

            if (isExists) {
                logic.set("up_dm", DateUtil.getNowDateTimeStr());
                update(table, logic);

            } else {
                logic.set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1");
                deleteByCustom(table, "m_code,control_type", old_m_code, control_type);
                save(table, logic);
            }
        }
        return true;
    }


    /**
     * 列表按钮
     */
    @Override
    public List<Record> getListButtonLogic(String mCode, String mType) {
        String table = TABLE_NAME_B;
        if (MTypeEnum.INNER_LIST.getCode().equals(mType)) {
            table = TABLE_NAME_C;
        }
        String sql = "select button_code,control_desc,control_style,but_di_cd from " + table + " where m_code=? and control_type=? and control_desc is not null and control_desc != '' ";
        List<Record> records = selectListBySql(sql, mCode, ControlTypeEnum.updateButton.name());
        return records;
    }

    /**
     * 是否是统计按钮
     * @param buttonCode
     * @param mType
     * @param controlStyle
     * @return
     */
    @Override
    public Record statisticButton(String buttonCode, String mType, String controlStyle) {
        String table = TABLE_NAME_B;
        if (MTypeEnum.INNER_LIST.getCode().equals(mType)) {
            table = TABLE_NAME_C;
        }
        String sql = "select cont_type,load_cond from "+ table+" where button_code=? and control_style=?";
        Record record = selectFirstOneBySql( sql , buttonCode, controlStyle );
        return record;
    }

    /**
     * 2021-12-01 校验是否是正整数
     * @param str
     * @param isPositive
     * @return
     */
    public boolean isInteger(String str,boolean isPositive) {
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        if (!isPositive)//不继续检查是否是正整数
        return pattern.matcher(str).matches();
       //继续检查是否是正整数
        if(pattern.matcher(str).matches()){
            return Integer.parseInt(str) >0;
        }
        return pattern.matcher(str).matches();
    }
}
