package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.entity.KsSyCEntity;

/**
 * 系统配置-dao接口
 * @author zf
 *
 */
public interface KsSyCDao extends BaseDao{
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	Boolean save(Record record);
	
	/**
	 * 系统是否存在
	 * @param syNa 系统名称
	 * @param syId 系统id
	 * @return
	 */
	List<Record> isExists(String syNa,Long syId);
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	
	/**
	 * 删除
	 * @param id 主键
	 * @return
	 */
	Boolean delete(Long id);
	
	/**
	 * 列表查询
	 * @return
	 */
	List<Record> getList();
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	Record getOne(Long id);
	/**
	 * 一键修正系统路径配置
	 * @return
	 */
	Boolean correctUrl(String baseCompUrl);
}
