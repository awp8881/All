package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.common.collect.Maps;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsCompConfParaBDao;
import com.qzsoft.lims.ks.dao.KsCompParaDefBDao;

/**
 * 组件参数定义管理-dao实现
 * @author hqp
 *
 */
@Repository
public class KsCompParaDefBDaoImpl extends BaseDaoImpl implements KsCompParaDefBDao {
	private static final String TABLE_NAME = "ks_comp_para_def_b";
	
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	@Override
	public Boolean save(Record record) {
		return super.save(TABLE_NAME,record);
	}
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	@Override
	public Boolean update(Record record) {
		return super.update(TABLE_NAME,record);
	}
	
	/**
	 * 删除
	 * @param defCode 组件编码
	 * @return
	 */
	@Override
	public Boolean deleteByDefCode(String defCode) {
		return super.deleteByCustom(TABLE_NAME, "def_code", defCode);
	}
	
	/**
	 * 删除
	 * @param compType 组件类型
	 * @return
	 */
	@Override
	public Boolean deleteByCompType(String compType) {
		return super.deleteByCustom(TABLE_NAME, "comp_type", compType);
	}
	
	
	/**
	 * 根据定义编码查询
	 * @param compType 定义编码
	 * @return
	 */
	@Override
	public List<Record> getListByDefCode(String defCode) {
		return DbEx.find("select * from " + TABLE_NAME+" where def_code = ? order by para_order+0",defCode);
//		return DbEx.find("select * from " + TABLE_NAME+" where comp_type = ? order by para_order ",compType);
	}
	
	/**
	 * 根据组件类型查询
	 * @param compType 组件类型
	 * @return
	 */
	@Override
	public List<Record> getListByCompType(String compType) {
		return DbEx.find("select * from " + TABLE_NAME+" where comp_type = ? ",compType);
//		return DbEx.find("select * from " + TABLE_NAME+" where comp_type = ? order by para_order ",compType);
	}
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	@Override
	public Record getOne(Long id) {
		return super.selectById(TABLE_NAME,id);
	}
	
	/**
	 * 删除
	 * @param id 主键
	 * @return
	 */
	@Override
	public Boolean deleteById(Long id) {
		return super.deleteByCustom(TABLE_NAME, "id", id);
	}

	@Override
	public Map<String, List<Record>> getAllCompParas() {
		String sql = "select * from "+TABLE_NAME+" order by cr_dm";
		List<Record> compParas = selectListBySqlNoParas(sql);
		if (null == compParas ){
			return Maps.newHashMap();
		}
		Map<String, List<Record>> paraMap = compParas.stream().collect(Collectors.groupingBy( compPara -> compPara.getStr("def_code")));
		if (null == paraMap ){
			return Maps.newHashMap();
		}
		return paraMap;
	}
}
