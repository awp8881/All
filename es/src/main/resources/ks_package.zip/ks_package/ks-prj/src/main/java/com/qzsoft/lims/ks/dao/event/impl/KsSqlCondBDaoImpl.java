package com.qzsoft.lims.ks.dao.event.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.comp.GroupCond;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.KsModelDynSqlBDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondBDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondParaBDao;
import com.qzsoft.lims.ks.eum.groupCond.GroupCondLeftEnum;
import com.qzsoft.lims.ks.eum.groupCond.GroupCondRightEnum;
import com.qzsoft.lims.ks.expression.ExpressRepository;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.util.TableHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
public class KsSqlCondBDaoImpl extends BaseDaoImpl implements KsSqlCondBDao{

	private static final String TABLE_NAME = "ks_sql_cond_b";
	
	@Autowired
	private KsSqlCondParaBDao ksSqlCondParaBDao;

	@Autowired
	private KsDicBDao ksDicBDao;

	@Autowired
	private ExpressRepository expressRepository;

	@Autowired
	private KsModelDynSqlBDao ksModelDynSqlBDao;


	/**
	 *  条件组
	 */
	@Override
	public List<Record> getByPCode(String pCode, Boolean jsonYn) {
		String condSql = "select * from "+TABLE_NAME+" where p_code=? order by group_no+0,group_order+0";
		List<Record> condList = selectListBySql(condSql, pCode);
		List<Record> condParaList = ksSqlCondParaBDao.getByPCode(pCode);
		DataBaseUtil.buildCondList(condList, condParaList, "gro_cond_code");
		parse(condList, jsonYn);
		return condList;
	}

	/**
	 * 批量保存
	 * */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> allCondList) {
		boolean succYn = true;
		if (null == allCondList || allCondList.isEmpty()) {
			return succYn;
		}
		for (Map<String, Object> map : allCondList) {
			map.put("cr_dm", DateUtil.getNowDateTimeStr());
			map.put("up_ver", "1");
			map.remove("di_cd_str");
			map.remove("dicParaList_str");
		}
		List<Record> recordList = DataBaseUtil.map2Record(allCondList);
		return saveList(TABLE_NAME, recordList);
	}
	
	private void parse(List<Record> condList, Boolean jsonYn) {
		if (null == condList || condList.isEmpty()) {
			return;
		}
		if (!jsonYn){
			return;
		}

		for (Record record : condList) {
			String paraType = record.getStr("para_type");
			String paraVal = record.getStr("para_val");
			if (GroupCondRightEnum.ZD.getCode().equals(paraType) ) {
				record.set("para_val", DataBaseUtil.buildFieldName(paraVal));
			}
			if(!jsonYn){
				continue;
			}
			String paraTypeK = record.getStr("para_type_k");
			String paraName = record.getStr("para_name");

			if (GroupCondLeftEnum.EXP.getCode().equals(paraTypeK)){
				Set<String> leftExpBusCodes =  expressRepository.getExpBusCode( paraName);
				record.set("leftExpBusCodes", leftExpBusCodes);

			}else if(GroupCondLeftEnum.SQL.getCode().equals(paraTypeK)){
				Set<String> leftDynBusCodes = ksModelDynSqlBDao.getBusCode(Lists.newArrayList( paraName));
				record.set("leftDynBusCodes", leftDynBusCodes);
			}

			if (GroupCondRightEnum.EXP.getCode().equals(paraType)){
				Set<String> rightExpBusCodes =  expressRepository.getExpBusCode( paraVal);
				record.set("rightExpBusCodes", rightExpBusCodes);

			}else if(GroupCondRightEnum.SQL.getCode().equals(paraType)){
				Set<String> rightDynBusCodes = ksModelDynSqlBDao.getBusCode(Lists.newArrayList( paraVal));
				record.set("rightDynBusCodes", rightDynBusCodes);
			}
		}

	}

	@Override
	public Map<String, Object> getGroupConds(String pCode, Boolean jsonYn) {

		String condSql = "select * from "+TABLE_NAME+" where p_code=? order by group_no+0,group_order+0";
		List<Record> condList = selectListBySql(condSql, pCode);
		List<Record> condParaList = ksSqlCondParaBDao.getGroupCondParas(pCode);
		parse(condList, jsonYn);
		List<Record> allDicds = ksDicBDao.getAllList();
		return GroupCond.buildLogicCondList( condList, condParaList, allDicds, "gro_cond_code" );
	}


	@Override
	public Map<String, Object> getGroupCondsByCode(List<String> codes) {
		if (null == codes || codes.isEmpty()){
			return Maps.newHashMap();
		}
		String inSql = TableHelper.getInSql("gro_cond_code", codes);
		String sql = "select * from "+TABLE_NAME+" where 1=1 "+inSql;
		List<Record> condList = selectListBySql(sql, codes.toArray());
		List<Record> condParaList = ksSqlCondParaBDao.getGroupCondsByCode(codes);
		List<Record> allDicds = ksDicBDao.getAllList();
		return GroupCond.buildLogicCondList( condList, condParaList, allDicds, "gro_cond_code" );
	}

	@Override
	@JFinalTx
	public Boolean saveGroupConds(List<List<Map<String, Object>>> groupConds, String pCode, String menuId) {
		boolean succYn = true;
		if (null == groupConds || groupConds.isEmpty()) {
			return succYn;
		}
		Map<String, Object> condParaMap = Maps.newHashMap();
		condParaMap.put("p_code", pCode);
		condParaMap.put("menu_id", menuId);

		Map<String, Object> condMap = Maps.newHashMap( condParaMap );

		Set<String> relateFields = Sets.newHashSet();
		relateFields.add("gro_cond_code");

		Map<String, Object> map = GroupCond.formatGroupConds( groupConds, condMap, condParaMap, relateFields, pCode);
		List<Map<String, Object>> conds = (List<Map<String, Object>>)map.get("conds");
		List<Map<String, Object>> condParas = (List<Map<String, Object>>)map.get("condParas");
		saveList(TABLE_NAME, DataBaseUtil.map2Record( conds ));
		ksSqlCondParaBDao.saveGroupCondParas( condParas );
		return succYn;
	}
}
