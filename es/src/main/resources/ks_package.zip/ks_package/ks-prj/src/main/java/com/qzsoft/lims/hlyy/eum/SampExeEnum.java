package com.qzsoft.lims.hlyy.eum;

public enum SampExeEnum {

    YPZT_ZC("YPZT_ZC", "正常"),
    YPZT_XS("YPZT_XS", "形式"),
    YPZT_FJ("YPZT_FJ", "复检"),
    YPZT_CZ("YPZT_CZ", "重置"),
    YPZT_CQ("YPZT_CQ", "超期"),
    YPZT_ZF("YPZT_ZF", "作废"),
    YPZT_GD("YPZT_GD", "归档"),
    ;

    private String code;
    private String desc;

    SampExeEnum(String code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
