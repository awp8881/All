package com.qzsoft.lims.hlyy.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.hlyy.entity.vo.HLYYGroupVo;
import com.qzsoft.lims.hlyy.service.SamplingService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Api(value = "采样设计", tags = "采样设计")
@RequestMapping("/samp")
@Slf4j
public class SamplingController {


    @Autowired
    SamplingService samplingService;

    @ApiOperation(value="页面点击采样设计请求接口，返回当前项目的采购设计")
    @GetMapping("/getProjSampInfo")
    @ApiImplicitParams({
            @ApiImplicitParam(name="projId",value="项目Id",required=true,dataType="string",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Boolean> getProjSampInfo(String projId){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        if(StringUtils.isEmpty(projId))
            return result;
        Map<String,Object> resMap = samplingService.getProjSampInfo(projId);
        result.setExObj(resMap);
        return result;
    }

    @ApiOperation(value="点击某个采样量，如果该分组的属性isHaveNode为Y,说明该采样量有节点信息，请求此接口返回节点信息")
    @GetMapping("/getNodeInfoByClick")
    @ApiImplicitParams({
            @ApiImplicitParam(name="groupId",value="分组Id",required=true,dataType="string",paramType="query"),
    })
    @ResponseAddHead
    public RequestResult<Boolean> getNodeInfoByClick(String groupId){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        Map<String,Object> resMap = samplingService.getNodeInfoByClick(groupId);
        result.setExObj(resMap);
        return result;
    }

    @ApiOperation(value="新增分组信息")
    @PostMapping("/addGroups")
    @ResponseAddHead
    public RequestResult<Boolean> addGroups(HLYYGroupVo groupVo){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        Map<String,Object> resMap = samplingService.addGroups(groupVo);
        result.setExObj(resMap);
        return result;
    }

    @ApiOperation(value="删除分组")
    @PostMapping("/delGroups")
    @ApiImplicitParams({
            @ApiImplicitParam(name="groupIds",value="组Id,数组",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="projId",value="项目id",required=true,dataType="string",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Boolean> delGroups(String[] groupIds,String projId){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        result.setExObj(samplingService.delGroups(groupIds,0,projId));
        return result;
    }

    @ApiOperation(value="修改分组内值")
    @PostMapping("/updateGroupInfo")
    @ApiImplicitParams({
            @ApiImplicitParam(name="groupId",value="组Id",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="groupInfo",value="修改项Json，传所有字段，如：{grop_code：‘A’,grop_no：‘1’,grop_num,'20'}",required=true,dataType="string",paramType="query"),
    })
    @ResponseAddHead
    public RequestResult<Boolean> updateGroupInfo(String groupId,String groupInfo){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        boolean res =  samplingService.updateGroupInfo( groupId, groupInfo);
        result.setObj(res);
        return result;
    }

    @ApiOperation(value="添加/删除周期（弃用）")
    @PostMapping("/addOrDelCycle")
    @ApiImplicitParams({
            @ApiImplicitParam(name="cycle_no",value="周期号,添加时值为maxCycleNum+1,删除是值为maxCycleNum",required=true,dataType="int",paramType="query"),
            @ApiImplicitParam(name="projId",value="项目id",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="delSt",value="操作类型,N:新增，Y：删除",required=true,dataType="string",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Boolean> addOrDelCycle(int cycle_no,String projId,String delSt){
        RequestResult<Boolean> result = new RequestResult<Boolean>();

        Map<String,Object> resMap = samplingService.addCycle(cycle_no,projId,delSt);
        result.setExObj(resMap);

        return result;
    }


    @ApiOperation(value="修改周期内值（弃用）")
    @PostMapping("/updateCycleInfo")
    @ApiImplicitParams({
            @ApiImplicitParam(name="cycleId",value="周期Id",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="cycleVal",value="值",required=true,dataType="string",paramType="query"),
    })
    @ResponseAddHead
    public RequestResult<Boolean> updateCycleInfo(String cycleId,String cycleVal){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        boolean res =  samplingService.updateCycleInfo( cycleId, cycleVal);
        result.setObj(res);
        return result;
    }



    @ApiOperation(value="添加种类/节点;删除种类")
    @PostMapping("/addOrDelTypeNode")
    @ApiImplicitParams({
            @ApiImplicitParam(name="groupId",value="分组Id",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="nd_type",value="采样类型( BLOOD:血液  PLASMA:血浆  TISSUES:组织 URN:尿液)，没数据时初始化为ZL：种类。当改变了类型从ZL(种类)到XY（血液）时，添加节点时传XY",required=false,dataType="string",paramType="query"),
            @ApiImplicitParam(name="delSt",value="操作类型,N:新增，Y：删除",required=true,dataType="string",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Boolean> addOrDelTypeNode(String groupId,String nd_type,String delSt){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        Map<String,Object> resMap = samplingService.addOrDelTypeNode(groupId,nd_type,delSt);
        result.setExObj(resMap);
        return result;
    }

    @ApiOperation(value="修改种类类型")
    @PostMapping("/updateType")
    @ApiImplicitParams({
            @ApiImplicitParam(name="groupId",value="分组Id",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="original_type",value="原来的类型",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="current_type",value="修改后的类型",required=true,dataType="string",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Boolean> updateType(String groupId,String original_type,String current_type){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        Map<String,Object> resMap = samplingService.updateType(groupId,original_type,current_type);
        result.setExObj(resMap);
        return result;
    }


    @ApiOperation(value="删除节点")
    @PostMapping("/delNode")
    @ApiImplicitParams({
            @ApiImplicitParam(name="groupId",value="分组Id",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="nodeIds",value="节点Id,数组",required=true,dataType="string",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Boolean> delNode(String[] nodeIds,String groupId){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        result.setExObj(samplingService.delNode(nodeIds,groupId));
        return result;
    }


    @ApiOperation(value="修改节点值")
    @PostMapping("/updateNodeVal")
    @ApiImplicitParams({
            @ApiImplicitParam(name="nodeId",value="节点Id",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="nodeInfo",value="修改项Json，传所有字段，如：{nd_start_day:null,nd_start_hour:'20',nd_start_min:null}",required=true,dataType="string",paramType="query"),
    })
    @ResponseAddHead
    public RequestResult<Boolean> updateNodeVal(String nodeId,String nodeInfo){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        boolean res =  samplingService.updateNodeVal( nodeId, nodeInfo);
        result.setObj(res);
        return result;
    }


    @ApiOperation(value="生成样品清单(点击预览)")
    @PostMapping("/createSamples")
    @ApiImplicitParams({
            @ApiImplicitParam(name="projId",value="项目Id",required=true,dataType="string",paramType="query"),
    })
    @ResponseAddHead
    public RequestResult<Boolean> createSamples(String projId){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        boolean res =  samplingService.createSamples(projId);
        result.setObj(res);
        return result;
    }

    @ApiOperation(value="点击撤销")
    @PostMapping("/revoke")
    @ApiImplicitParams({
            @ApiImplicitParam(name="projId",value="项目Id",required=true,dataType="string",paramType="query"),
    })
    @ResponseAddHead
    public RequestResult<Boolean> revoke(String projId){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        boolean res =  samplingService.revoke(projId);
        result.setObj(res);
        return result;
    }

    @ApiOperation(value="复制样品节点配置到目标分组（针对采样量单元格）")
    @PostMapping("/copyAndPaste")
    @ApiImplicitParams({
            @ApiImplicitParam(name="copiedCycId",value="被复制的分组Id",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="targetCycId",value="目标分组Id",required=true,dataType="string",paramType="query"),
    })
    @ResponseAddHead
    public RequestResult<Boolean> copyAndPaste(String copiedCycId,String targetCycId){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        Map<String,Object> resMap = samplingService.copyAndPaste(copiedCycId,targetCycId);
        result.setExObj(resMap);
        return result;
    }


}
