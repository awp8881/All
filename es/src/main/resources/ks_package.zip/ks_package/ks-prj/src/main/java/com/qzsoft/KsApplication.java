package com.qzsoft;

import cn.hutool.core.util.StrUtil;
import com.qzsoft.lims.ks.rule.CustomRuleConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.ribbon.RibbonClients;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.util.unit.DataSize;
import org.springframework.util.unit.DataUnit;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.servlet.MultipartConfigElement;
import java.io.File;


@EnableDiscoveryClient
@SpringBootApplication(exclude = {FlywayAutoConfiguration.class})
//@EnableEurekaClient
@EnableCaching
@EnableScheduling
@EnableTransactionManagement
@EnableFeignClients
@EnableSwagger2
@ComponentScan(excludeFilters= {@ComponentScan.Filter(type= FilterType.ASSIGNABLE_TYPE, value= {CustomRuleConfig.class})})
@RibbonClients(defaultConfiguration = CustomRuleConfig.class)
@EnableAsync //开启异步调用
public class KsApplication extends SpringBootServletInitializer {

    @Value("${multipart.maxFileSize}")
    private String maxFileSize;

    @Value("${multipart.maxRequestSize}")
    private String maxRequestSize;

    @Value("${json.dir}")
    private String jsonDir;



    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(KsApplication.class);
    }

    public static void main(String[] args) {
        ApplicationContext ctx = SpringApplication.run(KsApplication.class,args);
        System.out.println("finished......classes：" + ctx.getBeanDefinitionNames().length);

    }

    /**
     * 文件上传配置
     * @return
     */
    @Bean
    public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        // 单个文件最大
        if (StrUtil.isNotBlank( maxFileSize )) {
            factory.setMaxFileSize(DataSize.parse(maxFileSize,DataUnit.MEGABYTES)); // KB,MB
        } else {
            factory.setMaxFileSize(DataSize.ofMegabytes(100)); // KB,MB
        }
        /// 设置总上传数据总大小
        if (StrUtil.isNotBlank(maxRequestSize)) {
            factory.setMaxRequestSize(DataSize.parse(maxRequestSize,DataUnit.MEGABYTES)); // KB,MB
        } else {
            factory.setMaxRequestSize(DataSize.ofMegabytes(500)); // KB,MB
        }

        File tmpFile = new File(jsonDir);
        if (!tmpFile.exists()) {
            tmpFile.mkdirs();
        }
        factory.setLocation(jsonDir);

        return factory.createMultipartConfig();
    }

}
