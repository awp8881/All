package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 按钮激活条件参数配置列表
 * @author zf
 *
 */
public interface KsSqlButtonParaBDao extends BaseDao{
	
	/**
	 * 按钮激活条件参数配置列表
	 * @param button_code
	 * @param m_code_type
	 * @return
	 */
	List<Record> getButtonParaList(String button_code,String m_code_type);
	
	List<Record> getButtonParaList(String m_code,String info_code,String m_code_type);
	
	/**
	 * 删除后批量插入
	 * @param allParaList
	 * @param isSaveAs
	 * @param old_m_code
	 * @param info_code
	 * @return
	 */
	Boolean batchUpdate(List<Map<String, Object>> allParaList,Integer isSaveAs,String old_m_code,String info_code, String menu_id );

	Boolean saveGroupCondParas( List<Map<String, Object>> condParas, Integer isSaveAs, String pMCode, String infoCode);
}
