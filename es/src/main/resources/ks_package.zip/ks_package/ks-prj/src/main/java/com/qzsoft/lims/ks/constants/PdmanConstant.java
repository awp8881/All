package com.qzsoft.lims.ks.constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

@Slf4j
public class PdmanConstant {
    public  static    String studentPdmanPath;

    public  static    String demoPdmanPath;//哎,名称和param反了,先用吧

    public  static    String studentPdmanParam;

    public  static    String demoPdmanParam;
    static {
        ioFile();
    }

    public  static final  String ksMetaOpt = "ks_meta_opt";
    public  static final  String ksMetaCycle = "ks_meta_cycle";
    public  static final  String tableType = "table";
    public  static final  String tableFiled = "field";
    public  static final  int defalutPage = 1;
    public  static final  int defalutPageSize = 100;
    public  static final  String pdmanSaveJson = "pdman-saveJson";//修改字段代码
    public  static final  String createTableTemplate = "createTableTemplate";//新建数据库代码
    public  static final  String deleteTableTemplate = "deleteTableTemplate";//删除数据库代码
    public  static final  String createIndexTemplate = "createIndexTemplate";//新建索引代码
    public  static final  String deleteIndexTemplate = "deleteIndexTemplate";//删除索引代码
    public  static final  String rebuildTableTemplate = "rebuildTableTemplate";//重建数据表代码
    public  static final  String createFieldTemplate = "createFieldTemplate";//新增字段代码
    public  static final  String deleteFieldTemplate = "deleteFieldTemplate";//删除字段代码
    public  static final  String updateFieldTemplate = "updateFieldTemplate";//修改字段代码

    /**
     * 刷新数据
     * @author yuanj
     */
    public static void ioFile(){
        try {
            String[] strings = new String[]{"WEB-INF/build/demo.project.json","WEB-INF/build/student.pdman.json"};
            for (String ster: strings) {
                ClassPathResource cpr = new ClassPathResource(ster);
                InputStream in = cpr.getInputStream();
                byte[] buffer = new byte[1024];
                int len = 0;
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                while((len = in.read(buffer)) != -1) {
                    bos.write(buffer, 0, len);
                }
                bos.close();
/*
                log.info("请求json数据返回：{}",bos.toString());
*/
                if(ster.contains("demo")) {
                    demoPdmanPath = bos.toString();
                    demoPdmanParam = cpr.getURL().getPath();

                }else {
                    studentPdmanPath = bos.toString();
                    studentPdmanParam =cpr.getURL().getPath();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
