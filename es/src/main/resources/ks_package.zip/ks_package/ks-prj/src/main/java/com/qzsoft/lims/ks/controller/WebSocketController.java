package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.WebSocket;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Api(value = "websocket通信接口", tags = "websocket通信接口")
@RestController
@RequestMapping("/websocket")
@Slf4j
public class WebSocketController {


    @ApiOperation(value="发送消息",notes="关联表：无")
    @PostMapping("sendMsg")
    @ResponseBody
    public RequestResult sendMsg(String channleName, String msg){
        WebSocket.sendMsgByChannleName( channleName, msg );
        return new RequestResult( "发送成功" );
    }

}
