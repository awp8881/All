package com.qzsoft.lims.ks.dao.impl;

import com.google.common.collect.Lists;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.KsModelDynSqlParaBDao;
import com.qzsoft.lims.ks.eum.dynamic.DynamicParaTypeEnum;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @Description 动态sql
 * @Date 2019/4/11
 */
@Repository
public class KsModelDynSqlParaBDaoImpl extends BaseDaoImpl implements KsModelDynSqlParaBDao {
    private static final String TABLE_NAME = "ks_model_dyn_sql_para_b";

    @Autowired
    private KsDicBDao ksDicBDao;

    //动态sql参数
    @Override
    public List<Record> getByPCode(String pCode) {
        List<Record> records = selectListByCustomAndSort(TABLE_NAME , "p_code", "para_order+0", false, pCode);
        if (null == records || records.isEmpty()) {
            return Lists.newArrayList();
        }
        parse( records);
        return records;
    }

    //保存动态sql参数
    @Override
    @JFinalTx
    public boolean saveDynSql(List<Map<String, Object>> allDynParaList, String pCode) {
        boolean isSucc = true;

        if (null == allDynParaList || allDynParaList.isEmpty()){
            return true;
        }

        for (Map<String, Object> map : allDynParaList) {
            map.put("p_code", pCode);
            map.put("cr_dm", DateUtil.getNowDateTimeStr());
            map.put("up_ver", "1");


            List<String> dicParas = (List<String>) map.get("dicParas");

            map.remove("dicParas");
            map.remove("di_cd_str");
            map.remove("dicParasStr");
            if (null == dicParas || dicParas.isEmpty()) {
                continue;
            }
            map.put("para_val", StringUtil.listTOString(dicParas));
        }
        saveList(TABLE_NAME, DataBaseUtil.map2Record(allDynParaList));
        return isSucc;
    }

    @Override
    @JFinalTx
    public boolean saveDynPara(List<Map<String, Object>> allDynParaList, String dynCode) {
        boolean isSucc = true;
        DbEx.delete("delete from "+TABLE_NAME+" where dyn_code=?", dynCode);

        if (null == allDynParaList || allDynParaList.isEmpty()){
            return true;
        }
        for (Map<String, Object> map : allDynParaList) {
            map.put("cr_dm", DateUtil.getNowDateTimeStr());
            map.put("up_ver", "1");
            List<String> dicParas = (List<String>) map.get("dicParas");

            //这儿是动态sql占位符参数时添加的
            map.remove("set_code");
            map.remove("set_val");
            map.remove("but_di_cd_code");
            map.remove("dyn_para_order");

            map.remove("dicParas");
            map.remove("di_cd_str");
            map.remove("dicParasStr");
            if (null == dicParas || dicParas.isEmpty()) {
                continue;
            }
            map.put("para_val", StringUtil.listTOString(dicParas));
        }
        saveList(TABLE_NAME, DataBaseUtil.map2Record(allDynParaList));
        return isSucc;
    }

    @Override
    public List<Record> getByDynCode(String dynCode) {
        List<Record> records = selectListByCustomAndSort(TABLE_NAME , "dyn_code", "para_order+0", false, dynCode);
        if (null == records || records.isEmpty()) {
            return Lists.newArrayList();
        }
        parse( records);
        return records;
    }

    private void parse( List<Record> records ){
        if (null == records || records.isEmpty()){
            return;
        }
        List<Record> allDicds = ksDicBDao.getAllList();
        for (Iterator iterator = records.iterator(); iterator.hasNext();) {
            Record record = (Record) iterator.next();
            String paraType = record.getStr("para_type");
            if (!DynamicParaTypeEnum.ZDJ.getCode().equals(paraType)) {
                continue;
            }
            String paraVal = record.getStr("para_val");
            String dicd = record.getStr("di_cd");
            List<String> dicParas = CommonUtil.strToList(paraVal, ","  );
            String di_cd_str = CommonUtil.getDicdDesc( dicd, allDicds);
            String dicParasStr = CommonUtil.getDicdParasDesc( dicd, dicParas, allDicds);

            record.set("dicParas", dicParas).set("di_cd_str", di_cd_str).set("dicParasStr", dicParasStr);

        }
    }
}
