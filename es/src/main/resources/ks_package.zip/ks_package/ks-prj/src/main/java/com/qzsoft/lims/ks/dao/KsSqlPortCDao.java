package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.PageVO.InfoLists.InfoGroups.GroupFields.InfoFieldClickScript;
import com.qzsoft.lims.ks.vo.SourceConfigVO.PortVO;
import com.qzsoft.lims.ks.vo.page.PageCommonVO;

/**
 * 接口请求地址
 * @author zf
 * */
public interface KsSqlPortCDao extends BaseDao{
	
	/**
	 * 通过接口编码获取某一接口
	 * @param port_code
	 * @param m_code_type
	 * @return
	 */
	Record getListByPortCode(String port_code,String m_code_type);
	
	/**
	 * 删除后插入
	 * @param allPortsList
	 * @param isSaveAs
	 * @return
	 */
	Boolean batchUpdate(List<Map<String,Object>> allPortsList, Integer isSaveAs, String code, String otherCode, String menu_id);


	void buildPortParaReturn(List<PortVO> portVOList, List<Record> portList, List<Record> allPortParasList, List<Record> allPortReturnList,String menu_id);
	
	/**
	 * 接口配置修改--引用接口修改
	 * @param dic_port_code
	 * @param port_type
	 * @param port_name
	 * @param logic_url
	 * @return
	 */
	Boolean updateByPortConfig(String dic_port_code,String port_type,String port_name,String logic_url, String url_type);
	
	/**
	 * 接口配置删除
	 * @param dicPortCodeList
	 * @return
	 */
	Boolean deleteByPortConfig(List<String> dicPortCodeList);
	
	/**
	 * 获取接口所有信息
	 * @param port_code
	 * @param m_code_type
	 * @return
	 */
	PortVO getPortAndParaAndReturn(String port_code, String m_code_type);
	
	Map<String,Object> getPortToMap(String port_code, String m_code_type);
	
	//json文件的接口数据
	PageCommonVO.PortData getPortToJson(String portCode, String tableBC);

	Record getPortInfo(String portCode);

}
