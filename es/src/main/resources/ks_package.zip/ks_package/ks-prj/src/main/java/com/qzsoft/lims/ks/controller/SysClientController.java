package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.RequestLimit;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.hlyy.service.SamplingService;
import com.qzsoft.lims.ks.service.SysClientService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@Api(value = "前端初始化数据", tags = "前端初始化数据")
@RequestMapping("/cptfile")
@Slf4j
public class SysClientController {
    @Autowired
    SysClientService sysClientService;

    @ApiOperation(value="获取前端初始化数据")
    @GetMapping("/getSysClient")
    @ResponseAddHead
    @RequestLimit(count = 10,time = 1000)//幂等控制
    public RequestResult<Boolean> getSysClient(){
        RequestResult<Boolean> result = new RequestResult<Boolean>();
        List<Map<String, Object>> resMap = sysClientService.getSysClient();
        result.setPrePageDatas(resMap);
        return result;
    }
}
