package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface KsModelDynSqlBDao {

    //获取动态sql
    List<Record> getByPCode(String pCode, String dynType);

    //保存动态sql
    Set<String> saveDynSql(List<Map<String,Object>> allDynList, String pCode, String dynType);

    Map<String, Object> saveDynSql(Map<String, Object> dynData);

    Record getByDynCode(String dynCode);

    /**
     * 行按钮统计
     * @param pCode
     * @param mType
     * @param controlStyle
     * @return
     */
    List<Record> getByPCodeAndControlStyle( String pCode , String mType, String controlStyle);

    /**
     * 分组条件动态sql
     * @param pCode
     * @param conds
     */
    void  getCondDynSql( String pCode, String dynType, List<Record> conds);

    Boolean deleteDyn(List<String> dynCodes);

    List<Record> getDynList(List<String> dynCodes);

    Set<String> getBusCode(List<String> dynCodes);

    Boolean updateDynSql(String dynCode, String countNa, String unitType, String condCode);
}
