package com.qzsoft.lims.ks.constants;

public class ConstantMsgNum {

    //未开放功能编码
    public static Integer NO_OPEN_FN=11019;
    //联系管理员解决***
    public static Integer CONTACT_ADMIN_SOLVE_CONFI=11020;

    //参数校验错误***
    public static Integer PARAM_TYPE_ERROR=11010;
}
