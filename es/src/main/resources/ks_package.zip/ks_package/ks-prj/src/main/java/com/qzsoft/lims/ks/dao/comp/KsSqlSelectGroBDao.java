package com.qzsoft.lims.ks.dao.comp;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

import java.util.List;
import java.util.Map;

/**
 * @Author zf
 * @Description 条件组
 * @Date 2019/9/3
 */
public interface KsSqlSelectGroBDao extends BaseDao {

    /**
     * 条件组
     * @param pCode
     * @return
     */
    List<Record> getGroupConds( String groSelectCode );

    Boolean saveGroupConds( List<Map<String, Object>> groupConds );

}
