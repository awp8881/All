package com.qzsoft.lims.ks.config.msg;

import lombok.Data;

import java.io.Serializable;

/**
 * 配置基类
 * ps:暂时无需序列化，如需要字段无序列化，加transient即可
 * @author yuanj
 * @since 2021/12/29
 **/
@Data
public abstract class Config {
    private static final long serialVersionUID = 2765017560754006377L;

    private transient long configId;
    private transient boolean defaultFlag;
    private transient String configName;

}
