package com.qzsoft.lims.hlyy.config;

public enum Fileds {


    groups("[{\"key\":\"grop_no_type\",\"name\":\"种属\"},{\"key\":\"grop_no\",\"name\":\"分组\"},{\"key\":\"grop_code\",\"name\":\"代号\"},{\"key\":\"grop_num\",\"name\":\"数量\"},{\"key\":\"grop_begin_code\",\"name\":\"起始序号\"},{\"key\":\"grop_get_val\",\"name\":\"采样量\"}]", "分组表头"),
    node("[{\"key\":\"nd_start_day\",\"name\":\"开始(天)\"},{\"key\":\"nd_start_hour\",\"name\":\"开始(时)\"},{\"key\":\"nd_start_min\",\"name\":\"开始(分)\"},{\"key\":\"nd_start_remark\",\"name\":\"说明\"}]", "节点表头1"),
    node2("[{\"key\":\"nd_start_day\",\"name\":\"开始(天)\"},{\"key\":\"nd_start_hour\",\"name\":\"开始(时)\"},{\"key\":\"nd_start_min\",\"name\":\"开始(分)\"},{\"key\":\"nd_start_remark\",\"name\":\"说明\"},{\"key\":\"nd_end_day\",\"name\":\"结束(天)\"},{\"key\":\"nd_end_hour\",\"name\":\"结束(时)\"},{\"key\":\"nd_end_min\",\"name\":\"结束(分)\"},{\"key\":\"nd_end_remark\",\"name\":\"说明\"}]", "节点表头2（有结束节点）"),
    node3("[{\"key\":\"nd_start_day\",\"name\":\"开始\"},{\"key\":\"nd_start_remark\",\"name\":\"说明\"}]", "2022.4需求")
    ;



    private String code;
    private String desc;

    Fileds(String code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
