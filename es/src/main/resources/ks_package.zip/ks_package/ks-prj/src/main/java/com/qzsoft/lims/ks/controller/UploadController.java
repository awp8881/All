//package com.qzsoft.lims.ks.controller;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.multipart.MultipartFile;
//
//import com.alibaba.fastjson.JSON;
//import com.qzsoft.common.tools.ConfigUtil;
//import com.qzsoft.common.tools.FileUtils;
//import com.qzsoft.common.tools.WonUtil;
//import com.qzsoft.common.tools.FileUtils.FileTypeVO;
//import com.qzsoft.common.ui.RequestResult;
//
//
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//
//@Api(tags="文件上传",value="文件上传")
//@Controller
//public class UploadController {
//	private static final Logger LOG = LoggerFactory.getLogger(UploadController.class);
//
////	@Autowired
////	private UIDGeneratorBizService UIDGeneratorBizService;
//
//	private String gimeUpload(MultipartFile myfile) throws IOException{
//		String fileName = myfile.getOriginalFilename();
//		String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
//		byte[] content = myfile.getBytes();
//		String tempDir = ConfigUtil.getPropertyValue("fs.temp.dir");
//		FileTypeVO fileType = FileUtils.getFileType(suffix);
////		String newName = UIDGeneratorBizService.getWonByPre(fileType.getFileFlag()) + "." + suffix;
//		String newName = WonUtil.getWon(null,"f") + "." + suffix;
//		FileUtils.saveFile(content, tempDir, newName);
//		String tempMapping = ConfigUtil.getPropertyValue("fs.temp.mapping");
//		return tempMapping + "/" + newName;
//	}
//	@ApiOperation("文件上传")
//	@RequestMapping(value = "uploadFile", method = RequestMethod.POST)
//	public void uploadFile(@RequestParam("file") MultipartFile myfile, HttpServletRequest request,
//			HttpServletResponse response) {
//
//		RequestResult<Map<String, Object>> result = null;
//		try {
//			if (myfile.isEmpty()) {
//				LOG.error(this.getClass().getSimpleName() + ".uploadFile()");
//				result = RequestResult.error("上传文件获取失败！");
//			} else {
//				String uri = gimeUpload(myfile);
//				String path = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
//			    + request.getContextPath();
//				Map<String, Object> map = new HashMap<>();
//				uri=path+uri;
//				map.put("uri", uri);
//				result = new RequestResult<Map<String, Object>>(map);
//			}
//		} catch (Exception e) {
//			result = RequestResult.error(e);
//			LOG.error(this.getClass().getSimpleName() + ".uploadFile()", e);
//		}
//		try {
//			String json = JSON.toJSONString(result);
//			response.setContentType("text/html;charset=utf-8");
//			response.getWriter().write(json);
//		} catch (IOException e) {
//			LOG.error(this.getClass().getSimpleName() + ".uploadFile()", e);
//		}
//	}
//	@ApiOperation("付文本框上传")
//	@RequestMapping(value = "editerUploadFile", method = RequestMethod.POST)
//	public void editerUploadFile(@RequestParam("file") MultipartFile myfile, HttpServletRequest request,
//			HttpServletResponse response) {
//		Map<String, Object> map = new HashMap<>();
//		try {
//			if (myfile.isEmpty()) {
//				LOG.error(this.getClass().getSimpleName() + ".uploadFile()");
//				map.put("errno", 1);
//			} else {
//				String uri = gimeUpload(myfile);
//				map.put("errno", 0);
//				List<String> tempDataPath = new ArrayList<String>();
//				tempDataPath.add(uri);
//				map.put("data", tempDataPath);
//
//			}
//		} catch (Exception e) {
//			map.put("errno", 1);
//			LOG.error(this.getClass().getSimpleName() + ".uploadFile()", e);
//		}
//		try {
//			String json = JSON.toJSONString(map);
//			response.setContentType("text/html;charset=utf-8");
//			response.getWriter().write(json);
//		} catch (IOException e) {
//			LOG.error(this.getClass().getSimpleName() + ".uploadFile()", e);
//		}
//	}
//}
