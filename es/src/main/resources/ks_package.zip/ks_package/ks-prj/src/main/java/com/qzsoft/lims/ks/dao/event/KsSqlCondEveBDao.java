package com.qzsoft.lims.ks.dao.event;

import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlCondEveBDao extends BaseDao{
	
	/**
	 * 事件流列表
	 * @return
	 */
	Record getByPCode(String pCode, Boolean jsonYn ,String condType);

	/**
	 * 删除后插入
	 * @param fieldEveCondMap
	 * @param pCode
	 * @return
	 */
	Boolean batchUpdate(Map<String,Object> fieldEveCondMap, String pCode ,String menu_id );

	/**
	 * 删除事件流
	 * @param pCode
	 * @return
	 */
	void deleteEve( String pCode );

}
