package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.service.extComp.FileBean;
import com.qzsoft.lims.ks.service.project.SysManaService;
import com.qzsoft.lims.ks.vo.CommonTreeVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Api(value = "系统管理监控", tags = "系统管理监控")
@RestController
@RequestMapping("/sysMana")
@Slf4j
public class SysManaController {

    @Autowired
    private SysManaService sysManaService;

    @ApiOperation(value = "系统管理树")
    @GetMapping("/getManaTree")
    @ResponseAddHead
        public RequestResult<CommonTreeVO> getManaTree() {
        RequestResult<CommonTreeVO> result = new RequestResult<>();
        result.setList( sysManaService.getManaTree() );
        return result;
    }

    @ApiOperation(value = "管理分类模块")
    @GetMapping("/getManaByPCode")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getManaByPCode(String manaCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( sysManaService.getManaByPCode( manaCode ) );
        return result;
    }

    @ApiOperation(value = "管理详情")
    @GetMapping("/getManaInfo")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getManaInfo(String manaCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj( sysManaService.getManaInfo( manaCode ) );
        return result;
    }

    @ApiOperation(value = "保存")
    @PostMapping("/save")
    @ResponseAddHead
        public RequestResult<Boolean> save(@RequestParam(value = "sysManaData") String sysManaDataStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(sysManaService.saveSysMana( sysManaDataStr ));
        return result;
    }


    @ApiOperation(value = "删除管理")
    @PostMapping("/deleteMana")
    @ResponseAddHead
        public RequestResult<Boolean> deleteMana(String manaCode) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( sysManaService.deleteMana( manaCode ) );
        return result;
    }

    @ApiOperation(value="文件上传返回二进制")
    @PostMapping(value = "/getManaFileByBinary")
    @ResponseAddHead
    @ResponseBody
        public RequestResult<Object> getManaFileByBinary(FileBean fileBean) {
        RequestResult<Object> result = new RequestResult<>();
        result.setObj( sysManaService.getManaFileByBinary(fileBean) );
        return result;
    }

}
