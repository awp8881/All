package com.qzsoft.lims.ks.dao.impl;

import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsOptLogDiffGDao;

/** 
 * 系统配置：系统自动化SQL语句
 * 创建时间:2018-11-07 16:36:29 
 */ 
public class KsOptLogDiffGDaoImpl  extends BaseDaoImpl implements KsOptLogDiffGDao {



}
