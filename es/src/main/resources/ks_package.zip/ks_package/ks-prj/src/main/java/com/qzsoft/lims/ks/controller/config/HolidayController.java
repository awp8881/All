package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.service.extComp.HolidayService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 节假日管理-控制器
 * @author zf
 */
@Api(value = "节假日管理", tags = "节假日管理")
@RestController
@RequestMapping("/holiday")
@Slf4j
public class HolidayController {

    @Autowired
    private HolidayService holidayService;

    @ApiOperation(value = "节假日更新")
    @PostMapping("/updateHoliday")
    @ResponseAddHead
        public RequestResult<Boolean> updateHoliday(@RequestBody Map<String, Object> map) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( holidayService.updateHoliday(map));
        return result;
    }

    @ApiOperation(value = "生成一年节假日")
    @PostMapping("/generateHoliday")
    @ResponseAddHead
        public RequestResult<Boolean> generateHoliday(@RequestParam(value = "year") String year) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(holidayService.generateHoliday( year));
        return result;
    }

    @ApiOperation(value = "获取一年节假日")
    @GetMapping("/getHoliday")
    @ResponseAddHead
        public RequestResult<Map<Integer, Object>> getHoliday(@RequestParam(value = "year") String year) {
        RequestResult<Map<Integer, Object>> result = new RequestResult<>();
        result.setObj(holidayService.getHoliday( year));
        return result;
    }

    @ApiOperation(value = "获取已生成的所有年")
    @GetMapping("/getYears")
    @ResponseAddHead
        public RequestResult<String> getYears() {
        RequestResult<String> result = new RequestResult<>();
        result.setList(holidayService.getYears());
        return result;
    }
}
