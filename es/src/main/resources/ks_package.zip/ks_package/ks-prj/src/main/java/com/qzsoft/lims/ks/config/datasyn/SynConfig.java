package com.qzsoft.lims.ks.config.datasyn;

import com.google.common.collect.Lists;
import com.qzsoft.lims.ks.plug.datasyn.Syn;
import com.qzsoft.lims.ks.plug.datasyn.SynHolder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class SynConfig {

    @Bean
    @ConditionalOnBean(Syn.class)
    public SynHolder createSynHolder(List<Syn> synList){
        SynHolder synHolder = new SynHolder();
        synHolder.setDataSyns( synList );
        return synHolder;
    }

    @Bean
    @ConditionalOnMissingBean(Syn.class)
    public SynHolder createDefaultSynHolder( ){
        SynHolder synHolder = new SynHolder();
        synHolder.setDataSyns(Lists.newArrayList() );
        return synHolder;
    }
}
