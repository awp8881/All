package com.qzsoft.lims.ks.controller.flow;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.flow.conf.FlowModuleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @Author zf
 * @Description 流程组件
 * @Date 2021/4/2
 */
@Api(value = "流程引擎组件", tags = "流程引擎组件")
@RestController
@RequestMapping("/flowModule")
@Slf4j
public class FlowModuleController {

    @Autowired
    private FlowModuleService flowModuleService;

    @ApiOperation(value = "流程动态参数")
    @GetMapping("/getFlowDynPara")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowPara() {
        RequestResult<Map<String, Object>> result =  new RequestResult<>();
        result.setList(flowModuleService.getFlowDynPara());
        return result;
    }

    @ApiOperation(value = "业务数据的打回流程环节")
    @PostMapping("/getFlowNode")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowNode(@RequestParam(value = "reqDatasStr") String reqDatasStr,
                                                          @RequestParam(value = "nodes", required = false) String nodesStr) {
        RequestResult<Map<String, Object>> result =  new RequestResult<>();
        result.setList(flowModuleService.getFlowNode(reqDatasStr, nodesStr));
        return result;
    }


    @ApiOperation(value = "流程最新版本环节")
    @GetMapping("/getFlowNodeByVer")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowNodeByVer(@RequestParam(value = "pFlowCode", required = false) String pFlowCode,
                                                               @RequestParam(value = "isAddSign", required = false) Boolean isAddSign,
                                                               @RequestParam(value = "instanceId", required = false) String instanceId) {
        RequestResult<Map<String, Object>> result =  new RequestResult<>();
        result.setList(flowModuleService.getFlowNodeByVer(pFlowCode, isAddSign, instanceId ));
        return result;
    }

}
