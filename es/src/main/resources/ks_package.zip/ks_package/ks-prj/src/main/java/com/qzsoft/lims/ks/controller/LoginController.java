package com.qzsoft.lims.ks.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.util.UserDataUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.LoginService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 登录
 * @author zf
 *
 */
@Api(value = "登录", tags = "登录")
@RestController
@RequestMapping("/login")
@Slf4j
public class LoginController {
	@Autowired
	private LoginService loginService;
	
	@ApiOperation(value="将用户信息保存到redis",notes="true-保存成功，false-保存失败")
	@PostMapping("/saveUserInfoToRedis")
		@ApiImplicitParam(name="user_name",value="用户名",required=true,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Boolean> saveUserInfoToRedis(@RequestParam(value="user_name") String user_name) {
		RequestResult<Boolean> result = new RequestResult<Boolean>(true);
		try {
			loginService.saveUserInfoToRedis(user_name);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveUserInfoToRedis()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveUserInfoToRedis()", e);
		}
		return result;

	}
	
	@ApiOperation(value="获取redis中的用户信息")
	@GetMapping("/getUserInfoByRedis")
	@ResponseAddHead
		@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getUserInfoByRedis( ) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result=new RequestResult<>(loginService.getUserInfoByRedis(UserDataUtil.getJID()));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getUserInfoByRedis()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getUserInfoByRedis()", e);
		}
		return result;

	}
}
