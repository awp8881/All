package com.qzsoft.lims.ks.controller;

import cn.hutool.core.util.ZipUtil;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.extComp.FileBean;
import com.qzsoft.lims.ks.service.extComp.PicService;
import com.qzsoft.lims.ks.vo.KsBusPicManageBVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

/**
 * @auther: hqp
 * @date: 2018/8/31
 * @description:
 */

@Api(value = "照片管理服务", tags = "照片管理服务")
@RestController
@RequestMapping("/pic")
@Slf4j
public class PicController {

	@Autowired
	private PicService picService;

	@ApiOperation(value="文件上传")
	@PostMapping(value = "/fileUpload")
	@ResponseAddHead
		@ResponseBody
	public RequestResult<Object> fileUpload(FileBean fileBean, HttpServletRequest request) {
		RequestResult<Object> result = new RequestResult<>();
		fileBean.setRequest(request);
		result.setObj( picService.fileUpload(fileBean) );
		return result;

	}

	@ApiOperation(value="转发上传数据到文档中心")
	@RequestMapping(value = "/dataUpload", method = RequestMethod.POST)
	@ResponseAddHead
	@ResponseBody
		@ApiImplicitParams({
		@ApiImplicitParam(name="bus_type",value="业务类型",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="data",value="待上传数据",required=true,dataType="byte[]",paramType="query"),
		@ApiImplicitParam(name="file_type",value="文件类型",required=false,dataType="String",paramType="query")
	})
	public RequestResult<Object> dataUpload(String bus_type,byte[] data, String file_type) {
		RequestResult<Object> result = new RequestResult<>();

		try {
			log.info(this.getClass().getSimpleName() + ".dataUpload()");
			result.setObj(picService.dataUpload(bus_type,data,file_type));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(null);
			log.error(this.getClass().getSimpleName() + ".dataUpload()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(null);
			log.error(this.getClass().getSimpleName() + ".dataUpload()", e);
		}
		return result;

	}

	@ApiOperation(value="从文档中心下载文件")
	@RequestMapping("/downloadFile")
	@ResponseAddHead
		public void downloadFile(@RequestParam(value="filePrn") String filePrn,
							 @RequestParam(value="isUploadLocal", required = false) String isUploadLocal,
							 @RequestParam(value="waterMark", required = false) String waterMark, HttpServletResponse response) {


		try {
			OutputStream toClient = response.getOutputStream();
	        response.setContentType("multipart/form-data");

			Map<String, Object> fileMap = picService.downloadFile(filePrn, isUploadLocal, waterMark);
			String fileName = StringUtil.toString( fileMap.get("fileName") );
			//2.设置文件
			response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
			response.setHeader("Content-Disposition", "attachment;fileName="+URLEncoder.encode(fileName , "UTF-8"));
			toClient.write((byte[])fileMap.get("fileData"));
			toClient.flush();
			toClient.close();

		}catch (BusinessException e) {
			log.error(this.getClass().getSimpleName() + ".downloadFile()", e);

		}catch (Exception e) {

			log.error(this.getClass().getSimpleName() + ".downloadFile()", e);
		}

	}


	@ApiOperation(value="修改",notes="true-保存成功，false-保存失败")
	@PostMapping("/update")
	@ResponseAddHead
		public RequestResult<Boolean> update(KsBusPicManageBVO ksBusPicManageBVO) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isUpdate = picService.update(ksBusPicManageBVO);
			result.setObj(isUpdate);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".update()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".update()", e);
		}
		return result;

	}

	@ApiOperation(value="从文档中心查询文件信息")
	@PostMapping("/getFileInfo")
	@ResponseAddHead
		public RequestResult<Object> getFileInfo(String filePrn) {
		RequestResult<Object> result = new RequestResult<Object>();

		try {
			result=new RequestResult<>(picService.getFileInfo(filePrn));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(null);
			log.error(this.getClass().getSimpleName() + ".getFileInfo()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(null);
			log.error(this.getClass().getSimpleName() + ".getFileInfo()", e);
		}
		return result;

	}


	@ApiOperation(value="根据业务prn查询",notes="没有分页")
	@GetMapping("/getListByPrn")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getListByPrn(@RequestParam(value="prn") String prn, @RequestParam(value="m_code") String m_code,
														   @RequestParam(value="isShowFirst",required = false) String isShowFirst,
														   @RequestParam(value="showType",required = false) String showType) {
		RequestResult<Map<String, Object>> result = null;
		try {
			result = new RequestResult<>(picService.getListByPrn(prn, m_code, isShowFirst, showType));
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getListByPrn()", e);
		}
		return result;
	}


	@ApiOperation("详情查询")
	@GetMapping("/getOne")
		@ApiImplicitParam(name="id",value="主键",required=true,dataType="Long",paramType="query")
	@ResponseAddHead
	public RequestResult<KsBusPicManageBVO> getOne(@RequestParam(value="id") Long id) {
		RequestResult<KsBusPicManageBVO> result = new RequestResult<>();
		try {
			result=new RequestResult<>(picService.getOne(id));
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOne()", e);
		}
		return result;

	}


	@ApiOperation(value="上传保存文件数据信息")
	@PostMapping("/saveFileDatas")
	@ResponseAddHead
		public RequestResult<Boolean> saveFileDatas(@RequestParam(value="fileDatasStr") String fileDatasStr) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		result.setObj ( picService.saveFileDatas( fileDatasStr ) );
		return result;

	}

	@ApiOperation(value="删除文件")
	@PostMapping("/deleteFiles")
	@ResponseAddHead
		public RequestResult<Boolean> deleteFiles(@RequestParam(value="fileDatasStr") String fileDatasStr) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		result.setObj ( picService.deleteFiles( fileDatasStr ) );
		return result;

	}

	@ApiOperation("文件预览")
	@GetMapping("/previewFile")
	@ResponseAddHead
		public RequestResult<String> previewFile(@RequestParam(value="filePrn") String filePrn,
											 @RequestParam(value="waterMark", required = false) String waterMark) {
		RequestResult<String> result = new RequestResult<>();
		result.setObj( picService.previewFile(filePrn, waterMark));
		return result;

	}


	@ApiOperation("本地文件预览")
	@GetMapping("/localViewFile")
	@ResponseAddHead
		public void localViewFile(@RequestParam(value="filePrn") String filePrn, HttpServletRequest request, HttpServletResponse response) {
		 picService.localViewFile(filePrn, request, response);

	}

	@ApiOperation(value="文件加载")
	@GetMapping("/loadFile")
	@ResponseAddHead
		public void loadFile(@RequestParam(value="filePrn") String filePrn, HttpServletResponse response) {

		try {
			InputStream inputStream = picService.loadFileInputStream(filePrn);
			response.setContentLength( inputStream.available() );
			response.setContentType("application/octet-stream");
			FileCopyUtils.copy(inputStream, response.getOutputStream());
		} catch (Exception e) {
			log.error(this.getClass().getSimpleName() + ".loadFile()", e);
		}

	}

	@ApiOperation("业务标识的所有文件信息")
	@GetMapping("/getFilesByPrn")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getFilesByPrn(@RequestParam(value="prn") String prn) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList( picService.getFilesByPrn( prn));
		return result;
	}

	@ApiOperation("ks文件详情")
	@GetMapping("/getByFilePrn")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getByFilePrn(@RequestParam(value="filePrn") String filePrn) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setObj( picService.getByFilePrn( filePrn));
		return result;
	}

	@ApiOperation(value="base64上传")
	@PostMapping(value = "/base64FileUpload")
	@ResponseAddHead
		public RequestResult<Object> base64FileUpload(@RequestParam(value="fileDatas") String fileDatas, @RequestParam(value="filePrn") Long filePrn,
			 @RequestParam(value="isAdd") boolean isAdd, @RequestParam(value="fileName") String fileName) {
		RequestResult<Object> result = new RequestResult<>();
		result.setObj( picService.base64FileUpload(fileDatas, filePrn, isAdd, fileName) );
		return result;

	}

	@ApiOperation(value="更新状态激活、作废")
	@PostMapping(value = "/updateStatus")
	@ResponseAddHead
		public RequestResult<Boolean> updateStatus(@RequestParam(value="ids") String ids, @RequestParam(value="status") String status) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( picService.updateStatus(ids, status) );
		return result;

	}


	@ApiOperation(value="根据业务id下载文件")
	@RequestMapping("/downloadFileByBusId")
	@ResponseAddHead
		public void downloadFileByBusId(@RequestParam(value="busId") String busId, HttpServletResponse response) {
		response.setContentType("application/octet-stream");
		response.setCharacterEncoding("utf-8");
		OutputStream toClient = null;
		try {
			response.setHeader("Content-Disposition", "attachment;fileName="+URLEncoder.encode(busId+".zip" , "UTF-8"));
			toClient = response.getOutputStream();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			picService.downloadFileByBusId(busId, bos);
			toClient.write(bos.toByteArray());
			toClient.flush();
			toClient.close();
		} catch (IOException e) {
			BusinessException.throwBiz(e.getMessage());
		}finally {
			try {
				if (null != toClient){
					toClient.flush();
					toClient.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage());
			}

		}

	}
}
