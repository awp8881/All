package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.AnalyzeDao;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @auther: puzhiqiang
 * @date: 2018/5/21 09:50
 * @description:
 */

@Repository
public class AnalyzeDaoImpl extends BaseDaoImpl implements AnalyzeDao {
    /**
     * @Author: pzq
     * @Date: 2018/5/22
     * @Params: []
     * @Description: 查找主表
     */
    @Override
    public List<Record> findMains() {
        List<Record> records = DbEx.find("select * from ks_table_c where t_type='main' order by table_order+0");
        return records;
    }

    /**
     * @Author: pzq
     * @Date: 2018/5/22
     * @Params: [mainTableName]
     * @Description: 根据主表查询其所有从表
     */
    @Override
    public List<Record> findFollows(String mainTableName) {
        List<Record> follows = DbEx.find("select * from ks_table_c where t_type='follow'" + " and" + " t_par_name='" + mainTableName + "'" + " order by table_order+0");
        return follows;
    }

}
