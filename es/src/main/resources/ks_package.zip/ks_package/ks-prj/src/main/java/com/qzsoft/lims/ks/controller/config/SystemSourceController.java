package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.service.systemSource.SystemSource;
import com.qzsoft.lims.ks.vo.CommonTreeVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @Author zf
 * @Description 系统数据源
 * @Date 2020/9/24
 */
@Api(value = "系统数据源", tags = "系统数据源")
@RestController
@RequestMapping("/systemSource")
@Slf4j
public class SystemSourceController {

    @Autowired
    private SystemSource systemSource;

    @ApiOperation(value = "系统租户树")
    @GetMapping("/getSystemTree")
    @ResponseAddHead
        public RequestResult<CommonTreeVO> getSystemTree() {
        RequestResult<CommonTreeVO> result = new RequestResult<>();
//        result.setList(systemSource.getSystemTree());
        return result;
    }

    @ApiOperation(value = "数据源信息")
    @GetMapping("/getDbProperty")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getDbProperty(@RequestParam(value = "tenantId") String tenantId) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
//        result.setObj(systemSource.getDbProperty( tenantId ));
        return result;
    }

    @ApiOperation(value = "初始化租户标识")
    @PostMapping("/initTenant")
    @ResponseAddHead
        public RequestResult<Boolean> initTenant() {
        RequestResult<Boolean> result = new RequestResult<>();
//        result.setObj(systemSource.initTenant());
        return result;
    }

}
