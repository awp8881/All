package com.qzsoft.lims.ks.config.msg;

import lombok.*;

/** 邮件
 * ps:先设置默认值
 * @author yuanj
 * @since 2021/12/29
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmailConfig extends Config {
    private static final long serialVersionUID = 3833630267273040696L;

    private String host="QQ邮箱:smtp.qq.com;企业邮箱:smtp.exmail.qq.com";
    private int port=587;
    private String from="邮箱格式(xx@qq.com;cc@qingzhi.net)";
    private String user="邮箱格式(xx@qq.com;cc@qingzhi.net)";
    private String password="邮箱协议密钥";

}
