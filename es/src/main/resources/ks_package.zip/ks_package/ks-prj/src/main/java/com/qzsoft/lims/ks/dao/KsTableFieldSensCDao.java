package com.qzsoft.lims.ks.dao;

import com.qzsoft.common.dao.BaseDao;

/** 
 * 系统配置：系统自动化SQL语句
 * 创建时间:2018-10-25 09:59:47 
 */ 
public interface KsTableFieldSensCDao  extends BaseDao {



}
