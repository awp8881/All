package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsSqlPortParaCDao;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

/**
 * 接口请求参数
 * */
@Repository
public class KsSqlPortParaCDaoImpl extends BaseDaoImpl implements KsSqlPortParaCDao {
	private static final String TABLE_NAME_B = "ks_sql_port_para_b";
	private static final String TABLE_NAME_C = "ks_sql_port_para_c";

	@Autowired
	private RedisTemplate<Object, Object> redisTemplate;

	/**通过接口编码获取某一接口参数
	 */
	@Override
	public List<Record> getParaListByPortCode(String port_code,String m_code_type) {
		String table = TABLE_NAME_B;
		String port_table = "ks_sql_port_b";
		if( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
			port_table = "ks_sql_port_c";
		}
		List<Record> recordList = null;
		if(StringUtils.isNotBlank(port_code)){
			String sql="select k1.para_type,k1.para_name,k1.para_val,k1.di_cd,k1.redis_key,k1.para_order,k1.para_resou_type,k1.para_code,k1.para_up,k1.para_m_code from "+table+" k1 where k1.port_code=? order by k1.para_order+0";
			recordList = DbEx.find(sql,port_code);

			String dicPortSql = "select dic_port_code from "+port_table+" where port_code=?";
			Record dicPort = DbEx.findFirst(dicPortSql, port_code);
			if (null != recordList && null != dicPort){
				recordList.stream().forEach( record -> {
					record.set("dic_port_code", dicPort.getStr("dic_port_code"));
				});
			}

		}
		return recordList;
	}

	/**
	 * 删除后插入
	 * */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<String> portCodeList, List<Record> allPortParasList,Integer isSaveAs,String menu_id) {
		String table= isSaveAs == YnEnum.N.getCode()  ? TABLE_NAME_B : TABLE_NAME_C;
		batchDelete(table,"port_code",portCodeList);
		
		if(null == allPortParasList || allPortParasList.isEmpty()){
			return true;
		}
		for(Record record : allPortParasList){
			record.set("menu_id", menu_id).remove("dic_port_code");
		}
		return saveList(table, allPortParasList);
	}

	/**
	 * 接口配置参数修改--引用接口修改
	 */
	@JFinalTx
	@Override
	public Boolean updateByPortConfig(String para_code, String para_type, String para_name,String para_up) {
		boolean isSucc = true;

		if(StringUtils.isBlank(para_code)){
			return isSucc;
		}
		String sqlB = "update "+TABLE_NAME_B+" set para_type=?,para_name=?,para_up=? where para_code=?";
		DbEx.update(sqlB, para_type,para_name,para_up,para_code);

		String sqlC = "update "+TABLE_NAME_C+" set para_type=?,para_name=?,para_up=? where para_code=?";
		DbEx.update(sqlC, para_type,para_name,para_up,para_code);

		cleanConfigCache();
		return isSucc;
	}

	private void cleanConfigCache(){
		Set<Object> set = redisTemplate.keys(CommonConstants.KS_CONFIG_DATAS+"*");
		if(null != set && !set.isEmpty()){
			redisTemplate.delete(set);
		}
	}


	/**
	 * 接口参数删除
	 */
	@JFinalTx
	@Override
	public Boolean deleteByPortConfig(List<String> paraCodeList) {
		boolean isSucc = true;
		if(null == paraCodeList || paraCodeList.isEmpty()){
			return isSucc;
		}
		batchDelete(TABLE_NAME_B, "para_code", paraCodeList);
		batchDelete(TABLE_NAME_C, "para_code", paraCodeList);
		return isSucc;
	}
}
