package com.qzsoft.lims.ks.controller;

import java.util.Map;

import com.qzsoft.common.annotation.TagResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsModelAttrBService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Api(value = "属性配置", tags = "属性配置")
@RestController
@RequestMapping("/modelAttr")
@Slf4j
public class KsModelAttrBController {
	@Autowired
	private KsModelAttrBService ksModelAttrBService;
	
	@ApiOperation(value="属性配置保存")
	@PostMapping("/saveModelAttr")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="menu_id",value="菜单号",required=true,dataType="Long",paramType="query"),
		@ApiImplicitParam(name="button_code",value="按钮编码",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="modelAttrStr",value="属性配置字符串",required=false,dataType="String",paramType="query")
	})
	public RequestResult<Boolean> saveModelAttr(@RequestParam(value="menu_id") Long menu_id,
			@RequestParam(value="button_code") String button_code,
			@RequestParam(value="modelAttrStr",required=false) String modelAttrStr) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			result.setObj(ksModelAttrBService.saveModelAttr(menu_id,button_code,modelAttrStr));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveModelAttr()", e);
		}catch (Exception e) {
			result.setObj(false);
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveModelAttr()", e);
		}
		return result;

	}
	
	@ApiOperation("根据按钮编码获取属性配置列表")
	@GetMapping("/getModelAttrListByButtonCode")
	@ResponseAddHead
		@ApiImplicitParam(name="button_code",value="按钮编码",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getModelAttrListByButtonCode(@RequestParam(value="button_code") String button_code) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksModelAttrBService.getModelAttrListByButtonCode(button_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getModelAttrListByButtonCode()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getModelAttrListByButtonCode()", e);
		}
		return result;

	}
}
