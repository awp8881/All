package com.qzsoft.lims.ks.controller;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.util.ExportExcelUtil;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.excel.ExcelService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @auther: hqp
 * @date: 2018/12/13
 * @description:
 */

@Api(value = "Excel服务", tags = "Excel服务")
@RestController
@RequestMapping("/excel")
@Slf4j
public class ExcelController {
	@Autowired
	ExcelService excelService;

	@ApiOperation(value="对上传的excel文件进行解析并保存列表数据")
	@RequestMapping(value = "/analyzeListData", method = RequestMethod.POST)
	@ResponseAddHead
	@ResponseBody
		public RequestResult<Boolean> analyzeListData(MultipartFile file,String excVal) {
		RequestResult<Boolean> result = new RequestResult<>();

		try {
			result.setObj(excelService.analyzeListData(file,excVal));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".analyzeListData()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".analyzeListData()", e);
		}
		return result;

	}

	@ApiOperation(value="下载excel导出模板")
		@RequestMapping(value = "/downloadImportTempl", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name="listCode",value="列表code",required=true,dataType="String",paramType="query")
	})
	public void downloadImportTempl(HttpServletResponse response, @RequestParam(value="listCode") String listCode ) {
		excelService.exportByListCode( response, listCode );
	}

	@ApiOperation(value="大列表导出excel")
		@RequestMapping(value = "/exportListTableData", method = RequestMethod.POST)
	@ApiImplicitParams({
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="export_file_style",value="导出格式 比如excel，pdf，目前只支持excel",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="template_id",value="模板id",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="req_meta_param",value="请求元参数",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="mainKeyIds",value="大列表选中的数据列表，用逗号分隔",required=true,dataType="String",paramType="query")
	})
	public RequestResult exportData(HttpServletResponse response,
						   @RequestParam(value="export_file_style") String export_file_style,
						   @RequestParam(value="template_id") String templaet_id,
						   @RequestParam(value="req_meta_param") String req_meta_param,
						   @RequestParam(value="titleConf",required = false) String titleConf,
						   @RequestParam(value="mainKeyIds",required = false) String mainKeyIds) {
		Set<String> selectData = Sets.newHashSet();
		if(StrUtil.isNotBlank(mainKeyIds)){
			JSONArray objects = JSON.parseArray(mainKeyIds);
			selectData.addAll( objects.toJavaList(String.class) );
		}
		return excelService.exportData( response, export_file_style, templaet_id, req_meta_param, selectData,titleConf );
	}

	@ApiOperation(value="是否有任务正在导出")
	@GetMapping(value = "/checkExportTask")
		@ApiImplicitParams({
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="template_id",value="模板id",required=true,dataType="String",paramType="query")
	})
	public  RequestResult<Boolean> checkExportTask(HttpServletResponse response,
												   @RequestParam(value="JID") String JID,
												   @RequestParam(value="template_id") String template_id ) {
		boolean isCanable = excelService.checkExportTask(JID, template_id);
		RequestResult<Boolean> requestResult = new RequestResult<>();
		requestResult.setObj( isCanable );
		if( !isCanable ){
			requestResult.setMsg( "正在导出请稍等" );
		}
		return requestResult;
	}


	@ApiOperation(value="清除导出文件")
		@GetMapping(value = "/cleanExportExcelFiles")
	@ApiImplicitParams({
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="fileIds",value="文件id",required=true,dataType="String",paramType="query")
	})
	public  RequestResult<Boolean> cleanExportExcelFiles( @RequestParam(value="fileIds") List<Long> fileIds ) {
		boolean isCanable = excelService.cleanExcelExportFiles( ExcelService.EXPORT_EXCEL_KEY, fileIds );
		RequestResult<Boolean> requestResult = new RequestResult<>();
		requestResult.setObj( isCanable );
		return requestResult;
	}

	@ApiOperation(value="excel文件下载")
		@PostMapping(value = "/downLoadExportExcls")
	@ApiImplicitParams({
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="fileIds",value="文件id",required=true,dataType="String",paramType="query")
	})
	public void downLoadExportExcls(HttpServletResponse response,@RequestParam(value="fileIds") String fileIds) throws IOException {
		excelService.downLoadExportExcels( response,fileIds );
	}

	@ApiOperation(value="获取下载列表")
		@GetMapping(value = "/getDownLoadExportExcls")
	@ApiImplicitParams({
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query")
	})
	public RequestResult getDownLoadExportExcls( ) throws IOException {
		return excelService.getDownLoadExportExcels( );
	}


}
