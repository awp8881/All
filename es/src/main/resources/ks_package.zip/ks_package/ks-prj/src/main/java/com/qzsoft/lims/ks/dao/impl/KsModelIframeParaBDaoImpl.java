package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSON;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.KsMenuCDao;
import com.qzsoft.lims.ks.dao.KsMenuModelBDao;
import com.qzsoft.lims.ks.dao.KsModelIframeParaBDao;
import com.qzsoft.lims.ks.eum.MTypeEnum;
import com.qzsoft.lims.ks.eum.logic.LogicValParaTypeEnum;
import com.qzsoft.lims.ks.util.CodesUtil;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.vo.SourceConfigVO;

@Repository
public class KsModelIframeParaBDaoImpl extends BaseDaoImpl implements KsModelIframeParaBDao{
	
	private static final String TABLE_NAME = "ks_model_iframe_para_b";

	@Autowired
	private KsMenuModelBDao ksMenuModelBDao;
	
	@Autowired
	private KsDicBDao ksDicBDao;
	
	@Autowired
	private KsMenuCDao ksMenuCDao;
	
	/**
	 * iframe信息
	 * */
	@Override
	public Map<String, Object> getByMenuId(String menuId) {
		if (StringUtils.isBlank(menuId)) {
			return null;
		}
		Record model = ksMenuModelBDao.getByMtype( menuId, MTypeEnum.IFRAME.getCode());
		if (null == model) {
			return null;
		}
		Map<String, Object> map = DataBaseUtil.record2Map(model);
		map.put("old_m_code", model.getStr("m_code"));
		List<Record> records = selectListByCustomAndSort(TABLE_NAME, "menu_id", "para_order+0", false, menuId);
		if (null == records || records.isEmpty()) {
			return map;
		}
		for (Record record : records) {
			String paraType = record.getStr("para_type");
			if (!LogicValParaTypeEnum.ZDJ.getCode().equals(paraType)) {
				continue;
			}
			String dicd = record.getStr("di_cd");
			String paraVal = record.getStr("para_val");
			String di_cd_str = ksDicBDao.getDicdDesc(dicd);
			String dicParaList_str = ksDicBDao.getDicdParaDesc(dicd, paraVal);
			record.set("di_cd_str", di_cd_str).set("dicParaList_str", dicParaList_str);
		}
		map.put("iframeList", DataBaseUtil.record2Map(records));
		return map;
	}

	/**
	 *  保存iframe
	 * */
	@JFinalTx
	@Override
	public boolean saveIframe(SourceConfigVO sourceConfigVO) {
		setMcode(sourceConfigVO);
		saveMenu(sourceConfigVO);
		saveMenuModel(sourceConfigVO);
		saveIframeList(sourceConfigVO);
		return true;
	}
	
	private void saveIframeList(SourceConfigVO sourceConfigVO) {
		deleteByCustom(TABLE_NAME, "menu_id", sourceConfigVO.getMenu_id());
		String iframeListStr = sourceConfigVO.getIframeListStr();
		if (StringUtils.isBlank(iframeListStr)) {
			return;
		}
		int count = 1;
		List<Map<String, Object>> iframeList = (List<Map<String, Object>>) JSON.parse(iframeListStr);
		for (Map<String, Object> map : iframeList) {
			map.put("menu_id", sourceConfigVO.getMenu_id());
			map.put("iframe_code", sourceConfigVO.getIframe_code());
			map.put("para_order", count);
			map.put("cr_dm", DateUtil.getNowDateTimeStr());
			map.put("up_ver", "1");
			
			List<Map<String, Object>> dicParaList = (List<Map<String, Object>>) map.get("dicParaList");
			map.remove("di_cd_str");
			map.remove("dicParaList");
			map.remove("dicParaList_str");
			count++;
			if (null == dicParaList || dicParaList.isEmpty()) {
				continue;
			}
			List<String> list = CommonUtil.getDicParaList(dicParaList);
			map.put("para_val", StringUtil.listTOString(list));
		}
		if (!iframeList.isEmpty()) {
			saveList(TABLE_NAME, DataBaseUtil.map2Record(iframeList));
		}
		
	}
	
	private void setMcode( SourceConfigVO sourceConfigVO ) {
		sourceConfigVO.setIframe_code(CodesUtil.createCommonCode("iframe_code"));
		String oldMcode = sourceConfigVO.getOld_m_code();
		if (StringUtils.isBlank(oldMcode)) {
			String newMcode = CodesUtil.createCommonCode("m_code");
			sourceConfigVO.setNew_m_code(newMcode);
		}else {
			sourceConfigVO.setNew_m_code(oldMcode);
		}
	}
	
	private void saveMenu( SourceConfigVO sourceConfigVO ) {
		String menuId = sourceConfigVO.getMenu_id();
		Record record = new Record();
		record.set("id", menuId).set("m_code", sourceConfigVO.getNew_m_code()).set("up_dm", DateUtil.getNowDateTimeStr());
		ksMenuCDao.update("ks_menu_c", record);
	}
	
	private void saveMenuModel( SourceConfigVO sourceConfigVO ) {
		ksMenuModelBDao.saveByIframe(sourceConfigVO);
	}

}
