package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

import java.util.List;

/**
 * @auther: puzhiqiang
 * @date: 2018/5/21 09:50
 * @description:
 */
public interface AnalyzeDao extends BaseDao{

    List<Record> findMains();

    List<Record> findFollows(String mainTableName);


}
