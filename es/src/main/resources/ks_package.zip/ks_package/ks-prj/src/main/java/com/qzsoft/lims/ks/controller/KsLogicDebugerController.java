package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.logic.KsLogicDebugerService;
import com.qzsoft.lims.ks.service.logic.bean.LogicActionRecordBean;
import com.qzsoft.lims.ks.service.logic.bean.LogicMenuBean;
import com.qzsoft.lims.ks.service.logic.bean.LogicReqParamBean;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(value = "逻辑编排调试控制层", tags = "逻辑编排调试控制层")
@RestController
@RequestMapping("/v1/logicDebug")
@Slf4j
public class KsLogicDebugerController {

    @Autowired
    private KsLogicDebugerService ksLogicDebugerService;


    @ApiOperation(value = "获取调试菜单列表")
    @GetMapping("/findUsableMenus")
        @ApiImplicitParam(name="logicCode",value="逻辑编排code",required=true,dataType="String",paramType="query")
    @ResponseAddHead
    public RequestResult<LogicMenuBean> findUsableMenus(String logicCode ){
        RequestResult<LogicMenuBean> requestResult = new RequestResult<>();
        List<LogicMenuBean> logicMenuBeans = ksLogicDebugerService.findUsableMenus( logicCode );
        requestResult.setList( logicMenuBeans );
        return requestResult;
    }

    @ApiOperation(value = "获取模板请求列表")
    @GetMapping("/findLogicActionRecords")
        @ApiImplicitParams({
            @ApiImplicitParam(name="logicCode",value="逻辑编排code",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="menuId",value="菜单id",required=true,dataType="String",paramType="query")
    } )
    @ResponseAddHead
    public RequestResult<LogicActionRecordBean>  findLogicActionRecords(String logicCode,String menuId ){
        RequestResult<LogicActionRecordBean> requestResult = new RequestResult<>();
        List<LogicActionRecordBean> logicActionRecordBeans = ksLogicDebugerService.findLogicActionRecords( logicCode, menuId );
        requestResult.setList( logicActionRecordBeans );
        return requestResult;
    }



    @ApiOperation(value = "获取本次请求参数")
    @GetMapping("/findLogicReqParam")
        @ApiImplicitParam(name="recordId",value="逻辑编排执行请求记录id",required=true,dataType="String",paramType="query")
    @ResponseAddHead
    public RequestResult findLogicReqParam(Long recordId ){
        RequestResult<LogicReqParamBean> requestResult = new RequestResult<>();
        LogicReqParamBean logicReqParamBean = ksLogicDebugerService.findLogicReqParam( recordId );
        requestResult.setObj( logicReqParamBean );
        return requestResult;

    }


    @ApiOperation(value = "更新模板版本同步")
    @PostMapping("/updateRecordUpVerSwitch")
        @ApiImplicitParams({
            @ApiImplicitParam(name="recordId",value="逻辑编排执行请求记录id",required=true,dataType="long",paramType="query"),
            @ApiImplicitParam(name="useLastUpVerSwitch",value="启动或者关闭，启动：1, 禁用：2",required=true,dataType="String",paramType="query")
    } )
    @ResponseAddHead
    public RequestResult<Boolean>  updateRecordUpVerSwitch(Long recordId, String useLastUpVerSwitch ){
        RequestResult<Boolean> requestResult = new RequestResult<>();
        boolean success =  ksLogicDebugerService.updateRecordUpVerSwitch( recordId, useLastUpVerSwitch );
        requestResult.setObj( success );
        return requestResult;
    }


    //执行debugger调试

}
