package com.qzsoft.lims.ks.config;

import com.qzsoft.common.exception.KsVerifyException;
import com.qzsoft.common.ui.RequestResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;

/**
 * @Author zf
 * @Description 全局异常
 * @Date 2020/10/20
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler{

    @Value("${multipart.maxFileSize}")
    private String maxFileSize;

    /**
     * 处理上传异常
     */
    @ExceptionHandler(MultipartException.class)
    public RequestResult<Object> exception(MaxUploadSizeExceededException e) {
        String error = "上传异常：超过系统"+maxFileSize+"限制";
        RequestResult<Object> requestResult = new RequestResult<>();
        requestResult.setStatus(false);
        requestResult.setError(error);
        return requestResult;
    }

    /**
     * 处理ks登录拦截导致的异常
     * @param e
     * @return
     */
    @ExceptionHandler(KsVerifyException.class)
    public RequestResult<Object> exception(KsVerifyException e) {
        RequestResult<Object> requestResult = new RequestResult<>();
        requestResult.setStatus(false);
        requestResult.setCode(e.getCode());
        requestResult.setError(e.getMessage());
        requestResult.setThrowable(e);
        return requestResult;
    }


}