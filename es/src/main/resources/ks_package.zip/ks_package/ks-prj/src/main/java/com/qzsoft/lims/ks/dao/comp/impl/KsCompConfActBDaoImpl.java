package com.qzsoft.lims.ks.dao.comp.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.UIDGenerator;
import com.qzsoft.lims.ks.dao.comp.KsCompConfActBDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondEveBDao;
import com.qzsoft.lims.ks.eum.event.CondTypeEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @Author zf
 * @Description 外部组件事件动作
 * @Date 2019/7/31
 */
@Repository
public class KsCompConfActBDaoImpl extends BaseDaoImpl implements KsCompConfActBDao {

    private static final String TABLE_NAME = "ks_comp_conf_act_b";


    /**
     * 获取组件事件配置
     * b
     * @param compCode
     * @return
     */
    @Override
    public List<Record> getByCompCode(String compCode) {
        List<Record> records = selectListByCustom( TABLE_NAME, "comp_code", compCode);
        return records;
    }

    /**
     * 保存组件事件配置
     *
     * @param pCode
     * @param compCode
     * @param compEves
     * @return
     */
    @Override
    public Boolean saveCompConfAct(String pCode, String compCode, String menuId, List<Map<String, Object>> compEves) {
        boolean isSave = true;
        if (null == compEves || compEves.isEmpty()){
            return isSave;
        }

        for (Map<String, Object> compEve : compEves) {
            compEve.put("comp_code", compCode);
            compEve.put("menu_id", menuId);
            compEve.put("cr_dm", DateUtil.getNowDateTimeStr());
            compEve.put("up_ver", "1");
            compEve.remove("def_code");
        }
        List<Record> records = DataBaseUtil.map2Record( compEves );
        saveList( TABLE_NAME, records);
        return isSave;
    }
}
