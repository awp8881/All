package com.qzsoft.lims.hlyy.eum;

public enum SampZSEnum {

    MOUSE("Mouse", "老鼠"),
    RAT("Rat", "小鼠"),
    DOG("Dog", "狗"),
    MONKEY("Monkey", "猴子"),
    HUMAN("Human", "人类"),
    PIG("Pig", "猪"),
    RABBIT("Rabbit", "兔子"),
    ;

    private String code;
    private String desc;

    SampZSEnum(String code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
