package com.qzsoft.lims.ks.constants;

public class DBConstant {

    public static String TABLE_KS_TABLE_NOTE_C = "ks_table_note_c";

    public static String TABLE_KS_TABLE_NOTE_FIELD_C = "ks_table_note_field_c";

    public static String TABLE_KB_TABLE_NOTE_CHG_B = "kb_table_note_chg_b";

    public static String TABLE_KS_TABLE_NOTE_VAL_B = "ks_table_note_val_b";

    public static String TABLE_KB_SYS_PARA = "kb_sys_para";


}
