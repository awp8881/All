package com.qzsoft.lims.ks.dao.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.google.common.collect.Lists;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.eum.UrlTypeEnum;
import com.qzsoft.lims.ks.util.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.ConfigUtil;
import com.qzsoft.lims.ks.dao.KsPortDicBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;

/**
 * 后端动作
 * @author zf
 * */
@Repository
public class KsPortDicBDaoImpl extends BaseDaoImpl implements KsPortDicBDao{
	private static final String TABLE_NAME = "ks_port_dic_b";

	/**
	 * 获取后端类型列表
	 * */
	@Override
	public List<Map<String,Object>> getActionTypeList(String sy_id) {
		List<Record> recordList = null;
		if(StringUtils.isNotBlank(sy_id)){
			recordList = selectListByCustomAndSort(TABLE_NAME, "sy_id", "cr_dm", true, sy_id);
		}else{
			recordList = findAll(TABLE_NAME,"cr_dm");
		}
		if ( null == recordList || recordList.isEmpty()){
			return Lists.newArrayList();
		}
		List<Record> newRecordList = removeDuplicate(recordList);
		return DataBaseUtil.record2Map(newRecordList);
	}
	
	private static List<Record> removeDuplicate(List<Record> recordList) {
        Set<Record> set = new TreeSet<Record>(new Comparator<Record>() {
            @Override
            public int compare(Record recordA, Record recordB) {
                // 字符串则按照asicc码升序排列
				String action_type_code_a = recordA.getStr("action_type_code");
				String sy_id_a = StringUtil.toString(recordA.getStr("sy_id"));
				String action_type_code_b = recordB.getStr("action_type_code");
				String sy_id_b = StringUtil.toString(recordB.getStr("sy_id"));
				if( null==action_type_code_a || null==action_type_code_b ){
					return 1;
				}
				return action_type_code_a.compareTo(action_type_code_b) == 0 ? sy_id_a.compareTo( sy_id_b ):action_type_code_a.compareTo(action_type_code_b);
            }
        });
        set.addAll(recordList);
        return new ArrayList<Record>(set);
    }

	/**
	 * 获取后端动作列表
	 * */
	@Override
	public List<Map<String, Object>> getActionList(String action_type_code,String sy_id) {
		if(StringUtils.isBlank(action_type_code)){
			throw new BusinessException(11003,ConfigUtil.getMessage(11003, "后端动作类型"));
		}
		String sql = " select * from "+TABLE_NAME+" where action_type_code=? and sy_id = ? and ((action_desc IS NOT NULL and action_desc != '') "
				+ " OR (action_code IS NOT NULL and action_code != '') OR (port_type IS NOT NULL and port_type != '') OR (logic_url IS NOT NULL and logic_url != ''))";
		List<Record> recordList = selectListBySql(sql, action_type_code,sy_id);
		if (null != recordList  && !recordList.isEmpty()){
			recordList.stream().forEach( record -> {
				String urlType = record.getStr("url_type");
				if (UrlTypeEnum.FIELD_URL.getCode().equals( urlType)){
					String logicUrl = record.getStr("logic_url");
					record.set("logic_url", CommonUtil.strToList(logicUrl, ","));
				}
			});
		}
		return DataBaseUtil.record2Map(recordList);
	}
	
	
}
