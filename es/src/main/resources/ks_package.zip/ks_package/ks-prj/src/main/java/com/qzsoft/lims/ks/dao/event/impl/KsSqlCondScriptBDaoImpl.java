package com.qzsoft.lims.ks.dao.event.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.dao.event.KsSqlCondScriptBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;

@Repository
public class KsSqlCondScriptBDaoImpl extends BaseDaoImpl implements KsSqlCondScriptBDao{
	
	private static final String TABLE_NAME = "ks_sql_cond_script_b";

	/**
	 * 条件脚本
	 */
	@Override
	public List<Record> getByPCode(String pCode) {
		String condScriptSql = "select gro_cond_code,cond_script from "+TABLE_NAME+" where p_code=?";
		List<Record> condScriptList = selectListBySql(condScriptSql, pCode);
		return condScriptList;
	}

	/**
	 * 批量保存
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> allCondScriptList) {
		boolean succYn = true;
		if (null == allCondScriptList || allCondScriptList.isEmpty()) {
			return succYn;
		}
		for (Map<String, Object> map : allCondScriptList) {
			map.put("cr_dm", DateUtil.getNowDateTimeStr());
			map.put("up_ver", "1");
		}
		List<Record> recordList = DataBaseUtil.map2Record(allCondScriptList);
		return saveList(TABLE_NAME, recordList);
	}
}
