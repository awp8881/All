package com.qzsoft.lims.ks.dao.event.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.KsSqlButtonDicBDao;
import com.qzsoft.lims.ks.dao.KsSqlPortCDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondFieldValBDao;
import com.qzsoft.lims.ks.eum.ButtonParaTypeEnum;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.event.EveFieldValTypeEnum;
import com.qzsoft.lims.ks.expression.ExpressRepository;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.vo.SourceConfigVO.PortVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
public class KsSqlCondFieldValBDaoImpl extends BaseDaoImpl implements KsSqlCondFieldValBDao{
	
	private static final String TABLE_NAME = "ks_sql_cond_field_val_b";

	@Autowired
	private KsSqlPortCDao ksSqlPortCDao;

	@Autowired
	private KsDicBDao ksDicBDao;

	@Autowired
	private KsSqlButtonDicBDao ksSqlButtonDicBDao;

	@Autowired
	private ExpressRepository expressRepository;

	/**
	 * 事件字段赋值
	 */
	@Override
	public List<Record> getByPCode(String pCode, Boolean jsonYn) {
		List<Record> records = selectListByCustom(TABLE_NAME, "p_code", pCode);
		parse(records, jsonYn);
		return records;
	}
	
	private void parse(List<Record> records, Boolean jsonYn) {
		if (null == records || records.isEmpty()) {
			return;
		}

		List<Record> allDicds = ksDicBDao.getAllList();
		for (Iterator<Record> iterator = records.iterator(); iterator.hasNext();) {
			Record record = iterator.next();
			
			String paraType = record.getStr("para_type");
			String paraVal = record.getStr("para_val");
			String portCode = record.getStr("port_code");
			if (EveFieldValTypeEnum.ZDJ.getCode().equals(paraType)) {//字典
				String dicd = record.getStr("di_cd");
				List<String> dicParas = CommonUtil.strToList(paraVal, ","  );
				String di_cd_str = CommonUtil.getDicdDesc( dicd, allDicds);
				String dicParasStr = CommonUtil.getDicdParasDesc(dicd, dicParas, allDicds);

				record.set("dicParas", dicParas).set("di_cd_str", di_cd_str).set("dicParasStr", dicParasStr);

			}else if(EveFieldValTypeEnum.JK.getCode().equals(paraType)){//接口
				PortVO portVO = ksSqlPortCDao.getPortAndParaAndReturn(portCode, McodeTypeEnum.YMSJY.getCode());
				record.set("portVO", portVO);
				
			}else if (EveFieldValTypeEnum.ZD.getCode().equals(paraType) && jsonYn) {
				record.set("para_val", DataBaseUtil.buildFieldName(paraVal));

			}else if (EveFieldValTypeEnum.GLOBAL_DIC.getCode().equals(paraType)) {
				String dicd = record.getStr("di_cd");
				Record dicRecord = ksSqlButtonDicBDao.getByCode(dicd);
				if (null != dicRecord){
					record.set("di_cd_str", dicRecord.getStr("val"));
				}

				List<String> dicParas = CommonUtil.strToList(paraVal, ","  );
				List<Record> dicDescs = null;
				if (null != dicParas && !dicParas.isEmpty()){
					dicDescs = ksSqlButtonDicBDao.getByChilds(dicParas);
				}
				record.set("dicParas", dicParas).set("dicParasStr", StringUtil.listTOString( DataBaseUtil.record2String( dicDescs, "val")));

			}else if (EveFieldValTypeEnum.EXP.getCode().equals(paraType) && jsonYn) {
				Set<String> expBusCode = expressRepository.getExpBusCode(paraVal);
				record.set("expBusCode", expBusCode);

			}
			
		}
		
	}

	/**
	 * 批量插入
	 */
	@JFinalTx
	@Override
	public boolean batchUpdate(List<Map<String, Object>> allFieldValList) {
		boolean succYn = true;
		if (null == allFieldValList || allFieldValList.isEmpty()) {
			return succYn;
		}
		for (Map<String, Object> map : allFieldValList) {
			map.put("cr_dm", DateUtil.getNowDateTimeStr());
			map.put("up_ver", "1");
		}
		List<Record> recordList = DataBaseUtil.map2Record(allFieldValList);
		return saveList(TABLE_NAME, recordList);
	}
}
