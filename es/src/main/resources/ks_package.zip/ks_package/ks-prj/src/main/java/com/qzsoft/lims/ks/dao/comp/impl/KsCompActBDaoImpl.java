package com.qzsoft.lims.ks.dao.comp.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.comp.KsCompActBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author zf
 * @Description 外部组件事件动作
 * @Date 2019/7/30
 */
@Repository
public class KsCompActBDaoImpl extends BaseDaoImpl implements KsCompActBDao{
    private static final String TABLE_NAME = "ks_comp_act_b";

    /**
     * 组件编码获取事件
     *
     * @param defCode
     * @return
     */
    @Override
    public List<Record> getByDefCode(String defCode) {
        String sql = "select * from "+TABLE_NAME+" where def_code=? order by cr_dm";
        List<Record> records = selectListBySql( sql, defCode);
        return records;
    }
}
