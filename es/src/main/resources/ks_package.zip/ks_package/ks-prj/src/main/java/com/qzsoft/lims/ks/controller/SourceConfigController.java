package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.log.OptLog;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.dao.KsPortDicBDao;
import com.qzsoft.lims.ks.dao.KsPortDicParaBDao;
import com.qzsoft.lims.ks.service.KsTableFieldCService;
import com.qzsoft.lims.ks.service.KsTableSqlService;
import com.qzsoft.lims.ks.service.SourceConfigService;
import com.qzsoft.lims.ks.service.menu.MenuConfigService;
import com.qzsoft.lims.ks.service.meta.KsTableService;
import com.qzsoft.lims.ks.vo.SourceConfigVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 数据源配置-控制器
 * @author zf
 *
 */
@Api(value = "数据源配置", tags = "数据源配置")
@RestController
@RequestMapping("/source/config")
@Slf4j
@TagResource("数据源配置")
public class SourceConfigController {

	@Autowired
	private KsTableSqlService ksTableSqlService;
	@Autowired
	private KsTableFieldCService ksTableFieldCService;
	@Autowired
	private SourceConfigService sourceConfigService;
	@Autowired
	private KsPortDicBDao ksPortDicBDao;
	@Autowired
	private KsPortDicParaBDao ksPortDicParaBDao;

	@Autowired
	private MenuConfigService menuConfigService;

	@Autowired
	private KsTableService ksTableService;

	@ApiOperation("获取数据源列表")
	@GetMapping("/getTableSqlList")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="m_code_type",value="数据源类型：初始数据源CSSJY，组件数据源ZJSJY，页面数据源YMSJY，CPT数据源CPTSJY",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="t_type",value="表类型：多表0，单表1，全部2",required=false,dataType="Integer",paramType="query")
	})
	public RequestResult<Map<String,Object>> getTableSqlList(@RequestParam(value="m_code_type") String m_code_type,
			@RequestParam(value="t_type",required=false) Integer t_type) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksTableSqlService.getTableSqlList(m_code_type,false,t_type));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableSqlList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableSqlList()", e);
		}
		return result;

	}

	@ApiOperation("模糊查询并获取数据源列表")
	@GetMapping("/getTableSqlSearchList")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="mCodeType",value="数据源类型：初始数据源CSSJY，组件数据源ZJSJY，页面数据源YMSJY，CPT数据源CPTSJY",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="search",value="查询字符",required=false,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getTableSqlSearchList(@RequestParam(value="mCodeType") String mCodeType,
			@RequestParam(value="search") String search) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksTableSqlService.getTableSqlSearchList(mCodeType,search,false));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableSqlSearchList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableSqlSearchList()", e);
		}
		return result;

	}

	@ApiOperation("获取表字段列表")
	@GetMapping("/getTableFieldList")
	@ResponseAddHead
		@ApiImplicitParam(name="t_name",value="表名",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getTableFieldList( @RequestParam(value="t_name") String t_name ) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksTableFieldCService.getTableFieldList( t_name ));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableFieldList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTableFieldList()", e);
		}
		return result;

	}

	@ApiOperation(value="通过选择的数据源获取页面属性模板",notes="tableSql:数据源信息;fieldList:字段列表，初始类型可能跟其他两种不一样;logicButtonList:工具栏列表;"
			+ "attrVO:综合属性对象")
	@GetMapping("/getModelData")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="isFromLeft",value="是否左侧树加载:true是false否",required=false,dataType="Boolean",paramType="query"),
		@ApiImplicitParam(name="menu_id",value="菜单id",required=false,dataType="String",paramType="query"),
		@ApiImplicitParam(name="m_code",value="模板编码",required=false,dataType="String",paramType="query"),
		@ApiImplicitParam(name="m_code_type",value="数据源类型：初始数据源CSSJY，组件数据源ZJSJY，页面数据源YMSJY，CPT数据源CPTSJY",required=false,dataType="String",paramType="query"),
		@ApiImplicitParam(name="old_m_code",value="旧模板编码，如果不为空，则为更新数据源，否则为选择新数据源",required=false,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getModelData(@RequestParam(value="menu_id",required=false) String menu_id,
			@RequestParam(value="m_code",required=false) String m_code,
			@RequestParam(value="m_code_type",required=false) String m_code_type,
			@RequestParam(value="old_m_code",required=false) String old_m_code,
			@RequestParam(value="isFromLeft",required=false) Boolean isFromLeft) {

		RequestResult<Map<String,Object>> result = null;
		try {
			Map<String, Object> map=sourceConfigService.getModelData(menu_id,m_code,m_code_type,isFromLeft ,old_m_code);
			result=new RequestResult<>(map);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getModelData()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getModelData()", e);
		}
		return result;
	}


	@ApiOperation(value="保存")
	@PostMapping("/save")
	@TagResource("大列表保存")
	@ResponseAddHead
		@OptLog(module = "out_list_save",remark = "大列表保存")
	public RequestResult<String> save(SourceConfigVO sourceConfigVO) {
		RequestResult<String> result = new RequestResult<>();
		try {
			String menuVer = sourceConfigService.save(sourceConfigVO);
			result.setObj(menuVer);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".save()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".save()", e);
		}
		return result;

	}

	@ApiOperation(value="获取模板对应的字段")
	@GetMapping("/getMcodeField")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="m_code",value="列表编码",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="m_type",value="列表类型",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getMcodeField(@RequestParam(value="m_code") String mCode,
			@RequestParam(value="m_type") String mType) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(sourceConfigService.getMcodeField(mCode , mType));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMcodeField()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMcodeField()", e);
		}
		return result;
	}


	@ApiOperation(value="获取后端类型列表")
	@GetMapping("/getActionTypeList")
	@ResponseAddHead
		@ApiImplicitParam(name="sy_id",value="系统主键",required=false,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getActionTypeList(@RequestParam(value="sy_id",required=false) String sy_id) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksPortDicBDao.getActionTypeList(sy_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getActionTypeList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getActionTypeList()", e);
		}
		return result;
	}

	@ApiOperation(value="获取后端动作列表")
	@GetMapping("/getActionList")
	@ResponseAddHead
		@ApiImplicitParams({
	@ApiImplicitParam(name="action_type_code",value="后端动作类型",required=true,dataType="String",paramType="query"),
	@ApiImplicitParam(name="sy_id",value="系统编码",required=true,dataType="String",paramType="query")})
	public RequestResult<Map<String,Object>> getActionList(@RequestParam(value="action_type_code") String action_type_code,
														   @RequestParam(value="sy_id") String sy_id) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksPortDicBDao.getActionList(action_type_code,sy_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getActionList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getActionList()", e);
		}
		return result;
	}

	@ApiOperation(value="获取后端动作参数列表")
	@GetMapping("/getActionParamsList")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="action_type_code",value="后端动作类型",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="port_code",value="后端动作",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getActionParamsList(@RequestParam(value="action_type_code") String action_type_code,
			@RequestParam(value="port_code") String port_code) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksPortDicParaBDao.getActionParamsList(action_type_code,port_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getActionParamsList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getActionParamsList()", e);
		}
		return result;
	}

	@ApiOperation(value="大列表是否可以重新选择数据源",notes="true:可以重新选择,false:不可以")
	@PostMapping("/isChooseDataSource")
	@ResponseAddHead
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
	public RequestResult<Boolean> isChooseDataSource(@RequestParam(value="menu_id") String menu_id) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			result.setObj(sourceConfigService.isChooseDataSource(menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".isChooseDataSource()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".isChooseDataSource()", e);
		}
		return result;
	}

	@ApiOperation(value="获取临时常量")
	@GetMapping("/getTmpConstantList")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="m_code",value="组件编码",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="info_code",value="详情编码",required=false,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getTmpConstantList(@RequestParam(value="m_code") String m_code,
																 @RequestParam(value="info_code",required = false) String info_code) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(ksPortDicParaBDao.getTmpConstantList(m_code,info_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getActionParamsList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getActionParamsList()", e);
		}
		return result;
	}

	@ApiOperation(value="大列表和详情编码字段列表")
	@GetMapping("/getMcodeAndFieldList")
	@ResponseAddHead
		@ApiImplicitParams({
    	@ApiImplicitParam(name="code",value="详情编码：大列表是m_code,大详情是info_code,小详情、小列表是list_code",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="m_type",value="类型",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getMcodeAndFieldList(@RequestParam(value="code") String code,@RequestParam(value="m_type") String m_type) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(sourceConfigService.getMcodeAndFieldList(code,m_type));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMcodeAndFieldList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMcodeAndFieldList()", e);
		}
		return result;
	}

	@ApiOperation(value="列表修改")
	@PostMapping("/updateInnerList")
	@ResponseAddHead
		@ApiImplicitParam(name="fields_str",value="一行字段json字符串",required=true,dataType="String",paramType="query")
	public RequestResult<Map> updateInnerList(@RequestParam(value="fields_str") String fields_str,
											  @RequestParam(value="update_table_filed")String update_table_filed,
											  @RequestParam(value="m_code",required = false)String m_code) {
		RequestResult<Map> result = new RequestResult<>();
		List<Map> list = sourceConfigService.updateInnerList(fields_str, update_table_filed,m_code);
		result.setList(list);
		if( !list.isEmpty() ){
			result.setObj( list.get(0) );
		}
		return result;
	}

	@ApiOperation(value="菜单所有列表字段")
	@GetMapping("/getMenuListField")
	@ResponseAddHead
	    @ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getMenuListField(@RequestParam(value="menu_id") String menu_id) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(menuConfigService.getMenuListField(menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListField()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListField()", e);
		}
		return result;
	}

	@ApiOperation(value="菜单table字段树结构")
	@GetMapping("/getMenuFieldsTree")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="para_type",value="参数类型：目前只有列表字段值为12，全局字段值为13",required=false,dataType="String",paramType="query")
	})

	public RequestResult<Map<String,Object>> getMenuFieldsTree(@RequestParam(value="menu_id") String menu_id,
			@RequestParam(value="para_type", required =false) String paraType) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setList( menuConfigService.getMenuFieldsTree(menu_id, paraType));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuFieldsTree()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuFieldsTree()", e);
		}
		return result;
	}


	@ApiOperation(value="打开详情")
	@PostMapping("/openInfos")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="inner_info_s",value="详情编码字段",required=false,dataType="String",paramType="query")
	})
	public RequestResult<String> openInfos(@RequestParam(value="menu_id") String menu_id,@RequestParam(value="inner_info_s",required=false) String inner_info_s) {
		RequestResult<String> result = null;
		try {
			List<String> list=sourceConfigService.openInfos(menu_id,inner_info_s);
			result = new RequestResult<>(list);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".openInfos()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".openInfos()", e);
		}
		return result;
	}

	@ApiOperation(value="页面所有按钮")
	@GetMapping("/getPageButtons")
	@ResponseAddHead
		@ApiImplicitParams({
    	@ApiImplicitParam(name="code",value="详情编码：大列表是m_code,大详情是info_code,小详情、小列表是list_code",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="m_type",value="类型",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getPageButtons(@RequestParam(value="code") String code,@RequestParam(value="m_type") String m_type) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(sourceConfigService.getPageButtons(m_type,code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getPageButtons()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getPageButtons()", e);
		}
		return result;
	}


	@ApiOperation("详情页table列表")
	@GetMapping("/getMenuListInfo")
	@ResponseAddHead
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getMenuListInfo(@RequestParam(value="menu_id") String menu_id) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(menuConfigService.getMenuListInfo(menu_id));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListInfo()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListInfo()", e);
		}
		return result;

	}

	@ApiOperation(value="获取列表信息的层级结构")
	@GetMapping("/getMenuListTree")
	@ResponseAddHead
		@ApiImplicitParam(name="menu_id",value="菜单ID",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getMenuListTree(@RequestParam(value = "menu_id") String menu_id) {

		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
//			Map<String, Object> menuListTree = sourceConfigService.getMenuListTree(menu_id);
//			result.setExObj(menuListTree);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListTree()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListTree()", e);
		}
		return result;
	}

	@ApiOperation(value="根据code获取使用到的表")
	@GetMapping("/getTablesByMcode")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="code",value="详情编码：大列表是m_code,大详情是info_code,小详情、小列表是list_code",required=true,dataType="String",paramType="query"),
	})
	public RequestResult<String> getTablesByMcode(@RequestParam(value="code") String code) {

		RequestResult<String> result = new RequestResult<>();
		List<String> tables = ksTableService.getTables(code);
		result.setList( tables );
		return result;
	}

}
