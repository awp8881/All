package com.qzsoft.lims.ks.dao.comp;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

import java.util.List;
import java.util.Map;

public interface KsCompConfActBDao extends BaseDao {

    /**
     * 获取组件事件配置
     * @param compCode
     * @return
     */
    List<Record> getByCompCode(String compCode );

    /**
     * 保存组件事件配置
     * @param pCode
     * @param compCode
     * @param compEves
     * @return
     */
    Boolean saveCompConfAct( String pCode, String compCode, String menuId, List<Map<String, Object>> compEves);

}
