
package com.qzsoft.lims.ks.base;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.qzsoft.lims.ks.entity.TableEntity;
import com.qzsoft.lims.ks.util.StringKitUtil;

import java.io.Serializable;
import java.util.List;

/**
 * @author : yuanj
 * @date : 2021/6/12
 * @desc : 列字段信息
 * 来源于siner结构json文件:entities.fields
 */
@JsonPropertyOrder({
        "rowNo",
        "defKey",
        "defName",
        "comment",
        "domain",
        "type",
        "len",
        "scale",
        "primaryKey",
        "notNull",
        "autoIncrement",
        "defaultValue",
        "hideInGraph",
})
public class ColumnField implements Serializable, Cloneable {
    @JsonIgnore
    private TableEntity tableEntity;
    private int rowNo;              //行号，从1开始
    private String defKey;          //字段代码
    private String defName;         //字段名称
    private String comment = "";    //字段注释说明
    private String domain = "";                     //数据域（暂时留空，前端自行匹配）
    private String type = "";       //字段数据类型，如varchar
    private Integer len = null;     //字段长度，如32
    private Integer scale = null;   //字段小数位数据
    private String typeFullName = "";//类型+长度+小数位数
    private Boolean primaryKey = Boolean.FALSE;     //是否主键
    private String primaryKeyName = "";
    private Boolean notNull = Boolean.FALSE;        //是否允许为空
    private String notNullName = "";
    private Boolean autoIncrement = Boolean.FALSE;  //是否自增
    private String autoIncrementName = "";
    private String refDict = "";               //引用数据字典
    private String defaultValue = "";               //默认值
    private Boolean hideInGraph = Boolean.FALSE;    //关系图是否隐藏（第15个之前，默认为true)
/* "chnname":"更新时间",
         "name":"UPDATED_TIME",
         "remark":"",
         "type":"DateTime"
}*/
    private String chnname; //pdman中字段名称
    private String name; //pdman中字段
    private String remark;//描述
    private Boolean pk;//是否主键
    private String dataType;//数据库类型
    private String url;//数据库地址---用于后续判断是否是主库操作,如果不是就不许增删改----yuanj

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public Boolean getPk() {
        return pk;
    }

    public void setPk(Boolean pk) {
        this.pk = pk;
    }

    public String getChnname() {
        return chnname;
    }

    public void setChnname(String chnname) {
        this.chnname = chnname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public TableEntity getTableEntity() {
        return tableEntity;
    }

    public void setTableEntity(TableEntity tableEntity) {
        this.tableEntity = tableEntity;
    }

    public int getRowNo() {
        return rowNo;
    }

    public void setRowNo(int rowNo) {
        this.rowNo = rowNo;
    }

    public String getDefKey() {
        return defKey;
    }

    public void setDefKey(String defKey) {
        this.defKey = defKey;
    }

    public String getDefName() {
        return defName;
    }

    public void setDefName(String defName) {
        this.defName = defName;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getLen() {
        return len;
    }

    public void setLen(Integer len) {
        this.len = len;
    }

    public Integer getScale() {
        return scale;
    }

    public void setScale(Integer scale) {
        this.scale = scale;
    }

    /**
     * 字段类型+长度+小数位数
     * @return
     */
    public String getTypeFullName() {
        return typeFullName;
    }

    public void setTypeFullName(String typeFullName) {
        this.typeFullName = typeFullName;
    }

    public Boolean getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(Boolean primaryKey) {
        this.primaryKey = primaryKey;
    }

    public Boolean getNotNull() {
        return notNull;
    }

    public void setNotNull(Boolean notNull) {
        this.notNull = notNull;
    }

    public Boolean getAutoIncrement() {
        return autoIncrement;
    }

    public void setAutoIncrement(Boolean autoIncrement) {
        this.autoIncrement = autoIncrement;
    }

    public String getRefDict() {
        return refDict;
    }

    public void setRefDict(String refDict) {
        this.refDict = refDict;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public Boolean getHideInGraph() {
        return hideInGraph;
    }

    public void setHideInGraph(Boolean hideInGraph) {
        this.hideInGraph = hideInGraph;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getPrimaryKeyName() {
        return primaryKeyName;
    }

    public void setPrimaryKeyName(String primaryKeyName) {
        this.primaryKeyName = primaryKeyName;
    }

    public String getNotNullName() {
        return notNullName;
    }

    public void setNotNullName(String notNullName) {
        this.notNullName = notNullName;
    }

    public String getAutoIncrementName() {
        return autoIncrementName;
    }

    public void setAutoIncrementName(String autoIncrementName) {
        this.autoIncrementName = autoIncrementName;
    }

    public void fillConvertNames(){
        //处理类型名
        StringBuffer buffer = new StringBuffer(type);
        if(len != null && len > 0){
            buffer.append("(").append(len);
            if(scale != null && scale > 0){
                buffer.append(",").append(scale);
            }
            buffer.append(")");
        }
        typeFullName = buffer.toString();

        if(primaryKey.equals(Boolean.TRUE)){
            primaryKeyName = "√";
        }
        if(notNull.equals(Boolean.TRUE)){
            notNullName = "√";
        }
        if(autoIncrement.equals(Boolean.TRUE)){
            autoIncrementName = "√";
        }
        if(StringKitUtil.isNotBlank(refDict)){
            Dict dict = lookupDict(tableEntity.getDicts(),refDict);
            String dictText = "";
            if(dict != null){
                dictText = "<字典:"+dict.getDefKey()+">";
            }
            if(StringKitUtil.isNotBlank(comment)
                    && comment.indexOf(dictText) < 0
                    && StringKitUtil.isNotBlank(dictText)){
                comment += dictText;
            }else{
                comment = dictText;
            }
        }
    }

    public Dict lookupDict(List<Dict> dictList, String dictId){
        for(Dict dict : dictList){
            if(dictId.equals(dict.getId())){
                return dict;
            }
        }
        return null;
    }

}
