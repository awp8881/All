package com.qzsoft.lims.ks.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsCompConfFileBDao;

/**
 * 组件文件管理-dao实现
 * @author hqp
 *
 */
@Repository
public class KsCompConfFileBDaoImpl extends BaseDaoImpl implements KsCompConfFileBDao {
private static final String TABLE_NAME = "ks_comp_conf_file_b";
	
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	@Override
	public Boolean save(Record record) {
		return super.save(TABLE_NAME,record);
	}
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	@Override
	public Boolean update(Record record) {
		return super.update(TABLE_NAME,record);
	}
	
	/**
	 * 删除
	 * @param infoCode INFO编码
	 * @return
	 */
	@Override
	public Boolean deleteByInfoCode(String infoCode) {
		return super.deleteByCustom(TABLE_NAME, "info_code", infoCode);
	}
	
	/**
	 * 根据INFO编码查询
	 * @return
	 */
	@Override
	public List<Record> getListByInfoCode(String infoCode) {
		return DbEx.find("select * from " + TABLE_NAME+" where info_code = ? ",infoCode);
	}
	
	/**
	 * 根据组件编码查询
	 * @return
	 */
	@Override
	public Record getOneByCompCode(String compCode) {
		List<Record> recs = DbEx.find("select * from " + TABLE_NAME+" where comp_code = ? ",compCode);
		if(recs != null && recs.size() > 0){
			return recs.get(0);
		}else{
			return null;
		}	 
	}
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	@Override
	public Record getOne(Long id) {
		return super.selectById(TABLE_NAME,id);
	}
}
