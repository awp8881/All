package com.qzsoft.lims.ks.controller.flow;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.flow.core.bean.ProcessReqBean;
import com.qzsoft.lims.ks.flow.core.run.FlowHistoryService;
import com.qzsoft.lims.ks.flow.core.run.ProcessService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @Description 流程引擎执行
 * @Date 2021/3/5
 */
@Api(value = "流程引擎执行", tags = "流程引擎执行")
@RestController
@RequestMapping("/flowRun")
@Slf4j
public class FlowRunController {

    @Autowired
    private ProcessService processService;

    @Autowired
    private FlowHistoryService flowHistoryService;


    @ApiOperation(value = "流程环节执行")
    @PostMapping("/exe")
    @ResponseAddHead
    public RequestResult<Object> run(ProcessReqBean processReqBean) {
        RequestResult<Object> result = new RequestResult<>();
        result.setObj(processService.runFlow(processReqBean));
        return result;
    }

    @ApiOperation(value = "流转记录")
    @PostMapping("/note")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> note(String instanceId) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(flowHistoryService.flowNote(instanceId));
        return result;
    }


}
