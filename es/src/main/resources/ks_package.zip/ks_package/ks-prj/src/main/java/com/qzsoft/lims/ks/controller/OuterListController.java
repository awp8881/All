package com.qzsoft.lims.ks.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.CommonService;
import com.qzsoft.lims.ks.service.LoginService;
import com.qzsoft.lims.ks.service.page.OuterListService;
import com.qzsoft.lims.ks.service.page.TakeEffectJsonService;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.util.UserDataUtil;
import com.qzsoft.lims.ks.vo.page.PageBaseVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * 前台页面-控制器
 * @author zf
 * /cros处理跨域不支持此类型参数传递 content-type:application/json不支持，不能使用@RequestBody接收复杂对象
 */

@Api(value = "前台页面", tags = "前台页面")
@RestController
@RequestMapping("/list")
@Slf4j
@TagResource("前台页面")
public class OuterListController {

	@Autowired
	private OuterListService outerListService;

	@Autowired
	private TakeEffectJsonService takeEffectJsonService;

	@Autowired
	private CommonService commonService;

	@Autowired
	private LoginService loginService;


	@ApiOperation("生效json文件")
	@PostMapping("/takeEffect")
		@ApiImplicitParams({
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="remark",value="备注",required=false,dataType="String",paramType="query")
	})
	@ResponseAddHead
	@TagResource("生效json文件")
	public RequestResult<Boolean> takeEffect(@RequestParam(value="menu_id") String menu_id, @RequestParam(value="remark",required=false) String remark,
											 HttpServletRequest request) {

		RequestResult<Boolean> result = new RequestResult<>();
		String JID = UserDataUtil.getJID();
		loginService.validateSuperManager(JID);

		takeEffectJsonService.handleBackAndLoadField( menu_id , remark, request);
		boolean isSucc = takeEffectJsonService.takeEffectJsonFile(menu_id , remark, request);

		result.setObj(isSucc);
		return result;
	}

	@ApiOperation("生效的菜单列表")
		@GetMapping("/getEffectMenuList")
	@ResponseAddHead
	public RequestResult<Map<String, Object>> getEffectMenuList() {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		List<Map<String, Object>> list = takeEffectJsonService.getEffectMenuList();
		result.setList(list);
		return result;
	}

	@ApiOperation("批量生效菜单")
	@PostMapping("/batchTakeEffect")
		@ResponseAddHead
	public RequestResult<Boolean> batchTakeEffect(@RequestBody Map<String, Object>  menuIdMap) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj(takeEffectJsonService.batchTakeEffect((List<String>) menuIdMap.get("menuIds")));
		return result;
	}

	@ApiOperation("预览生效")
	@PostMapping("/previewEffect")
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<PageBaseVO> previewEffect(@RequestParam(value="menu_id") String menu_id) {
		RequestResult<PageBaseVO> result = new RequestResult<>();
		PageBaseVO pageVO = takeEffectJsonService.previewEffect(menu_id);
		result.setObj(pageVO);
		return result;
	}

	@ApiOperation(value = "调整数据排序", notes = "调整显示字段排序")
	@RequestMapping("/adjustDataOrder")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="m_code",value="小列表编码",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="row_source",value="交换的字段，将row_source与row_target交换排序,格式选中行的json字符串",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="row_target",value="被交换的字段，格式格式选中行的json字符串",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Boolean> adjustDataOrder( @RequestParam("m_code") String m_code,
																@RequestParam("row_source") String row_source,
																@RequestParam("row_target") String row_target) {
		RequestResult<Boolean> result = new RequestResult();
		Boolean success = outerListService.adjustDataOrder( m_code, row_source, row_target );
		result.setObj( success );

		return result;
	}

	@ApiOperation(value = "简单调整数据排序", notes = "简单调整数据排序")
	@PostMapping("/simpleAdjustDataOrder")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="selectRowData",value="选中行数据json字符串",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="m_code",value="m_code",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="completeSqlKey",value="completeSqlKey",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="moveTypes",value="移动方式，上移(up)下移(down)",required=true,dataType="String",paramType="query")
	})
	public RequestResult<Map<String, Object>> simpleAdjustDataOrder( @RequestParam("selectRowData") String selectRowData,
														 @RequestParam("m_code") String m_code,
														 @RequestParam("completeSqlKey") String completeSqlKey,
														 @RequestParam("moveTypes") String moveTypes) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		Map<String, Object> map = outerListService.simpleAdjustDataOrder( selectRowData,m_code, completeSqlKey, moveTypes );
		result.setObj( map );

		return result;
	}


	@ApiOperation(value = "批量上移下移", notes = "批量上移下移")
	@PostMapping("/batchDataOrderMove")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="m_code",value="m_code",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="selectRowData",value="选中行数据json字符串",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="changeRowData",value="要交换的数据",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="moveTypes",value="移动方式",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="mainKeyIds",value="你选中行的唯一标识",required=false,dataType="String",paramType="query")
	})
    public RequestResult<String> batchDataOrderMove(
            @RequestParam("m_code") String m_code, @RequestParam("selectRowData") String selectRowData,
            @RequestParam("changeRowData") String changeRowData,
			@RequestParam("moveTypes") String moveTypes) {
        RequestResult<String> result = new RequestResult<>();
		String mainKeyIds = outerListService.batchDataOrderMove(m_code, selectRowData, changeRowData, moveTypes);
		result.setObj( mainKeyIds );
        return result;
    }



	@ApiOperation(value = "批量修改数据值", notes = "批量修改数据值")
	@PostMapping("/batchUpdateData")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="originalData",value="原始数据，格式选中行的json字符串数组",
					required=true,dataType="String",paramType="query",
					defaultValue="[{\"flm_test_main$age\":3,\"flm_test_main$address\":\"北京212\",\"flm_test_main$crt_time\":\"2018-08-26 11:13:02\",\"flm_test_main$name\":\"章三\",\"flm_test_main$sex\":\"1\",\"flm_test_main$hobby\":\"2\",\"flm_test_main$summary\":\"简介\",\"flm_test_main$id\":1},\n" +
							"{\"flm_test_main$age\":2,\"flm_test_main$address\":\"上海2\",\"flm_test_main$crt_time\":\"2018-08-26 11:13:02\",\"flm_test_main$name\":\"李斯\",\"flm_test_main$sex\":\"2\",\"flm_test_main$hobby\":\"1\",\"flm_test_main$summary\":\"简介\",\"flm_test_main$id\":2}]"),
			@ApiImplicitParam(name="changeValueData",value="要改变的值格式是json字符串[{ 表.字段:最终值,is_submit:1 }]",
					required=true,dataType="String",paramType="query",
					defaultValue="[{\"field_name\":\"flm_test_main$summary\",\"flm_test_main$summary\":\"简介批量修改\",\"is_submit\":\"1\"}]")
	})
	public RequestResult<String> batchUpdateData( @RequestParam("m_code") String m_code,
												   @RequestParam("info_code") String info_code,
												   @RequestParam("originalData") String originalData,
												   @RequestParam("changeValueData") String changeValueData) {
		RequestResult<String> result = new RequestResult();
		Boolean success = outerListService.batchUpdateData( m_code,info_code,originalData, changeValueData );
		result.setObj( "操作成功" );

		return result;
	}

	@ApiOperation(value = "更新单元格", notes = "更新单元格")
	@PostMapping("/updateCell")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="key",value="单元格key值",
					required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="val",value="单元格值",
					required=true,dataType="String",paramType="query",
					defaultValue="")
	})
	public RequestResult<String> updateCell( @RequestParam("key") String key, @RequestParam("val") String val) {
		RequestResult<String> result = new RequestResult();
		Boolean success = outerListService.updateCell( key, val);
		result.setObj( "操作成功" );
		return result;
	}


	@ApiOperation("检查菜单下是否有模型存在")
	@PostMapping("/menuCheck")
		@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="Integer",paramType="query")
	@ResponseAddHead
	public RequestResult<Boolean> menuCheck(@RequestParam(value="menu_id") Long menu_id) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			Boolean isSucc=outerListService.menuCheck(menu_id);
			result.setObj(isSucc);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".import()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".import()", e);
		}
		return result;
	}

	@ApiOperation(value = "执行动态sql")
	@PostMapping("/executeDynamicSql")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="dynamicSqlType",value="动态sql类型",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="dynCode",value="动态sql编码",required=true,dataType="String",paramType="query"),
			@ApiImplicitParam(name="reqDatasStr",value="请求数据", required=false, dataType="String",paramType="query")
	})
	public RequestResult<Object> executeDynamicSql(@RequestParam(value="dynamicSqlType") String dynamicSqlType,
												   @RequestParam(value="dynCode") String dynCode, @RequestParam(value="reqDatasStr",required=false) String reqDatasStr) {
		Map<String, Object> reqDatas = CommonUtil.handleReqDatas(reqDatasStr);
		RequestResult<Object> result =  null;
		result =  new RequestResult<>(commonService.executeDynamicSql(dynamicSqlType, dynCode, reqDatas));
		return result;
	}
}
