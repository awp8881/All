package com.qzsoft.lims.ks.controller;


import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.AnalyzeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * @auther: puzhiqiang
 * @date: 2018/5/10 09:33
 * @description:
 */

@Api(value = "数据源", tags = "数据源")
@RestController
@RequestMapping("/analyze")
@Slf4j
public class AnalyzeController {

    @Autowired
    AnalyzeService analyzeService;


    @ApiOperation(value = "刷新数据")
    @GetMapping("/refreshDatas")
    @ResponseAddHead
        public SseEmitter refreshDatas(HttpServletResponse response) {
		return analyzeService.refreshDatas(response);
    }


    @ApiOperation(value = "刷新后字段差异")
    @GetMapping("/refreshDiff")
    @ResponseAddHead
        public RequestResult<String> refreshDiff() {
        RequestResult<String> result = new RequestResult<>();
        result.setObj(analyzeService.refreshDiff());
        return result;
    }
}
