package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 接口请求参数
 * @author zf
 * */
public interface KsSqlPortParaCDao extends BaseDao{
	
	/**通过接口编码获取某一接口参数
	 * @param port_code
	 * @param m_code_type
	 * @return
	 */
	List<Record> getParaListByPortCode(String port_code,String m_code_type);
	
	/**
	 * 删除后插入
	 * */
	Boolean batchUpdate(List<String> portCodeList,List<Record> allPortParasList,Integer isSaveAs,String menu_id);
	
	/**
	 * 接口配置参数修改--引用接口修改
	 * @param para_code
	 * @param para_type
	 * @param para_resou_type
	 * @param para_name
	 * @param para_up
	 * @return
	 */
	Boolean updateByPortConfig(String para_code,String para_type,String para_name,String para_up);
	
	/**
	 * 接口参数删除
	 * @param paraCodeList
	 * @return
	 */
	Boolean deleteByPortConfig(List<String> paraCodeList);

}
