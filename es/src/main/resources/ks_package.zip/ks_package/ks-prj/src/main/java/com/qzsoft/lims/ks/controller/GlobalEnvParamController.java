package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.GlobalEnvParamService;
import com.qzsoft.lims.ks.vo.KsEnvParaVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author zhouyou
 * @Title: GlobalEnvParamController
 * @Description: 自定义环境变量
 * @date 2022/1/14 15:20
 */

@Api(value = "自定义环境变量", tags = "自定义环境变量")
@RestController
@TagResource("自定义环境变量")
@RequestMapping("/globalEnvParam")
@Slf4j
public class GlobalEnvParamController {

    @Autowired
    GlobalEnvParamService globalEnvParamService;

    @ApiOperation(value = "获取自定义环境变量数据")
    @GetMapping("/sysEnvConfigList")
    @ResponseAddHead
        public RequestResult<KsEnvParaVO> getEnvConfigList(@RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
                                                       @RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
        return globalEnvParamService.getEnvConfigList(pageNum, pageSize);
    }

    @ApiOperation(value = "保存自定义环境变量")
    @PostMapping("/saveEnvVar")
    @TagResource("保存自定义环境变量")
    @ResponseAddHead
        public RequestResult<Boolean> saveEnvVar(@RequestBody KsEnvParaVO paraVO) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(globalEnvParamService.saveEnvVar(paraVO));
        return result;
    }

    @ApiOperation(value = "删除")
    @PostMapping("/delete")
    @TagResource("删除")
    @ResponseAddHead
        public RequestResult<Boolean> delete(@RequestParam(value = "id") Long id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(globalEnvParamService.delete(id));
        return result;
    }
}
