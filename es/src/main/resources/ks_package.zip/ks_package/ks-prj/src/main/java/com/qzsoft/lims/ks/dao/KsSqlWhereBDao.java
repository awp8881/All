package com.qzsoft.lims.ks.dao;

import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.SourceConfigVO;

/**
 * where条件用于分组搜索条件参数
 * @author zf
 * */
public interface KsSqlWhereBDao extends BaseDao{
	
	/**
	 * 保存模板的where分组条件
	 * @return
	 */
	Boolean save(SourceConfigVO sourceConfigVO);
}
