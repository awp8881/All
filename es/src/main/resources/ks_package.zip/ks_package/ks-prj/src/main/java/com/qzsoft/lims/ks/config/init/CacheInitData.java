package com.qzsoft.lims.ks.config.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.qzsoft.lims.ks.service.InitService;

@Component
public class CacheInitData implements CommandLineRunner{
	
	@Autowired
	private InitService initService;
	
	@Override
	public void run(String... str) {
		
		initService.deleteCacheConfigDatas();//系统启动清除redis缓存配置
		
	}

}
