package com.qzsoft.lims.ks.dao.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.comp.GroupCond;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.KsSqlButtonSelectBDao;
import com.qzsoft.lims.ks.dao.KsSqlButtonSelectParaBDao;
import com.qzsoft.lims.ks.eum.groupCond.GroupCondRightEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
public class KsSqlButtonSelectBDaoImpl extends BaseDaoImpl implements KsSqlButtonSelectBDao{
	private static final String TABLE_NAME = "ks_sql_button_select_b";

	@Autowired
	private KsSqlButtonSelectParaBDao ksSqlButtonSelectParaBDao;

	@Autowired
	private KsDicBDao ksDicBDao;

	/**
	 * 字典值配置条件
	 */
	@Override
	public List<Record> getButtonSelectList(String down_code) {
		List<Record> buttonSelectList = DbEx.find("select * from "+TABLE_NAME+" where down_code=? order by group_no+0,group_order+0",down_code);
		if (null == buttonSelectList || buttonSelectList.isEmpty()){
			return Lists.newArrayList();
		}
		List<Record> buttonSelectParaList = ksSqlButtonSelectParaBDao.getButtonSelectParaList(down_code);
		DataBaseUtil.buildCondList(buttonSelectList, buttonSelectParaList, "dic_paras_name");
		return buttonSelectList;
	}

	/**
	 * 删除后插入
	 * */
	@JFinalTx
	@Override
	public Boolean batchUpdate(String parent_code, List<Map<String, Object>> allSelectList) {
		boolean isSucc = true;
		if (StringUtils.isBlank(parent_code)){
			return isSucc;
		}
		parent_code = parent_code+"$";
		DbEx.delete("delete from "+TABLE_NAME+" where locate(?,down_code)>0 ",parent_code);
		DbEx.delete("delete from ks_sql_button_select_para_b where locate(?,down_code)>0 ",parent_code);
		if(null == allSelectList || allSelectList.isEmpty()){
			return isSucc;
		}
		List<Map<String, Object>> allParaList = new ArrayList<>();
		for(Map<String,Object> map : allSelectList){
			String dic_paras_name = StringUtil.toString(map.get("dic_paras_name"));
			String sql_paras_name = StringUtil.toString(map.get("sql_paras_name"));
			
			DataBaseUtil.buildSaveDicdSqlPara( TABLE_NAME,  map,  dic_paras_name,  sql_paras_name,  allParaList);
		}
		List<Record> recordList = DataBaseUtil.map2Record(allSelectList);
		isSucc= super.saveList(TABLE_NAME, recordList);
		ksSqlButtonSelectParaBDao.batchUpdate(parent_code, allParaList);
		return isSucc;
	}

	@Override
	public List<List<Map<String, Object>>> getGroupConds(String downCode) {
		String sql = "select * from "+TABLE_NAME+" where down_code=? order by group_no+0,group_order+0";
		List<Record> buttonSelectList = DbEx.find( sql, downCode);
		List<Record> buttonSelectParaList = ksSqlButtonSelectParaBDao.getButtonSelectParaList( downCode );
		List<Record> allDicds = ksDicBDao.getAllList();
		return GroupCond.buildCommonCondList( buttonSelectList, buttonSelectParaList, allDicds, "down_code");
	}

	@JFinalTx
	@Override
	public Boolean saveGroupConds(List<List<Map<String, Object>>> groupConds) {
		boolean isSucc = true;
		if (null == groupConds || groupConds.isEmpty() ){
			return isSucc;
		}
		Map<String, Object> condParaMap = Maps.newHashMap();
		Map<String, Object> condMap = Maps.newHashMap();
		Set<String> relateFields = Sets.newHashSet();
		relateFields.add("down_code");

		Map<String, Object> map = GroupCond.formatGroupConds( groupConds, condMap, condParaMap, relateFields,"");
		List<Map<String, Object>> conds = (List<Map<String, Object>>)map.get("conds");
		List<Map<String, Object>> condParas = (List<Map<String, Object>>)map.get("condParas");
		saveList(TABLE_NAME, DataBaseUtil.map2Record( conds ));
		ksSqlButtonSelectParaBDao.saveGroupCondParas( condParas );
		return isSucc;
	}

	@Override
	public Boolean isDynGlobalDic(String dicCode) {
		String sql = "select id from "+TABLE_NAME+" k1 where exists(select id from ks_sql_button_dic_b k2 where k2.parent_code=? and k2.code=k1.down_code  ) and para_type=?";
		Record record = DbEx.findFirst(sql, dicCode, GroupCondRightEnum.DICSQL.getCode());
		if (null == record){
			return false;
		}
		return true;
	}
}
