package com.qzsoft.lims.ks.config;

import com.jfinal.plugin.activerecord.IContainerFactory;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.constants.CommonConstants;
import org.apache.commons.lang3.StringUtils;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QzContainerFactory implements IContainerFactory {


        public QzContainerFactory() {
        }

        public Map<String, Object> getAttrsMap() {
            return new QzContainerFactory.CaseInsensitiveMap<Object>();
        }

        public Map<String, Object> getColumnsMap() {
            return new QzContainerFactory.CaseInsensitiveMap<Object>();
        }

        public Set<String> getModifyFlagSet() {
            return new QzContainerFactory.CaseInsensitiveSet();
        }

        private static String convert(String key) {
            if( DbEx.isOracle() ){
                String realField = DbEx.getRealFieldByAliasField(key);
                if( StringUtils.isNotBlank(realField) ){
                    if( realField.startsWith("\""+CommonConstants.DYN_SQL_TABLE) ){
                        return realField.replaceAll("\"","").replaceAll("'","");
                    }
                    return realField.replaceAll("\"","").replaceAll("'","").toLowerCase();
                }
                if (isNeedCovLowerCase(key)) {
                    return key.toLowerCase();
                }
            }
            return key;
        }

    /**
     * 判断是否需要全部转为小写
     * @param str
     * @return
     */
    private static Boolean isNeedCovLowerCase( String str ) {
        if( str.contains("\"") ){
            return false;
        }
        //是否包含小写字母，包含全是小写字母不需要转换大写字母
        String regEx = "[a-z]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        return !m.find();
    }


    /*
         * 1：非静态内部类拥有对外部类的所有成员的完全访问权限，包括实例字段和方法，
         *    为实现这一行为，非静态内部类存储着对外部类的实例的一个隐式引用
         * 2：序列化时要求所有的成员变量是Serializable 包括上面谈到的引式引用
         * 3：外部类CaseInsensitiveContainerFactory 需要 implements Serializable 才能被序列化
         * 4：可以使用静态内部类来实现内部类的序列化，而非让外部类实现 implements Serializable
         */
        public static class CaseInsensitiveSet extends TreeSet<String> {

            private static final long serialVersionUID = 6236541338642353211L;

            public CaseInsensitiveSet() {
                super(String.CASE_INSENSITIVE_ORDER);
            }

            public boolean add(String e) {
                return super.add(convert(e));
            }

            public boolean addAll(Collection<? extends String> c) {
                boolean modified = false;
                for (String o : c) {
                    if (super.add(convert(o))) {
                        modified = true;
                    }
                }
                return modified;
            }
        }

        public static class CaseInsensitiveMap<V> extends TreeMap<String, V> {

            private static final long serialVersionUID = 7482853823611007217L;

            public CaseInsensitiveMap() {
                super(String.CASE_INSENSITIVE_ORDER);
            }

            public V put(String key, V value) {
                return super.put(convert(key), value);
            }

            public void putAll(Map<? extends String, ? extends V> map) {
                for (Map.Entry<? extends String, ? extends V> e : map.entrySet()) {
                    super.put(convert(e.getKey()), e.getValue());
                }
            }
        }
    }



