package com.qzsoft.lims.hlyy.entity.vo;

import com.qzsoft.lims.hlyy.entity.HLYYEntity;
import com.qzsoft.lims.hlyy.entity.HLYYGroupEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value="yyky_group",description="分组表")
public class HLYYGroupVo extends HLYYGroupEntity {


}
