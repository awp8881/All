package com.qzsoft.lims.ks.controller.comp;

import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.service.extComp.CompApiService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Api(value = "组件数据接口", tags = "组件数据接口")
@RestController
@RequestMapping(value = "/compApi")
public class CompApiController {

    @Autowired
    CompApiService compApiService;

    @ApiOperation(value = "载入接口响应数据")
        @GetMapping(value ="/{compType}/{useCode}")
    public RequestResult<Map<String, Object>>  loadCompData(@PathVariable(value = "compType") String compType,
                                                            @PathVariable(value = "useCode") String useCode){
        Map<String,Object> compData = compApiService.loadCompData(compType, useCode);
        return new RequestResult<>( compData );
    }


}
