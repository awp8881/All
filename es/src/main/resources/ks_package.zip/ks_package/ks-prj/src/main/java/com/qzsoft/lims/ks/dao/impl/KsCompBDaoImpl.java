package com.qzsoft.lims.ks.dao.impl;

import java.util.List;

import com.qzsoft.lims.ks.entity.KsCompBEntity;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsCompBDao;

/**
 * 组件定义-dao实现
 * @author hqp
 *
 */
@Repository
public class KsCompBDaoImpl extends BaseDaoImpl implements KsCompBDao {

	private static final String TABLE_NAME = "ks_comp_b";
	
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	@Override
	public Boolean save(Record record) {
		return super.save(TABLE_NAME,record);
	}
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	@Override
	public Boolean update(Record record) {
		return super.update(TABLE_NAME,record);
	}
	
	/**
	 * 删除
	 * @return
	 */
	@Override
	public Boolean deleteByDefCode(String defCode) {
		return super.deleteByCustom(TABLE_NAME, "def_code", defCode);
	}
	
	/**
	 * 删除
	 * @param compType 组件类型
	 * @return
	 */
	@Override
	public Boolean deleteByCompType(String compType) {
		return super.deleteByCustom(TABLE_NAME, "comp_type", compType);
	}
	
	/**
	 * 删除
	 * @return
	 */
	@Override
	public Boolean deleteById(Long id) {
		return super.deleteByCustom(TABLE_NAME, "id", id);
	}
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	@Override
	public Record getOne(Long id) {
		return super.selectById(TABLE_NAME,id);
	}
	
	/**
	 * 根据组件类型查询组件定义
	 * @return
	 */
	@Override
	public Record getCompByCompType(String compType) {
		List<Record> recs = DbEx.find("select * from " + TABLE_NAME+" where comp_type = ? ",compType);
		if(recs != null && recs.size() > 0){
			return recs.get(0);
		}else{
			return null;
		}
	}
	
	/**
	 * 根据定义编码查询组件定义
	 * @return
	 */
	@Override
	public Record getCompByDefCode(String defCode) {
		List<Record> recs = DbEx.find("select * from " + TABLE_NAME+" where def_code = ? ",defCode);
		if(recs != null && recs.size() > 0){
			return recs.get(0);
		}else{
			return null;
		}
	}
	
	/**
	 * 查询所有组件定义
	 * @return
	 */
	@Override
	public List<Record> getAll() {
		return DbEx.find("select * from " + TABLE_NAME+" order by cr_dm" );
//		return DbEx.find("select * from " + TABLE_NAME + " order by comp_order");
	}


	/**
	 * 查询当前组件的子节点数量
	 * @return
	 */
	@Override
	public List<Record> getChildCountById(String id) {
		return DbEx.find("select * from " + TABLE_NAME+" where parent_id = ?",id);
	}

	/**
	 * 查询除此Id外的所有组件
	 * @return
	 */
	@Override
	public List<Record> getAllCompsWithOutThisId(String id) {
		return DbEx.find("select * from " + TABLE_NAME+" where id != ?",id);
	}

	/**
	 * 更新组件图片信息
	 * @param ksCompBEntity
	 */
	@Override
	public void updateComPic(KsCompBEntity ksCompBEntity) {
		DbEx.update("update "+ TABLE_NAME +" set copm_img = ? where id = ?",ksCompBEntity.getCopm_img(),ksCompBEntity.getId());
	}
}
