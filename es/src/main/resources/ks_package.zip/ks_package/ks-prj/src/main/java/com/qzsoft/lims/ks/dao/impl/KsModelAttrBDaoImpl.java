package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.dao.KsModelAttrBDao;
import com.qzsoft.lims.ks.eum.AttrTypeEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.vo.SourceConfigVO.AttrVO;

@Repository
public class KsModelAttrBDaoImpl extends BaseDaoImpl implements KsModelAttrBDao{
	private static final String TABLE_NAME = "ks_model_attr_b";

	/**
	 * 删除后插入
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> attrList, String new_m_code, String old_m_code,String menu_id) {
		boolean isSucc = true;
		deleteByCustom(TABLE_NAME, "m_code", old_m_code);
		if (null == attrList || attrList.isEmpty()){
			return isSucc;
		}
		List<Record> recordList = DataBaseUtil.map2Record(attrList);
		int disp_or = 1;
		for(Record record : recordList){
			record.set("m_code", new_m_code).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1").set("disp_or", disp_or)
			.set("menu_id", menu_id).remove("id");
			disp_or++;
		}
		isSucc = saveList(TABLE_NAME, recordList);

		return isSucc;
	}

	/**
	 * 排序列表
	 */
	@Override
	public void getAttrList(AttrVO attrVO, String m_code) {
		StringBuffer sb = new StringBuffer();
		List<Record> recordList = selectListBySql("select trance_code_type,attr_name,attr_type,disp_or from ks_model_attr_b where m_code=? order by disp_or+0", m_code);
		if(null != recordList && !recordList.isEmpty()){
			for(Record record : recordList){
				String attr_name =record.getStr("attr_name");
				String attr_type = record.getStr("attr_type");
				String desc = AttrTypeEnum.getDescByCode(attr_type);
				sb.append(" ").append(attr_name).append("(").append(desc).append(") ");
				if(StringUtils.isBlank( record.getStr( "trance_code_type" ) )){
					record.set( "trance_code_type", "0" );
				}
			}
		}
		attrVO.setAttr_desc(sb.toString());
		attrVO.setAttrList(DataBaseUtil.record2Map(recordList));
	}

	@Override
	public List<Record> getByMcode(String mCode) {
		String sql = "select attr_name,attr_type,trance_code_type from ks_model_attr_b where m_code=? order by disp_or+0";
		return selectListBySql(sql , mCode);
	}
}
