package com.qzsoft.lims.ks.controller.excel;

import cn.hutool.core.io.FileUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.style.column.AbstractColumnWidthStyleStrategy;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.excel.ExcelTemplImportService;
import com.qzsoft.lims.ks.vo.CommonTreeVO;
import com.qzsoft.lims.ks.vo.ExcelBindFieldTreeVO;
import com.qzsoft.lims.ks.vo.excel.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Api(value = "Excel模板导入服务", tags = "Excel模板导入服务")
@RestController
@RequestMapping("/excelTempl")
@Slf4j
public class ExcelTemplImportController {

    @Autowired
    ExcelTemplImportService excelTemplImportService;

    /**
     * excel文件上传  提炼头部返回给前端
     */
    @ApiOperation(value="excel文件上传  提炼摘要返回给前端")
    @RequestMapping(value = "/takeSummary", method = RequestMethod.POST)
    public RequestResult takeSummary(MultipartFile file ) {
        RequestResult result = new RequestResult<>();
        SchemeFileVO summary = excelTemplImportService.takeSummary( file );
        result.setObj( summary );
        return result;
    }

    /**
     * 解析文件生成配置选项
     */
    @ApiOperation(value="解析文件生成配置选项")
    @RequestMapping(value = "/loadImportRowConf", method = RequestMethod.POST)
    public RequestResult loadImportRowConf( String schemeFileVOStr, String importTbsStr, String headFieldsStr ) {
        RequestResult result = new RequestResult<>();
        SchemeFileVO schemeFileVO = JSONUtil.toBean(schemeFileVOStr, SchemeFileVO.class);
        List<InTargetTbVO> importTbs = JSONUtil.toList( JSONUtil.parseArray( importTbsStr ), InTargetTbVO.class);
        List<HeadCellVO> headFields = JSONUtil.toList( JSONUtil.parseArray(headFieldsStr), HeadCellVO.class);
        List<HeadCellVO> importRowConfs = excelTemplImportService.loadImportRowConfs( schemeFileVO, importTbs, headFields );
        result.setList( importRowConfs );
        return result;
    }



    /**
     * 获取导入方案列表
     */
    @ApiOperation(value="获取导入方案列表")
    @GetMapping(value = "/listConfig2Import")
    public RequestResult<SchemeVO> listConfig2Import( ) throws IOException {
        List<SchemeVO> schemeVOs = excelTemplImportService.listConfig2Import( );
        return new RequestResult<>( schemeVOs );
    }

    /**
     * 获取导入方案列表
     */
    @ApiOperation(value="处理方案")
    @PostMapping(value = "/handleConfig2Import")
    @ApiImplicitParams({
            @ApiImplicitParam(name="schemeId",value="schemeId",required=true,dataType="String",paramType="方案标识"),
            @ApiImplicitParam(name="handleType",value="handleType",required=true,dataType="String",
                    paramType="处理类型可选值为 del,off,on")
    })
    public RequestResult handleConfig2Import( Long schemeId, String handleType) throws IOException {

        excelTemplImportService.handleConfig2Import(schemeId, handleType);
        return new RequestResult("操作成功");
    }


    /**
     * 获取导入方案详情
     */
    @ApiOperation(value="获取导入方案详情")
    @GetMapping(value = "/infoConfig2Import")
    public RequestResult infoConfig2Import( Long schemeId ) throws IOException {

        SchemeInfoVO schemeInfoVO = excelTemplImportService.getSchemeInfoVO( schemeId );
        SchemeFileVO schemeFileVO = excelTemplImportService.getSchemeFileVO( schemeId );
        Map<String,Object> infoMap = Maps.newHashMap();
        infoMap.put("schemeInfo", schemeInfoVO);
        infoMap.put("schemeFile", schemeFileVO);
        return new RequestResult<>( infoMap );
    }


    /**
     * 保存导入方案
     */
    @ApiOperation(value="保存导入方案")
    @PostMapping(value = "/saveConfig2Import")
    public RequestResult saveConfig2Import( String schemeInfoVOStr, String schemeFileVOStr ) throws IOException {

        checkConfig2Import(schemeInfoVOStr);
        SchemeInfoVO schemeInfoVO = JSONUtil.toBean(schemeInfoVOStr, SchemeInfoVO.class);
        SchemeFileVO schemeFileVO = JSONUtil.toBean(schemeFileVOStr, SchemeFileVO.class);
        excelTemplImportService.saveConfig2Import( schemeInfoVO,schemeFileVO );
        return infoConfig2Import( schemeInfoVO.getSchemeId() );
    }


    /**
     * 检测导入方案
     */
    @ApiOperation(value="检测导入方案,将必填字段返回")
    @PostMapping(value = "/checkConfig2Import")
    public RequestResult checkConfig2Import( String schemeInfoVOStr  ) throws IOException {
        SchemeInfoVO schemeInfoVO = JSONUtil.toBean(schemeInfoVOStr, SchemeInfoVO.class);
        excelTemplImportService.checkConfig2Import( schemeInfoVO );
        return new RequestResult();
    }


    /**
     * 可绑定的字段列表
     */
    @ApiOperation(value="可绑定的字段列表")
    @PostMapping(value = "/bindableAIFields")
    public RequestResult bindableAIFields( String headFieldStr, String importTbsStr ) throws IOException {
        HeadCellVO headField = JSONUtil.toBean(headFieldStr, HeadCellVO.class,true);
        List<InTargetTbVO> importTbs = JSONUtil.toList( JSONUtil.parseArray( importTbsStr ), InTargetTbVO.class);

        List<ExcelBindFieldTreeVO> commonTreeVO = excelTemplImportService.bindableAIFields(headField, importTbs);
        return new RequestResult( commonTreeVO );
    }


    /**
     * 依赖字段列表
     */
    @ApiOperation(value="可依赖字段列表")
    @PostMapping(value = "/relyableFields")
    public RequestResult relyableFields( String myHeadFieldStr, String headFieldsStr,@RequestParam(required = false) String fromSource ) throws IOException {
        HeadCellVO myHeadField = JSONUtil.toBean(myHeadFieldStr, HeadCellVO.class,true);
        List<HeadCellVO> allheadFields = JSONUtil.toList( JSONUtil.parseArray( headFieldsStr ), HeadCellVO.class);


        List<String> relyableFields = excelTemplImportService.buildRelyableFields(myHeadField, allheadFields,fromSource);
        List relyableFieldMaps = Lists.newArrayList();

        for (String relyableField : relyableFields) {
            Map<String, String> relyableFieldMap = Maps.newHashMap();
            relyableFieldMap.put("label", excelTemplImportService.transLabel( relyableField ));
            relyableFieldMap.put("value", relyableField);
            relyableFieldMaps.add( relyableFieldMap );
        }
        return new RequestResult( relyableFieldMaps );
    }

    /**
     * 导出方案
     */
    @ApiOperation(value="导出方案")
    @PostMapping(value = "/exportScheme")
    public void exportScheme( Long templId, HttpServletResponse response) {
        try {
            String scheme = excelTemplImportService.exportScheme(templId);
            response.setContentType("text/html;charset=utf-8");
            response.getWriter().write(scheme);
        }catch (Exception e) {
            log.error(this.getClass().getSimpleName() + ".exportScheme()", e);
        }
    }

    /**
     * 导出方案
     */
    @ApiOperation(value="导入方案")
    @PostMapping(value = "/importScheme")
    public RequestResult importScheme( @RequestParam("file") MultipartFile file) {
        RequestResult result = new RequestResult<>();
        result.setObj(excelTemplImportService.importScheme(file));
        return result;
    }

    /**
     * 解析数据
     */
    @ApiOperation(value="excel文件上传  解析数据，返回前端websocket连接")
    @RequestMapping(value = "/parseExcelByTemplId", method = RequestMethod.POST)
    public RequestResult parseExcelByTemplId( Long templId,@RequestParam(required = false) String params, MultipartFile file ) {
        RequestResult result = new RequestResult<>();
        Map<String,Object> styleMap = excelTemplImportService.parseExcelByTemplId( templId,params, file );
        result.setObj( styleMap );
        return result;
    }



    /**
     * 下载模板
     */
    @ApiOperation(value="获取导入方案详情")
    @PostMapping(value = "/downLoadTempl")
    public void downLoadTempl(Long schemeId, HttpServletResponse response ) throws Exception {

        SchemeFileVO schemeFileVO = excelTemplImportService.getSchemeFileVO( schemeId );

        String fileName = schemeFileVO.getFileName();
        List<CellVO> headSummary = schemeFileVO.getHeadSummary();
        // 封装标题行
        List<List<String>> head = headSummary.stream().map(cellVO -> Lists.newArrayList( cellVO.getColName() )).collect(Collectors.toList());

        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        try {
            fileName = java.net.URLEncoder.encode(FileUtil.mainName( fileName ), "UTF-8").replaceAll("\\+", "%20");
        } catch (UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
            BusinessException.throwBiz(e.getMessage());
        }
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
        response.setHeader("Content-Disposition", "attachment;fileName=" + fileName+".xlsx");

        EasyExcel.write(response.getOutputStream())
                .registerWriteHandler(new CustemColumnWidthhandler())
                .head(head)
                .autoCloseStream(true)
                .excelType(ExcelTypeEnum.XLSX)
                .sheet( "Sheet1"  )
                .doWrite(Lists.newLinkedList());

    }

    class CustemColumnWidthhandler extends AbstractColumnWidthStyleStrategy {
        private static final int MAX_COLUMN_WIDTH = 255;

        public CustemColumnWidthhandler() {
        }

        @Override
        protected void setColumnWidth(WriteSheetHolder writeSheetHolder, List<CellData> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
            if (isHead) {
                int columnWidth = cell.getStringCellValue().getBytes().length;
                if (columnWidth > MAX_COLUMN_WIDTH) {
                    columnWidth = MAX_COLUMN_WIDTH;
                } else {
                    if (cell.getColumnIndex() == 1) {
                        columnWidth = columnWidth + 10;
                    } else {
                        columnWidth = columnWidth + 3;
                    }

                }
                writeSheetHolder.getSheet().setColumnWidth(cell.getColumnIndex(), columnWidth * 256);
            }
        }
    }
}
