package com.qzsoft.lims.ks.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.map.MapUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.exception.BusinessRollbackException;
import com.qzsoft.common.tools.ThreadLocalUtil;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.logic.KsLogicExecService;
import com.qzsoft.lims.ks.service.logic.bean.LogicReqParamBean;
import com.qzsoft.lims.ks.util.QzAssert;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;

@Api(value = "逻辑编排执行", tags = "逻辑编排执行")
@RestController
@RequestMapping("/logicOpt")
@Slf4j
public class KsLogicOptController {

    @Autowired
    KsLogicExecService ksLogicExecService;


    @ApiOperation(value="逻辑编排统一执行方法",notes="逻辑编排统一执行方法")
    @PostMapping("/doOpt")
    @ResponseAddHead
        public void doOpt(HttpServletResponse servletResponse, LogicReqParamBean logicReqParamBean) {
        QzAssert.isTrue(StringUtils.isNotBlank( logicReqParamBean.getLogic_code() ),BusinessException.buildBiz("逻辑code不能为空"));
        if( logicReqParamBean.getPageSize()==null || logicReqParamBean.getPageSize()==0 ){
            logicReqParamBean.setPageSize( -1 );
        }
        if( logicReqParamBean.getPageNum()==null  ){
            logicReqParamBean.setPageNum( -1 );
        }
        RequestResult requestResult =  ksLogicExecService.handleOptLogic( logicReqParamBean,servletResponse );

    }

    @ApiOperation(value="逻辑编排统一预执行方法",notes="逻辑编排统一预执行方法")
    @PostMapping("/preDoOpt")
        @ApiImplicitParams({
            @ApiImplicitParam(name="logic_code",value="逻辑编码",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="sourceDataJsonStr",value="依赖的逻辑数据",dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult preDoOpt(LogicReqParamBean logicReqParamBean) {
        QzAssert.isTrue(StringUtils.isNotBlank( logicReqParamBean.getLogic_code() ),BusinessException.buildBiz("逻辑code不能为空"));
        if( logicReqParamBean.getPageSize()==null || logicReqParamBean.getPageSize()==0 ){
            logicReqParamBean.setPageSize( -1 );
        }
        if( logicReqParamBean.getPageNum()==null  ){
            logicReqParamBean.setPageNum( -1 );
        }
        try{
            ThreadLocalUtil.set(CommonConstants.LOGIC_PRE_SHOW_KEY, true);
            RequestResult requestResult =  ksLogicExecService.preHandleOptLogic(logicReqParamBean);
            return requestResult;
        }catch (BusinessRollbackException ex){
            return ex.getRequestResult();
        }finally {
            ThreadLocalUtil.remove();
        }
    }


    @ApiOperation(value="逻辑编排统一执行方法",notes="逻辑编排统一执行方法")
    @PostMapping("/doOptByJson")
    @ResponseAddHead
    public void doOptByJson(HttpServletResponse servletResponse,@RequestBody Map<String,Object> logicReqParamForJsonBean) {
        LogicReqParamBean logicReqParamBean = new LogicReqParamBean();
        BeanUtil.fillBeanWithMap( logicReqParamForJsonBean,logicReqParamBean,true );
        Object sourceDataJson = MapUtil.get( logicReqParamForJsonBean, "sourceDataJsonStr",Object.class );
        if( sourceDataJson==null ){
            sourceDataJson = Maps.newHashMap();
        }
        logicReqParamBean.setSourceDataJsonStr( JSONObject.toJSONString( sourceDataJson ) );
        QzAssert.isTrue(StringUtils.isNotBlank( logicReqParamBean.getLogic_code() ),BusinessException.buildBiz("逻辑code不能为空"));
        if( logicReqParamBean.getPageSize()==null || logicReqParamBean.getPageSize()==0 ){
            logicReqParamBean.setPageSize( -1 );
        }
        if( logicReqParamBean.getPageNum()==null  ){
            logicReqParamBean.setPageNum( -1 );
        }
        RequestResult requestResult =  ksLogicExecService.handleOptLogic( logicReqParamBean,servletResponse );

    }


}
