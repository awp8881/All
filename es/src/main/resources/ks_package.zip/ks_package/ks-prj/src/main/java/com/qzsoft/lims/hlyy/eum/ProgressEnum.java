package com.qzsoft.lims.hlyy.eum;

public enum ProgressEnum {

    CYGL("CYGL", "采样管理"),
    XMFAGL("XMFAGL", "项目方案管理"),
    YBSY("YBSY", "样本实验"),
    YBZBGL("YBZBGL", "样本指标管理"),
    YBSF("YBSF", "样本收发"),
    SYJH("SYJH", "实验校核"),
    ;

    private String code;
    private String desc;

    ProgressEnum(String code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
