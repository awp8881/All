/* 
 * Pointcut可以有下列方式来定义或者通过&& || 和!的方式进行组合.  
 * args() 
 * @args() 
 * execution() 
 * this() 
 * target() 
 * @target() 
 * within() 
 * @within() 
 * @annotation 
 * 其中execution 是用的最多的,其格式为: 
 * execution 表达式,其格式为: 
 * execution(modifiers-pattern? ret-type-pattern declaring-type-pattern? name-pattern(param-pattern)throws-pattern?) 
 * returning type pattern,name pattern, and parameters pattern是必须的. 
 * ret-type-pattern:可以为*表示任何返回值,全路径的类名等. 
 * name-pattern:指定方法名,*代表所以,set*,代表以set开头的所有方法. 
 * parameters pattern:指定方法参数(声明的类型),(..)代表所有参数,(*)代表一个参数,(*,String)代表第一个参数为任何值,第二个为String类型. 
 * 举例说明: 
 * 任意公共方法的执行： 
 * execution(public * *(..)) 
 * 任何一个以“set”开始的方法的执行： 
 * execution(* set*(..)) 
 * AccountService 接口的任意方法的执行： 
 * execution(* com.xyz.service.AccountService.*(..)) 
 * 定义在service包里的任意方法的执行： 
 * execution(* com.xyz.service.*.*(..)) 
 * 定义在service包和所有子包里的任意类的任意方法的执行： 
 * execution(* com.xyz.service..*.*(..)) 
 * 定义在pointcutexp包和所有子包里的JoinPointObjP2类的任意方法的执行： 
 * execution(* com.test.spring.aop.pointcutexp..JoinPointObjP2.*(..))") 
 * 最靠近(..)的为方法名,靠近.*(..))的为类名或者接口名,如上例的JoinPointObjP2.*(..)) 
 * pointcutexp包里的任意类. 
 * within(com.test.spring.aop.pointcutexp.*) 
 * pointcutexp包和所有子包里的任意类. 
 * within(com.test.spring.aop.pointcutexp..*) 
 * 实现了Intf接口的所有类,如果Intf不是接口,限定Intf单个类. 
 * this(com.test.spring.aop.pointcutexp.Intf) 
 *  
 * 当一个实现了接口的类被AOP的时候,用getBean方法必须cast为接口类型,不能为该类的类型. 
 *  
 * 带有@Transactional标注的所有类的任意方法. 
 * @within(org.springframework.transaction.annotation.Transactional) 
 * @target(org.springframework.transaction.annotation.Transactional) 
 * 带有@Transactional标注的任意方法. 
 * @annotation(org.springframework.transaction.annotation.Transactional) 
 * @within和@target针对类的注解,@annotation是针对方法的注解 
 *  
 * 参数带有@Transactional标注的方法. 
 * @args(org.springframework.transaction.annotation.Transactional) 
 * 参数为String类型(运行是决定)的方法. 
 * args(String) 
 * Pointcut 可以通过Java注解和XML两种方式配置 
 */  
package com.qzsoft.lims.ks.aspect;  
  
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.impl.BaseDaoImpl;  
  
/**
 * 数据库操作记录表
 *
 */
// @Aspect的意思是面向切面编程，一个类前面加上@Aspect说明这个类使用了这个技术  
@Aspect  
// 这里就是说把这个类交给Spring管理，重新起个名字叫operationLogger，由于不好说这个类属于哪个层面，就用@Component  
@Component(value = "operationLogger")  
public class OperationLogger {  
	
//	@Autowired
//	TableRecordService bzjxTableService;
  
    // @Pointcut是指那些方法需要被执行"AOP",是由"Pointcut Expression"来描述的  
    @Pointcut("execution(* com.qzsoft..dao..*(..)) && !execution(* com.qzsoft..dao..*RecordDaoImpl.*(..)) && !execution(com.jfinal.plugin.activerecord.Record com.qzsoft..dao.*.*(..)) && !execution(com.jfinal.plugin.activerecord.Page com.qzsoft..dao.*.*(..))")  
    public void log() {  
    }  
  
    // @AfterReturning(value="切入点表达式或命名切入点",pointcut="切入点表达式或命名切入点",argNames="参数列表参数名",returning="返回值对应参数名")  
    @AfterReturning(value = "log()", returning = "retVal")  
    public void log(JoinPoint point, Object retVal){  
    	
    	String tableName = "";
    	 Object[] paramValues = point.getArgs();// 获取参数  值
    	 //获取参数名
    	 Signature signature = point.getSignature();  
    	 MethodSignature methodSignature = (MethodSignature) signature;  
    	 String[] paramNames = methodSignature.getParameterNames();  
    	 //封装至JSON对象
    	 JSONObject paramsJson = new JSONObject();
    	 
    	 if(paramNames != null && paramNames.length>0){
    		 for(int i=0;i<paramNames.length;i++){
    			 if(paramNames[i].equals("tableName")){
        			 tableName = paramValues[i].toString();
        		 }
    			 paramsJson.put(paramNames[i], paramValues[i]==null?"":paramValues[i].toString());
    		 }
    	 }
         String methodName = point.getSignature().getName();// 获取方法名  
         Class<?> targetClass = point.getTarget().getClass();// 获取目标对象的类名  
          
         Record record = new Record();
         
         Map<String,Object> columns = new HashMap<String,Object>();
         
         //如果表名为空获取实现类的变量
         if(StringUtils.isBlank(tableName)){
        	 BaseDaoImpl daoImpl = (BaseDaoImpl) point.getTarget();
        	 tableName = daoImpl.tableName;
         }
         
         columns.put("table_name", tableName);
         
         columns.put("oper_id", 1);
         
         columns.put("oper_name", "admin");
         
         columns.put("oper_time", new Date());
         
         columns.put("message", "操作类名:"+targetClass.getName()+",请求方法:"+methodName+",请求参数:"+paramsJson.toJSONString()+"。");
         
//         System.out.println(columns.get("message").toString());
         
         record.setColumns(columns);
         
//         bzjxTableService.save(record);
         
         
    } 
  
}  