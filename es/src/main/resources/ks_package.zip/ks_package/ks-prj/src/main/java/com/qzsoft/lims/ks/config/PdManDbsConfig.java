package com.qzsoft.lims.ks.config;

import cn.hutool.core.io.FileUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.qzsoft.common.activerecord.DataSourceHolder;
import com.qzsoft.lims.ks.constants.PdmanConstant;
import com.qzsoft.lims.ks.service.operationMsg.impl.OperationPingServiceImpl;
import com.qzsoft.lims.ks.util.FileKitUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.util.Map;

@Slf4j
@Configuration
@DependsOn("activeRecordPluginConfig")
@AutoConfigureOrder()
/**
 * 项目启动,初始化pdman数据库连接
 * @author yuanj
 */
public class PdManDbsConfig {
    @Autowired
    ActiveRecordPluginConfig activeRecordPluginConfig;


    @PostConstruct
    public void initPdmanDbs( ){
        try {
            Map<String,Object> maps = DataSourceHolder.getDbProperty();
            //构建数据库连接
            Map<String, Object> dbsMap = Maps.newHashMap();
            Map<String, Object> dbsChilesMap = Maps.newHashMap();
            dbsChilesMap.put("password",maps.get("password"));
            dbsChilesMap.put("driver_class_name",maps.get("driverClassName"));
            dbsChilesMap.put("url",maps.get("url"));
            dbsChilesMap.put("username",maps.get("username"));
            dbsMap.put("name","本地数据库连接");
            dbsMap.put("defaultDB",true);
            dbsMap.put("properties",dbsChilesMap);
            String jsonDbsMap = JSON.toJSONString(dbsMap);
            //读取文件内容
            Map<String, Object> resultMap = JSON.parseObject( JSON.parseObject(PdmanConstant.demoPdmanPath).getString("data") );
            JSONObject projectJSON = (JSONObject) resultMap.get("projectJSON");
            //项目启动后加载进本地连接
            JSONObject profileJson = JSON.parseObject(projectJSON.getString("profile"));
            String dbs = profileJson.getString("dbs");
            JSONArray dbsJsonArray = new JSONArray(dbs);
            //判断是否主库已经加入,防止项目重启后，再次添加主库信息.(前端控制主库无法删除)
            if(dbsJsonArray.isEmpty()) {
                dbsJsonArray.add(JSON.parseObject(jsonDbsMap));
                profileJson.put("dbs", dbsJsonArray);
                //数据覆盖重写------yuanj
                projectJSON.put("profile", profileJson);
                OperationPingServiceImpl.sendTextOut(PdmanConstant.studentPdmanPath, projectJSON.toJSONString());
                cn.hutool.json.JSONObject json1 = JSONUtil.createObj()
                        .put("data", resultMap);
                OperationPingServiceImpl.sendTextOut(PdmanConstant.demoPdmanPath, json1.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
