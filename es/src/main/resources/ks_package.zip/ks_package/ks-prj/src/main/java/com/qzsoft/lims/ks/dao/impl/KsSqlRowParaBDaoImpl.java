package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsSqlRowParaBDao;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 列表行条件参数配置
 *
 */
@Repository
public class KsSqlRowParaBDaoImpl extends BaseDaoImpl implements KsSqlRowParaBDao{
	private static final String TABLE_NAME_B = "ks_sql_row_para_b";
	private static final String TABLE_NAME_C = "ks_sql_row_para_c";

	/**
	 * 按钮激活条件参数配置列表
	 */
	@Override
	public List<Record> getRowParaList(String m_code, String m_code_type) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		String sql = "select * from "+table+" where m_code=? and (info_code is null or info_code ='' ) ";
		List<Record> recordList = DbEx.find(sql, m_code);
		return recordList;
	}
	

	@JFinalTx
	@Override
	public Boolean saveGroupCondParas(List<Map<String, Object>> condParas, Integer isSaveAs, String oldMCode) {

		String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
		String rowParaSql = "delete from "+table+" where m_code=? and (info_code is null or info_code ='' ) ";
		DbEx.delete(rowParaSql, oldMCode);
		if (null == condParas || condParas.isEmpty()){
			return true;
		}
		return saveList(table, DataBaseUtil.map2Record(condParas));
	}
}
