package com.qzsoft.lims.ks.comp;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.eum.groupCond.GroupCondRightEnum;
import com.qzsoft.lims.ks.util.CodesUtil;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * @Author zf
 * @Description  分组条件
 * @Date 2019/8/14
 */
public class GroupCond {

    /**
     *  类似逻辑编排分组条件组装
     * @param condList  条件
     * @param condParaList  条件参数 - 字典
     * @param condCode  条件关联字段
     */
    public static Map<String, Object> buildLogicCondList(List<Record> condList, List<Record> condParaList, List<Record> allDicds, String condCode){
        if(null == condList || condList.isEmpty()){
            return Collections.emptyMap();
        }
        handleCondParas(condList, condParaList, allDicds, condCode);
        List<Record> codeList = DataBaseUtil.removeDuplicate(condList, condCode);
        Map<String, Object> map = Maps.newHashMap();

        for (Iterator<Record> iterator = codeList.iterator(); iterator.hasNext();) {
            Record record = iterator.next();
            String code = record.getStr(condCode);

            List<Record> logicCondList = Lists.newArrayList();
            for (Iterator<Record> iter = condList.iterator(); iter.hasNext();) {
                Record condRecord = iter.next();
                String compareCode = condRecord.getStr(condCode);
                if (code.equals(compareCode)) {
                    logicCondList.add(condRecord);
                }
            }
            List<List<Map<String, Object>>> groupList = groupColumnToList(logicCondList, "group_no" );
            map.put(code, groupList);
        }

        return map;
    }

    /**
     * 共用分组条件组装
     * @param condList
     * @param condParaList
     * @param allDicds
     * @return
     */
    public static List<List<Map<String, Object>>> buildCommonCondList( List<Record> condList, List<Record> condParaList, List<Record> allDicds, String condCode ){
        if(null == condList || condList.isEmpty()){
            return Collections.emptyList();
        }
        handleCondParas(condList, condParaList, allDicds, condCode);
        List<List<Map<String, Object>>> groupConds = groupColumnToList(condList, "group_no" );
        return groupConds;
    }

    public static void handleCondParas(List<Record> condList, List<Record> condParaList, List<Record> allDicds, String condCode ){
        if (null == condList || condList.isEmpty()){
            return;
        }
        for (Iterator<Record> iterator = condList.iterator(); iterator.hasNext(); ) {
            Record condRecord =  iterator.next();
            String dicd = condRecord.getStr("di_cd");
            condRecord.set("di_cd_str", null);
            if (StringUtils.isNotBlank( dicd)){
                String di_cd_str = CommonUtil.getDicdDesc(dicd, allDicds);
                condRecord.set("di_cd_str", di_cd_str);
            }

            if (null == condParaList || condParaList.isEmpty()) {
                condRecord.set("dicParas", Lists.newArrayList());
                condRecord.set("dicParasStr", null);
                continue;
            }
            String condGroCondCode = StringUtil.toString (condRecord.getStr(condCode));
            String paraCode = condRecord.getStr( "para_code" );
            if ( StringUtils.isBlank( paraCode )){// 兼容以前配置
                paraCode = condRecord.getStr( "dic_paras_name" );
            }
            if (StringUtils.isBlank( paraCode )){
                continue;
            }
            List<String> dicParas = Lists.newArrayList();
            for (Iterator<Record> paraIter = condParaList.iterator(); paraIter.hasNext(); ) {
                Record paraRecord =  paraIter.next();
                String condParaGroCondCode = StringUtil.toString ( paraRecord.getStr(condCode) );
                String condParaCode = paraRecord.getStr( "para_code" );
                if ( StringUtils.isBlank( condParaCode )){// 兼容以前配置
                    condParaCode = StringUtil.toString (paraRecord.getStr( "dic_paras_name" ));
                }

                if (condParaGroCondCode.equals(condGroCondCode) && condParaCode.equals(paraCode)) {
                    dicParas.add(  paraRecord.getStr("para_val"));
                }

            }
            String dicParasStr = CommonUtil.getDicdParasDesc( dicd, dicParas, allDicds );
            condRecord.set("dicParas", dicParas);
            condRecord.set("dicParasStr", dicParasStr);
        }

    }

    /**
     * 按某字段分组
     * @param condList
     * @param column 分组字段
     * @return
     */
    public static List<List<Map<String, Object>>> groupColumnToList(List<Record> condList , String column) {

        if (null == condList || condList.isEmpty()) {
            return Lists.newArrayList();
        }
        String key;
        List<Record> list ;
        Map<String, List<Record>> map = Maps.newLinkedHashMap();
        for (Record record : condList) {
            key = record.getStr(column);
            list = map.get(key);
            if (null == list) {
                list = Lists.newArrayList();
                map.put(key, list);
            }
            list.add(record);

        }
        List<List<Map<String, Object>>> resultList = Lists.newArrayList();
        Set<Map.Entry<String, List<Record>>> set = map.entrySet();
        Iterator<Map.Entry<String, List<Record>>> iterator = set.iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, List<Record>> entry = iterator.next();
            resultList.add(DataBaseUtil.record2Map(entry.getValue()));

        }
        return resultList;

    }

    /**
     * 分组条件格式化数据
     * @param groupConds 条件
     * @param condMap 组参数
     * @param condParaMap 组内字典参数
     * @param relateFields 父级编码
     * @param paraCodePre 前缀
     */
    public static Map<String, Object> formatGroupConds( List<List<Map<String, Object>>> groupConds, Map<String, Object> condMap,
                                                        Map<String, Object> condParaMap, Set<String> relateFields, String paraCodePre){
        Map<String, Object> resultMap = Maps.newHashMap();

        if (null == groupConds || groupConds.isEmpty()) {
            resultMap.put("conds", null);
            resultMap.put("condParas", null);
            return resultMap;
        }
        List<Map<String, Object>> allConds = formatTileConds( groupConds );
        condMap.put("cr_dm", DateUtil.getNowDateTimeStr());
        condMap.put("up_ver", "1");
        condParaMap.put("cr_dm", DateUtil.getNowDateTimeStr());
        condParaMap.put("up_ver", "1");

        List<Map<String, Object>> allCondParas = Lists.newArrayList();
        Set<String> busCodes = Sets.newHashSet();
        List<String> dynCodes = Lists.newArrayList();

        if (StringUtils.isNotBlank(paraCodePre)){
            paraCodePre = paraCodePre+"$para_code";
        }else{
            paraCodePre = "para_code";
        }

        for (Iterator<Map<String, Object>> iterator = allConds.iterator(); iterator.hasNext(); ) {
            Map<String, Object> map =  iterator.next();
            map.putAll( condMap );

            List<String> dicParas = (List<String>)map.get("dicParas");
            map.remove("dicParas");
            map.remove("di_cd_str");
            map.remove("dicParasStr");
            map.remove("field_style");
            map.remove("code");

            //动态sql父级数据源
            String paraType = StringUtil.toString(map.get("para_type"));
            if(GroupCondRightEnum.SQL.getCode().equals( paraType)){
                dynCodes.add(StringUtil.toString(map.get("para_val")));
            }
            //新版单独保存此处注释
            map.remove("dynData");

            String paraMCode = StringUtil.toString(map.get("para_m_code"));
            if(StringUtils.isNotBlank(paraMCode)){
                busCodes.add(paraMCode);
            }

            if (null == dicParas || dicParas.isEmpty()){
                continue;
            }
            Map<String, Object> relateMap = Maps.newHashMap();
            if ( null != relateFields && !relateFields.isEmpty()){
                for (String relateField : relateFields) {
                    relateMap.put(relateField, map.get(relateField));
                }
            }
            List<Map<String, Object>> dicParaList = Lists.newArrayList();
            String paraCode = CodesUtil.createCommonCode( paraCodePre );
            map.put("para_code", paraCode);
            for (String str : dicParas) {
                Map<String, Object> dicParaMap = Maps.newHashMap();
                dicParaMap.put("para_code", paraCode);
                dicParaMap.put("para_val", str);
                dicParaMap.putAll( condParaMap );
                dicParaMap.putAll( relateMap );
                dicParaList.add( dicParaMap );
            }
            allCondParas.addAll(dicParaList);
        }
        resultMap.put("conds", allConds);
        resultMap.put("condParas", allCondParas);
        resultMap.put("busCodes", busCodes);
        resultMap.put("dynCodes", dynCodes);
        return resultMap;
    }

    /**
     * 分组条件平铺结构
     * @param groupConds
     * @return
     */
    public static List<Map<String, Object>> formatTileConds( List<List<Map<String, Object>>> groupConds ){
        if (null == groupConds || groupConds.isEmpty()) {
            return Lists.newArrayList();
        }

        List<Map<String, Object>> allConds = Lists.newArrayList();
        for (List<Map<String, Object>> list : groupConds) {
            int count = 1;
            for (Iterator<Map<String, Object>> iterator = list.iterator(); iterator.hasNext(); ) {
                Map<String, Object> map =  iterator.next();
                map.put("group_order", StringUtil.toString( count ));
                count++;
            }
            allConds.addAll(list);
        }
        return allConds;
    }

    /**
     * 无值取空
     * */
    public static String getParaNull( List<Map<String, Object>> selectList ) {
        if ( null == selectList || selectList.isEmpty()){
            return "0";
        }
        Map<String, Object> groupConds = selectList.get(0);
        if ( null == groupConds || groupConds.isEmpty()){
            return "0";
        }
        List<List<Map<String, Object>>> sourceConds = (List<List<Map<String, Object>>>)groupConds.get("sourceConds");
        if ( null == sourceConds || sourceConds.isEmpty()){
            return "0";
        }
        return StringUtil.toString (sourceConds.get(0).get(0).get("is_para_nul"));
    }
}
