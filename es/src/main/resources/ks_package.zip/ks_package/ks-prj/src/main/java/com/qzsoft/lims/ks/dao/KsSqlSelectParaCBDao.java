package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlSelectParaCBDao extends BaseDao{

	/**
	 * 数据源条件参数配置列表
	 * @param whereSql
	 * @param whereList
	 * @param select_code_b
	 * @return
	 */
	List<Record> getSelectParaList(String whereSql,List<String> whereList,String select_code_b);
	
	/**
	 * 删除后批量插入
	 * @return
	 */
	Boolean batchUpdate(List<Map<String, Object>> allParaList, String newSelectCodeB, String menu_id, String mCode, String pCode);

	Boolean saveGroupCondParas(List<Map<String, Object>> condParas);
}
