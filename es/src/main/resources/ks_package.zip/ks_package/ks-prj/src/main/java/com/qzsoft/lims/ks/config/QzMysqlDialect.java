package com.qzsoft.lims.ks.config;

import com.jfinal.plugin.activerecord.dialect.MysqlDialect;

import java.util.regex.Pattern;

/**
 * @version 1.0
 * @Author pujh
 * @Date 2022/3/23 10:10
 * @description
 */
public class QzMysqlDialect extends MysqlDialect {

    protected static class Holder {
        // "order\s+by\s+[^,\s]+(\s+using\s+gbk\s*\))?(\s+asc|\s+desc)?(\s*,\s*[^,\s]+(\s+using\s+gbk\s*\))?(\s+asc|\s+desc)?)*";
        private static final Pattern ORDER_BY_PATTERN = Pattern.compile(
                "order\\s+by\\s+[^,\\s]+(\\s+using\\s+gbk\\s*\\))?(\\s+asc|\\s+desc)?(\\s*,\\s*[^,\\s]+(\\s+using\\s+gbk\\s*\\))?(\\s+asc|\\s+desc)?)*",
                Pattern.CASE_INSENSITIVE | Pattern.MULTILINE);

        private static final Pattern ORDER_BY_CASE = Pattern.compile("\\sorder\\s+by\\s+case\\s+when", Pattern.CASE_INSENSITIVE);
    }

    @Override
    public String replaceOrderBy(String sql) {
        //用druid分析或直接返回
        if (Holder.ORDER_BY_CASE.matcher(sql).find()){
            return sql;
        }
        return Holder.ORDER_BY_PATTERN.matcher(sql).replaceAll("");
    }

}
