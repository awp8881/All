package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.InitService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

/**
 * 页面初始化-控制器
 * @author zf
 *
 */
@Api(value = "前台页面初始化", tags = "前台页面初始化")
@RestController
@RequestMapping("/init")
@Slf4j
public class InitController {

	@Autowired
	private InitService initService;


	@ApiOperation("获取json文件")
	@GetMapping("/getJson")
		@ApiImplicitParam(name="menu_id", value="菜单主键", required=true, dataType="Long", paramType="query")
	@ResponseAddHead
	public void getJson(@RequestParam(value="menu_id") Long menu_id, HttpServletResponse response) {
		response.setContentType("application/octet-stream");
		response.setHeader("Content-disposition","attachment");
		response.setCharacterEncoding("utf-8");
		response.setHeader("Cache-Control","max-age=31104000");//浏览器缓存时间  1年
		initService.checkMenuPermission( menu_id );
		OutputStream out = null;
		try {
			out = response.getOutputStream();
			initService.getJsonFile(out, menu_id);

		} catch (IOException e) {
			String err = "获取菜单:"+menu_id+"json文件失败";
			log.error(err);
			BusinessException.throwBiz(err);
		}finally {
			try {
				if (null != out){
					out.flush();
					out.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage());
			}

		}

	}


	@ApiOperation("所有菜单生效json文件")
	@GetMapping("/initMenuJson")
	@ResponseAddHead
		public SseEmitter initMenuJson(HttpServletResponse response) {

		return initService.initMenuJson(response);
	}

	@ApiOperation("菜单json版本号")
	@GetMapping("/getMenuJsonVer")
		@ApiImplicitParam(name="menu_id", value="菜单主键", required=true, dataType="String", paramType="query")
	@ResponseAddHead
	public RequestResult<String> getMenuJsonVer( @RequestParam(value="menu_id") String menuId) {

		RequestResult<String> result = new RequestResult<>();
		result.setObj( initService.getMenuJsonVer( menuId ) );
		return result;
	}

	@ApiOperation("字典数据")
	@GetMapping("/getDicData")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getDicData() {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList( initService.getDicData() );
		return result;
	}

	@ApiOperation("全局字典数据")
	@GetMapping("/getGlobalDicData")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getGlobalDicData() {

		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList( initService.getGlobalDicData() );
		return result;
	}

}
