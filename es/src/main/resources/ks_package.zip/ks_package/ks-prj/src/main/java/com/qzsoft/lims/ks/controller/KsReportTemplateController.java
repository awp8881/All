package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.ConfigUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.dto.request.ExportDataSqlRequest;
import com.qzsoft.lims.ks.service.KsReportTemplateService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @author pjh
 * @Title: KsReportTemplateController
 * @Description: TODO
 * @date 2018/8/7 14:13
 */
@Api(value = "报表模板接口", tags = "报表模板接口")
@RestController
@RequestMapping("/report")
@Slf4j
public class KsReportTemplateController {

    @Autowired
    KsReportTemplateService ksReportTemplateService;

    @ApiOperation(value="获取列表字段基础信息")
    @GetMapping("/getListFieldsInfo")
        @ApiImplicitParams({
            @ApiImplicitParam(name="m_code",value="列表编码",required=true,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Map<String,Object>> getListFieldsInfo( @RequestParam(value="m_code" ) String m_code) {
        List<Map<String, Object>> listFieldInfos = ksReportTemplateService.getListFieldInfos(m_code);
        RequestResult<Map<String, Object>> result = new RequestResult<Map<String, Object>>();
        result.setList( listFieldInfos );
        return result;
    }


    @ApiOperation(value="创建模板")
    @PostMapping("/createTemp")
        @ApiImplicitParams({
            @ApiImplicitParam(name="m_code",value="模板编码",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="temp_na",value="报表模板名称",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="fields_info",value="字段列表的json字符串",required=true,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Map<String,Object>> createTemp( @RequestParam(value="temp_id",required = false) Long temp_id,
                                                         @RequestParam(value="m_code",required = false) String m_code,
                                                         @RequestParam(value="temp_na") String temp_na,
                                                         @RequestParam(value="is_active",required = false) String is_active,
                                           @RequestParam(value="fields_info") String fields_info) {
        if(StringUtil.toString(temp_na).length()>15){
            throw new BusinessException(11013,"模板名字最长不能超过15个字");
        }

        if( null!=temp_id ){
           return updateTemp( temp_id,temp_na,is_active, fields_info );
        }
        ksReportTemplateService.createTemp( m_code,temp_na, fields_info,is_active );
        RequestResult<Map<String, Object>> result = null;
        try {
            result= new RequestResult<Map<String, Object>>(ksReportTemplateService.findTempListByMCode(m_code));
        }catch (Exception e) {
            result = RequestResult.error(e);
            log.error(this.getClass().getSimpleName() + ".createTemp()", e);
        }
        return result;
    }


    @ApiOperation(value="删除模板")
    @PostMapping("/delTemp")
        @ApiImplicitParams({
            @ApiImplicitParam(name="temp_id",value="报表模板Id",required=true,dataType="Long",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Map<String,Object>> delTemp(@RequestParam(value="temp_id") Long temp_id) {

        Map<String, Object> tempListById = ksReportTemplateService.findTempListById(temp_id);
        ksReportTemplateService.delTemp( temp_id );
        RequestResult<Map<String, Object>> result = null;
        try {
            result= new RequestResult<Map<String, Object>>(ksReportTemplateService.findTempListByMCode( tempListById.get("m_code").toString()));
        }catch (Exception e) {
            result = RequestResult.error(e);
            log.error(this.getClass().getSimpleName() + ".delTemp()", e);
        }
        return result;
    }

    @ApiOperation(value="更新模板")
    @PostMapping("/updateTemp")
        @ApiImplicitParams({
            @ApiImplicitParam(name="temp_id",value="报表模板Id",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="temp_na",value="报表模板名称",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="fields_info",value="字段列表的json字符串",required=true,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Map<String,Object>> updateTemp(@RequestParam(value="temp_id") Long temp_id,
                                                        @RequestParam(value="temp_na") String temp_na,
                                                        @RequestParam(value="is_active",required = false) String is_active,
                                             @RequestParam(value="fields_info") String fields_info) {

        ksReportTemplateService.updateTemp( temp_id,temp_na, fields_info,is_active );

        RequestResult<Map<String, Object>> result = null;
        try {
            Map<String, Object> tempListById = ksReportTemplateService.findTempListById(temp_id);
            result= new RequestResult<Map<String, Object>>(ksReportTemplateService.findTempListByMCode( tempListById.get("m_code").toString()) );
        }catch (Exception e) {
            result = RequestResult.error(e);
            log.error(this.getClass().getSimpleName() + ".updateTemp()", e);
        }
        return result;
    }

    @ApiOperation(value="模板列表")
    @PostMapping("/findTempList")
    @ResponseAddHead
        @ApiImplicitParams({
            @ApiImplicitParam(name="m_code",value="模板编码",required=true,dataType="String",paramType="query")
    })
    public RequestResult<Map<String,Object>> findTempList(  @RequestParam(value="m_code") String m_code ) {

        RequestResult<Map<String, Object>> result = null;
        try {
            result= new RequestResult<Map<String, Object>>(ksReportTemplateService.findTempListByMCode( m_code ));
        }catch (Exception e) {
            result = RequestResult.error(e);
            log.error(this.getClass().getSimpleName() + ".findTempList()", e);
        }
        return result;

    }

    @ApiOperation(value="导出模板")
    @PostMapping("/exportTemp")
    @ResponseAddHead
        @ApiImplicitParams({
            @ApiImplicitParam(name="temp_id",value="报表模板Id",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="global_dic_list",value="全局字段",required=true,dataType="String",paramType="query"),
            @ApiImplicitParam(name="group",value="查询条件",required=true,dataType="String",paramType="query"),
    })
    public RequestResult<Map<String,Object>> exportTemp( ExportDataSqlRequest exportDataSqlRequest, HttpServletResponse response ) {

        RequestResult<Map<String, Object>> result = null;
        try {
            result= new RequestResult<Map<String, Object>>(ksReportTemplateService.exportTemp( exportDataSqlRequest, response ));
        }catch (Exception e) {
            result = RequestResult.error(e);
            log.error(this.getClass().getSimpleName() + ".exportTemp()", e);
        }
        return result;

    }

}
