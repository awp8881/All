package com.qzsoft.lims.ks.config;

import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.druid.DruidPlugin;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.mvc.configuration.properties.DruidDataSourceProperties;
import com.qzsoft.lims.ks.interceptor.PrintSqlParamInterceptor;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * @Author zf
 * @Description 同步数据源配置
 * @Date 2019/7/3
 */
@Configuration
public class DbSynSourceConfig {

    private DruidPlugin druidPlugin;

    private ActiveRecordPlugin activeRecordPlugin;

    public  void init(String configName, String url, String userName, String passWord, String driverClass){

        this.druidPlugin = createDruidPlugin(url, userName, passWord, driverClass);
        this.activeRecordPlugin = new ActiveRecordPlugin(configName, druidPlugin);
    }

    public  void start(){
        try{
            this.druidPlugin.start();
            this.activeRecordPlugin.start();

        }catch (Exception e){
            BusinessException.throwBiz("数据库连接失败："+e.getMessage());
        }
    }

    public void stop(){
        this.druidPlugin.stop();
        this.activeRecordPlugin.stop();
    }

    private DruidPlugin createDruidPlugin(String url, String userName, String passWord, String driverClass) {
        DruidPlugin druidPlugin = new DruidPlugin( url,  userName,  passWord,  driverClass);
        return druidPlugin;
    }
}
