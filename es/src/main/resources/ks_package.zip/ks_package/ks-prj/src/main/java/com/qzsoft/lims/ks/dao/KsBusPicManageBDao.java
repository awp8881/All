package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 照片管理-dao接口
 * @author hqp
 *
 */
public interface KsBusPicManageBDao extends BaseDao {
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	Boolean save(Record record);
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	
	/**
	 * 删除
	 * @param id 主键
	 * @return
	 */
	Boolean delete(Long id);
	
	/**
	 * 根据业务prn删除多条记录
	 * @param prn 业务prn
	 * @return
	 */
	Boolean deleteByPrn(String prn);
	
	
	/**
	 * 根据业务类型查询
	 * @return
	 */
	List<Record> getListByBusType(String busType);
	
	/**
	 * 根据业务prn查询
	 * @return
	 */
	List<Record> getListByPrn(String prn, String showType);
	
	/**
	 * 根据业务prn查询非敏感文件（bus_type不是“客户文件”）
	 * @return
	 */
	List<Record> getListByPrnNotSens(String prn, String showType);
	
	/**
	 * 根据业务prn及其他参数模糊查询
	 * @return
	 */
	List<Record> getListByPrnSearch(String prn,String search);
	
	/**
	 * 根据业务prn及其他参数模糊查询非敏感文件（bus_type不是“客户文件”）
	 * @return
	 */
	List<Record> getListByPrnSearchNotSens(String prn,String search);
	
	/**
	 * 根据文件名称、业务编号、业务类型模糊查询
	 * @return
	 */
	List<Record> getListBySearch(String search);
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	Record getOne(Long id);
	
	/**
	 * 根据文件全局唯一标识查询详情
	 * @param filePrn 文件全局唯一标识
	 * @return
	 */
	Record getOneByFilePrn(String filePrn);
}
