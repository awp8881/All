package com.qzsoft.lims.hlyy.desUtil;

import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public final class DESCryption
{
    private static String code = "UTF-8";

    public static String encrypt(String originalContent, String key)
    {
        if ((isNullOrEmpty(originalContent)) || (isNullOrEmpty(key))) {
            return null;
        }
        try
        {
            byte[] byteContent = encrypt(originalContent.getBytes(code), key.getBytes(code));
            return byte2hex(byteContent);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    public static String decrypt(String ciphertext, String key)
    {
        if ((isNullOrEmpty(ciphertext)) || (isNullOrEmpty(key))) {
            return null;
        }
        try
        {
            byte[] bufCiphertext = hex2byte(ciphertext);
            byte[] contentByte = decrypt(bufCiphertext, key.getBytes(code));
            return new String(contentByte, code);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    private static byte[] encrypt(byte[] oringianlContent, byte[] key)
            throws Exception
    {
        SecureRandom sercureRandom = new SecureRandom();

        DESKeySpec desKeySpec = new DESKeySpec(key);

        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey secretKey = keyFactory.generateSecret(desKeySpec);

        Cipher cipher = Cipher.getInstance("DES");

        cipher.init(1, secretKey, sercureRandom);

        return cipher.doFinal(oringianlContent);
    }

    private static byte[] decrypt(byte[] ciphertextByte, byte[] key)
            throws Exception
    {
        SecureRandom sercureRandom = new SecureRandom();

        DESKeySpec desKeySpec = new DESKeySpec(key);

        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey secretKey = keyFactory.generateSecret(desKeySpec);

        Cipher cipher = Cipher.getInstance("DES");

        cipher.init(2, secretKey, sercureRandom);

        return cipher.doFinal(ciphertextByte);
    }

    private static byte[] hex2byte(String s)
    {
        byte[] result = new byte[s.length() / 2];
        String hs = "";
        int b = 0;
        for (int i = 0; i < s.length(); i += 2)
        {
            hs = s.substring(i, i + 2);
            b = Integer.parseInt(hs, 16);
            result[(i / 2)] = ((byte)b);
        }
        return result;
    }

    private static String byte2hex(byte[] b)
    {
        StringBuilder sb = new StringBuilder();
        String stmp = "";
        for (int n = 0; n < b.length; n++)
        {
            stmp = Integer.toHexString(b[n] & 0xFF);
            if (stmp.length() == 1) {
                sb.append('0');
            }
            sb.append(stmp);
        }
        return sb.toString();
    }

    private static boolean isNullOrEmpty(String str)
    {
        return (str == null) || (str.trim().length() == 0);
    }
}
