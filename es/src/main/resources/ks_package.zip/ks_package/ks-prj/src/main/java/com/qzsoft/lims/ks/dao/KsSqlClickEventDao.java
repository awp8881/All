package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 列表行事件动作
 * @author zf
 *
 */
public interface KsSqlClickEventDao extends BaseDao{
	
	/**
	 * 通过模板编码获取行点击动作
	 * @param m_code
	 * @return
	 */
	Record getClickEventByMcode(String m_code);
	
	/**
	 * 大列表保存点击事件
	 * @param m_code
	 * @param click_code
	 * @param old_m_code
	 * @return
	 */
	Boolean saveByOuter(String m_code,String click_code,String old_m_code);

}
