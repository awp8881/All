package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.info.FormNoteService;
import com.qzsoft.lims.ks.service.page.PageCompProcessor;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @Author zf
 * @Description 前台页面组件
 * @Date 2019/10/12
 */
@Api(value = "前台页面组件", tags = "前台页面组件")
@RestController
@RequestMapping("/pageComp")
@Slf4j
public class PageCompController {

    @Autowired
    private PageCompProcessor pageCompProcessor;

    @Autowired
    private FormNoteService formNoteService;


    @ApiOperation("搜索组件返显")
    @PostMapping("/getSearchCompShow")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getSearchCompShow( @RequestParam("field_value") String fieldValue,
                                                                 @RequestParam("showFields") String showFields,
                                                                 @RequestParam("field_name_set") String fieldNameSet) {

        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( pageCompProcessor.getSearchCompShow( fieldValue, showFields, fieldNameSet));
        return result;
    }


    @ApiOperation("接口转发")
    @PostMapping("/portForward")
    @ResponseAddHead
        public Object portForward( @RequestParam("reqDataStr") String reqDataStr,
                                              @RequestParam("portCode") String portCode) {
        return pageCompProcessor.portForward( reqDataStr, portCode);
    }

    @ApiOperation("表单日志记录")
    @PostMapping("/getFormNoteData")
    @ResponseAddHead
        public RequestResult<String> getFormNoteData( @RequestParam("infoCode") String infoCode,
                                              @RequestParam("fieldName") String fieldName) {

        RequestResult<String> result = new RequestResult<>();
        result.setList(formNoteService.getFormNoteData( infoCode, fieldName));
        return result;
    }

    @ApiOperation("删除表单日志记录")
    @PostMapping("/deleteFormNoteData")
    @ResponseAddHead
        public RequestResult<Boolean> deleteFormNoteData( @RequestParam("infoCode") String infoCode,
                                                      @RequestParam("fieldName") String fieldName,
                                                      @RequestParam("noteStr") String noteStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(formNoteService.deleteFormNoteData( infoCode, fieldName, noteStr));
        return result;
    }

}
