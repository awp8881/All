package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.logic.KsLogicConfService;
import com.qzsoft.lims.ks.service.logic.KsLogicParserService;
import com.qzsoft.lims.ks.service.logic.LogicReqService;
import com.qzsoft.lims.ks.vo.logic.KsLogicConfigVO;
import com.qzsoft.lims.ks.vo.logic.KsModelLogicMenuBVO;
import com.qzsoft.lims.ks.vo.logic.LogicBasTmpVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * 逻辑编排配置-控制器
 */
@Api(value = "逻辑编排配置", tags = "逻辑编排配置")
@RestController
@TagResource("逻辑编排配置")
@RequestMapping("/logicConf")
@Slf4j
public class KsLogicConfController {
	
	@Autowired 
	private KsLogicConfService ksLogicConfService;

	@Autowired
	private KsLogicParserService ksLogicParserService;

	@Autowired
    private LogicReqService logicReqService;

	
    @ApiOperation(value = "菜单逻辑树")
    @GetMapping("/getMenuLogicTree")
    @ApiImplicitParam(name="menu_id",value="菜单主键",required=false,dataType="String",paramType="query")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getMenuLogicTree( @RequestParam(value="menu_id", required=false) String menuId,
                                                               @RequestParam(value="logic_type", required=false) String logicType) {
        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = ksLogicConfService.getMenuLogicTree(  menuId, logicType);
        result.setList( maps );
        return result;
    }
    
    @ApiOperation(value = "新增逻辑")
    @PostMapping("/addLogic")
    @ResponseAddHead
    @TagResource("新增逻辑")
        public RequestResult<Boolean> addLogic( KsModelLogicMenuBVO ksModelLogicMenuBVO ) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean saveYn = ksLogicConfService.addLogic( ksModelLogicMenuBVO);
    	result.setObj(saveYn);
		return result;
    }
    
    @ApiOperation(value = "修改逻辑")
    @PostMapping("/updateLogic")
    @ResponseAddHead
    @TagResource("修改逻辑")
        public RequestResult<Boolean> updateLogic( KsModelLogicMenuBVO ksModelLogicMenuBVO ) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean updateYn = ksLogicConfService.updateLogic( ksModelLogicMenuBVO);
    	result.setObj(updateYn);
		return result;
    }
    
    @ApiOperation(value = "单一详情")
    @GetMapping("/getLogicOne")
    @ResponseAddHead
        @ApiImplicitParam(name="id",value="逻辑主键",required=true,dataType="String",paramType="query")
    public RequestResult<Map<String,Object>> getLogicOne( @RequestParam(value="id") String logicId ) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        Map<String, Object> map = ksLogicConfService.getLogicOne( logicId);
        result.setObj( map );
        return result;
    }
    
    @ApiOperation(value = "逻辑删除")
    @PostMapping("/deleteLogic")
    @ResponseAddHead
    @TagResource("逻辑删除")
        @ApiImplicitParam(name="id",value="逻辑主键",required=true,dataType="String",paramType="query")
    public RequestResult<Boolean> deleteLogic( @RequestParam(value="id") String logicId ) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean deleteYn = ksLogicConfService.deleteLogic( logicId );
    	result.setObj(deleteYn);
		return result;
    }
    
    @ApiOperation(value = "逻辑规则树")
    @GetMapping("/getLogicRuleTree")
    @ResponseAddHead
        @ApiImplicitParam(name="logic_code",value="逻辑编码",required=true,dataType="String",paramType="query")
    public RequestResult<Map<String,Object>> getLogicRuleTree( @RequestParam(value="logic_code") String logicCode ) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = ksLogicConfService.getLogicRuleTree( logicCode);
        result.setList( maps );
        return result;
    }
    
    @ApiOperation(value = "逻辑详情")
    @GetMapping("/getLogicDetails")
    @ResponseAddHead
        @ApiImplicitParam(name="logic_code",value="逻辑编码",required=true,dataType="String",paramType="query")
    
    public RequestResult<Map<String,Object>> getLogicDetails( @RequestParam(value="logic_code") String logicCode) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        Map<String, Object> map = ksLogicConfService.getLogicDetails( logicCode );
        result.setObj( map );
        return result;
    }
    
    @ApiOperation(value = "方法函数")
    @GetMapping("/getLogicFn")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getLogicFn() {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = ksLogicConfService.getLogicFn();
        result.setList( maps );
        return result;
    }
    
    @ApiOperation(value = "逻辑数据对象树结构")
    @GetMapping("/getLogicDataTree")
    @ResponseAddHead
        @ApiImplicitParams({
    	@ApiImplicitParam(name="logic_code",value="逻辑编码",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="menu_id",value="菜单主键",required=false,dataType="String",paramType="query")
    })
    public RequestResult<Map<String,Object>> getLogicDataTree( @RequestParam(value="menu_id",required=false) String menuId,
    		@RequestParam(value="logic_code") String logicCode) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = ksLogicConfService.getLogicDataTree( menuId, logicCode);
        result.setList( maps );
        return result;
    }
    
    @ApiOperation(value = "保存逻辑详情")
    @PostMapping("/saveLogicDetails")
    @TagResource("保存逻辑详情")
    @ResponseAddHead
        public RequestResult<Boolean> saveLogicDetails( KsLogicConfigVO ksLogicConfigVO ) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean saveYn = ksLogicConfService.saveLogicDetails( ksLogicConfigVO);
    	result.setObj(saveYn);
		return result;
    }
    
    @ApiOperation(value = "逻辑涉及的唯一标识")
    @GetMapping("/getMethCode")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getMethCode(@RequestParam(value="menu_id", required = false) String menuId) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        Map<String,Object> map = ksLogicConfService.getMethCode( menuId );
        result.setObj( map );
        return result;
    }
    
    @ApiOperation(value = "保存基础数据和临时数据")
    @PostMapping("/saveBasAndTmp")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> saveBasAndTmp( LogicBasTmpVO logicBasTmpVO) {
    	RequestResult<Map<String, Object>> result = new RequestResult<>();
    	Map<String, Object> map = ksLogicConfService.saveBasAndTmp(logicBasTmpVO );
    	result.setObj(map);
		return result;
    }
    
    @ApiOperation(value = "方法函数参数")
    @GetMapping("/getLogicFnPara")
    @ResponseAddHead
        @ApiImplicitParam(name="methodName",value="方法名称",required=true,dataType="String",paramType="query")
    public RequestResult<Map<String,Object>> getLogicFnPara( @RequestParam(value="methodName") String methodName ) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        Map<String,Object> maps = ksLogicConfService.getLogicFnPara(  methodName);
        result.setObj( maps );
        return result;
    }

    @ApiOperation(value = "三层菜单逻辑树")
    @GetMapping("/getThreeMenuLogicTree")
    @ApiImplicitParam(name="menu_id",value="菜单主键",required=false,dataType="String",paramType="query")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getThreeMenuLogicTree( @RequestParam(value="menu_id", required=false) String menuId) {
        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = ksLogicConfService.getMenuLogicTreeOfThree(menuId);
        result.setList( maps );
        return result;
    }

    @ApiOperation(value = "四层菜单逻辑树")
    @GetMapping("/getFourMenuLogicTree")
    @ApiImplicitParam(name="menu_id",value="菜单主键",required=false,dataType="String",paramType="query")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getFourMenuLogicTree( @RequestParam(value="menu_id", required=false) String menuId) {
        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = ksLogicConfService.getMenuLogicTreeOfFour(menuId);
        result.setList( maps );
        return result;
    }


    @ApiOperation(value = "获取逻辑编排友好语言")
    @GetMapping("/getFriendlyLanguage")
    @ApiImplicitParam(name="logic_code",value="逻辑编排code",required=false,dataType="String",paramType="query")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getFriendlyLanguage( @RequestParam(value="logic_code") String logic_code) {
        RequestResult<Map<String,Object>> result = new RequestResult<>();
        Map<String, Object> friendlyLanguage = ksLogicParserService.getFriendlyLanguage(logic_code);
        result.setObj( friendlyLanguage );
        return result;
    }

    @ApiOperation(value = "保存逻辑编排请求参数")
    @PostMapping("/saveReqPara")
    @ResponseAddHead
        public RequestResult<String> saveReqPara(@RequestParam(value="logic_code") String logicCode,
                                             @RequestParam(value="reqParaType") String reqParaType,
                                             @RequestParam(value="reqPara") String reqPara) {
        RequestResult<String> result = new RequestResult<>();
        result.setList( logicReqService.saveReqPara(logicCode, reqParaType, reqPara));
        return result;
    }

    @ApiOperation(value = "共用逻辑数据对象树")
    @GetMapping("/getCommonDataTree")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getCommonDataTree(@RequestParam(value="logic_code") String logicCode) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = ksLogicConfService.getCommonDataTree( logicCode);
        result.setList( maps );
        return result;
    }

    @ApiOperation(value = "删除逻辑编排请求参数")
    @PostMapping("/deleteReqPara")
    @ResponseAddHead
        public RequestResult<Boolean> deleteReqPara(@RequestParam(value="logic_code") String logicCode,
                                                @RequestParam(value="reqParaType") String reqParaType,
                                                @RequestParam(value="reqPara") String reqPara) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( logicReqService.deleteReqPara(logicCode, reqParaType, reqPara));
        return result;
    }

    @ApiOperation(value = "逻辑逻辑请求参数")
    @GetMapping("/getReqPara")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getReqPara(@RequestParam(value="logic_code") String logicCode) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> maps = logicReqService.getReqPara( logicCode);
        result.setList( maps );
        return result;
    }

    @ApiOperation(value = "刷新字段")
    @PostMapping("/refreshField")
    @ResponseAddHead
        public RequestResult<Boolean> refreshField(@RequestParam(value="logic_code") String logicCode) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( logicReqService.refreshField(logicCode));
        return result;
    }

    @ApiOperation(value = "公共逻辑接口报文导出")
    @PostMapping("/exportLogicReqFile")
    @ResponseAddHead
        public void exportLogicReqFile(@RequestParam(value="logicCode") String logicCode, HttpServletResponse response) {
        try {
            String logicReqData = ksLogicConfService.exportLogicReqFile(logicCode);
            response.setContentType("text/html;charset=utf-8");
            response.getWriter().write(logicReqData);

        }catch (Exception e) {
            log.error(this.getClass().getSimpleName() + ".exportLogicReqFile()", e);
        }
    }

    @ApiOperation(value = "导出逻辑编排数据")
    @PostMapping("/exportLogicConf")
    @ResponseAddHead
        public void exportLogicConf(@RequestParam(value="logicCode") String logicCode, HttpServletResponse response) {
        try {
            String logicReqData = ksLogicConfService.exportLogicConf(logicCode);
            response.setContentType("text/html;charset=utf-8");
            response.getWriter().write(logicReqData);

        }catch (Exception e) {
            log.error(this.getClass().getSimpleName() + ".exportLogicConf()", e);
        }
    }

    @ApiOperation(value = "导入逻辑编排数据")
    @PostMapping("/inportLogicConf")
    @ResponseAddHead
        public RequestResult<Boolean> inportLogicConf(@RequestParam("file") MultipartFile file, @RequestParam(value="pLogicCode", required = false) String pLogicCode) {
        RequestResult<Boolean> result = new RequestResult<>();
        boolean importYn = ksLogicConfService.inportLogicConf( file, pLogicCode );
        result.setObj(importYn);
        return result;
    }

    @ApiOperation(value = "获取公共逻辑目录")
    @GetMapping("/getDirList")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getDirList() {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(ksLogicConfService.getDirList());
        return result;
    }
}
