package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 菜单配置-dao接口
 * @author zf
 *
 */
public interface KsMenuCDao extends BaseDao{
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	Boolean save(Record record);

	/**
	 * 修改
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	
	/**
	 * 删除
	 * @param id 主键
	 * @return
	 */
	Boolean delete(Long id);
	
	/**
	 * 菜单是否存在
	 * @param resNa 菜单名称
	 * @param menuId 菜单id
	 * @return
	 */
	List<Record> isExists(String resNa,Long menuId);
	
	/**
	 * 树列表查询
	 * @param res_na
	 * @return
	 */
	List<Record> getTreeList(String res_na,Boolean isAnalyze);
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	Record getOne(Long id);
	
	/**
	 * 通过父id获取
	 * @param faResNo
	 * @return
	 */
	List<Record> getByFaResNo(Long faResNo);

    Record selectMaxOrder();
    
    /**
     * 菜单是否已有数据源
     * @param menuId
     * @return
     */
    Boolean isExistsModel(String menuId);
    
    /**
     * 页面使用菜单
     * @return
     */
    List<Record> getUseList(String menuId);

	/**
	 * 逻辑编排界面菜单
	 * @return
	 */
	List<Record> getNewUseList(String menuId);

	/**
	 * 一二级树列表查询
	 * @return
	 */
	List<Record> getTreeListOfRemove();

	List<Record> getParents( String menuId );
}
