package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlButtonSelectParaBDao extends BaseDao{

	/**
	 * 字典值配置条件参数
	 * @param down_code
	 * @return
	 */
	List<Record> getButtonSelectParaList(String down_code);
	
	/**
	 * 删除后插入
	 * @param parent_code
	 * @param allParaList
	 * @return
	 */
	Boolean batchUpdate(String parent_code,List<Map<String, Object>> allParaList);

	Boolean saveGroupCondParas(List<Map<String, Object>> condParas);
}
