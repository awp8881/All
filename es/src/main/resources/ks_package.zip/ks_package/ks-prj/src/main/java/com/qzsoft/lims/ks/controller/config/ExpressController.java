package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.expression.ExpressConf;
import com.qzsoft.lims.ks.expression.ExpressParse;
import com.qzsoft.lims.ks.util.CommonUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 表达式引擎
 * @author zf
 */
@Api(value = "表达式引擎", tags = "表达式引擎")
@RestController
@TagResource("表达式引擎")
@RequestMapping("/express")
@Slf4j
public class ExpressController {

    @Autowired
    private ExpressConf expressionConf;

    @Autowired
    private ExpressParse expressParse;

    @ApiOperation(value = "表达式函数")
    @GetMapping("/getFunctions")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getFunctions(){
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(expressionConf.getFunctions());
        return result;
    }

    @ApiOperation(value = "表达式脚本及参数")
    @GetMapping("/getExpScriptAndPara")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getExpScriptAndPara(@RequestParam(value = "expCode") String expCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj(expressionConf.getExpScriptAndPara( expCode ));
        return result;
    }

    @ApiOperation(value = "表达式保存")
    @PostMapping("/saveExp")
    @TagResource("表达式保存")
    @ResponseAddHead
        public RequestResult<String> saveExp(@RequestParam(value = "expData") String expDataStr,
                                         @RequestParam(value = "quoteId", required = false) String quoteId,
                                         @RequestParam(value = "quoteType") String quoteType) {
        RequestResult<String> result = new RequestResult<>();
        result.setObj(expressionConf.saveExp( expDataStr, quoteId, quoteType ));
        return result;
    }

    @ApiOperation(value = "检查合法性")
    @PostMapping("/verifyExp")
    @ResponseAddHead
        public RequestResult<Object> verifyExp(@RequestParam(value = "expData") String expDataStr) {
        RequestResult<Object> result = new RequestResult<>();
        result.setObj( expressParse.verifyExp( expDataStr));
        return result;
    }

    @ApiOperation(value = "前台表达式解析")
    @PostMapping("/parseExp")
    @ResponseAddHead
        public RequestResult<Object> parseExp(@RequestParam(value = "expCode") String expCode,
                                          @RequestParam(value = "reqDatasStr", required = false) String reqDatasStr) {
        RequestResult<Object> result = new RequestResult<>();
        result.setObj( expressParse.parseExp( expCode, CommonUtil.handleReqDatas(reqDatasStr)));
        return result;
    }

    @ApiOperation(value = "删除表达式")
    @PostMapping("/delete")
    @TagResource("删除表达式")
    @ResponseAddHead
        public RequestResult<Object> delete(@RequestParam(value = "expCode") String expCode) {
        RequestResult<Object> result = new RequestResult<>();
        result.setObj( expressionConf.delete( expCode));
        return result;
    }
}
