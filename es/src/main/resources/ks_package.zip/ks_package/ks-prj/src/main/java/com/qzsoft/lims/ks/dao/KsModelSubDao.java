package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsModelSubDao extends BaseDao {

    /**
     * 保存列表引用
     * @param pCode
     * @param mCode
     * @param subMcode
     * @param menuId
     * @return
     */
    Boolean saveModelSub(String pCode, String mCode, String subMcode, String menuId);

    /**
     * 是否已存在该列表的引用
     * @param subMcode
     * @return
     */
    Boolean isExistsModelSub(String subMcode);

    String handleModelSub( String pCode, String mCode, String menuId);

    Record getBySubMcode( String subMcode );
}
