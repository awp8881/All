package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/** 
 * 
 * 创建时间:2018-07-03 13:42:06 
 */ 
public interface KsConfVerGDao  extends BaseDao {

	
	Boolean saveVerG(Record record);

}
