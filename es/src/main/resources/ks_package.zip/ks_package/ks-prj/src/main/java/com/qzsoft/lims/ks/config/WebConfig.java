package com.qzsoft.lims.ks.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {

    @Autowired
    @Qualifier("globalParamInterceptor")
    HandlerInterceptor handlerInterceptor;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
      registry.addMapping("/**")
        .allowedOrigins("*")
        .allowedMethods("GET","POST").allowCredentials(true);
    }
    
    @Override
	public void addInterceptors(InterceptorRegistry registry) {
		//注册自定义拦截器，添加拦截路径和排除拦截路径
        registry.addInterceptor(handlerInterceptor).addPathPatterns("/**").excludePathPatterns("/login","/error","/swagger-ui.html","/v2/api-docs?group=接口文档","/swagger-resources/**","/equipmentB/getOneById");
		super.addInterceptors(registry);
	}
}