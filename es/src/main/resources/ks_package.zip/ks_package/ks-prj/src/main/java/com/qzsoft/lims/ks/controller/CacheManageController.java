package com.qzsoft.lims.ks.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.configdata.BizDataService;
import com.qzsoft.lims.ks.service.meta.BizTableOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 动态sql-控制器
 */
@Api(value = "缓存管理控制接口", tags = "缓存管理控制接口")
@RestController
@RequestMapping("/cacheManage")
@Slf4j
public class CacheManageController {

    @Resource(name = "stringRedisTemplate")
    private RedisTemplate<Object, Object> redisTemplate;

    //可删除的缓存
    Set<String> delable = Sets.newHashSet(Arrays.asList( BizTableOrderService.BIZ_TABLE_ORDER_VAL_REDIS_KEY ) );


    @ApiOperation(value = "转发服务方法")
    @PostMapping("/clean")
        @ApiImplicitParams({
            @ApiImplicitParam(name="JID",value="JID",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="cacheName",value="btnCode",required=false,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult clean( @RequestParam("cacheName") String cacheName ) {
        RequestResult result = new RequestResult<>();
        if( StringUtils.isBlank( cacheName ) ){
            return result;
        }
        result.setObj("删除成功");
        if( delable.contains( cacheName ) ){
            redisTemplate.delete( cacheName );
        }else{
            result.setObj("删除失败");
        }
        return result;
    }


}
