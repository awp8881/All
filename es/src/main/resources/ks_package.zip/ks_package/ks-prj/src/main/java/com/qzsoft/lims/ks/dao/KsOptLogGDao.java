package com.qzsoft.lims.ks.dao;

import com.qzsoft.common.dao.BaseDao;

/** 
 * 系统配置：系统自动化SQL语句
 * 创建时间:2018-11-07 16:36:29 
 */ 
public interface KsOptLogGDao  extends BaseDao {



}
