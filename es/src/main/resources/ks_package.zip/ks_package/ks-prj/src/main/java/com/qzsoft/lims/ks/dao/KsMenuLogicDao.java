package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.SourceConfigVO;

/**
 * 页面属性dao
 * @author zf
 *
 */
public interface KsMenuLogicDao extends BaseDao{

	/**
	 * 删除后批量插入
	 * @param sourceConfigVO
	 * @return
	 */
	Boolean batchUpdate(SourceConfigVO sourceConfigVO);

	/**
	 * 通过数据源类型获取工具栏信息
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	List<Record> getLogicByMcodeType(String m_code,String m_code_type);

	/**
	 * 构建按钮扩展属性  比如获取组合查询搜索信息
	 * @param m_code
	 * @param button_code
	 * @param control_style
	 * @return
	 */
	Object buildExpBtnAttr(String m_code, String button_code, String control_style,String button_type);

	/**
	 * 获取组合查询搜索信息
	 * @param m_code
	 * @param button_code
	 * @return
	 */
	List buildBtnCombFindAttr(String m_code, String button_code);

	/**
	 * 通过位置类型获取页面属性
	 * @param m_code
	 * @param control_type
	 * @param m_code_type
	 * @return
	 */
	Record getLogicByControlType(String m_code,String control_type,String m_code_type);

	/**
	 * 保存加载列表时 loadList,关键词selectField,分组selectButton
	 * @param sourceConfigVO
	 * @return
	 */
	Boolean saveToControlType(SourceConfigVO sourceConfigVO);

	/**
	 * 列表按钮
	 * @param mCode
	 * @param mType
	 * @return
	 */
	List<Record> getListButtonLogic(String mCode, String mType);

	/**
	 * 是否是统计按钮
	 * @param buttonCode
	 * @param mType
	 * @param controlStyle
	 * @return
	 */
	Record statisticButton( String buttonCode, String mType, String controlStyle);

}
