package com.qzsoft.lims.ks.config.msg;

import com.qzsoft.common.constants.MsgConstants;
import com.qzsoft.lims.ks.eum.msg.MessageType;
import com.qzsoft.lims.ks.handler.MessageHandler;
import com.qzsoft.lims.ks.service.msg.MessageSendService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;


/**系统加载时候将消息中心预处理数据载入map中
 * 如果后续要实现CommandLineRunner多个，且多个可以用order注解进行排序(@order（value= 1))
 * @author yuanj
 * @since 2021/12/31
 **/
@Component
@Slf4j
public class MessageHandlerHolder implements CommandLineRunner {

    @Autowired
    private ApplicationContext applicationContext;
    /**
     * 系统所有的消息处理器
     */
    private static final Map<MessageType, MessageHandler<?>> HANDLER_MAP = new LinkedHashMap<>();

    public static MessageHandler<?> get(MessageType messageType) {
        return HANDLER_MAP.get(messageType);
    }

    public static Collection<MessageHandler<?>> values() {
        return HANDLER_MAP.values();
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void run(String... args) throws Exception {
        //设置关闭jvm钩子,在主线程中定义一次即可，检查是否有未执行完成的线程，
        // 优雅关闭程序,不至于服务器挂掉队列任务丢失（kill -9除外）------yuanj
        ShutdownHook();
        Map<String, MessageHandler> springMap = applicationContext.getBeansOfType(MessageHandler.class);
        for (MessageHandler messageHandler : springMap.values()) {
            MessageType messageType = messageHandler.messageType();
            if (HANDLER_MAP.containsKey(messageType)) {
                // 一种消息平台只接受一个消息处理器（如果接受多个会有处理器执行的顺序问题，会变复杂，暂时不处理这种情况）
                throw new IllegalStateException("存在重复消息处理器");
            }
            HANDLER_MAP.put(messageType, messageHandler);
        }
    }

    /**触发条件说明
     * 1. 程序正常退出
     * 2. 使用System.exit()
     * 3. 终端使用Ctrl+C触发的中断
     * 4. 系统关闭
     * 5. 使用Kill pid命令干掉进程。
     * @author yuanj
     * 2021-01-05
     */
    private void ShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run() {
                    // 修改全局变量，告诉子线程中断while循环
                MsgConstants.shutdownInProgress.set(true);
                log.info("ShutdownHook 执行完成，全局信号已经修改");
                // 等待3秒，让当前任务，进入executorService线程池。
                try {
                    Thread.sleep(3000);
                // 3秒后关闭线程池，但是，线程池里面没执行完的任务会继续执行
                    MessageSendService bean = applicationContext.getBean(MessageSendService.class);
                    bean.executor.shutdown();
                // 这里设置等待10秒，让线程池里面的任务执行，10秒后，强制停机。
                Thread.sleep(10 * 1000);
                log.info("已停止");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }});
    }
}
