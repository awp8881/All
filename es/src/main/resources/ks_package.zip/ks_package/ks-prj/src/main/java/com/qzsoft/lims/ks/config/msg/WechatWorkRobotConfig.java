package com.qzsoft.lims.ks.config.msg;

import com.qzsoft.lims.ks.interfaces.ConfigValue;
import lombok.*;

/**
 * 企业微信-群机器人配置
 * @author yuanj
 * @since 2021/12/29
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WechatWorkRobotConfig extends Config {
    private static final long serialVersionUID = -9206902816158196669L;

    @ConfigValue(value = "群机器人的webhook")
    private String webhook;

}
