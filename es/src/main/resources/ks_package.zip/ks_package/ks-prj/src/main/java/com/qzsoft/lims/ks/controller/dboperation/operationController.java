package com.qzsoft.lims.ks.controller.dboperation;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.lims.ks.base.ExecResult;
import com.qzsoft.lims.ks.base.Module;
import com.qzsoft.lims.ks.entity.TableEntity;
import com.qzsoft.lims.ks.service.operationMsg.OperationPingService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Map;

/**
 * 数据库操作
 * @author yuanj
 */
@Api(value = "数据库操作", tags = "数据库操作")
@RestController
@Slf4j
public class operationController {

    @Autowired
    OperationPingService operationPingService;


    @ApiOperation(value = "数据库连接")
    @PostMapping("/connector/ping")
    @ResponseAddHead
    @ResponseBody
    public Map connectorPing(@RequestBody String dblinkParam) {
        Map<String,Object> maps = Maps.newHashMap();
        Map<String,Object> mapss = Maps.newHashMap();
        ExecResult exec = operationPingService.exec(dblinkParam);
        mapss.put("status",exec.getStatus());
        mapss.put("body", exec.getBody());
        maps.put("data",mapss);
        maps.put("status",200);
        return maps ;
    }


    @ApiOperation(value = "数据库保存")
    @PostMapping("/project/save")
    @ResponseAddHead
    @ResponseBody
    public Map connectorSave(@RequestBody String connectorSave) {
        Map<String,Object> maps = Maps.newHashMap();
        Map<String,Object> mapss = Maps.newHashMap();
        operationPingService.saveJson(connectorSave);
        mapss.put("status","SUCCESS");
        maps.put("data",mapss);
        maps.put("status",200);
        return maps ;
    }


    @ApiOperation(value = "用户操作的sql语句入库")
    @PostMapping("/project/saveResultString")
    @ResponseAddHead
    @ResponseBody
    public Map saveResultString(@RequestBody String resultString) {
        log.info("用户操作的sql语句{}",resultString);
        Map<String,Object> maps = Maps.newHashMap();
        Map<String,Object> mapss = Maps.newHashMap();
        operationPingService.saveResultString(resultString);
        maps.put("status",200);
        mapss.put("status","SUCCESS");
        maps.put("data",mapss);
        return maps ;
    }

    @ApiOperation(value = "用户进行sql语句查询")
    @PostMapping("/project/querySql")
    @ResponseAddHead
    @ResponseBody
    public  List<Record> querySql(@RequestBody String resultString) {
        List<Record> requestResult = operationPingService.querySql(resultString);
        return requestResult ;
    }



    @ApiOperation(value = "解析数据库连接")
    @PostMapping("/connector/dbReverseParse")
    @ResponseAddHead
    @ResponseBody
    public Map dbReverseParse(@RequestBody String dbReverseParse) {
        log.info("解析数据库连接{}",dbReverseParse);
        Map<String,Object> maps = Maps.newHashMap();
        Map<String,Object> mapss = Maps.newHashMap();
        ExecResult exec = operationPingService.dbReverseParse(dbReverseParse);
        List<TableEntity> tableEntityList = (List<TableEntity>) exec.getBody();
        tableEntityList.stream().forEach(o->{
            o.setTitle(o.getDefKey());
            o.getFields().stream().forEach(p->{
                p.setName(p.getDefKey());
                p.setChnname(p.getDefName());
                p.setPk(p.getPrimaryKey());
                p.setType(p.getTypeFullName());
                p.setDataType(p.getTypeFullName());
                p.setUrl(JSONObject.parseObject(dbReverseParse).getString("url"));
            });
            o.getIndexs().stream().forEach(q->{
                List<String> list = Lists.newArrayList();
                q.getField().stream().forEach(y->{list.add(y.getFieldDefKey());
                q.setFields(list);
                q.setisUnique(q.isUnique());
                });
                q.setName(q.getDefKey());
            });
        });
        mapss.put("status","SUCCESS");
        //mapss.put("body",tableEntityList);
        //如果没有分组，则构建一个默认分组
        Module module = new Module();
        module.setDefKey("CHINER");
        module.setDefName("");
        module.setName("");
        module.setCode("数据库");
        module.setEntities(tableEntityList);
        mapss.put("module",module);
        maps.put("data",mapss);
        maps.put("status",200);
        return maps ;
    }

    @ApiOperation(value = "获得页面配置")
    @PostMapping("/project/getJson")
    @ResponseAddHead
    @ResponseBody
    public Map getJson() {
        Map<String, Object> resultMap = operationPingService.getJson();
       /* mapss.put("status","SUCCESS");
        maps.put("data",mapss);
        maps.put("status",200);*/
        return resultMap ;
    }

}
