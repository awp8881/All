package com.qzsoft.lims.ks.conversion;

import com.google.common.base.Splitter;
import com.qzsoft.common.tools.StringUtil;

import java.util.Collections;

import org.apache.commons.lang3.StringUtils;

/**
 * @author pjh
 * @Title: ArrayDataSelectConversionImpl
 * @Description: 数组转换器  转换格式 1,2,3,4 => [1,2,3,4]
 * @date 2018/9/7 13:59
 */
public class ArrayDataSelectConversionImpl implements DataConversion {
    @Override
    public Object conversion(Object originalObj) {

        String originalStr = StringUtil.toString( originalObj );
        if(StringUtils.isBlank( originalStr )){
            return Collections.emptyList();
        }
        return Splitter.on(",").omitEmptyStrings().splitToList( originalStr );
    }
}
