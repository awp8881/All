package com.qzsoft.lims.ks.dao.impl;

import com.google.common.collect.Lists;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.conversion.ConversionHolder;
import com.qzsoft.lims.ks.dao.KsSqlRowBDao;
import com.qzsoft.lims.ks.dao.KsSqlRowEventBDao;
import com.qzsoft.lims.ks.eum.ColorEventTypeEnum;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.util.CodesUtil;
import com.qzsoft.lims.ks.util.CommonUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 行颜色
 *
 */
@Repository
public class KsSqlRowEventBDaoImpl extends BaseDaoImpl implements KsSqlRowEventBDao{
	private static final String TABLE_NAME_B = "ks_sql_row_event_b";
	private static final String TABLE_NAME_C = "ks_sql_row_event_c";

	public KsSqlRowEventBDaoImpl(){
		super.tableName=TABLE_NAME_B;
	}

	@Autowired
	private KsSqlRowBDao ksSqlRowBDao;

	/**
	 * 行事件列表
	 */
	@Override
	public List<Record> getRowEventByMcode(String m_code, String m_code_type, String eventType) {
		String table = TABLE_NAME_B;
		if(McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		String sql = "select * from "+table+" where m_code=? and (info_code is null or info_code ='' ) and event_type =? order by event_order+0";
		List<Record> recordList = selectListBySql(sql, m_code, eventType);

		if (null == recordList || recordList.isEmpty()){
			return Lists.newArrayList();
		}
		Map<String, Object> groupConds = ksSqlRowBDao.getGroupConds(m_code, m_code_type);

		for(Record record : recordList){
			String eventRowCode = record.getStr("row_code");
			List<String> secField = CommonUtil.strToList( record.getStr("sec_field"), ",");
			record.set("sec_field", secField);
			Object event_name = record.get("event_name");
			record.set("event_name", Lists.newArrayList());

			if(!ObjectUtils.isEmpty(event_name)){
				event_name = ConversionHolder.selectDataConversion(ColorEventTypeEnum.FONT_COLOR.getCode(), event_name);
				record.set("event_name", event_name);
			}

			if (null == groupConds || groupConds.isEmpty()){
				record.set("rowList", Lists.newArrayList());
				continue;
			}
			List<List<Map<String, Object>>> conds = (List<List<Map<String, Object>>>)groupConds.get( eventRowCode );
			if(null == conds || conds.isEmpty()){
				record.set("rowList", Lists.newArrayList());
				continue;
			}
			record.set("rowList", conds);
		}

		return recordList;
	}

	/**
	 * 删除后插入
	 * */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> colorList, String new_m_code, Integer isSaveAs, String old_m_code, String menu_id) {
		boolean isSucc = true;
		String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
		String rowEventSql = "delete from "+table+" where m_code=? and (info_code is null or info_code ='' ) ";
		DbEx.delete(rowEventSql, old_m_code);

		List<List<Map<String, Object>>> allRowList = Lists.newArrayList();
		if (null == colorList || colorList.isEmpty()){
			ksSqlRowBDao.saveGroupConds(allRowList, new_m_code, old_m_code, isSaveAs, menu_id);
			return isSucc;
		}
		List<Record> recordList = DataBaseUtil.map2Record(colorList);
		int count = 1;
		for(Record record : recordList){
			String row_code = CodesUtil.createCommonCode(new_m_code+"$row_code");
			record.set("m_code", new_m_code);
			record.set("row_code", row_code);
			record.set("cr_dm", DateUtil.getNowDateTimeStr());
			record.set("up_ver", "1");
			record.set("menu_id", menu_id);
			record.set("event_order", count);
			record.set("sec_field", StringUtil.listTOString( record.get("sec_field")));

			String eventType = record.getStr("event_type");
			if (ColorEventTypeEnum.FONT_COLOR.getCode().equals( eventType)){
				record.set("sec_type", ColorEventTypeEnum.FIELD_COLOR.getCode());
			}

			Object event_name = record.get("event_name");
			record.set("event_name", "");
			if(!ObjectUtils.isEmpty(event_name)){
				Object objConver = ConversionHolder.saveDataConversion( ColorEventTypeEnum.FONT_COLOR.getCode(), event_name );
				record.set("event_name", objConver);
			}
			count++;

			List<List<Map<String, Object>>> rowList = record.get("rowList");
			record.remove("rowList");

			if (null == rowList || rowList.isEmpty()){
				continue;
			}
			setRowCode( rowList, row_code);
			allRowList.addAll(rowList);

		}
		isSucc = saveList(table,recordList);
		ksSqlRowBDao.saveGroupConds(allRowList, new_m_code, old_m_code, isSaveAs, menu_id);
		return isSucc;
	}

	private void setRowCode( List<List<Map<String, Object>>> rowList, String rowCode){
		for (Iterator<List<Map<String, Object>>> iterator = rowList.iterator(); iterator.hasNext(); ) {
			List<Map<String, Object>> next =  iterator.next();

			for (Iterator<Map<String, Object>> mapIterator = next.iterator(); mapIterator.hasNext(); ) {
				Map<String, Object> map =  mapIterator.next();
				map.put("row_code", rowCode);
			}
		}

	}
}
