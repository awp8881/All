package com.qzsoft.lims.hlyy.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class HLYYEntity {


    @ApiModelProperty(value="create_time",dataType="String",required=false)
    private String create_time;

    @ApiModelProperty(value="update_time",dataType="String",required=false)
    private String update_time;

    @ApiModelProperty(value="update_lname",dataType="String",required=false)
    private String update_lname;

    @ApiModelProperty(value="create_lname",dataType="String",required=false)
    private String create_lname;

    @ApiModelProperty(value="up_ver",dataType="String",required=false)
    private String up_ver;

    @ApiModelProperty(value="tenant_id",dataType="String",required=false)
    private String tenant_id;

    @ApiModelProperty(value="disp_or",dataType="String",required=false)
    private String disp_or;

}
