package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.UIDGenerator;
import com.qzsoft.lims.ks.dao.KsMenuCDao;
import com.qzsoft.lims.ks.dao.KsModelAttrBao;
import com.qzsoft.lims.ks.util.DataBaseUtil;

/**
 * 属性配置-dao实现
 * @author hqp
 *
 */
@Repository
public class KsModelAttrBaoImpl extends BaseDaoImpl implements KsModelAttrBao {
	private static final String TABLE_NAME = "ks_model_attr_b";
	
	@Autowired
	private KsMenuCDao ksMenuCDao;
	
	/**
	 * 删除后插入
	 * @param button_code 按钮编码
	 * @param modelAttrList
	 * @return
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdate(Long menu_id,String button_code,List<Map<String,Object>> modelAttrList) {	
		Boolean isSucc=true;
		
		//获取m_code
		String m_code = null;
		Record ksMenuCRec = ksMenuCDao.getOne(menu_id);
		if(ksMenuCRec == null){
			return false;
		}
		m_code = ksMenuCRec.getStr("m_code");
		if(StringUtils.isBlank(m_code)){
			return false;
		}
		
		//删除旧数据
		DbEx.delete("delete from "+TABLE_NAME+" where button_code = ? ",button_code);
		if(null == modelAttrList || modelAttrList.isEmpty()){
			return isSucc;
		}
		
		Integer disp_or = 1;
		for(Map<String,Object> modelAttr : modelAttrList) {
			modelAttr.remove("id");
			String attr_code = m_code + "$attr_code_" + UIDGenerator.getUID();
			modelAttr.put("m_code", attr_code);
			modelAttr.put("button_code", button_code);
			modelAttr.put("disp_or", disp_or ++);
			modelAttr.put("cr_dm", DateUtil.getNowDateTimeStr());
			modelAttr.put("up_ver", "1");
			modelAttr.put("menu_id", menu_id);
		}
		
		List<Record> recordList=DataBaseUtil.map2Record(modelAttrList);
		isSucc= super.saveList(TABLE_NAME, recordList);
		return isSucc;
	}
}
