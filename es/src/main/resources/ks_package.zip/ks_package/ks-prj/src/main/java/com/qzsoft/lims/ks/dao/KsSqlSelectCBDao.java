package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 小列表数据源条件
 * */
public interface KsSqlSelectCBDao extends BaseDao{
	/**
	 * 数据源条件列表
	 * @param p_m_code
	 * @param m_code
	 * @param m_order
	 * @param event_type
	 * @param select_code_b
	 * @return
	 */
	List<Record>  getSelectList(String p_m_code, String m_code, String m_order, String event_type, String select_code_b);
	
	/**
	 * 删除后批量插入
	 */
	Boolean batchUpdate(List<Map<String, Object>> selectList, String newSelectCodeB, String menuId, String mCode, String pCode, String isParaNul);

	List<List<Map<String, Object>>> getGroupConds( String pMCode, String mCode, String mOrder, String eventType, String selectCodeB );

	Set<String> saveGroupConds( List<List<Map<String, Object>>> groupConds, String newSelectCodeB,
							String menuId, String mCode, String pCode, String isParaNul );

}
