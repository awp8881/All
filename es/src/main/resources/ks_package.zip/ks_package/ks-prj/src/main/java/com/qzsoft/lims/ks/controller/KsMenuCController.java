package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.constants.Constant;
import com.qzsoft.lims.ks.service.menu.KsMenuCService;
import com.qzsoft.lims.ks.util.NetworkUtil;
import com.qzsoft.lims.ks.vo.KsMenuCVO;
import com.qzsoft.lims.ks.vo.KsMenuFeVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * 菜单配置-控制器
 * @author zf
 *
 */
@Api(value = "菜单配置", tags = "菜单配置，表：ks_menu_c")
@RestController
@RequestMapping("/menu")
@Slf4j
public class KsMenuCController {
	
	@Autowired
	private KsMenuCService ksMenuCService;
	
	@ApiOperation(value="新增",notes="true-保存成功，false-保存失败")
	@PostMapping("/add")
		@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Boolean> add(KsMenuCVO ksMenuCVO) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			if (StringUtils.isBlank( ksMenuCVO.getIs_active() )) {
				ksMenuCVO.setIs_active( Constant.COMMON_VALID );
			}
			Boolean isSave = ksMenuCService.save(ksMenuCVO);
			result.setObj(isSave);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".add()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".add()", e);
		}
		return result;

	}
	
	@ApiOperation(value="修改",notes="true-保存成功，false-保存失败")
	@PostMapping("/update")
		@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Boolean> update(KsMenuCVO ksMenuCVO) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			if (StringUtils.isBlank( ksMenuCVO.getIs_active() )) {
				ksMenuCVO.setIs_active( Constant.COMMON_VALID );
			}
			Boolean isUpdate = ksMenuCService.update(ksMenuCVO);
			result.setObj(isUpdate);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".update()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".update()", e);
		}
		return result;

	}
	
	@ApiOperation(value="删除",notes="true-删除成功，false-删除失败")
	@ApiImplicitParam(name="menuId",value="主键",required=true,dataType="Long",paramType="query")
	@PostMapping("/delete")
	@ResponseAddHead
		public RequestResult<Boolean> delete(@RequestParam(value="menuId") Long menuId) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isDelete = ksMenuCService.delete(menuId);
			result.setObj(isDelete);	
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}
		return result;
	}
	
	@ApiOperation(value="菜单是否存在",notes="true-存在，false-不存在；编辑时传入主键id")
	@PostMapping("/isExists")
		@ApiImplicitParams({
		@ApiImplicitParam(name="resNa",value="菜单名称",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="menuId",value="菜单id",required=false,dataType="Long",paramType="query")
	})
	@ResponseAddHead
	public RequestResult<Boolean> isExists(@RequestParam(value="resNa") String resNa,
			@RequestParam(value="menuId",required=false) Long menuId) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isExists = ksMenuCService.isExists( resNa, menuId);
			result.setObj(isExists);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".isExists()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".isExists()", e);
		}
		return result;

	}
	
	@ApiOperation("树列表查询")
	@GetMapping("/getTreeList")
		@ApiImplicitParam(name="res_na",value="菜单名称",required=false,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<KsMenuCVO> getTreeList(@RequestParam(value="res_na",required=false)String res_na) {
		RequestResult<KsMenuCVO> result = new RequestResult<>();
		try {
			result=new RequestResult<>(ksMenuCService.getTreeList(res_na,false));
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getTreeList()", e);
		}
		return result;

	}

	@ApiOperation("移动一二级树列表")
	@GetMapping("/getMoveTreeList")
		@ApiImplicitParam(name="level",value="选择菜单层级",required=false,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Map<String,Object>> getMoveTreeList(@RequestParam(value="level")String level) {
		RequestResult<Map<String,Object>> result;
		try {
			result=new RequestResult<>(ksMenuCService.getMoveTreeList(level));
			result.setObj(null);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMoveTreeList(level)", e);
		}
		return result;

	}


	@ApiOperation("获取三级之前菜单")
	@GetMapping("/getMenuListBeforeThree")
		@ResponseAddHead
	public RequestResult<KsMenuCVO> getTwoTreeList( ) {
		RequestResult<KsMenuCVO> result = new RequestResult<>();
		try {
			result=new RequestResult<>(ksMenuCService.getMenuListBeforeThree());
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getMenuListBeforeThree()", e);
		}
		return result;

	}

	@ApiOperation("前端树列表查询")
	@GetMapping("/getFETreeList")
		@ApiImplicitParams({
			@ApiImplicitParam(name="res_na",value="菜单名称",required=false,dataType="String",paramType="query"),
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
	})
	@ResponseAddHead
	public RequestResult<KsMenuFeVO> getFETreeList(@RequestParam(value="res_na",required=false)String res_na,
												   @RequestParam(value="JID",required=false)String JID,
												   HttpServletRequest request) {
		String userAgent= request.getHeader("User-Agent");
		String clientIp = NetworkUtil.getIpAddress( request );
		List<KsMenuFeVO> feTreeList = ksMenuCService.getFETreeList(res_na, JID, clientIp, userAgent);
		RequestResult<KsMenuFeVO> result=new RequestResult<KsMenuFeVO>();
		if( null!=feTreeList && !feTreeList.isEmpty() ){
			result.setObj( feTreeList.get(0) );
		}
		return result;

	}

	
	@ApiOperation("详情查询")
	@GetMapping("/getOne")
		@ApiImplicitParam(name="menuId",value="主键",required=true,dataType="Long",paramType="query")
	@ResponseAddHead
	public RequestResult<KsMenuCVO> getOne(@RequestParam(value="menuId") Long menuId) {
		RequestResult<KsMenuCVO> result = new RequestResult<>();
		try {
			result=new RequestResult<>(ksMenuCService.getOne(menuId));
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getOne()", e);
		}
		return result;

	}
	
	@ApiOperation("获取子集")
	@GetMapping("/getSonList")
		@ApiImplicitParam(name="faResNo",value="父级id",required=true,dataType="Long",paramType="query")
	@ResponseAddHead
	public RequestResult<KsMenuCVO> getSonList(@RequestParam(value="faResNo") Long faResNo) {
		RequestResult<KsMenuCVO> result = new RequestResult<>();
		try {
			result=new RequestResult<>(ksMenuCService.getSonList(faResNo));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getSonList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getSonList()", e);
		}
		return result;

	}

	@ApiOperation("同步所有菜单到tu系统")
	@GetMapping("/allSynMenuToTuSys")
		@ResponseAddHead
	public RequestResult<KsMenuCVO> allSynMenuToTuSys(  ) {

		RequestResult<KsMenuCVO> result = new RequestResult<>();
		try {
			Boolean aBoolean = ksMenuCService.allSynMenuToTuSys();
			result.setStatus( aBoolean );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".allSynMenuToTuSys()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".allSynMenuToTuSys()", e);
		}
		return result;

	}


	@ApiOperation("交换菜单排序")
		@ApiImplicitParams({
			@ApiImplicitParam(name="menuIdOne",value="菜单ID",required=true,dataType="Long",paramType="query"),
			@ApiImplicitParam(name="menuIdTwo",value="菜单ID",required=true,dataType="Long",paramType="query")
	})
	@GetMapping("/exchangeMenuOrder")
	@ResponseAddHead
	public RequestResult<Boolean> exchangeMenuOrder(@RequestParam(value="menuIdOne")Long menuIdOne,
													  @RequestParam(value="menuIdTwo")Long menuIdTwo ) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			Boolean aBoolean = ksMenuCService.exchangeMenuOrder( menuIdOne, menuIdTwo );
			result.setStatus( aBoolean );
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".exchangeMenuOrder()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".exchangeMenuOrder()", e);
		}
		return result;

	}


	@ApiOperation("三级菜单")
		@GetMapping("/getThreeMenus")
	@ResponseAddHead
	public RequestResult<Map<String, Object>> getThreeMenus( ) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList(ksMenuCService.getThreeMenus());
		return result;

	}
}
