package com.qzsoft.lims.ks.dao;

import java.util.Set;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.SourceConfigVO;

/**
 * 模版列表
 * @author zf
 *
 */
public interface KsModelListDao extends BaseDao{
	/**
	 * 通过模板编码查询模板列表
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	Record getModelListByMcode(String m_code,String m_code_type);
	
	/**
	 * 保存
	 * @param sourceConfigVO
	 * @return
	 */
	Boolean save(SourceConfigVO sourceConfigVO);

	/**
	 * 查询group by字段
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	Record getAttrByMcode(String m_code, String m_code_type);
	
}
