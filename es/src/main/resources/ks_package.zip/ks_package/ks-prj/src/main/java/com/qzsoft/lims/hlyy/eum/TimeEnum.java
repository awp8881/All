package com.qzsoft.lims.hlyy.eum;

public enum TimeEnum {

    DAY("DAY", "天（Day）"),
    HOUR("HOUR", "小时（Hour）"),
    MINT("MINT", "分钟（Minute）"),
    ;

    private String code;
    private String desc;

    TimeEnum(String code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
