
package com.qzsoft.lims.ks.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

/**
 * @author : yuanj
 * @date : 2022/03/09
 * @desc :
 */
@JsonPropertyOrder({
        "defKey",
        "defName",
})
public class Diagram implements Serializable,Cloneable{
    private String id;              //关系图ID
    private String defKey;          //关系图代码
    private String defName;         //关系图名称
   /* @JsonIgnore
    private RenderData renderData;*/

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDefKey() {
        return defKey;
    }

    public void setDefKey(String defKey) {
        this.defKey = defKey;
    }

    public String getDefName() {
        return defName;
    }

    public void setDefName(String defName) {
        this.defName = defName;
    }

 /*   public RenderData getRenderData() {
        return renderData;
    }

    public void setRenderData(RenderData renderData) {
        this.renderData = renderData;
    }*/
}
