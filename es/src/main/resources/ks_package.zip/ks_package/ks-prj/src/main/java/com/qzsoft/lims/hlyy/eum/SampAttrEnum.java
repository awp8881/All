package com.qzsoft.lims.hlyy.eum;

public enum SampAttrEnum {

    SX_PT("SX_PT", "普通"),
    SX_ZKY("SX_ZKY", "质控样"),
    SX_BY("SX_BY", "标样"),
    SX_QTY("SX_QTY", "其他样"),
    SX_KBY("SX_KBY", "空白样")
    ;

    private String code;
    private String desc;

    SampAttrEnum(String code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
