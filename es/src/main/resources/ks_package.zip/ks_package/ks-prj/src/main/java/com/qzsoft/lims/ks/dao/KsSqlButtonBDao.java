package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 按钮激活条件
 * @author zf
 *
 */
public interface KsSqlButtonBDao extends BaseDao{
	
	/**
	 * 数据源条件列表
	 * @param button_code
	 * @param m_code_type
	 * @return
	 */
	List<List<Map<String, Object>>>  getButtonList(String button_code, String m_code_type);
	
	List<Record>  getButtonList(String m_code, String info_code, String m_code_type);
	
	/**
	 * 删除后批量插入
	 * @param allButtonList
	 * @param isSaveAs
	 * @param old_m_code
	 * @param info_code
	 * @return
	 */
	Boolean batchUpdate(List<Map<String, Object>> allButtonList,Integer isSaveAs,String old_m_code,String info_code,String menu_id);

	Map<String, Object> getGroupConds( String mCode, String infoCode, String mCodeType );

	Boolean saveGroupConds( List<List<Map<String, Object>>> groupConds, Integer isSaveAs,
							 String pMCode, String infoCode, String menuId );
	
}
