package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 自定义数据源Dao
 * @author zf
 *
 */
public interface KsTableSqlDao extends BaseDao{

	 Record getSqlNameByMcode(String m_code, String m_type);


	/**
	 * 通过模板编码获取数据源列表
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	List<Record> getTableSqlList(String m_code,String m_code_type);
	
	/**
	 * 通过模板编码获取数据源列表适用于表关系模块
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	List<Record> getTableSqlListForTableRel(String m_code,String m_code_type);

	/**
	 * 通过模板编码获取数据源列表,根据查询字符进行筛选
	 * @param m_code_type:数据源类型
	 * @param search:查询字符
	 * @return
	 */
	List<Record> getTableSqlSearchList(String m_code_type,String search);
	
	/**
	 * 按类型从abc表获取
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	Record getSqlByMcode(String sql_name,String m_code,String m_code_type);
	
	/**
	 * 组件小列表数据源
	 * @param innerCodeList
	 * @return
	 */
	List<Record> getAssemblySourceList(List<String> innerCodeList);


}
