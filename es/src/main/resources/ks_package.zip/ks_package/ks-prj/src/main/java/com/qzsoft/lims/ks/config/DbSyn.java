package com.qzsoft.lims.ks.config;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.DbPro;
import com.jfinal.plugin.activerecord.Record;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * @Author zf
 * @Description 系统同步db
 * @Date 2019/7/8
 */
public class DbSyn extends Db{

    private static DbPro useDb(String configName ){

        if( StringUtils.isBlank( configName ) ){
            return Db.use( );

        }else{
            return Db.use(configName);
        }
    }

    public static List<Record> find(String configName, String sql) {
        return useDb(configName).find(sql);
    }
}
