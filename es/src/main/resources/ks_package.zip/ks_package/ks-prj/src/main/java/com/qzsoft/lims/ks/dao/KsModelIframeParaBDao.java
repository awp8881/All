package com.qzsoft.lims.ks.dao;

import java.util.Map;

import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.SourceConfigVO;

public interface KsModelIframeParaBDao extends BaseDao{

	Map<String, Object> getByMenuId( String menuId);
	
	boolean saveIframe( SourceConfigVO sourceConfigVO );
}
