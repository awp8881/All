package com.qzsoft.lims.ks.controller;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.annotation.TagResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsTableFieldUrlCService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(value = "字段接口地址配置", tags = "字段接口地址配置")
@RestController
@RequestMapping("/fieldUrlConfig")
public class KsTableFieldUrlCController {

    @Autowired
    private KsTableFieldUrlCService ksTableFieldUrlCService;

    @ApiOperation(value = "保存字段接口地址配置")
    @PostMapping("/saveFieldUrl")
        @ResponseAddHead
    public RequestResult<Map<String, Object>> saveFieldUrl(  @RequestParam("t_name")String t_name, @RequestParam("field_name_s")String field_name_s,
                                                             @RequestParam(value = "id", required = false)Long id) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        Map<String, Object> map = ksTableFieldUrlCService.saveFieldUrl( t_name, field_name_s, id);
        result.setObj( map );
        return result;
    }
    
    @ApiOperation(value = "字段接口地址配置列表")
    @GetMapping("/getFieldUrlList")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getFieldUrlList( ) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> fieldUrlList = ksTableFieldUrlCService.getFieldUrlList();
        result.setList( fieldUrlList );
        return result;
    }

    @ApiOperation(value = "删除字段接口地址配置")
    @PostMapping("/deleteFieldUrl")
    @ApiImplicitParam(name="id",value="主键逗号分隔",dataType="String",paramType="query")
    @ResponseAddHead
        public RequestResult<Boolean> deleteFieldUrl( @RequestParam("ids") String ids ) {
        RequestResult<Boolean> result = new RequestResult<>();
        Boolean success = ksTableFieldUrlCService.deleteFieldUrl(ids);
        result.setObj( success );
        return result;
    }

    @ApiOperation(value = "所有字段地址")
    @GetMapping("/getAllFieldUrl")
    @ResponseAddHead
        public RequestResult<Map<String,Object>> getAllFieldUrl( ) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> fieldUrlList = ksTableFieldUrlCService.getAllFieldUrl();
        result.setList( fieldUrlList );
        return result;
    }
}
