package com.qzsoft.lims.ks.config.msg;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
@Slf4j
public class ApplicationEventListener implements ApplicationListener<ApplicationEvent> {

    @Override
    public void onApplicationEvent(ApplicationEvent applicationEvent) {
      /*  if(applicationEvent instanceof ContextClosedEvent){
            log.info("Spring容器即将执行关闭");
            int time = 0;
            while (ThreadPoolExecutorManager.haveActiveThread() && time <= 30){
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                time++;
            }
            log.info("Spring容器关闭");

        }*/
    }

/*    *//**
     * 判断是否有进程在工作
     * @return 是否
     *//*
    public static Boolean haveActiveThread(){
        for (ThreadPoolExecutor executor : EXECUTOR_MAP.values()) {
            if (executor.getActiveCount() > 0) {
                return true;
            }
        }
        return false;
    }*/
}