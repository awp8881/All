package com.qzsoft.lims.hlyy.dao;

import com.jfinal.plugin.activerecord.Record;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface SamplingDao {

    boolean addGroups(Record record);

    List<Record> getAllGroupsByProjId(Long proj_id);

    boolean addCycle(Record record);

    List<Record> getAllCycleByProjId(Long proj_id);

    List<Record> getAllCycleByProjAndGroupId(String id, String proj_id);

    void delCycleByProjId(Long proj_id);

    void delCycleByProjIdAndNo(String proj_id, int cycle_no);

    boolean delCycleByGropId(List<String> ids);

    boolean delGropsByIds(List<String> ids);

    Record findGroById(String groupId);

    boolean updateGropInfo(Record record);

    Record findCycById(String cycleId);

    boolean updateCycInfo(Record record);

    boolean addType(Record info);

    List<Record> getAllNodeByCycId(String cycleId);

    Object getMaxNodeNo(String grop_id, String nd_type);

    void delType(Record info);

    Boolean updateType(String groupId, String original_type, String current_type);

    boolean delNodeByIds(List<String> ids);

    Record findNodeById(String nodeId);

    boolean updateNodeVal(Record record);

    Object isHaveNode(Object id);

    Object getMaxCycleNo(String proj_id);

    void saveDonor(Record donor);

    void saveSample(Record sample);

    void saveDonCycle(Record donCycle);

    Record getProjectById(String projId);

    void updateProj(Record proj_effect_yn);

    List<Record> getTypeOrderByCTime(String cycleId);

    void delDonorByProjId(String projId);

    void delDonCycByProjId(String projId);

    void delSampByProjId(String projId);

    Record getCycleById(String copiedCycId);

    void batchPaste(List<Record> nodeList);

    void delNodeByCycId(String targetCycId);

    Record getGroupsById(Object grop_id);

    List<Record> getAllSampleByProjIdAndGroupBy(String projId);

    List<Record> getAllSampleByProjId(String projId);

    void updateSampInfo(Record res);

    void saveSampleBatch(List<Record> records);

    void saveDonCycleBatch(List<Record> records);

    List<Record> getSampleCodeRule(Record project);

    Object getSampleByNameAndProjId(String finName, Object proj_id);

    List<Record> getAllNodeByGroupId(String groupId);

    List<Record> getTypeOrderByCTime2(String groupId);

    void delNodeByGGroupId(String targetGroupId);
}
