package com.qzsoft.lims.ks.controller;

import java.util.Map;

import com.qzsoft.common.annotation.TagResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsSyParaCService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 系统环境变量参数
 * @author zf
 *
 */
@Api(value = "系统环境变量参数", tags = "系统环境变量参数，表：ks_sy_para_c")
@RestController
@RequestMapping("/syPara")
@Slf4j
public class KsSyParaCController {
	
	@Autowired
	private KsSyParaCService ksSyParaCService;

	@ApiOperation(value="环境变量列表",notes="表：ks_sy_para_c")
	@GetMapping("/getList")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getList() {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		try {
			result=new RequestResult<>(ksSyParaCService.getList());
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getList()", e);
		}
		return result;

	}
}
