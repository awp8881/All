package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 按钮的逻辑脚本
 * @author zf
 *
 */
public interface KsMenuLogicContentBDao extends BaseDao{
	
	/**
	 * 列表或详情所有按钮脚本
	 * @param m_code
	 * @param info_code
	 * @param m_code_type
	 * @return
	 */
	List<Record> getLogicContentByMcode(String m_code,String info_code,String m_code_type);
	
	/**
	 * 删除后插入
	 * @param logicContentList
	 * @param isSaveAs
	 * @param old_m_code
	 * @param info_code
	 * @return
	 */
	Boolean batchUpdate(List<Record> logicContentList,Integer isSaveAs,String old_m_code,String info_code,String menu_id);


	/**
	 * 根据mcode获取event_val
	 * @param mCode
	 * @return
	 */
	List<Record> getEventValByMCode(String mCode,String type,String infoCode);

	/**
	 * 根据组件类型，获取相应表格的所有数据
	 * @param type
	 * @return
	 */
	List<Record> getAllEventValList(String type);
}
