package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;

import com.qzsoft.lims.ks.util.TableHelper;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsSqlButtonDicBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;

@Repository
public class KsSqlButtonDicBDaoImpl extends BaseDaoImpl implements KsSqlButtonDicBDao{

	private static final String TABLE_NAME = "ks_sql_button_dic_b";

	/**
	 * 删除后插入
	 * */
	@JFinalTx
	@Override
	public Boolean batchUpdate(String parent_code, List<Map<String, Object>> dicSelectList) {
		boolean isSucc = true;
		if (null == dicSelectList || dicSelectList.isEmpty()){
			return isSucc;
		}
		List<Record> recordList = DataBaseUtil.map2Record(dicSelectList);
		return super.saveList(TABLE_NAME, recordList);
	}

	@Override
	public Record getByCode(String code) {
		String sql = "select code,val from ks_sql_button_dic_b where code=?";
		return selectFirstOneBySql( sql, code);
	}

	@Override
	public List<Record> getChilds(String code) {
		String sql = "select parent_code,code,val from ks_sql_button_dic_b where parent_code=?";
		return selectListBySql(sql , code);
	}

	@Override
	public List<Record> getByChilds(List<String> dics) {
		String inSql = TableHelper.getInSql("code", dics);
		String sql = "select val from ks_sql_button_dic_b where 1=1 "+inSql;

		return DbEx.find(sql, dics.toArray());
	}
}
