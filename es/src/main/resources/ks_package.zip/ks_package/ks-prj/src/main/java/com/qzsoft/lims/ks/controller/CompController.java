package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.CompService;
import com.qzsoft.lims.ks.service.extComp.FileBean;
import com.qzsoft.lims.ks.vo.CompConfVO;
import com.qzsoft.lims.ks.vo.CompVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @auther: hqp
 * @date: 2018/9/5
 * @description:
 */

@Api(value = "组件管理服务", tags = "组件管理服务")
@RestController
@TagResource("组件管理服务")
@RequestMapping("/comp")
@Slf4j
public class CompController {

	@Autowired
	private CompService compService;

	@ApiOperation(value="保存组件配置",notes="true-保存成功，false-保存失败")
	@PostMapping("/saveCompConf")
	@TagResource("保存组件配置")
	@ApiImplicitParam(name="compConfStr",value="组件配置信息json",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<Boolean> saveCompConf(@RequestParam(value="compConfStr") String compConfStr) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		
		try {
			Boolean isSave = compService.saveCompConf(compConfStr);
			result.setObj(isSave);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveCompConf()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveCompConf()", e);
		}
		return result;

	}
	
	@ApiOperation(value="删除组件配置",notes="true-删除成功，false-删除失败")
	@ApiImplicitParam(name="infoCode",value="info编码",required=true,dataType="String",paramType="query")
	@PostMapping("/deleteCompConfByInfoCode")
	@ResponseAddHead
	@TagResource("删除组件配置")
		public RequestResult<Boolean> deleteCompConfByInfoCode(@RequestParam(value="infoCode") String infoCode) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isDelete = compService.deleteCompConfByInfoCode(infoCode);
			result.setObj(isDelete);	
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteCompConfByInfoCode()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteCompConfByInfoCode()", e);
		}
		return result;
	}
	
	@ApiOperation(value="根据info编码查询组件配置",notes="没有分页")
	@GetMapping("/getCompConfListByInfoCode")
	@ApiImplicitParam(name="infoCode",value="info编码",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<List<CompConfVO>> getCompConfListByInfoCode(@RequestParam(value="infoCode") String infoCode) {
		RequestResult<List<CompConfVO>> result = new RequestResult<>();
		try {
			List<CompConfVO> ret = compService.getCompConfListByInfoCode(infoCode);
			result.setObj(ret);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getCompConfListByInfoCode()", e);
		}
		return result;
	}
	
	@ApiOperation(value="保存组件定义",notes="true-保存成功，false-保存失败")
	@PostMapping("/saveComp")
	@TagResource("保存组件定义")
	@ApiImplicitParam(name="compStr",value="组件定义信息json",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<Boolean> saveComp(@RequestParam(value="compStr") String compStr) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		
		try {
			Boolean isSave = compService.saveComp(compStr);
			result.setObj(isSave);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveComp()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveComp()", e);
		}
		return result;

	}
	
	@ApiOperation(value="删除组件定义",notes="true-删除成功，false-删除失败")
	@ApiImplicitParam(name="compType",value="组件类型",required=true,dataType="String",paramType="query")
	@PostMapping("/deleteCompByCompType")
	@ResponseAddHead
	@TagResource("删除组件定义")
		public RequestResult<Boolean> deleteCompByCompType(@RequestParam(value="compType") String compType) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isDelete = compService.deleteCompByCompType(compType);
			result.setObj(isDelete);	
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteCompByCompType()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteCompByCompType()", e);
		}
		return result;
	}
	
	@ApiOperation(value="根据组件编码删除组件定义",notes="true-删除成功，false-删除失败")
	@ApiImplicitParam(name="defCode",value="组件编码",required=true,dataType="String",paramType="query")
	@PostMapping("/deleteCompByDefCode")
	@ResponseAddHead
	@TagResource("根据组件编码删除组件定义")
		public RequestResult<Boolean> deleteCompByDefCode(@RequestParam(value="defCode") String defCode) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isDelete = compService.deleteCompByDefCode(defCode);
			result.setObj(isDelete);	
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteCompByDefCode()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteCompByDefCode()", e);
		}
		return result;
	}
	
	@ApiOperation(value="删除多条组件定义",notes="true-删除成功，false-删除失败")
	@ApiImplicitParam(name="ids",value="以逗号分隔的主键",required=true,dataType="String",paramType="query")
	@PostMapping("/deleteAllCompByIds")
	@ResponseAddHead
	@TagResource("删除多条组件定义")
		public RequestResult<Boolean> deleteAllCompByIds(@RequestParam(value="ids") String ids) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isDelete = compService.deleteAllCompByIds(ids);
			result.setObj(isDelete);	
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteAllCompByIds()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteAllCompByIds()", e);
		}
		return result;
	}
	
	@ApiOperation(value="根据组件类型查询组件定义")
	@GetMapping("/getCompByCompType")
	@ApiImplicitParam(name="compType",value="组件类型",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<CompVO> getCompByCompType(@RequestParam(value="compType") String compType) {
		RequestResult<CompVO> result = new RequestResult<>();
		try {
			CompVO ret = compService.getCompByCompType(compType);
			result.setObj(ret);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getCompByCompType()", e);
		}
		return result;
	}
	
	@ApiOperation(value="查询所有组件定义")
	@GetMapping("/getAllComps")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getAllComps() {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		try {
			List<Map<String, Object>> comps = compService.getAllComps();
			result.setList(comps);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getAllComps()", e);
		}
		return result;
	}

	@ApiOperation(value="查询所有组件定义(树形结构)")
	@GetMapping("/getAllCompsToTree")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getAllCompsToTree() {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		try {
			List<Map<String, Object>> comps = compService.getAllCompsToTree();
			result.setList(comps);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getAllCompsToTree()", e);
		}
		return result;
	}


	
	@ApiOperation(value="保存综合组件运行接口参数定义",notes="true-保存成功，false-保存失败")
	@PostMapping("/saveCompParaDef")
	@TagResource("保存综合组件运行接口参数定义")
	@ApiImplicitParams({
		@ApiImplicitParam(name="defCode",value="定义编码",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="compParaDefStr",value="综合组件运行接口参数定义json",required=true,dataType="String",paramType="query")
	})	
	@ResponseAddHead
		public RequestResult<Boolean> saveCompParaDef(@RequestParam(value="defCode") String defCode,
			@RequestParam(value="compParaDefStr") String compParaDefStr) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		
		try {
			Boolean isSave = compService.saveCompParaDef(defCode,compParaDefStr);
			result.setObj(isSave);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".综合组件运行接口参数定义()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".综合组件运行接口参数定义()", e);
		}
		return result;

	}


	@ApiOperation(value="删除多条综合组件运行接口参数定义",notes="true-删除成功，false-删除失败")
	@ApiImplicitParam(name="ids",value="以逗号分隔的主键",required=true,dataType="String",paramType="query")
	@PostMapping("/deleteAllCompParaDefByIds")
	@ResponseAddHead
	@TagResource("删除多条综合组件运行接口参数定义")
		public RequestResult<Boolean> deleteAllCompParaDefByIds(@RequestParam(value="ids") String ids) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isDelete = compService.deleteAllCompParaDefByIds(ids);
			result.setObj(isDelete);	
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteAllCompParaDefByIds()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".deleteAllCompParaDefByIds()", e);
		}
		return result;
	}
	
	@ApiOperation(value="根据定义编码查询综合组件运行接口参数定义")
	@GetMapping("/getCompParaDefByDefCode")
	@ApiImplicitParam(name="defCode",value="定义编码",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getCompParaDefByDefCode(@RequestParam(value="defCode") String defCode) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		try {
			List<Map<String, Object>> ret = compService.getCompParaDefByDefCode(defCode);
			result.setList(ret);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getCompParaDefByDefCode()", e);
		}
		return result;
	}

	@ApiOperation(value="外部组件事件")
	@GetMapping("/getCompEve")
	@ApiImplicitParam(name="defCode",value="组件编码",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getCompEve(@RequestParam(value="defCode") String defCode) {
		RequestResult<Map<String, Object>> result = new RequestResult<>(compService.getCompEve( defCode ));
		return result;
	}

	@ApiOperation(value="保存外部组件事件")
	@PostMapping("/saveCompEve")
	@ApiImplicitParam(name="compEveStr",value="json字符串",required=true,dataType="String",paramType="query")
	@ResponseAddHead
	@TagResource("保存外部组件事件")
		public RequestResult<Boolean> saveCompEve(@RequestParam(value="compEveStr") String compEveStr) {
		RequestResult<Boolean> result = new RequestResult<>(compService.saveCompEve( compEveStr ));
		return result;
	}

	@ApiOperation(value="删除外部组件事件")
	@ApiImplicitParam(name="ids",value="以逗号分隔的主键",required=true,dataType="String",paramType="query")
	@PostMapping("/deleteCompEve")
	@ResponseAddHead
	@TagResource("删除外部组件事件")
		public RequestResult<Boolean> deleteCompEve(@RequestParam(value="ids") String ids) {
		RequestResult<Boolean> result = new RequestResult<Boolean>(compService.deleteCompEve( ids ));
		return result;
	}

	@ApiOperation(value="更改组件图片")
	@PostMapping("/updateCompsPic")
	@ResponseAddHead
	@TagResource("更改组件图片")
		@ApiImplicitParams({
			@ApiImplicitParam(name="file",value="图片对象",dataType="file", paramType = "query"),
			@ApiImplicitParam(name="id",value="组件id",dataType="string", paramType = "query",required = true)})
	@ResponseBody
	public RequestResult<Object> updateCompsPic(FileBean fileBean, @RequestParam(value = "id")String id){
		RequestResult<Object> result =  new RequestResult();
		MultipartFile file = fileBean.getFile();
		byte[] fileBytes = null;
		try {
			fileBytes = file == null?null:file.getBytes();
		} catch (IOException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".updateCompsPic()", e);
			return  result;
		}
		boolean isSuccess = compService.updateCompsPic(fileBean,id);
		if(isSuccess)
			result.setObj(fileBytes);
		return  result;
	}


	@ApiOperation(value="更改组件父节点树")
	@PostMapping("/updateCompsParentTree")
	@ResponseAddHead
	@TagResource("更改组件父节点树")
		@ApiImplicitParams({
			@ApiImplicitParam(name="pId",value="所选择父组件id",dataType="string", paramType = "query"),
			@ApiImplicitParam(name="cId",value="当前组件id",dataType="string", paramType = "query",required = true)})
	@ResponseBody
	public RequestResult<Object> updateCompsParentTree(@RequestParam(value = "pId")String pId, @RequestParam(value = "cId")String cId){
		RequestResult<Object> result =  new RequestResult();
		if(!pId.equals(cId)){
			//父节点为空则不做操作,父子id相同不做操作
			compService.updateCompsParentTree(pId,cId);
		}
		return  result;
	}

	@ApiOperation(value="获取组件图片以及当前组件的所有父节点组成下拉框")
	@GetMapping("/getComInfoAndParentTree")
	@ResponseAddHead
		@ApiImplicitParams({
			@ApiImplicitParam(name="id",value="当前组件id",dataType="string", paramType = "query",required = true)})
	@ResponseBody
	public RequestResult<Map<String, Object>> getComInfoAndParentTree(@RequestParam(value = "id")String id){
		RequestResult<Map<String, Object>> result =  new RequestResult();

		HashMap<String,Object> map  = compService.getComInfoAndParentTree(id);
		List<Map<String, Object>> comps = (List<Map<String, Object>>) map.get("tree");
		result.setList(comps);
		result.setObj((Map<String, Object>) map.get("comObj"));
		return  result;
	}

}
