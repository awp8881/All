package com.qzsoft.lims.ks.config.msg;

import lombok.*;

/** 站内信
 * ps:先设置默认值
 * @author yuanj
 * @since 2021/12/29
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@Builder
public class MessagesConfig extends Config {
}
