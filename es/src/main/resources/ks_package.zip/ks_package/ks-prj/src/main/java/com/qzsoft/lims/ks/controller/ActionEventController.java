package com.qzsoft.lims.ks.controller;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.service.menu.MenuConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.info.ActionEventService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 动作事件流-控制器
 * @author zf
 *
 */
@Api(value = "动作事件流", tags = "动作事件流")
@RestController
@RequestMapping("/actionEvent")
public class ActionEventController {
	
	@Autowired
	private ActionEventService actionEventService;

	@Autowired
    private MenuConfigService menuConfigService;
    
    @ApiOperation(value = "页面按钮")
    @GetMapping("/getButtonByListOrInfo")
    @ResponseAddHead
        @ApiImplicitParams({
    	@ApiImplicitParam(name="code",value="列表或详情编码",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="m_type",value="类型",required=true,dataType="String",paramType="query")
    })
    public RequestResult<Map<String,Object>> getStepConfigMenuList( @RequestParam(value="code") String code,
    		@RequestParam(value="m_type") String mType) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> buttonList = actionEventService.getButtonByListOrInfo(code, mType);
        result.setList( buttonList );
        return result;
    }
    
    @ApiOperation(value = "页面字段树")
    @GetMapping("/getFieldsTreeByListOrInfo")
    @ResponseAddHead
        @ApiImplicitParams({
    	@ApiImplicitParam(name="code",value="列表或详情编码",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="m_type",value="类型",required=true,dataType="String",paramType="query")
    })
    public RequestResult<Map<String,Object>> getFieldsTreeByListOrInfo( @RequestParam(value="code") String code,
    		@RequestParam(value="m_type") String mType) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> buttonList = actionEventService.getFieldsTreeByListOrInfo(code, mType);
        result.setList( buttonList );
        return result;
    }
    
    @ApiOperation(value = "页面按钮字段")
    @GetMapping("/getPageButtonAndField")
    @ResponseAddHead
        @ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query")
    public RequestResult<Map<String,Object>> getPageButtonAndField( @RequestParam(value="menu_id") String menuId) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> buttonList = menuConfigService.getPageButtonAndField( menuId);
        result.setList( buttonList );
        return result;
    }
}
