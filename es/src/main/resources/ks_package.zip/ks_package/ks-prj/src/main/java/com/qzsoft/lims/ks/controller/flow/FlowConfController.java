package com.qzsoft.lims.ks.controller.flow;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.flow.conf.FlowConfService;
import com.qzsoft.lims.ks.vo.CommonTreeVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @Description 流程引擎配置
 * @Date 2021/3/5
 */
@Api(value = "流程引擎配置", tags = "流程引擎配置")
@RestController
@TagResource("流程引擎配置")
@RequestMapping("/flowConf")
@Slf4j
public class FlowConfController {

    @Autowired
    private FlowConfService flowConfService;

    @ApiOperation(value = "流程定义树")
    @GetMapping("/getFlowTree")
    @ResponseAddHead
    public RequestResult<CommonTreeVO> getFlowTree() {
        RequestResult<CommonTreeVO> result = new RequestResult<>();
        result.setList( flowConfService.getFlowTree() );
        return result;
    }

    @ApiOperation(value = "流程定义详情")
    @GetMapping("/getFlowDefInfo")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowDefInfo(String pFlowCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj( flowConfService.getFlowDefInfo( pFlowCode ) );
        return result;
    }

    @ApiOperation(value = "保存流程定义")
    @PostMapping("/saveFlowDef")
    @TagResource("保存流程定义")
    @ResponseAddHead
    public RequestResult<Boolean> saveFlowDef(@RequestParam(value = "flowDefData") String flowDefDataStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.saveFlowDef( flowDefDataStr ) );
        return result;
    }

    @ApiOperation(value = "保存初始化环节")
    @PostMapping("/saveInitNode")
    @ResponseAddHead
    @TagResource("保存初始化环节")
    public RequestResult<Boolean> saveInitNode(@RequestParam(value = "p_flow_code") String pFlowCode,
                                               @RequestParam(value = "p_flow_node", required = false) String pFlowNode,
                                               @RequestParam(value = "label", required = false) String label,
                                               @RequestParam(value = "id", required = false) Long id,
                                               @RequestParam(value = "flowBusStDatas", required = false) String flowBusStDatasStr,
                                               @RequestParam(value = "flowStDatas", required = false) String flowStDatasStr
                                               ) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.saveInitNode( pFlowCode, pFlowNode, label, id, flowBusStDatasStr, flowStDatasStr ) );
        return result;
    }

    @ApiOperation(value = "删除流程")
    @PostMapping("/deleteFlow")
    @ResponseAddHead
    @TagResource("删除流程")
    public RequestResult<Boolean> deleteFlow(String id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.deleteFlow( id ) );
        return result;
    }

    @ApiOperation(value = "删除初始化环节")
    @PostMapping("/deleteInitNode")
    @ResponseAddHead
    @TagResource("删除初始化环节")
    public RequestResult<Boolean> deleteInitNode(@RequestBody List<Long> ids) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.deleteInitNode( ids ) );
        return result;
    }

    @ApiOperation(value = "环节初始化列表")
    @GetMapping("/getInitNodeList")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getInitNodeList(String pFlowCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( flowConfService.getInitNodeList( pFlowCode ) );
        return result;
    }

    @ApiOperation(value = "获取基础环节")
    @GetMapping("/getBaseNode")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getBaseNode(String pFlowCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( flowConfService.getBaseNode( pFlowCode ) );
        return result;
    }

    @ApiOperation(value = "流程节点事件弹窗")
    @GetMapping("/getFlowNodeEvent")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowNodeEvent(@RequestParam(value = "nodeIdCode") String nodeIdCode,
                                                               @RequestParam(value = "nodeOpt") String nodeOpt) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( flowConfService.getFlowNodeEvent( nodeIdCode, nodeOpt ) );
        return result;
    }

    @ApiOperation(value = "保存流程节点事件弹窗")
    @PostMapping("/saveFlowNodeEvent")
    @ResponseAddHead
    @TagResource("保存流程节点事件弹窗")
    public RequestResult<Boolean> saveFlowNodeEvent(@RequestParam(value = "nodeIdCode") String nodeIdCode,
                                                    @RequestParam(value = "nodeOpt") String nodeOpt,
                                                    @RequestParam(value = "nodeDatas") String nodeDatasStr,
                                                    @RequestParam(value = "isAddSign", required = false) Boolean isAddSign) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.saveFlowNodeEvent( nodeIdCode, nodeOpt, nodeDatasStr, isAddSign ) );
        return result;
    }

    @ApiOperation(value = "流程线条件弹窗")
    @GetMapping("/getFlowLinkCond")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowLinkCond(@RequestParam(value = "linkIdCode") String linkIdCode) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj( flowConfService.getFlowLinkCond( linkIdCode ) );
        return result;
    }

    @ApiOperation(value = "保存流程线条件弹窗")
    @PostMapping("/saveFlowLinkCond")
    @ResponseAddHead
    @TagResource("保存流程线条件弹窗")
    public RequestResult<Boolean> saveFlowLinkCond(@RequestParam(value = "linkIdCode") String linkIdCode,
                                                   @RequestParam(value = "linkConds") String linkCondsStr,
                                                   @RequestParam(value = "isAddSign", required = false) Boolean isAddSign) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.saveFlowLinkCond( linkIdCode, linkCondsStr, isAddSign ) );
        return result;
    }

    @ApiOperation(value = "流程图数据")
    @GetMapping("/getFlowPicData")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowPicData(@RequestParam(value = "pFlowCode", required = false) String pFlowCode,
                                                             @RequestParam(value = "instanceId", required = false) String instanceId,
                                                             @RequestParam(value = "isAddSign", required = false) Boolean isAddSign) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( flowConfService.getFlowPicData( pFlowCode, isAddSign, instanceId ) );
        return result;
    }


    @ApiOperation(value = "保存流程图数据")
    @PostMapping("/saveFlowPicData")
    @ResponseAddHead
    @TagResource("保存流程图数据")
    public RequestResult<Boolean> saveFlowPicData(@RequestParam(value = "pFlowCode", required = false) String pFlowCode,
                                                  @RequestParam(value = "flowData") String flowDataStr,
                                                  @RequestParam(value = "isAddSign", required = false) Boolean isAddSign,
                                                  @RequestParam(value = "instanceId", required = false) String instanceId ) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.saveFlowPicData( pFlowCode, flowDataStr, isAddSign, instanceId ) );
        return result;
    }

    @ApiOperation(value = "启用激活")
    @PostMapping("/active")
    @ResponseAddHead
    @TagResource("启用激活")
    public RequestResult<Boolean> active(@RequestParam(value = "pFlowCode") String pFlowCode) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.active( pFlowCode ) );
        return result;
    }


    @ApiOperation(value = "流程动态参数列表")
    @GetMapping("/getFlowParaList")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowParaList( @RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
                                                          @RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
        RequestResult<Map<String, Object>> result =  flowConfService.getFlowParaList( pageNum, pageSize );
        return result;
    }

    @ApiOperation(value = "流程动态参数详情")
    @GetMapping("/getFlowParaInfo")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowParaInfo(Long id) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj( flowConfService.getFlowParaInfo( id));
        return result;
    }

    @ApiOperation(value = "保存流程动态参数")
    @PostMapping("/saveFlowPara")
    @ResponseAddHead
    @TagResource("保存流程动态参数")
    public RequestResult<Boolean> saveFlowPara(@RequestBody Map<String, Object> paraMap) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.saveFlowPara( paraMap));
        return result;
    }

    @ApiOperation(value = "删除流程动态参数")
    @PostMapping("/deleteFlowPara")
    @ResponseAddHead
    @TagResource("删除流程动态参数")
    public RequestResult<Boolean> deleteFlowPara(@RequestBody List<Long> ids) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.deleteFlowPara( ids ) );
        return result;
    }

    @ApiOperation(value = "流程业务字段选择")
    @GetMapping("/getFlowBusFields")
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getFlowBusFields(@RequestParam(value = "pFlowCode", required = false) String pFlowCode,
                                                               @RequestParam(value = "isAddSign", required = false) Boolean isAddSign,
                                                               @RequestParam(value = "instanceId", required = false) String instanceId) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( flowConfService.getFlowBusFields( pFlowCode, isAddSign, instanceId ) );
        return result;
    }

    @ApiOperation(value = "删除线条件")
    @PostMapping("/deleteLinkCond")
    @ResponseAddHead
    @TagResource("删除线条件")
    public RequestResult<Boolean> deleteLinkCond(Long id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj( flowConfService.deleteLinkCond( id ) );
        return result;
    }


    @ApiOperation(value = "导出流程")
    @PostMapping("/exportFlow")
    @ResponseAddHead
    public void exportFlow(@RequestParam(value="p_flow_code") String pFlowCode, HttpServletResponse response) {
        try {
            String flowData = flowConfService.exportFlow(pFlowCode);
            response.setContentType("text/html;charset=utf-8");
            response.getWriter().write(flowData);

        }catch (Exception e) {
            log.error(this.getClass().getSimpleName() + ".exportFlow()", e);
        }
    }

    @ApiOperation(value = "导入流程")
    @PostMapping("/importFlow")
    @ResponseAddHead
    public RequestResult<Boolean> importFlow(@RequestParam("file") MultipartFile file, @RequestParam(value="parent_code") String parentCode) {
        RequestResult<Boolean> result = new RequestResult<>();
        boolean importYn = flowConfService.importFlow( file, parentCode );
        result.setObj(importYn);
        return result;
    }

}
