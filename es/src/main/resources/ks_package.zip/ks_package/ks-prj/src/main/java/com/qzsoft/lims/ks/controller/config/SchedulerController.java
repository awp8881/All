package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.scheduler.admin.JobConfService;
import com.qzsoft.lims.ks.scheduler.admin.JobHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Api(value = "任务调度", tags = "任务调度")
@RestController
@TagResource("任务调度")
@RequestMapping("/scheduler")
@Slf4j
public class SchedulerController {

    @Autowired
    private JobConfService jobConfService;

    @Autowired
    private JobHandler jobHandler;

    @ApiOperation(value = "任务管理列表")
    @GetMapping("/getPageList")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getPageList(
            @RequestParam(value = "job_name", required = false) String jobName,
            @RequestParam(value = "job_status", required = false) String jobStatus,
            @RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
            @RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
        RequestResult<Map<String, Object>> result = jobConfService.getPageList( jobName, jobStatus, pageNum, pageSize);
        return result;
    }

    @ApiOperation(value = "任务详情")
    @PostMapping("/getJob")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getJob(@RequestParam(value = "id") Long id) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj(jobConfService.getJob( id ));
        return result;
    }

    @ApiOperation(value = "任务保存")
    @PostMapping("/saveJob")
    @TagResource("任务保存")
    @ResponseAddHead
        public RequestResult<Boolean> saveJob(@RequestParam(value = "jobData") String jobDataStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(jobConfService.saveJob( jobDataStr ));
        return result;
    }


    @ApiOperation(value = "启动")
    @PostMapping("/start")
    @ResponseAddHead
    @TagResource("启动")
        public RequestResult<Boolean> start(@RequestParam(value = "id") Long id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(jobHandler.start( id, null ));
        return result;
    }

    @ApiOperation(value = "手动执行一次")
    @PostMapping("/exeOne")
    @ResponseAddHead
    @TagResource("手动执行一次")
        public RequestResult<Boolean> exeOne(@RequestParam(value = "id") Long id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(jobHandler.exeOne( id ));
        return result;
    }

    @ApiOperation(value = "暂停")
    @PostMapping("/pause")
    @ResponseAddHead
    @TagResource("暂停")
        public RequestResult<Boolean> pause(@RequestParam(value = "id") Long id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(jobHandler.pauseMsg( id ));
        return result;
    }

    @ApiOperation(value = "恢复")
    @PostMapping("/resume")
    @ResponseAddHead
    @TagResource("恢复")
        public RequestResult<Boolean> resume(@RequestParam(value = "id") Long id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(jobHandler.resumeMsg( id ));
        return result;
    }

    @ApiOperation(value = "删除")
    @PostMapping("/delete")
    @ResponseAddHead
    @TagResource("删除")
        public RequestResult<Boolean> delete(@RequestParam(value = "id") Long id) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(jobHandler.deleteMsg( id ));
        return result;
    }

}
