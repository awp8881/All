package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.customize.UserCustomizeService;
import com.qzsoft.lims.ks.util.UserDataUtil;
import com.qzsoft.lims.ks.vo.UserTHConfigVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(value = "用户个性化配置", tags = "用户个性化配置")
@RestController
@RequestMapping("/userCustomize")
public class UserCustomizeController {

    @Autowired
    private UserCustomizeService userCustomizeService;

    //列表表头自定义  th
    @ApiOperation("列表表头自定义，id值存在就修改，不存在就新增")
    @PostMapping("/defindTHConfig")
    @ApiImplicitParams({
            @ApiImplicitParam(name="JID",value="JID", required=true, dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<UserTHConfigVO> defindTHConfig(UserTHConfigVO userTHConfig){
        RequestResult<UserTHConfigVO> result = new RequestResult<UserTHConfigVO>();
        userTHConfig.setPara_type("list_def");
        userTHConfig = userCustomizeService.saveUserCustomize(UserDataUtil.getUsId(),userTHConfig);
        result.setObj( userTHConfig );
        return result;
    }

    @ApiOperation("获取用户所有的自定义列表")
    @GetMapping("/getAllTHConfig")
    @ApiImplicitParams({
            @ApiImplicitParam(name="menu_id",value="menu_id 菜单id", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="m_code",value="m_code 列表编码", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID", required=false, dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<UserTHConfigVO> getAllTHConfig( String menu_id, String m_code ){

        RequestResult<UserTHConfigVO> result = new RequestResult<>();
        List<UserTHConfigVO> userTHConfigVOList = userCustomizeService.getAllTHConfig( UserDataUtil.getUsId(), menu_id, m_code );
        result.setList( userTHConfigVOList );
        return result;
    }

    @ApiOperation("获取用户正在使用的自定义表头")
    @GetMapping("/getActiveTHConfig")
    @ApiImplicitParams({
            @ApiImplicitParam(name="menu_id",value="menu_id 菜单id", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="m_code",value="m_code 列表编码", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID", required=false, dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<UserTHConfigVO> getActiveTHConfig( String menu_id, String m_code ){

        RequestResult<UserTHConfigVO> result = new RequestResult<>();
        UserTHConfigVO userTHConfigVO = userCustomizeService.getActiveTHConfig( UserDataUtil.getUsId(), menu_id, m_code );
        result.setObj( userTHConfigVO );
        return result;
    }

    @ApiOperation("删除用户自定义表头")
    @PostMapping("/delTHConfig")
    @ApiImplicitParams({
            @ApiImplicitParam(name="JID",value="JID", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="id",value="表头自定义id", required=false, dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Boolean> delTHConfig( long id ){
        RequestResult<Boolean> result = new RequestResult<>();
        Boolean isSucess = userCustomizeService.delTHConfig( UserDataUtil.getUsId(), id  );
        result.setObj( isSucess );
        return result;
    }

    @ApiOperation("详情宽度定义")
    @PostMapping("/defindInfoWidthConfig")
    @ApiImplicitParams({
            @ApiImplicitParam(name="menu_id",value="menu_id 菜单id", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="m_code",value="m_code 列表编码", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="width_per",value="width_per 详情宽度", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID", required=true, dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<UserTHConfigVO> defindInfoWidthConfig( String menu_id, String m_code, String width_per  ){
        RequestResult<UserTHConfigVO> result = new RequestResult<UserTHConfigVO>();
        UserTHConfigVO infoWidthConfig = userCustomizeService.defindInfoWidthConfig(UserDataUtil.getUsId(),menu_id, m_code, width_per);
        result.setObj( infoWidthConfig );
        return result;
    }

    @ApiOperation("获取详情宽度定义")
    @GetMapping("/getDefindInfoWidthConfig")
    @ApiImplicitParams({
            @ApiImplicitParam(name="menu_id",value="menu_id 菜单id", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="m_code",value="m_code 列表编码", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID", required=true, dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<UserTHConfigVO> getDefindInfoWidthConfig( String menu_id, String m_code  ){
        RequestResult<UserTHConfigVO> result = new RequestResult<UserTHConfigVO>();
        UserTHConfigVO infoWidthConfig = userCustomizeService.getDefindInfoWidthConfig(UserDataUtil.getUsId(),menu_id, m_code );
        result.setObj( infoWidthConfig );
        return result;
    }


    @ApiOperation("用户自定义习惯配置")
    @PostMapping("/saveCustomizeConfig")
    @ApiImplicitParams({
            @ApiImplicitParam(name="menu_id",value="menu_id 菜单id", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="m_code",value="m_code 列表编码", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="para_type",value="配置类型", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="user_conf",value="自定义配置", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID", required=true, dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<UserTHConfigVO> saveCustomizeConfig( String menu_id, String m_code, String para_type, String user_conf  ){
        RequestResult<UserTHConfigVO> result = new RequestResult<UserTHConfigVO>();
        UserTHConfigVO infoWidthConfig = userCustomizeService.saveCustomizeConfig(UserDataUtil.getUsId(),menu_id, m_code, para_type,user_conf );
        result.setObj( infoWidthConfig );
        return result;
    }

    @ApiOperation("获取用户自定义习惯配置")
    @GetMapping("/getCustomizeConfig")
    @ApiImplicitParams({
            @ApiImplicitParam(name="menu_id",value="menu_id 菜单id", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="m_code",value="m_code 列表编码", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="para_type",value="配置类型", required=false, dataType="String",paramType="query"),
            @ApiImplicitParam(name="JID",value="JID", required=true, dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<UserTHConfigVO> getCustomizeConfig( String menu_id, String m_code, String para_type  ){
        RequestResult<UserTHConfigVO> result = new RequestResult<UserTHConfigVO>();
        UserTHConfigVO infoWidthConfig = userCustomizeService.getCustomizeConfig(UserDataUtil.getUsId(),menu_id, m_code,para_type );
        result.setObj( infoWidthConfig );
        return result;
    }
}
