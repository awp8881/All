package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.SqlRecordCacheService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @author pjh
 * @Title: SqlRecordController
 * @Description: TODO
 * @date 2018/12/26 18:45
 */
@Api(value = "sql记录查询", tags = "sql记录查询")
@RestController
@RequestMapping("/sqlrecord")
@Slf4j
public class SqlRecordController {

    @Autowired
    SqlRecordCacheService sqlRecordCacheService;

    @ApiOperation("获取执行sql源码")
    @GetMapping("/getSqlSource")
    @ResponseAddHead
        @ApiImplicitParams({
            @ApiImplicitParam(name="completeSqlKey",value="完整sqlkey",required=false,dataType="string",paramType="query")
    })
    public RequestResult<String> getTableSqlList( @RequestParam(value="completeSqlKey") String completeSqlKey ) {
        String sqlFromCache = sqlRecordCacheService.getSqlFromCache(completeSqlKey);
        RequestResult<String> result=new RequestResult(sqlFromCache);
        return result;

    }

}
