package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.dao.BaseDao;

/**
 * 属性配置-dao接口
 * @author hqp
 *
 */
public interface KsModelAttrBao extends BaseDao {
	/**
	 * 删除后插入
	 * @param button_code 按钮编码
	 * @param modelAttrList 属性配置列表
	 * @return
	 */
	Boolean batchUpdate(Long menu_id,String button_code,List<Map<String,Object>> modelAttrList);
}
