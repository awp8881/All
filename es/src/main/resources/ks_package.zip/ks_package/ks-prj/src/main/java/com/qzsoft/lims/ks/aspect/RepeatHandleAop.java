package com.qzsoft.lims.ks.aspect;

import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.TokenService;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * 重复处理拦截器
 */
@Aspect
@Component
@Order(Integer.MAX_VALUE-1)
public class RepeatHandleAop {

    @Autowired
    TokenService tokenService;

    @Pointcut("execution(* com.qzsoft.lims.ks.controller..*(..))")
    public void handleException() {
    }

    @Around(value = "handleException()")
    public Object doAround(ProceedingJoinPoint pjp) {

        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String accessToken= request.getParameter("accessTokenLock");
        try {
            if(StringUtils.isBlank( accessToken )){
                return pjp.proceed();
            }
            synchronized (accessToken.intern()) {
                //判断令牌是否有效
                boolean isValidToken = tokenService.useToken(accessToken);
                //是有效的令牌进行下一步操作
                if (isValidToken) {

                    Object proceed = pjp.proceed();
                    if (proceed instanceof RequestResult) {
                        if (!((RequestResult) proceed).getStatus()) {
                            tokenService.recoverToken(accessToken);
                        } else {
                            tokenService.useTokenFin(accessToken);
                        }
                    }
                    return proceed;

                } else { //无效的令牌直接返回前端
                    RequestResult result = RequestResult.error("正在处理该操作，稍后再试");
                    return result;
                }
            }

        }catch (Throwable t){
            //还原出错的令牌
            if( StringUtils.isNotBlank(accessToken) ){
                tokenService.recoverToken( accessToken );
            }
            RequestResult result = RequestResult.error( t );
            return result;
        }
    }

}
