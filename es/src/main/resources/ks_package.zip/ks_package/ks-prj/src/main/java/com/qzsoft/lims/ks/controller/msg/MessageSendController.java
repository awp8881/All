package com.qzsoft.lims.ks.controller.msg;

import com.qzsoft.common.annotation.RequestLimit;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.msg.MessageSendService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 消息发送处理
 * @author yuanj
 */
@Api(value = "消息发送", tags = "消息发送")
@RestController
@RequestMapping("/message")
@Slf4j
public class MessageSendController {

    @Autowired
    private MessageSendService messageSendService;



    @ApiOperation(value = "发送消息")
    @PostMapping("/sendMessage")
    @ResponseAddHead
    @RequestLimit(count = 1,time = 3000)
    @ApiImplicitParam(name="sendParam",value="发送的json参数",required=true,dataType="String",paramType="query")
    public RequestResult<Object> sendMessage(@RequestParam(value = "sendParam") String sendParam) {
        RequestResult<Object> result = new RequestResult<>();
        messageSendService.sendMessage(sendParam);
        result.setObj("");
        return result;
    }



}
