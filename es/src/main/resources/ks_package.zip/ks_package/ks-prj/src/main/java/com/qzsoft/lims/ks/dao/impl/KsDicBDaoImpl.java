package com.qzsoft.lims.ks.dao.impl;

import java.util.List;

import com.qzsoft.common.annotation.CacheAvl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.constants.Constant;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.eum.DicdStEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;

/**
 * 字典dao实现
 * @author zf
 *
 */
@Repository
public class KsDicBDaoImpl extends BaseDaoImpl implements KsDicBDao{
	private static final String TABLE_NAME = "ks_dic_b";

	/**
	 * 通过字典代码获取
	 * @param di_cd
	 * @return
	 */
	@Override
	public List<Record> getByDicd(String di_cd) {
		if(StringUtils.isNotEmpty(di_cd)){
			List<Record> recordList= DbEx.find("select * from "+TABLE_NAME+" where (parent_code = ? or code = ? ) and st=? order by disp_or+0",di_cd,di_cd,DicdStEnum.JH.getCode());
			return recordList;
		}
		return null;
	}

	/**
	 * 获取字典
	 * @return
	 */
	@Override
	public List<Record> getAllList() {
		return DbEx.find("select * from "+TABLE_NAME+" where st=? order by disp_or+0 ",DicdStEnum.JH.getCode());
	}

	/**
	 * 获取父子节点字典代码
	 */
	@Override
	public List<Record> getByParentCode(String di_cd) {
		if(StringUtils.isNotEmpty(di_cd)){
			List<Record> recordList= DbEx.find("select * from "+TABLE_NAME+" where parent_code = ? and st=? order by disp_or+0",di_cd,DicdStEnum.JH.getCode());
			return recordList;
		}
		return null;
	}

	/**
	 * 通过根节点获取列表
	 */
	@Override
	public List<Record> getByRoot() {
		return DbEx.find("select * from "+TABLE_NAME+" where  parent_code=? and st=? order by disp_or+0", Constant.DICD_ROOT, DicdStEnum.JH.getCode());
	}

	/**
	 * 获取字典分类
	 * */
	@Override
	public Record getCode(String di_cd) {
		if(StringUtils.isNotBlank(di_cd)){
			return DbEx.findFirst("select * from "+TABLE_NAME+" where code=? and st=? ", di_cd , DicdStEnum.JH.getCode());
		}
		return null;
	}

	//字典描述
	@Override
	public String getDicdDesc(String diCd) {
		String str = null;
		if (StringUtils.isBlank(diCd)) {
			return str;
		}
		String sql = "select val from "+TABLE_NAME+" where code=? and st=?";
		Record record = selectFirstOneBySql(sql, diCd, DicdStEnum.JH.getCode());
		if (null == record) {
			return str;
		}
		return record.getStr("val");
		
	}

	//字典分类描述  dicdPara逗号隔开
	@Override
	public String getDicdParaDesc(String dicd, String dicdPara) {
		String str = null;
		String sql = "select val from "+TABLE_NAME+" where parent_code=? and locate(code,?)>0 and st=? order by disp_or+0";
		List<Record> records = selectListBySql(sql, dicd, dicdPara, DicdStEnum.JH.getCode());
		if (null == records || records.isEmpty()) {
			return str;
		}
		List<String> list = DataBaseUtil.record2String(records, "val");
		return StringUtil.listTOString(list);
	}

}
