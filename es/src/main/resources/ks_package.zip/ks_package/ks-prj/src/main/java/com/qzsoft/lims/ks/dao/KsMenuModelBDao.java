package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.eum.MTypeEnum;
import com.qzsoft.lims.ks.vo.SourceConfigVO;

/**
 * 菜单组成表  大列表+详情
 * */
public interface KsMenuModelBDao extends BaseDao{
	
	/**
	 * 保存菜单  大列表
	 * @param sourceConfigVO
	 * @param new_m_code
	 * @return
	 */
	Boolean save(SourceConfigVO sourceConfigVO,String new_m_code);
	
	/**
	 * 获取详情页table列表
	 * @param menu_id
	 * @return
	 */
	List<Map<String,Object>> getInfoTableList(Long menu_id);

	/**
	 * 获取info_code分组
	 * @param m_code
	 * @param outerInfo
	 * @return
	 */
	List<Record> selectInfoCodeGroupList(String m_code, MTypeEnum outerInfo);
	
	/**
	 * 详情列表数据
	 * @param code
	 * @return
	 */
	Record getNameByCode(String code);
	
	List<Record> getAllListInfo( String menuId);
	
	boolean saveByIframe( SourceConfigVO sourceConfigVO);
	
	Record getByMtype( String menuId, String mType);
	
	//小列表父级数据源
	boolean updateBusCode(String menuId, String mCode, Set<String> codeList);
	
	//清除小列表父级数据源
	boolean deleteBusCode(String code);

	//详情列表版本号
	String getMenuModelVer( Map<String,Object> map, String mType);

	/**
	 * 获取列表包含信息的层级结构名称
	 * @param menu_id
	 * @return
	 */
	List<Map<String,Object>> getMenuListTree(String menu_id);

	boolean updateMenuName(String menuId, String menuName);

	List<Record> getByListInfo(String menuId, String type);
}
