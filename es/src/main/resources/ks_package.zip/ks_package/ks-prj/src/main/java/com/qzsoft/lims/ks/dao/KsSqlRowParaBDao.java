package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;

/**
 * 列表行条件参数配置
 * @author zf
 *
 */
public interface KsSqlRowParaBDao {
	/**
	 *  列表行条件参数配置
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	List<Record> getRowParaList(String m_code, String m_code_type);
	

	Boolean saveGroupCondParas( List<Map<String, Object>> condParas, Integer isSaveAs, String oldMCode);
}
