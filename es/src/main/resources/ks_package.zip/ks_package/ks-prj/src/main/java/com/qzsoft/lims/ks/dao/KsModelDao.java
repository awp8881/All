package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.SourceConfigVO;

/**
 * 模版定义dao
 * @author zf
 *
 */
public interface KsModelDao extends BaseDao{
	
	/**
	 * 根据ID查询数据
	 * @param id
	 * @return
	 * */
	Record selectById(Long id);
	
	/**
	 * 通过模板编码获取模板
	 * @param m_code
	 * @param m_type
	 * @return
	 */
	List<Record> getListByMcode(String m_code,String m_type);
	
	/**
	 * 页面配置新增保存模板
	 * @param sourceConfigVO
	 * @param new_m_code
	 * @return
	 */
	Boolean save(SourceConfigVO sourceConfigVO,String new_m_code);
	
	/**
	 * 通过模板名称获取模板列表
	 * @return
	 */
	List<Record> findAll(String m_name,String m_type);
	
	/**
	 * 获取组件列表
	 * @param m_name
	 * @return
	 */
	List<Record> getCompList(String m_name);
	
	Record getByMcode( String m_code, String m_code_type);

	/**
	 * 关联新增初始model
	 * @param sqlName
	 * @return
	 */
	Boolean saveBySource(String sqlName, String oldSqlName, Boolean isEdit);

    Record getByMeunId(String menu_id);
}
