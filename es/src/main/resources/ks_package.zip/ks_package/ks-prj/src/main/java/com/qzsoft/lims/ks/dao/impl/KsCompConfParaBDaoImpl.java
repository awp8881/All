package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.dao.KsCompConfParaBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 组件参数配置管理-dao实现
 * @author hqp
 *
 */
@Repository
public class KsCompConfParaBDaoImpl extends BaseDaoImpl implements KsCompConfParaBDao {
	private static final String TABLE_NAME = "ks_comp_conf_para_b";
	
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	@Override
	public Boolean save(Record record) {
		return super.save(TABLE_NAME,record);
	}
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	@Override
	public Boolean update(Record record) {
		return super.update(TABLE_NAME,record);
	}
	
	/**
	 * 删除
	 * @param compCode 组件编码
	 * @return
	 */
	@Override
	public Boolean deleteByCompCode(String compCode) {
		return super.deleteByCustom(TABLE_NAME, "comp_code", compCode);
	}
	
	
	/**
	 * 根据组件编码查询
	 * @return
	 */
	@Override
	public List<Record> getListByCompCode(String compCode) {
		return DbEx.find("select * from " + TABLE_NAME+" where comp_code = ? order by para_order+0 ",compCode);
	}
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	@Override
	public Record getOne(Long id) {
		return super.selectById(TABLE_NAME,id);
	}

	@Override
	public Boolean saveCompData(List<Map<String, Object>> compParas, String compCode, String menuId) {
		boolean isSave = true;
		if (null == compParas || compParas.isEmpty()){
			return isSave;
		}

		int count = 1;
		for (Map<String, Object> paraMap : compParas) {
			paraMap.put("comp_code", compCode);
			paraMap.put("menu_id", menuId);
			paraMap.put("cr_dm", DateUtil.getNowDateTimeStr());
			paraMap.put("up_ver", "1");
			paraMap.put("para_order", count);
			paraMap.remove("def_code");
			paraMap.remove("exe_type");
			paraMap.remove("comp_type");
			paraMap.remove("dicParasStr");
			paraMap.remove("dicParas");
			paraMap.remove("di_cd_str");
			count++;
		}
		List<Record> records = DataBaseUtil.map2Record( compParas );
		saveList( TABLE_NAME, records);
		return isSave;
	}
}
