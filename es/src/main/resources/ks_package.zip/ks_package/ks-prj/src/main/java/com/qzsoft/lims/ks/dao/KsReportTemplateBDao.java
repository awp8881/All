package com.qzsoft.lims.ks.dao;

import com.qzsoft.common.dao.BaseDao;

public interface KsReportTemplateBDao extends BaseDao {
}
