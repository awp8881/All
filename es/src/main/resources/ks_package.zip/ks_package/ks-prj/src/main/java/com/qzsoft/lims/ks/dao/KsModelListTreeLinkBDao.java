package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsModelListTreeLinkBDao extends BaseDao{

	/**
	 * 删除后插入
	 * @param treeLinkList
	 * @param new_m_code
	 * @param old_m_code
	 * @return
	 */
	Boolean  batchUpdate(List<Map<String, Object>> treeLinkList, String new_m_code,String old_m_code,String menu_id);
	
	/**
	 * 详情弹窗赋值批量操作
	 * @param popupConfigList
	 * @param data_code
	 * @return
	 */
	Boolean  batchUpdateInfo(List<Map<String, Object>> popupConfigList,String data_code);

	List<Record> getByDataCode(String dataCode);
}
