package com.qzsoft.lims.ks.dao.event.impl;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.qzsoft.lims.ks.util.TableHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondParaBDao;
import com.qzsoft.lims.ks.eum.ButtonParaTypeEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;

@Repository
public class KsSqlCondParaBDaoImpl extends BaseDaoImpl implements KsSqlCondParaBDao{
	
	private static final String TABLE_NAME = "ks_sql_cond_para_b";
	
	@Autowired
	private KsDicBDao ksDicBDao;

	/**
	 *  条件组
	 */
	@Override
	public List<Record> getByPCode(String pCode) {
		String condParaSql = "select * from "+TABLE_NAME+" where p_code=? order by para_order+0";
		List<Record> condParaList = selectListBySql(condParaSql, pCode);
		parse(condParaList);
		return condParaList;
	}

	/**
	 * 批量保存
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> allCondParaList) {
		boolean succYn = true;
		if (null == allCondParaList || allCondParaList.isEmpty()) {
			return succYn;
		}
		for (Map<String, Object> map : allCondParaList) {
			map.put("cr_dm", DateUtil.getNowDateTimeStr());
			map.put("up_ver", "1");
			map.remove("dicDesc");
			map.remove("dicParaDesc");
		}
		List<Record> recordList = DataBaseUtil.map2Record(allCondParaList);
		return saveList(TABLE_NAME, recordList);
	}
	
	
	private void parse(List<Record> condParaList) {
		if (null == condParaList || condParaList.isEmpty()) {
			return;
		}
		for (Record record : condParaList) {
			String paraType = record.getStr("para_type");
			String diCd = record.getStr("di_cd");
			String paraVal = record.getStr("para_val");
			
			if ( !ButtonParaTypeEnum.ZDJ.getCode().equals(paraType)) {
				continue;
			}
			Record dicRecord = ksDicBDao.getCode(diCd);
			String dicDesc = null != dicRecord ? dicRecord.getStr("val") : null;
			record.set("dicDesc", dicDesc);
			Record dicParaRecord = ksDicBDao.getCode(paraVal);
			String dicParaDesc = null != dicParaRecord ? dicParaRecord.getStr("val") : null;
			record.set("dicParaDesc", dicParaDesc);
		}

	}

	@Override
	public List<Record> getGroupCondParas( String pCode ) {
		String condParaSql = "select * from "+TABLE_NAME+" where p_code=? order by para_order+0";
		List<Record> condParaList = selectListBySql(condParaSql, pCode);
		return condParaList;
	}

	@Override
	public List<Record> getGroupCondsByCode(List<String> codes) {
		if (null == codes || codes.isEmpty()){
			return Lists.newArrayList();
		}
		String inSql = TableHelper.getInSql("gro_cond_code", codes);
		String sql = "select * from "+TABLE_NAME+" where 1=1 "+inSql;
		List<Record> condParaList = selectListBySql(sql, codes.toArray());
		return condParaList;
	}

	@Override
	@JFinalTx
	public Boolean saveGroupCondParas(List<Map<String, Object>> condParas) {
		boolean succYn = true;
		if (null == condParas || condParas.isEmpty()) {
			return succYn;
		}
		List<Record> recordList = DataBaseUtil.map2Record(condParas);
		return saveList(TABLE_NAME, recordList);
	}
}
