package com.qzsoft.lims.ks.controller;

import java.util.Map;

import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.log.OptLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.ControlConfigService;
import com.qzsoft.lims.ks.vo.KsMenuCVO;
import com.qzsoft.lims.ks.vo.SourceConfigVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
/**
 * 页面组件配置-控制器
 * @author zf
 *
 */
@Api(value = "页面组件配置", tags = "页面组件配置")
@RestController
@RequestMapping("/control/config")
@Slf4j
public class ControlConfigController {
	@Autowired
	private ControlConfigService controlConfigService;
	
	@ApiOperation(value="获取组件列表",notes="组件编码:m_code,名称:m_name,关联表:sql_rev,SQL:sql_name")
	@GetMapping("/getControlList")
		@ApiImplicitParam(name="m_name",value="组件名称",required=false,dataType="String",paramType="query")
	@ResponseAddHead
	public RequestResult<Map<String,Object>> getControlList(@RequestParam(value="m_name",required=false)String m_name) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(controlConfigService.getControlList(m_name));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getControlList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getControlList()", e);
		}
		return result;
	}
	
	@ApiOperation(value="通过选择的数据源获取页面属性模板",notes="tableSql:数据源信息;fieldList:字段列表，初始类型可能跟其他两种不一样;logicButtonList:工具栏列表;"
			+ "attrVO:综合属性对象")
	@GetMapping("/getModelData")
	@ResponseAddHead
		@ApiImplicitParams({
		@ApiImplicitParam(name="isFromLeft",value="是否左侧树加载:true是false否",required=false,dataType="Boolean",paramType="query"),
		@ApiImplicitParam(name="m_id",value="模板id",required=false,dataType="Long",paramType="query"),
		@ApiImplicitParam(name="m_code",value="模板编码",required=false,dataType="String",paramType="query"),
		@ApiImplicitParam(name="m_code_type",value="数据源类型：初始数据源CSSJY，组件数据源ZJSJY，页面数据源YMSJY",required=false,dataType="String",paramType="query")
	})
	public RequestResult<Map<String,Object>> getModelData(@RequestParam(value="m_id",required=false) Long m_id,@RequestParam(value="m_code",required=false) String m_code,
			@RequestParam(value="m_code_type",required=false) String m_code_type,@RequestParam(value="isFromLeft",required=false) Boolean isFromLeft) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
//			Map<String, Object> map=controlConfigService.getModelData(m_id, m_code, m_code_type,isFromLeft);
//			result=new RequestResult<>(map);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getModelData()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getModelData()", e);
		}
		return result;
	}
	
	@ApiOperation(value="保存左侧组件",notes="表：ks_model_c")
	@PostMapping("/saveControl")
	@ApiImplicitParam(name="m_name",value="模板名称",required=true,dataType="String",paramType="query")
	@ResponseAddHead
		public RequestResult<Boolean> saveControl(@RequestParam(value="m_name") String m_name) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isSave=controlConfigService.saveControl(m_name);
			result.setObj(isSave);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".save()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".save()", e);
		}
		return result;
	}
	
	@ApiOperation(value="保存")
	@PostMapping("/save")
	@ResponseAddHead
		@OptLog(module = "comp_list_save",remark = "组件保存")
	public RequestResult<Boolean> save(SourceConfigVO sourceConfigVO) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
//			Boolean isSave=controlConfigService.save(sourceConfigVO);
//			result.setObj(isSave);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".save()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".save()", e);
		}
		return result;
	}
	
	@ApiOperation(value="修改左侧组件",notes="表:ks_model_c true-保存成功，false-保存失败")
	@PostMapping("/update")
		@ApiImplicitParams({
		@ApiImplicitParam(name="m_name",value="模板名称",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="m_id",value="模板id",required=true,dataType="Long",paramType="query"),
		@ApiImplicitParam(name="up_ver",value="模板组件版本号",required=false,dataType="Integer",paramType="query"),
	})
	@ResponseAddHead
	public RequestResult<Boolean> update(@RequestParam(value="m_id")Long m_id,@RequestParam(value="m_name") String m_name,
			@RequestParam(value="up_ver") Integer up_ver) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isUpdate = controlConfigService.updateModel(m_id,m_name,up_ver);
			result.setObj(isUpdate);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".update()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".update()", e);
		}
		return result;

	}
	
	@ApiOperation(value="删除组件")
	@PostMapping("/delete")
	@ApiImplicitParam(name="m_id",value="模板id",required=true,dataType="Long",paramType="query")
	@ResponseAddHead
		public RequestResult<Boolean> delete(@RequestParam(value="m_id")Long m_id) {
		RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			Boolean isUpdate = controlConfigService.delete(m_id);
			result.setObj(isUpdate);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}
		return result;

	}

}
