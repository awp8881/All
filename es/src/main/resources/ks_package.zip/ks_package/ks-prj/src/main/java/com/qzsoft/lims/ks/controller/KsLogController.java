package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.log.LogService;
import com.qzsoft.lims.ks.service.logic.KsLogicConfService;
import com.qzsoft.lims.ks.service.logic.KsLogicParserService;
import com.qzsoft.lims.ks.service.logic.LogicReqService;
import com.qzsoft.lims.ks.vo.logic.KsLogicConfigVO;
import com.qzsoft.lims.ks.vo.logic.KsModelLogicMenuBVO;
import com.qzsoft.lims.ks.vo.logic.LogicBasTmpVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 逻辑编排配置-控制器
 */
@Api(value = "日志控制层", tags = "日志控制层")
@RestController
@RequestMapping("/log")
@Slf4j
public class KsLogController {

    private AtomicBoolean isStart = new AtomicBoolean(false);

    private LinkedBlockingQueue<Map<String,Object>> logQueue = new LinkedBlockingQueue();

    @Autowired
    LogService logService;

    @ApiOperation(value = "记录操作日志")
    @PostMapping("/recordOptLog")
        @ApiImplicitParam(name="id",value="逻辑主键",required=true,dataType="String",paramType="query")
    public RequestResult<Map<String,Object>> recordOptLog( @RequestBody  Map<String,Object> reqParam ) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        logQueue.add( reqParam );
        if (isStart.compareAndSet(false, true)) {
            new Thread(() -> {
                init();
            }).start();
        }
//        logService.recordOptLog( reqParam );
        return result;
    }


    public void init(){
        while (true){
            try{
                Map<String,Object> reqParam = logQueue.take();
                logService.recordOptLog( reqParam );
            }catch (Exception e){
                log.error(e.getMessage(), e);
            }

        }
    }

}
