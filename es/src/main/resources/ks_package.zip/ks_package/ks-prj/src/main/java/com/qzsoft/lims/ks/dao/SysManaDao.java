package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

import java.util.List;
import java.util.Map;

public interface SysManaDao extends BaseDao{

    List<Record> getManaFold();

    List<Record> getManaRoot();

    List<Record> getManaByPCode(String manaCode);

    Record getManaInfo(String manaCode);

    Boolean saveManaInfo(Map<String, Object> sysManaData);

    Boolean deleteMana(String manaCode);
}
