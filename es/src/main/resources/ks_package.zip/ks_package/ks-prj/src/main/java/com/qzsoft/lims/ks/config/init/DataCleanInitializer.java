package com.qzsoft.lims.ks.config.init;

import com.qzsoft.common.constants.CommonConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * @author pjh
 * @Title: DataCleanInitializer
 * @Description: TODO
 * @date 2018/12/19 15:33
 */
@Slf4j
@Component
public class DataCleanInitializer {

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    //清除admin登录数据
    public void cleanLoginUserJIDData(){

        log.info("执行清除登录用户相关数据动作");

        Set<Object> set=redisTemplate.keys(CommonConstants.GET_LOGINNAME_BY_JID+"*");
        if(null != set && !set.isEmpty()){
            redisTemplate.delete(set);
        }

        set=redisTemplate.keys(CommonConstants.SENS_JID_AND_MCODE+"*");
        if(null != set && !set.isEmpty()){
            redisTemplate.delete(set);
        }

        set=redisTemplate.keys(CommonConstants.SHIRO_ACTIVE_SESSION_CACHE+"*");
        if(null != set && !set.isEmpty()){
            redisTemplate.delete(set);
        }

        set=redisTemplate.keys(CommonConstants.TU_ENV+"*");
        if(null != set && !set.isEmpty()){
            redisTemplate.delete(set);
        }

        set=redisTemplate.keys(CommonConstants.SELECT_QUERY_JID_BUT+"*");
        if(null != set && !set.isEmpty()){
            redisTemplate.delete(set);
        }


    }
}
