package com.qzsoft.lims.ks.dao.impl;

import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsReportTemplateBDao;
import org.springframework.stereotype.Repository;

/**
 * @author pjh
 * @Title: KsReportTemplateBDaoImpl
 * @Description: TODO
 * @date 2018/8/7 14:47
 */
@Repository
public class KsReportTemplateBDaoImpl extends BaseDaoImpl implements KsReportTemplateBDao {


}
