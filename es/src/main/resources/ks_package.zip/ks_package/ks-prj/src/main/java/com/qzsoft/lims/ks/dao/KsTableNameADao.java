package com.qzsoft.lims.ks.dao;

import java.util.LinkedHashMap;
import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/** 
 * 业务表列表
 * 创建时间:2018-06-08 16:17:24 
 */ 
public interface KsTableNameADao  extends BaseDao {

	
	LinkedHashMap<String,String> getTableInfoByNotStartAs(String startString);
	
	/**
	 * 列表获取
	 * @return
	 */
	List<Record> getList();

}
