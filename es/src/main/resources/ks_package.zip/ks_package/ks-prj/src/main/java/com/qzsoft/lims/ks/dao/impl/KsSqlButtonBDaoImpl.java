package com.qzsoft.lims.ks.dao.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.comp.GroupCond;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.KsSqlButtonBDao;
import com.qzsoft.lims.ks.dao.KsSqlButtonParaBDao;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 按钮激活条件
 *
 */
@Repository
public class KsSqlButtonBDaoImpl extends BaseDaoImpl implements KsSqlButtonBDao{
	
	private static final String TABLE_NAME_B = "ks_sql_button_b";
	private static final String TABLE_NAME_C = "ks_sql_button_c";
	
	@Autowired
	private KsSqlButtonParaBDao ksSqlButtonParaBDao;

	@Autowired
	private KsDicBDao ksDicBDao;

	/**
	 * 按钮激活条件列表
	 * */
	@Override
	public List<List<Map<String, Object>>> getButtonList(String button_code, String m_code_type) {
		String table = TABLE_NAME_B;
		if(StringUtils.isNotBlank(m_code_type) && McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		String sql = "select * from "+table+" where button_code=? order by group_no+0,group_order+0";
		List<Record> buttonList = DbEx.find(sql,button_code);
		List<Record> buttonParaList = ksSqlButtonParaBDao.getButtonParaList(button_code, m_code_type);
		List<Record> allDicds = ksDicBDao.getAllList();
		return GroupCond.buildCommonCondList( buttonList, buttonParaList, allDicds, "button_code");
	}
	
	@Override
	public List<Record> getButtonList(String m_code, String info_code, String m_code_type) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			table = TABLE_NAME_C;
		}
		String sql = "select * from "+table+" where 1=1 ";
		List<String> list = new ArrayList<>();
		if(StringUtils.isNotBlank(m_code)){
			sql+= " and m_code=? and (info_code is null or info_code ='') ";
			list.add(m_code);
		} 
		if(StringUtils.isNotBlank(info_code)){
			sql+= " and info_code=? ";
			list.add(info_code);
		}
		sql+=" order by group_no+0,group_order+0";
		List<Record> buttonList = DbEx.find(sql,list.toArray());
		if ( null == buttonList || buttonList.isEmpty()){
			return buttonList;
		}
		List<Record> buttonParaList = ksSqlButtonParaBDao.getButtonParaList(m_code, info_code, m_code_type);
		DataBaseUtil.buildDicdSqlPara(buttonList, buttonParaList);
		return buttonList;
	}
	
	/**
	 * 删除后批量插入
	 */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> allButtonList,Integer isSaveAs, String old_m_code,String info_code, String menu_id) {
		boolean isSucc = true;
		String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
		String buttonParaTable = isSaveAs == YnEnum.N.getCode() ? "ks_sql_button_para_b" : "ks_sql_button_para_c";
		String code = StringUtils.isNotBlank(info_code) ? info_code : old_m_code;
		if (StringUtils.isBlank(code)){
			return isSucc;
		}
		String buttonSql = "delete from "+table+" where locate(?,button_code)>0 ";
		String buttonParaSql = "delete from "+buttonParaTable+" where locate(?,button_code)>0 ";

		DbEx.delete(buttonSql,code);
		DbEx.delete(buttonParaSql,code);

		if (null == allButtonList || allButtonList.isEmpty()){
			return isSucc;
		}
		List<Map<String, Object>> allParaList = Lists.newArrayList();
		for(Map<String, Object> map : allButtonList){
			map.put("menu_id", menu_id);
			String dic_paras_name=StringUtil.toString(map.get("dic_paras_name"));
			String sql_paras_name=StringUtil.toString(map.get("sql_paras_name"));

			DataBaseUtil.buildSaveDicdSqlPara( table,  map,  dic_paras_name,  sql_paras_name,  allParaList);
		}

		List<Record> recordList = DataBaseUtil.map2Record(allButtonList);
		isSucc = super.saveList(table, recordList);
		ksSqlButtonParaBDao.batchUpdate(allParaList,isSaveAs,old_m_code,info_code,menu_id);
		return isSucc;
	}

	@Override
	public Map<String, Object> getGroupConds(String mCode, String infoCode, String mCodeType) {
		String table = TABLE_NAME_B;
		if( McodeTypeEnum.ZJSJY.getCode().equals( mCodeType )){
			table = TABLE_NAME_C;
		}
		String sql = "select * from "+table+" where 1=1 ";
		List<String> list = new ArrayList<>();
		if(StringUtils.isNotBlank(mCode)){
			sql+= " and m_code=? and (info_code is null or info_code ='') ";
			list.add(mCode);
		}
		if(StringUtils.isNotBlank(infoCode)){
			sql+= " and info_code=? ";
			list.add( infoCode );
		}
		sql+=" order by group_no+0,group_order+0";
		List<Record> buttonList = DbEx.find(sql,list.toArray());
		List<Record> buttonParaList = ksSqlButtonParaBDao.getButtonParaList(mCode, infoCode, mCodeType);

		List<Record> allDicds = ksDicBDao.getAllList();
		return GroupCond.buildLogicCondList( buttonList, buttonParaList, allDicds, "button_code");
	}


	@JFinalTx
	@Override
	public Boolean saveGroupConds(List<List<Map<String, Object>>> groupConds, Integer isSaveAs, String pMCode, String infoCode, String menuId) {
		boolean isSucc = true;
		String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
		String buttonParaTable = isSaveAs == YnEnum.N.getCode() ? "ks_sql_button_para_b" : "ks_sql_button_para_c";
		String code = StringUtils.isNotBlank(infoCode) ? infoCode : pMCode;
		if (StringUtils.isBlank(code)){
			return isSucc;
		}
		String buttonSql = "delete from "+table+" where locate(?,button_code)>0 ";
		String buttonParaSql = "delete from "+buttonParaTable+" where locate(?,button_code)>0 ";

		DbEx.delete(buttonSql, code);
		DbEx.delete(buttonParaSql, code);

		if (null == groupConds || groupConds.isEmpty()){
			return isSucc;
		}
		Map<String, Object> condParaMap = Maps.newHashMap();
		condParaMap.put("menu_id", menuId);

		Map<String, Object> condMap = Maps.newHashMap( condParaMap );
		Set<String> relateFields = Sets.newHashSet();
		relateFields.add("m_code");
		relateFields.add("info_code");
		relateFields.add("button_code");
		relateFields.add("dic_paras_name");

		Map<String, Object> map = GroupCond.formatGroupConds( groupConds, condMap, condParaMap, relateFields, code);
		List<Map<String, Object>> conds = (List<Map<String, Object>>)map.get("conds");
		List<Map<String, Object>> condParas = (List<Map<String, Object>>)map.get("condParas");
		saveList(table, DataBaseUtil.map2Record( conds ));
		ksSqlButtonParaBDao.saveGroupCondParas( condParas, isSaveAs, pMCode, infoCode );
		return isSucc;
	}
}
