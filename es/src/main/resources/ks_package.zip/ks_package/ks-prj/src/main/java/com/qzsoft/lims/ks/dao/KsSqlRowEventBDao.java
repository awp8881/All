package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 行颜色
 * @author zf
 *
 */
public interface KsSqlRowEventBDao extends BaseDao{
	
	/**
	 * 行事件列表
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	List<Record> getRowEventByMcode(String m_code, String m_code_type, String eventType);

	/**
	 * 删除后插入
	 * @param colorList
	 * @param new_m_code
	 * @param isSaveAs
	 * @param old_m_code
	 * @return
	 */
	Boolean batchUpdate(List<Map<String,Object>> colorList, String new_m_code, Integer isSaveAs, String old_m_code, String menu_id);
}
