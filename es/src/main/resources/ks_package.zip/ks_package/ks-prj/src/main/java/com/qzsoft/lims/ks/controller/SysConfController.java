package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.SysConfServer;
import com.qzsoft.lims.ks.vo.KsSysConfBVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(value = "系统配置", tags = "系统配置")
@RestController
@RequestMapping("/sys/config")
@Slf4j
public class SysConfController {

    @Autowired
    private SysConfServer sysConfServer;

    @ApiOperation("保存或者更新配置")
    @PostMapping("/save")
    @ResponseAddHead
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="配置id",required=false,dataType="long",paramType="query"),
            @ApiImplicitParam(name="conf_type",value="配置类型",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="conf_val",value="配置值",required=true,dataType="string",paramType="query"),
            @ApiImplicitParam(name="remark",value="配置备注",required=false,dataType="string",paramType="query")
    })
    public RequestResult<KsSysConfBVO> saveConf( Long id, String conf_type, String conf_val,String remark ) {
        KsSysConfBVO ksSysConfBVO = sysConfServer.saveConf( id,conf_type,conf_val,remark );
        RequestResult<KsSysConfBVO> result=new RequestResult( ksSysConfBVO );
        return result;

    }

    @ApiOperation("获取保存配置")
    @GetMapping("/getConf")
    @ResponseAddHead
    @ApiImplicitParams({
            @ApiImplicitParam(name="conf_type",value="配置类型",required=true,dataType="string",paramType="query")
    })
    public RequestResult<KsSysConfBVO> getConf( String conf_type ) {
        KsSysConfBVO ksSysConfBVO = sysConfServer.getConfByConfType( conf_type );
        RequestResult<KsSysConfBVO> result=new RequestResult( ksSysConfBVO );
        return result;

    }

    @ApiOperation("获取保存配置")
    @GetMapping("/getConfs")
    @ResponseAddHead
    public RequestResult<KsSysConfBVO> getConfs( ) {
        List<KsSysConfBVO> ksSysConfBVO = sysConfServer.getConfs( );
        RequestResult<KsSysConfBVO> result=new RequestResult( ksSysConfBVO );
        return result;

    }


}
