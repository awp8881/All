package com.qzsoft.lims.ks.controller.dboperation;

import cn.hutool.core.io.resource.ResourceUtil;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * pdman静态页面展示
 * @author yuanj
 */
@Api(value = "pdman静态页面展示", tags = "pdman静态页面展示")
@RestController
@Slf4j
public class PdmanHtmlController {

    @RequestMapping("/htmls")
    public String htmls(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/index.html");
        return str;
    }

    @RequestMapping("/icon/awesome/css/font-awesome.min.css")
    public String minCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/icon/awesome/css/font-awesome.min.css");
        return str;
    }


    @RequestMapping("/icon/antd/iconfont.css")
    public String iconfontCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/icon/antd/iconfont.css");
        return str;
    }

    @RequestMapping("/icon/roic/iconfont.css")
    public String iconfontCsss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/icon/roic/iconfont.css");
        return str;
    }

    @RequestMapping("/css/antd.css")
    public String antdCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/css/antd.css");
        return str;
    }

    @RequestMapping("/highight/styles/atelier-estuary-dark.css")
    public String darkCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/highight/styles/atelier-estuary-dark.css");
        return str;
    }

    @RequestMapping("/style.2f98db86.css")
    public String styleCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/style.2f98db86.css");
        return str;
    }

    @RequestMapping("/js/html2canvas.min.js")
    public String html2canvasCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/js/html2canvas.min.js");
        return str;
    }

    @RequestMapping("/js/jquery.min.js")
    public String jqueryCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/js/jquery.min.js");
        return str;
    }

    @RequestMapping("/js/g6.min.js")
    public String g6Css(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/js/g6.min.js");
        return str;
    }

    @RequestMapping("/highight/highlight.pack.js")
    public String highightCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/highight/highlight.pack.js");
        return str;
    }

    @RequestMapping("/index.2f98db86.js")
    public String indexCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/index.2f98db86.js");
        return str;
    }

    @RequestMapping("/js/g6-plugins.min.js")
    public String jsCss(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/js/g6-plugins.min.js");
        return str;
    }

/**
     * 返回图片格式的文件
     *
     * @return
     */

    @RequestMapping(value = "/5265a2bbc5369d6fca1c4a550abb6672.png", produces = MediaType.IMAGE_PNG_VALUE)
    public byte[]  png(){
        ClassPathResource cpr = new ClassPathResource("WEB-INF/build/5265a2bbc5369d6fca1c4a550abb6672.png");
        BufferedImage bufferedImage = null;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            bufferedImage = ImageIO.read(cpr.getInputStream());
            ImageIO.write(bufferedImage, "png", out);
        } catch (IOException e) {
            e.printStackTrace();
        }
        log.info("获取图片输出的字节为{}",out.toByteArray());
        return  out.toByteArray();
    }

    @RequestMapping(value = "/icon/antd/font.woff", produces = MediaType.IMAGE_PNG_VALUE)
    public void font(HttpServletResponse response){
        responseParam(response,"/icon/antd/font.woff");
    }

    @RequestMapping(value = "/icon/awesome/fonts/fontawesome-webfont.woff2", produces = MediaType.IMAGE_PNG_VALUE)
    public void webfont(HttpServletResponse response){
        responseParam(response,"/icon/awesome/fonts/fontawesome-webfont.woff2");
    }

    @RequestMapping(value = "/icon/awesome/fonts/fontawesome-webfont.woff", produces = MediaType.IMAGE_PNG_VALUE)
    public void webfonts(HttpServletResponse response){
        responseParam(response,"/icon/awesome/fonts/fontawesome-webfont.woff");
    }

    @RequestMapping("/icon/antd/font.ttf")
    public String fonts(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/icon/antd/font.ttf");
        return str;
    }

    @RequestMapping("/icon/awesome/fonts/fontawesome-webfont.ttf")
    public String webfontes(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/icon/awesome/fonts/fontawesome-webfont.ttf");
        return str;
    }

    @RequestMapping("/index.4bf216ca.js")
    public String fase(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/index.4bf216ca.js");
        return str;
    }

    @RequestMapping("/style.4bf216ca.css")
    public String styles(){
        String str = ResourceUtil.readUtf8Str("WEB-INF/build/style.4bf216ca.css");
        return str;
    }


    public void responseParam(HttpServletResponse response,String params){
        try {
            ClassPathResource cpr = new ClassPathResource("WEB-INF/build"+params);
            String iconAdCa =cpr.getURL().getPath();
            FileCopyUtils.copy(cpr.getInputStream(), response.getOutputStream());
        } catch (Exception e) {
//			LOG.warn("找不到配置图片{}", e.getMessage());
//			LOG.info("获取默认图片");
            try {
                File file = ResourceUtils.getFile("classpath:WEB-INF/build"+params);

                response.setContentLength((int) file.length());
                response.setContentType("application/octet-stream");
                FileCopyUtils.copy(new FileInputStream(file), response.getOutputStream());
            } catch (Exception e2) {
//				LOG.error("错误：找不到默认图片！");
            }
        }
    }

}
