package com.qzsoft.lims.ks.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.vo.CommonTreeVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.GlobalVariableService;
import com.qzsoft.lims.ks.vo.KsPortDicBVO;
import com.qzsoft.lims.ks.vo.KsSqlButtonDicBVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

@Api(value = "全局变量", tags = "全局变量")
@RestController
@RequestMapping("/globalVariable")
@Slf4j
@TagResource("全局变量")
public class GlobalVariableController {

	@Autowired
	private GlobalVariableService globalVariableService;

	@ApiOperation(value="字典名称保存")
	@PostMapping("/saveDicName")
	@ResponseAddHead
	@TagResource("字典名称保存")
		public RequestResult<Map<String,Object>> saveDicName(KsSqlButtonDicBVO ksSqlButtonDicBVO) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setObj(globalVariableService.saveDicName(ksSqlButtonDicBVO));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveDicName()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveDicName()", e);
		}
		return result;

	}

	@ApiOperation(value="字典名称保存")
	@PostMapping("/saveDicNameV2")
	@ResponseAddHead
	@TagResource("字典名称保存V2")
		public RequestResult<Map<String,Object>> saveDicNameV2(KsSqlButtonDicBVO ksSqlButtonDicBVO) {
		RequestResult<Map<String,Object>> result = new RequestResult<>();
		try {
			result.setObj(globalVariableService.saveDicNameV2(ksSqlButtonDicBVO));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveDicName()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveDicName()", e);
		}
		return result;

	}

	@ApiOperation(value="字典值保存")
	@PostMapping("/saveDicVal")
	@ResponseAddHead
	@TagResource("字典值保存")
		@ApiImplicitParams({
		@ApiImplicitParam(name="parent_code",value="父级字典代码",required=true,dataType="String",paramType="query"),
		@ApiImplicitParam(name="dicSelectListStr",value="字典配置条件",required=false,dataType="String",paramType="query")
	})
	public RequestResult<Boolean> saveDicVal(@RequestParam(value="parent_code") String parent_code,
			@RequestParam(value="dicSelectListStr",required=false) String dicSelectListStr) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			result.setObj(globalVariableService.saveDicVal(parent_code,dicSelectListStr));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".saveDicVal()", e);
		}catch (Exception e) {
			result.setObj(false);
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".saveDicVal()", e);
		}
		return result;

	}

	@ApiOperation("字典名称列表")
	@GetMapping("/getDicNameList")
	@ResponseAddHead
		public RequestResult<Map<String,Object>> getDicNameList() {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(globalVariableService.getDicNameList());
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getDicNameList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getDicNameList()", e);
		}
		return result;

	}

	@ApiOperation("获取可移动的字典树列表")
	@GetMapping("/getMoveableDicNameTreeList")
		@ApiImplicitParams({
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
	})
	@ResponseAddHead
	public RequestResult<CommonTreeVO> getMoveableDicNameTreeList() {
		RequestResult<CommonTreeVO> result = new RequestResult<>();
		List<CommonTreeVO> dicNameTree = globalVariableService.getMoveableDicNameTreeList( );
		result.setList( dicNameTree );
		return result;
	}

	@ApiOperation("获取可用的字典树列表")
	@GetMapping("/getCanableDicNameTreeList")
		@ApiImplicitParams({
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
	})
	@ResponseAddHead
	public RequestResult<CommonTreeVO> getCanableDicNameTreeList() {
		RequestResult<CommonTreeVO> result = new RequestResult<>();
		List<CommonTreeVO> dicNameTree = globalVariableService.getCanableDicNameTreeList( );
		result.setList( dicNameTree );
		return result;
	}

	@ApiOperation("字典名称树列表")
	@GetMapping("/getDicNameTreeList")
		@ApiImplicitParams({
			@ApiImplicitParam(name="JID",value="JID",required=true,dataType="String",paramType="query"),
	})
	@ResponseAddHead
	public RequestResult<CommonTreeVO> getDicNameTreeList() {
		RequestResult<CommonTreeVO> result = new RequestResult<>();
		List<CommonTreeVO> dicNameTree = globalVariableService.getDicNameTree();
		result.setList( dicNameTree );
		return result;
	}

	@ApiOperation("字典值配置条件列表")
	@GetMapping("/getDicValConfigList")
		@ResponseAddHead
	@ApiImplicitParam(name="parent_code",value="父级字典代码",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getDicValConfigList(@RequestParam(value="parent_code") String parent_code) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(globalVariableService.getDicValConfigList(parent_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getDicValConfigList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getDicValConfigList()", e);
		}
		return result;

	}

	@ApiOperation("字典值列表")
	@GetMapping("/getDicValList")
		@ResponseAddHead
	@ApiImplicitParam(name="parent_code",value="父级字典代码",required=true,dataType="String",paramType="query")
	public RequestResult<Map<String,Object>> getDicValList(@RequestParam(value="parent_code") String parent_code) {
		RequestResult<Map<String,Object>> result = null;
		try {
			result=new RequestResult<>(globalVariableService.getDicValList(parent_code));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getDicValList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getDicValList()", e);
		}
		return result;

	}

	@ApiOperation(value="字典删除")
	@PostMapping("/delete")
		@ResponseAddHead
	@TagResource("字典删除")
	@ApiImplicitParam(name="ids",value="主键多个逗号隔开:1,2",required=true,dataType="String",paramType="query")
	public RequestResult<Boolean> delete(@RequestParam(value="ids") String ids) {
		RequestResult<Boolean> result = new RequestResult<>();
		try {
			result.setObj(globalVariableService.delete(ids));
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}
		return result;

	}

	@ApiOperation("全局字典导出")
	@PostMapping("/exportGlobalDic")
		@ResponseAddHead
	public void exportGlobalDic(@RequestParam(value="ids") String ids, HttpServletResponse response) {

		try {
			String globalDics = globalVariableService.exportGlobalDic(ids);

			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write( globalDics);
		} catch (IOException e) {
			log.error( e.getMessage());
		}
	}

	@ApiOperation(value = "全局字典导入")
	@PostMapping("/importGlobalDic")
		@ResponseAddHead
	public RequestResult<Boolean> importGlobalDic(@RequestParam("file") MultipartFile file, @RequestParam(value="id") Long id) {
		RequestResult<Boolean> result = new RequestResult<>();
		boolean importYn = globalVariableService.importGlobalDic( file, id );
		result.setObj(importYn);
		return result;
	}

	@ApiOperation(value = "全局字典复制")
	@PostMapping("/copyGlobalDic")
		@ResponseAddHead
	public RequestResult<Boolean> copyGlobalDic( @RequestParam(value="id") Long id) {
		RequestResult<Boolean> result = new RequestResult<>();
		boolean copyYn = globalVariableService.copyGlobalDic( id );
		result.setObj(copyYn);
		return result;
	}

	@ApiOperation(value = "普通字典转换为自定义")
	@PostMapping("/transformDic")
		@ResponseAddHead
	@TagResource("普通字典转换为自定义")
	public RequestResult<Map<String, Object>> transformDic(@RequestParam (value="transMap") String transMapStr ) {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setList( globalVariableService.transformDic( transMapStr) );
		return result;
	}
}
