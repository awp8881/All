package com.qzsoft.lims.ks.dao.impl;

import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsModelInfoFieldValBDao;
import org.springframework.stereotype.Repository;

/** 
 * 系统配置：系统自动化SQL语句
 * 创建时间:2018-09-13 15:01:00 
 */
@Repository
public class KsModelInfoFieldValBDaoImpl  extends BaseDaoImpl implements KsModelInfoFieldValBDao {



}
