package com.qzsoft.lims.ks.conversion;

import com.google.common.base.Joiner;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author pjh
 * @Title: DataSaveConversionImpl
 * @Description: 数组转换器  转换格式[1,2,3,4] => 1,2,3,4
 * @date 2018/9/7 13:57
 */
@Slf4j
public class ArrayDataSaveConversionImpl implements DataConversion {

    @Override
    public Object conversion(Object originalObj) {

        if( null==originalObj ){
            return "";
        }
        if( !(originalObj instanceof List) ){
        	if(originalObj instanceof String){
        		String str = originalObj.toString();
        		if(str.length()>2 && str.charAt(0) == '[' && str.charAt(str.length()-1) == ']'){
        			String str1 = str.substring(1, str.length()-1);
        			String[] strList = str1.split(",");
            		List retList = new ArrayList();
            		for(String str2 : strList){
            			retList.add(str2);
            		}
            		Object retObj = Joiner.on(",").join(retList);
            		return retObj;
        		}
        	}
    		log.error( "错误的数据类型:{}", originalObj );
            BusinessException.throwBiz("该数据不是数组类型，无法转换");
        }
        List originalList = (List) originalObj;

        return Joiner.on(",").join(originalList);
    }
}
