package com.qzsoft.lims.ks.dao.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.tools.UIDGenerator;
import com.qzsoft.lims.ks.dao.KsModelDynSqlBDao;
import com.qzsoft.lims.ks.dao.KsModelDynSqlParaBDao;
import com.qzsoft.lims.ks.eum.MTypeEnum;
import com.qzsoft.lims.ks.eum.dynamic.DynamicParaTypeEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.util.TableHelper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @Description 动态sql
 */
@Repository
public class KsModelDynSqlBDaoImpl extends BaseDaoImpl implements KsModelDynSqlBDao{
    private static final String TABLE_NAME = "ks_model_dyn_sql_b";

    @Autowired
    private KsModelDynSqlParaBDao ksModelDynSqlParaBDao;


    //获取动态sql
    @Override
    public List<Record> getByPCode(String pCode, String dynType) {
        String sql = "select * from "+TABLE_NAME+" where p_code=? and dyn_type=? order by disp_or+0";
        List<Record> dynList = DbEx.find(sql, pCode, dynType);
        if ( null == dynList || dynList.isEmpty()){
            return Lists.newArrayList();
        }
        List<Record> dynParasList = ksModelDynSqlParaBDao.getByPCode( pCode );
        for (Iterator<Record> iterator = dynList.iterator(); iterator.hasNext(); ) {
            Record next =  iterator.next();
            if ( null == dynParasList || dynParasList.isEmpty()){
                next.set("dynParasList", Lists.newArrayList());
                continue;
            }
            String dynCode = StringUtil.toString(next.getStr("dyn_code"));
            List<Record> paras = Lists.newArrayList();
            for (Iterator<Record> recordIterator = dynParasList.iterator(); recordIterator.hasNext(); ) {
                Record record =  recordIterator.next();
                String dynParaCode = record.getStr("dyn_code");
                if (dynCode.equals(dynParaCode)){
                    paras.add(record);
                }
            }
            next.set("dynParasList", DataBaseUtil.record2Map(paras ));
        }

        return dynList;
    }

    //保存动态sql
    @Override
    @JFinalTx
    public Set<String> saveDynSql(List<Map<String,Object>> allDynList, String pCode, String dynType) {
        deleteDynSql( pCode, dynType );

        if (null == allDynList || allDynList.isEmpty()){
            return Sets.newHashSet();
        }
        Set<String> busCode = Sets.newHashSet();
        List<Map<String,Object>> allDynParaList = Lists.newArrayList();
        int count = 1;
        for (Iterator<Map<String, Object>> iterator = allDynList.iterator(); iterator.hasNext(); ) {
            Map<String, Object> next =  iterator.next();
            next.put("p_code", pCode);
            next.put("dyn_type", dynType);
            next.put("cr_dm", DateUtil.getNowDateTimeStr());
            next.put("up_ver", "1");

            List<Map<String,Object>> dynParasList = (List<Map<String,Object>>)next.get("dynParasList");
            if (null != dynParasList && !dynParasList.isEmpty()){
                setDynCode(next, dynParasList, busCode);
                allDynParaList.addAll(dynParasList);
            }

            next.remove("dynParasList");
            next.put("disp_or", count);
            count++;
        }
        saveList(TABLE_NAME, DataBaseUtil.map2Record(allDynList));
        ksModelDynSqlParaBDao.saveDynSql(allDynParaList, pCode);
        return busCode;
    }


    private void deleteDynSql(String pCode, String dynType ){
        List<Record> dynSqls = DbEx.find("select dyn_code from "+TABLE_NAME+" where p_code=? and dyn_type=?", pCode, dynType);
        if (null == dynSqls){
            return;
        }
        deleteByCustom(TABLE_NAME, "p_code,dyn_type", pCode, dynType);
        List<String> dynCodes = DataBaseUtil.record2String(dynSqls, "dyn_code");
        DbEx.batchDelete("ks_model_dyn_sql_para_b", "dyn_code", dynCodes);

    }

    private void setDynCode(Map<String, Object> next, List<Map<String,Object>> dynParasList, Set<String> busCode){

        if (null == dynParasList || dynParasList.isEmpty()){
            return;
        }
        for (Map<String,Object> dynParaMap : dynParasList) {
            dynParaMap.put("dyn_code", next.get("dyn_code"));
            dynParaMap.put("menu_id", next.get("menu_id"));
            String paraType = StringUtil.toString(dynParaMap.get("para_type"));

            if (DynamicParaTypeEnum.ZD.getCode().equals( paraType )){
                busCode.add(StringUtil.toString( dynParaMap.get("para_m_code")));
            }
        }
        next.put("bus_code", StringUtil.listTOString(Lists.newArrayList(busCode)));

    }

    @Override
    public Record getByDynCode(String dynCode) {
        Record dynRecord = getOneByColumn(TABLE_NAME , "dyn_code", dynCode);
        if (null == dynRecord){
            return null;
        }
//        String dynSql = Base64.encode( StringUtil.toString(dynRecord.getStr("dyn_sql")));
//        dynRecord.set("dyn_sql", dynSql);
        List<Record> dynParasList = ksModelDynSqlParaBDao.getByDynCode( dynCode );
        dynRecord.set("dynParasList", DataBaseUtil.record2Map( dynParasList ));
        return dynRecord;
    }

    /**
     * 行按钮统计
     *
     * @param pCode
     * @param mType
     * @param controlStyle
     * @return
     */
    @Override
    public List<Record> getByPCodeAndControlStyle(String pCode, String mType, String controlStyle) {
        String buutonTable = "ks_menu_logic_b";
        if ( MTypeEnum.INNER_LIST.getCode().equals(mType) ) {
            buutonTable = "ks_menu_logic_c";
        }
        String sql = "select * from ks_model_dyn_sql_b k1 where k1.p_code=? and " +
                "exists(select 1 from ? k2 where k2.button_code = k1.dyn_code and k2.control_style=?) ";
        return selectListBySql( sql , pCode, buutonTable, controlStyle);
    }

    /**
     * 分组条件动态sql
     *
     * @param pCode
     * @param conds
     */
    @Override
    public void getCondDynSql(String pCode, String dynType, List<Record> conds) {
        if (null == conds || conds.isEmpty()){
            return;
        }
        List<Record> dynDatas = getByPCode( pCode, dynType );
        if (null == dynDatas || dynDatas.isEmpty()){
            return;
        }

        for (Iterator<Record> condIter = conds.iterator(); condIter.hasNext(); ) {
            Record condRecord =  condIter.next();
            String paraCode = StringUtil.toString (condRecord.getStr("para_code"));

            Map<String, List<Record>> dynData = dynDatas.stream().collect(Collectors.groupingBy(e -> e.getStr("dyn_code")));
            List<Record> dyns = dynData.get( paraCode );
            if (null == dyns || dyns.isEmpty()){
                condRecord.set("dynData", Maps.newHashMap());
                continue;
            }
            condRecord.set("dynData", DataBaseUtil.record2Map( dyns.get(0)));

        }
    }

    @Override
    @JFinalTx
    public Map<String, Object> saveDynSql(Map<String, Object> dynData) {
        Map<String, Object> map = Maps.newHashMap();
        Set<String> busCodes = Sets.newHashSet();

        String dynCode = StringUtil.toString(dynData.get("dyn_code"));

        List<Map<String,Object>> dynParasList = (List<Map<String,Object>>)dynData.get("dynParasList");
        dynData.remove("dynParasList");

        if (StringUtils.isBlank( dynCode)){
            dynCode = StringUtil.toString(UIDGenerator.getUID());
            dynData.put("dyn_code", dynCode);
            dynData.put("cr_dm", DateUtil.getNowDateTimeStr());
            dynData.put("up_ver", "1");

            setDynCode(dynData, dynParasList, busCodes);
            save(TABLE_NAME, DataBaseUtil.map2Record( dynData));

        }else{
            setDynCode(dynData, dynParasList, busCodes);
            update(TABLE_NAME, DataBaseUtil.map2Record( dynData));
        }

        ksModelDynSqlParaBDao.saveDynPara(dynParasList, dynCode);
        map.put("dynCode", dynCode);
        map.put("busCodes", busCodes);
        return map;
    }

    @Override
    @JFinalTx
    public Boolean deleteDyn(List<String> dynCodes) {
        if (dynCodes.isEmpty()){
            return true;
        }
        DbEx.batchDelete(TABLE_NAME, "dyn_code", dynCodes);
        DbEx.batchDelete("ks_model_dyn_sql_para_b", "dyn_code", dynCodes);
        return true;
    }

    @Override
    public List<Record> getDynList(List<String> dynCodes) {
        if (null == dynCodes || dynCodes.isEmpty()){
            return null;
        }
        String inSql = TableHelper.getInSql("dyn_code", dynCodes);
        String sql = "select * from "+TABLE_NAME+" where 1=1 "+inSql;
        return DbEx.find(sql, dynCodes.toArray());
    }

    @Override
    public Set<String> getBusCode(List<String> dynCodes) {
        if (null == dynCodes || dynCodes.isEmpty()){
            return Sets.newHashSet();
        }
        String inSql = TableHelper.getInSql("dyn_code", dynCodes);
        String sql = "select bus_code from "+TABLE_NAME+" where 1=1 "+inSql;
        List<Record> records = DbEx.find(sql, dynCodes.toArray());
        List<String> list = DataBaseUtil.record2String(records, "bus_code");
        Set<String> busCodes = Sets.newHashSet();
        list.stream().forEach( str -> {
            List<String> codes = StringUtil.strToList(str);
            busCodes.addAll(codes);
        });
        return busCodes;
    }

    @Override
    public Boolean updateDynSql(String dynCode, String countNa, String unitType, String condCode) {
        String sql = "update "+TABLE_NAME+" set count_na=?,unit_type=?,cond_code=? where dyn_code=? ";
        return DbEx.update(sql, countNa, unitType, condCode, dynCode) > 0;
    }
}
