package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.chg.ChgRecordService;
import com.qzsoft.lims.ks.vo.chg.ChgPlanVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 变更记录数据控制层
 */
@Api(value = "变更记录数据控制层", tags = "变更记录数据控制层")
@RestController
@RequestMapping("/chgRecord")
@Slf4j
public class ChgRecordController {

    @Autowired
    ChgRecordService chgRecordService;

    @ApiOperation("保存变更数据")
    @PostMapping("/saveChgData")
    @ResponseAddHead
        @ApiImplicitParams({
            @ApiImplicitParam(name="planId",value="方案id",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="busId",value="业务id",required=true,dataType="String",paramType="query")
    })
    public RequestResult<String> saveChgData( @RequestParam(value = "planId" ,required = false) String planId,@RequestParam(value = "busId") String busIds ) {
        RequestResult<String> chgPlanVOResult = new RequestResult<>();
        try {
            chgRecordService.saveChgData(planId,busIds);
            chgPlanVOResult.setObj( "记录成功" );
        }catch ( Exception e ){
            log.error(e.getMessage(),e);
            chgPlanVOResult.setObj( e.getMessage() );
            chgPlanVOResult.setThrowable( e );
        }
        return chgPlanVOResult;
    }

}
