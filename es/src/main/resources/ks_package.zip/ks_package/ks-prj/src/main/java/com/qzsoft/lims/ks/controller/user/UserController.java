package com.qzsoft.lims.ks.controller.user;

import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.vo.KsUserInfo;
import com.qzsoft.lims.ks.service.user.UserService;
import com.qzsoft.lims.ks.vo.user.KsConfResVO;
import com.qzsoft.lims.ks.vo.user.KsResVO;
import com.qzsoft.lims.ks.vo.user.KsUserGroupRespVO;
import com.qzsoft.lims.ks.vo.user.KsUserGroupVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

/**
 * @Description:
 * @author: zhouyou
 * @date: 2022/02/25 15:45
 **/
@RestController
@Api(tags = "用户登录相关服务")
@TagResource("用户登录相关服务")
@RequestMapping( "/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/doLogin")
    @ApiOperation("统一用户登录")
        @ApiImplicitParams({
            @ApiImplicitParam(name="username",value="用户名",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="password",value="密码",required=false,dataType="String",paramType="query"),
            @ApiImplicitParam(name="type",value="类型,1-只读用户,0-普通用户",required=true,dataType="Integer",paramType="query")
    })
    public RequestResult<KsUserInfo> doLogin(String username, String password, @RequestParam("type") @Max(1) @Min(0) Integer type) {
        RequestResult<KsUserInfo> result = new RequestResult<>();
        KsUserInfo infoVO = userService.doLogin(username, password,type);
        result.setObj(infoVO);
        return result;
    }

    @ApiOperation("初始化所有接口名及注释")
        @GetMapping("/initAllUrl")
    public RequestResult initAllUrl() {
        RequestResult<Boolean> result = new RequestResult<>();
        userService.initAllUrl();
        return result;
    }

    @ApiOperation("菜单列表展示")
    @PostMapping("/pageMenu")
        public RequestResult pageMenu(){
        RequestResult<KsResVO> result = new RequestResult<>();
        result.setList(userService.findRes());
        return result;
    }

    @ApiOperation("新增/修改用户")
    @TagResource("新增/修改用户")
    @PostMapping("/saveOrUpdateUser")
        public RequestResult<Boolean> saveOrUpdateUser(@RequestBody @Validated KsUserInfo vo){
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(userService.saveOrUpdateUser(vo));
        return result;
    }

    @ApiOperation("新增/修改用户组")
    @PostMapping("/saveOrUpdateGroup")
        public RequestResult<Boolean> saveOrUpdateGroup(@RequestBody @Validated KsUserGroupVO vo){
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(userService.saveOrUpdateGroup(vo));
        return result;
    }

    @ApiOperation("用户组分页列表")
    @PostMapping("/PageUserGroupList")
    @TagResource("用户组分页列表")
        public RequestResult<KsUserGroupRespVO> PageUserGroupList(@RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
                                                              @RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize){
        return userService.pageUserGroupList(pageNum,pageSize);
    }

    @ApiOperation("根据token查询用户信息")
    @PostMapping("/getUserInfo")
        public RequestResult getUserInfo(){
        RequestResult<KsUserInfo> result = new RequestResult<>();
        result.setObj(userService.getUserInfo());
        return result;
    }

    @ApiOperation("查询其他分组列表-传0查所有")
    @PostMapping("/findOtherGroup")
        public RequestResult findOtherGroup(@RequestParam("groupId") Long groupId){
        RequestResult<KsUserGroupVO> result = new RequestResult<>();
        result.setList(userService.findOtherGroup(groupId));
        return result;
    }



    @ApiOperation("退出")
    @PostMapping("/logout")
        public RequestResult logout(HttpServletRequest request){
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(userService.logout(request.getHeader("token")));
        // TODO: 2022/3/9  退出用户清空token
        return result;
    }

    @ApiOperation("删除用户/用户组")
    @PostMapping("/delete")
        @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="用户/用户组id",required=true,dataType="Long",paramType="query"),
            @ApiImplicitParam(name="type",value="用户/用户组类型,0：用户,1：用户组",required=true,dataType="Integer",paramType="query")
    })
    public RequestResult delete(@RequestParam(value="id") Long id, @RequestParam("type") @Max(1) @Min(0) Integer type){
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(userService.delete(id,type));
        return result;
    }

    @ApiOperation("查看用户/用户组对应资源")
    @PostMapping("/findResByUserOrGroup")
        @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="用户/用户组id",required=true,dataType="Long",paramType="query"),
            @ApiImplicitParam(name="type",value="用户/用户组类型,0：用户,1：用户组",required=true,dataType="Integer",paramType="query")
    })
    public RequestResult<KsResVO> findResByUserOrGroup(@RequestParam(value="id") Long id, @RequestParam("type") @Max(1) @Min(0) Integer type){
        RequestResult<KsResVO> result = new RequestResult<>();
        result.setList(userService.findResByUserOrGroup(id,type));
        return result;
    }

    @ApiOperation("配置用户/组资源")
    @PostMapping("/confUserRes")
        public RequestResult confUserRes(@RequestBody KsConfResVO vo){
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(userService.confUserRes(vo));
        return result;
    }

    @ApiOperation("删除用户/用户组资源")
    @PostMapping("/removeRes")
        @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="用户/用户组id",required=true,dataType="Long",paramType="query"),
            @ApiImplicitParam(name="resId",value="资源id",required=true,dataType="Long",paramType="query"),
            @ApiImplicitParam(name="type",value="用户/用户组类型,0：用户,1：用户组",required=true,dataType="Integer",paramType="query")
    })
    public RequestResult removeRes(@RequestParam(value="id") Long id,@RequestParam(value="resId") Long resId, @RequestParam("type") @Max(1) @Min(0) Integer type){
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(userService.removeRes(id,resId,type));
        return result;
    }

}
