package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.extComp.DynFieldService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @Author zf
 * @Description 提供外部接口调用
 * @Date 2020/11/18
 */
@Api(value = "外部接口调用", tags = "外部接口调用")
@RestController
@RequestMapping("/extComp")
@Slf4j
public class ExtCompController {

    @Autowired
    private DynFieldService dynFieldService;

    @ApiOperation(value = "动态字段列表")
    @GetMapping("/dynFieldSrcList")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> dynFieldList(
            @RequestParam(value = "field_name", required = false) String fieldName,
            @RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
            @RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
        RequestResult<Map<String, Object>> result = dynFieldService.dynFieldList(pageNum, pageSize, fieldName);
        return result;
    }

    @ApiOperation(value = "业务关联动态字段列表")
    @GetMapping("/busDynFieldList")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> busDynFieldList(
            @RequestParam(value = "busId") String busId,
            @RequestParam(value = "field_name", required = false) String fieldName,
            @RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
            @RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
        RequestResult<Map<String, Object>> result = dynFieldService.busDynFieldList(pageNum, pageSize, busId, fieldName);
        return result;
    }

    @ApiOperation(value = "动态字段详情")
    @GetMapping("/dynFieldSrcInfo")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> dynFieldInfo(@RequestParam(value = "dynFieldSrcId") Long dynFieldSrcId) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setObj(dynFieldService.dynFieldInfo( dynFieldSrcId ));
        return result;
    }

    @ApiOperation(value = "保存动态字段")
    @PostMapping("/saveDynFieldSrc")
    @ResponseAddHead
        public RequestResult<Boolean> saveDynFieldSrc(@RequestParam(value = "dynFieldSrcData") String dynFieldSrcDataStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(dynFieldService.saveDynFieldSrc( dynFieldSrcDataStr ));
        return result;
    }

    @ApiOperation(value = "删除动态字段")
    @PostMapping("/deleteDynFieldSrc")
    @ResponseAddHead
        public RequestResult<Boolean> deleteDynFieldSrc(@RequestParam(value = "dynFieldSrcIds") String dynFieldSrcIdsStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(dynFieldService.deleteDynFieldSrc( dynFieldSrcIdsStr ));
        return result;
    }

    @ApiOperation(value = "删除业务关联动态字段")
    @PostMapping("/deleteBusDynField")
    @ResponseAddHead
        public RequestResult<Boolean> deleteBusDynField(@RequestParam(value = "dynFieldIds") String dynFieldIdsStr) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(dynFieldService.deleteBusDynField( dynFieldIdsStr ));
        return result;
    }


    @ApiOperation(value = "业务关联动态字段数据")
    @GetMapping("/getBusDynFields")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getBusDynFields(@RequestParam(value = "busId") String busId) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(dynFieldService.getBusDynFields( busId ));
        return result;
    }

    @ApiOperation(value = "新增业务关联动态字段")
    @PostMapping("/addBusDynFields")
    @ResponseAddHead
        public RequestResult<Boolean> addBusDynFields(@RequestParam(value = "dynFieldSrcIds") String dynFieldSrcIdsStr,
                                                  @RequestParam(value = "busId") String busId ) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(dynFieldService.addBusDynFields( dynFieldSrcIdsStr, busId ));
        return result;
    }

    @ApiOperation(value = "保存业务关联动态字段数据")
    @PostMapping("/saveBusDynFields")
    @ResponseAddHead
        public RequestResult<Boolean> saveBusDynFields(@RequestParam(value = "busDynFieldData") String busDynFieldsDataStr,
                                                   @RequestParam(value = "busId") String busId) {
        RequestResult<Boolean> result = new RequestResult<>();
        result.setObj(dynFieldService.saveBusDynFields( busDynFieldsDataStr, busId));
        return result;
    }

}
