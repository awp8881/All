//package com.qzsoft.lims.ks.config.init;
//
//import com.google.common.base.CharMatcher;
//import com.google.common.base.Splitter;
//import com.qzsoft.common.activerecord.DbEx;
//import com.qzsoft.common.tools.DateUtil;
//import com.qzsoft.common.tools.MD5Utils;
//import lombok.Data;
//import lombok.extern.slf4j.Slf4j;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
//import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
//import org.springframework.boot.context.config.ResourceNotFoundException;
//import org.springframework.context.ApplicationContext;
//import org.springframework.core.io.InputStreamResource;
//import org.springframework.core.io.InputStreamSource;
//import org.springframework.core.io.Resource;
//import org.springframework.core.io.support.EncodedResource;
//import org.springframework.jdbc.config.SortedResourcesFactoryBean;
//import org.springframework.jdbc.datasource.DataSourceUtils;
//import org.springframework.jdbc.datasource.init.*;
//import org.springframework.stereotype.Component;
//import org.springframework.util.Assert;
//import org.springframework.util.StringUtils;
//
//import javax.annotation.PostConstruct;
//import javax.sql.DataSource;
//import java.io.IOException;
//import java.io.LineNumberReader;
//import java.sql.*;
//import java.util.*;
//import java.util.concurrent.atomic.AtomicBoolean;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//import static com.qzsoft.lims.ks.config.init.DataSourceInitializer.onceActionIng;
//
///**
// * @author pjh
// * @Title: DataSourceInitializer
// * @Description: 定制初始化sql脚本（防止重复提交）
// * @date 2018/10/15 14:20
// */
//@Slf4j
//@Component
//public class DataSourceInitializer {
//
//
//    @Autowired
//    private DataSourceProperties properties;
//
//    @Autowired
//    private ApplicationContext applicationContext;
//
//    @Autowired
//    private DataSource dataSource;
//
//    @Value("${ks.datasource.schema:}")
//    public String schema;
//
//    @Value("${ks.datasource.data:}")
//    public String data;
//
//    @Value("${ks.datasource.onceAction:}")
//    public String onceAction;
//
//    @Value("${ks.datasource.sqlSeparator:}")
//    public String sqlSeparator;
//
//    /**
//     * 是否正在执行一次性sql
//     */
//    static AtomicBoolean onceActionIng=new AtomicBoolean(false);
//
////    @PostConstruct
////    public void init() {
////        runSchemaScripts();
////        runOnceActionScripts();
////        runDataScripts();
////    }
//
//    /**
//     * 运行一次性脚本  每次执行后
//     */
//    private void runOnceActionScripts() {
//
//        onceActionIng.set(true);
//
//        List<String> resources = null;
//        if( !StringUtils.isEmpty( onceAction ) ){
//            resources = Arrays.asList(onceAction);
//        }
//        List<Resource> scripts = getScripts("ks.datasource.onceAction",
//                resources, "onceAction");
//        String username = this.properties.getDataUsername();
//        String password = this.properties.getDataPassword();
//        runScripts(scripts, username, password);
//        onceActionIng.set(false);
//
//    }
//
//
//    private void runSchemaScripts() {
//        List<String> resources = null;
//        if( !StringUtils.isEmpty( schema ) ){
//            resources = Arrays.asList(schema);
//        }
//        List<Resource> scripts = getScripts("ks.datasource.schema",
//                resources, "schema");
//        if (!scripts.isEmpty()) {
//            String username = this.properties.getSchemaUsername();
//            String password = this.properties.getSchemaPassword();
//            runScripts(scripts, username, password);
//        }
//    }
//
//
//    private void runDataScripts() {
//        List<String> resources = null;
//        if( !StringUtils.isEmpty( data ) ){
//            resources = Arrays.asList(data);
//        }
//        List<Resource> scripts = getScripts("ks.datasource.data",
//                resources, "data");
//        String username = this.properties.getDataUsername();
//        String password = this.properties.getDataPassword();
//        runScripts(scripts, username, password);
//    }
//
//    private List<Resource> getScripts(String propertyName, List<String> resources,
//                                      String fallback) {
//        if (resources != null) {
//            return getResources(propertyName, resources, true);
//        }
//        String platform = this.properties.getPlatform();
//        List<String> fallbackResources = new ArrayList<String>();
//        fallbackResources.add("classpath*:" + fallback + "-" + platform + ".sql");
//        fallbackResources.add("classpath*:" + fallback + ".sql");
//        return getResources(propertyName, fallbackResources, false);
//    }
//
//    private List<Resource> getResources(String propertyName, List<String> locations,
//                                        boolean validate) {
//        List<Resource> resources = new ArrayList<Resource>();
//        for (String location : locations) {
//            for (Resource resource : doGetResources(location)) {
//                if (resource.exists()) {
//                    resources.add(resource);
//                }
//                else if (validate) {
//                    throw new ResourceNotFoundException(propertyName, resource);
//                }
//            }
//        }
//        return resources;
//    }
//
//    private Resource[] doGetResources(String location) {
//        try {
//            SortedResourcesFactoryBean factory = new SortedResourcesFactoryBean(
//                    this.applicationContext, Collections.singletonList(location));
//            factory.afterPropertiesSet();
//            return factory.getObject();
//        }
//        catch (Exception ex) {
//            throw new IllegalStateException("Unable to load resources from " + location,
//                    ex);
//        }
//    }
//
//    private void runScripts(List<Resource> resources, String username, String password) {
//        if (resources.isEmpty()) {
//            return;
//        }
//        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
//        populator.setContinueOnError(this.properties.isContinueOnError());
//        populator.setSeparator( sqlSeparator );
////        populator.setSeparator(this.properties.getSeparator());
//        if (this.properties.getSqlScriptEncoding() != null) {
//            populator.setSqlScriptEncoding(this.properties.getSqlScriptEncoding().name());
//        }
//        for (Resource resource : resources) {
//            populator.addScript(resource);
//        }
//        DataSource dataSource = this.dataSource;
//        if (StringUtils.hasText(username) && StringUtils.hasText(password)) {
//            dataSource = DataSourceBuilder.create(this.properties.getClassLoader())
//                    .driverClassName(this.properties.determineDriverClassName())
//                    .url(this.properties.determineUrl()).username(username)
//                    .password(password).build();
//        }
//
//        try {
//            Connection connection = DataSourceUtils.getConnection(dataSource);
//            try {
//                populator.populate(connection);
//            }
//            finally {
//                DataSourceUtils.releaseConnection(connection, dataSource);
//            }
//        }
//        catch (Throwable ex) {
//            if (ex instanceof ScriptException) {
//                throw (ScriptException) ex;
//            }
//            throw new UncategorizedScriptException("Failed to execute database script", ex);
//        }
//
//    }
//
//
//}
//
//
//class ResourceDatabasePopulator implements DatabasePopulator {
//
//    List<Resource> scripts = new ArrayList<Resource>();
//
//    private String sqlScriptEncoding;
//
//    private String separator = ScriptUtils.DEFAULT_STATEMENT_SEPARATOR;
//
//    private String commentPrefix = ScriptUtils.DEFAULT_COMMENT_PREFIX;
//
//    private String blockCommentStartDelimiter = ScriptUtils.DEFAULT_BLOCK_COMMENT_START_DELIMITER;
//
//    private String blockCommentEndDelimiter = ScriptUtils.DEFAULT_BLOCK_COMMENT_END_DELIMITER;
//
//    private boolean continueOnError = false;
//
//    private boolean ignoreFailedDrops = false;
//
//
//    /**
//     * Construct a new {@code ResourceDatabasePopulator} with default settings.
//     * @since 4.0.3
//     */
//    public ResourceDatabasePopulator() {
//        /* no-op */
//    }
//
//    /**
//     * Construct a new {@code ResourceDatabasePopulator} with default settings
//     * for the supplied scripts.
//     * @param scripts the scripts to execute to initialize or clean up the database
//     * (never {@code null})
//     * @since 4.0.3
//     */
//    public ResourceDatabasePopulator(Resource... scripts) {
//        this();
//        setScripts(scripts);
//    }
//
//    /**
//     * Construct a new {@code ResourceDatabasePopulator} with the supplied values.
//     * @param continueOnError flag to indicate that all failures in SQL should be
//     * logged but not cause a failure
//     * @param ignoreFailedDrops flag to indicate that a failed SQL {@code DROP}
//     * statement can be ignored
//     * @param sqlScriptEncoding the encoding for the supplied SQL scripts; may
//     * be {@code null} or <em>empty</em> to indicate platform encoding
//     * @param scripts the scripts to execute to initialize or clean up the database
//     * (never {@code null})
//     * @since 4.0.3
//     */
//    public ResourceDatabasePopulator(boolean continueOnError, boolean ignoreFailedDrops,
//                                     String sqlScriptEncoding, Resource... scripts) {
//
//        this(scripts);
//        this.continueOnError = continueOnError;
//        this.ignoreFailedDrops = ignoreFailedDrops;
//        setSqlScriptEncoding(sqlScriptEncoding);
//    }
//
//
//    /**
//     * Add a script to execute to initialize or clean up the database.
//     * @param script the path to an SQL script (never {@code null})
//     */
//    public void addScript(Resource script) {
//        Assert.notNull(script, "Script must not be null");
//        this.scripts.add(script);
//    }
//
//    /**
//     * Add multiple scripts to execute to initialize or clean up the database.
//     * @param scripts the scripts to execute (never {@code null})
//     */
//    public void addScripts(Resource... scripts) {
//        assertContentsOfScriptArray(scripts);
//        this.scripts.addAll(Arrays.asList(scripts));
//    }
//
//    /**
//     * Set the scripts to execute to initialize or clean up the database,
//     * replacing any previously added scripts.
//     * @param scripts the scripts to execute (never {@code null})
//     */
//    public void setScripts(Resource... scripts) {
//        assertContentsOfScriptArray(scripts);
//        // Ensure that the list is modifiable
//        this.scripts = new ArrayList<Resource>(Arrays.asList(scripts));
//    }
//
//    private void assertContentsOfScriptArray(Resource... scripts) {
//        Assert.notNull(scripts, "Scripts array must not be null");
//        Assert.noNullElements(scripts, "Scripts array must not contain null elements");
//    }
//
//    /**
//     * Specify the encoding for the configured SQL scripts, if different from the
//     * platform encoding.
//     * @param sqlScriptEncoding the encoding used in scripts; may be {@code null}
//     * or empty to indicate platform encoding
//     * @see #addScript(Resource)
//     */
//    public void setSqlScriptEncoding(String sqlScriptEncoding) {
//        this.sqlScriptEncoding = (StringUtils.hasText(sqlScriptEncoding) ? sqlScriptEncoding : null);
//    }
//
//    /**
//     * Specify the statement separator, if a custom one.
//     * <p>Defaults to {@code ";"} if not specified and falls back to {@code "\n"}
//     * as a last resort; may be set to {@link ScriptUtils#EOF_STATEMENT_SEPARATOR}
//     * to signal that each script contains a single statement without a separator.
//     * @param separator the script statement separator
//     */
//    public void setSeparator(String separator) {
//        this.separator = separator;
//    }
//
//    /**
//     * Set the prefix that identifies single-line comments within the SQL scripts.
//     * <p>Defaults to {@code "--"}.
//     * @param commentPrefix the prefix for single-line comments
//     */
//    public void setCommentPrefix(String commentPrefix) {
//        this.commentPrefix = commentPrefix;
//    }
//
//    /**
//     * Set the start delimiter that identifies block comments within the SQL
//     * scripts.
//     * <p>Defaults to {@code "/*"}.
//     * @param blockCommentStartDelimiter the start delimiter for block comments
//     * (never {@code null} or empty)
//     * @since 4.0.3
//     * @see #setBlockCommentEndDelimiter
//     */
//    public void setBlockCommentStartDelimiter(String blockCommentStartDelimiter) {
//        Assert.hasText(blockCommentStartDelimiter, "BlockCommentStartDelimiter must not be null or empty");
//        this.blockCommentStartDelimiter = blockCommentStartDelimiter;
//    }
//
//    /**
//     * Set the end delimiter that identifies block comments within the SQL
//     * scripts.
//     * <p>Defaults to <code>"*&#47;"</code>.
//     * @param blockCommentEndDelimiter the end delimiter for block comments
//     * (never {@code null} or empty)
//     * @since 4.0.3
//     * @see #setBlockCommentStartDelimiter
//     */
//    public void setBlockCommentEndDelimiter(String blockCommentEndDelimiter) {
//        Assert.hasText(blockCommentEndDelimiter, "BlockCommentEndDelimiter must not be null or empty");
//        this.blockCommentEndDelimiter = blockCommentEndDelimiter;
//    }
//
//    /**
//     * Flag to indicate that all failures in SQL should be logged but not cause a failure.
//     * <p>Defaults to {@code false}.
//     * @param continueOnError {@code true} if script execution should continue on error
//     */
//    public void setContinueOnError(boolean continueOnError) {
//        this.continueOnError = continueOnError;
//    }
//
//    /**
//     * Flag to indicate that a failed SQL {@code DROP} statement can be ignored.
//     * <p>This is useful for a non-embedded database whose SQL dialect does not
//     * support an {@code IF EXISTS} clause in a {@code DROP} statement.
//     * <p>The default is {@code false} so that if the populator runs accidentally, it will
//     * fail fast if a script starts with a {@code DROP} statement.
//     * @param ignoreFailedDrops {@code true} if failed drop statements should be ignored
//     */
//    public void setIgnoreFailedDrops(boolean ignoreFailedDrops) {
//        this.ignoreFailedDrops = ignoreFailedDrops;
//    }
//
//
//    /**
//     * {@inheritDoc}
//     */
//    @Override
//    public void populate(Connection connection) throws ScriptException {
//        Assert.notNull(connection, "Connection must not be null");
//        for (Resource script : this.scripts) {
//            EncodedResource encodedScript = new EncodedResource(script, this.sqlScriptEncoding);
//            ScriptUtils.executeSqlScript(connection, encodedScript, this.continueOnError, this.ignoreFailedDrops,
//                    this.commentPrefix, this.separator, this.blockCommentStartDelimiter, this.blockCommentEndDelimiter);
//        }
//    }
//
//
//}
//
//
//
//class ScriptUtils {
//
//    /**
//     * Default statement separator within SQL scripts: {@code ";"}.
//     */
//    public static final String DEFAULT_STATEMENT_SEPARATOR = ";";
//
//    /**
//     * Fallback statement separator within SQL scripts: {@code "\n"}.
//     * <p>Used if neither a custom separator nor the
//     * {@link #DEFAULT_STATEMENT_SEPARATOR} is present in a given script.
//     */
//    public static final String FALLBACK_STATEMENT_SEPARATOR = "\n";
//
//    /**
//     * End of file (EOF) SQL statement separator: {@code "^^^ END OF SCRIPT ^^^"}.
//     * <p>This value may be supplied as the {@code separator} to {@link
//     * #executeSqlScript(Connection, EncodedResource, boolean, boolean, String, String, String, String)}
//     * to denote that an SQL script contains a single statement (potentially
//     * spanning multiple lines) with no explicit statement separator. Note that
//     * such a script should not actually contain this value; it is merely a
//     * <em>virtual</em> statement separator.
//     */
//    public static final String EOF_STATEMENT_SEPARATOR = "^^^ END OF SCRIPT ^^^";
//
//    /**
//     * Default prefix for single-line comments within SQL scripts: {@code "--"}.
//     */
//    public static final String DEFAULT_COMMENT_PREFIX = "--";
//
//    /**
//     * Default start delimiter for block comments within SQL scripts: {@code "/*"}.
//     */
//    public static final String DEFAULT_BLOCK_COMMENT_START_DELIMITER = "/*";
//
//    /**
//     * Default end delimiter for block comments within SQL scripts: <code>"*&#47;"</code>.
//     */
//    public static final String DEFAULT_BLOCK_COMMENT_END_DELIMITER = "*/";
//
//    private static final Logger logger = LoggerFactory.getLogger(ScriptUtils.class);
//
//
//    /**
//     * Split an SQL script into separate statements delimited by the provided
//     * separator character. Each individual statement will be added to the
//     * provided {@code List}.
//     * <p>Within the script, {@value #DEFAULT_COMMENT_PREFIX} will be used as the
//     * comment prefix; any text beginning with the comment prefix and extending to
//     * the end of the line will be omitted from the output. Similarly,
//     * {@value #DEFAULT_BLOCK_COMMENT_START_DELIMITER} and
//     * {@value #DEFAULT_BLOCK_COMMENT_END_DELIMITER} will be used as the
//     * <em>start</em> and <em>end</em> block comment delimiters: any text enclosed
//     * in a block comment will be omitted from the output. In addition, multiple
//     * adjacent whitespace characters will be collapsed into a single space.
//     * @param script the SQL script
//     * @param separator character separating each statement &mdash; typically a ';'
//     * @param statements the list that will contain the individual statements
//     * @throws ScriptException if an error occurred while splitting the SQL script
//     * @see #splitSqlScript(String, String, List)
//     * @see #splitSqlScript(EncodedResource, String, String, String, String, String, List)
//     */
//    public static void splitSqlScript(String script, char separator, List<String> statements) throws ScriptException {
//        splitSqlScript(script, String.valueOf(separator), statements);
//    }
//
//    /**
//     * Split an SQL script into separate statements delimited by the provided
//     * separator string. Each individual statement will be added to the
//     * provided {@code List}.
//     * <p>Within the script, {@value #DEFAULT_COMMENT_PREFIX} will be used as the
//     * comment prefix; any text beginning with the comment prefix and extending to
//     * the end of the line will be omitted from the output. Similarly,
//     * {@value #DEFAULT_BLOCK_COMMENT_START_DELIMITER} and
//     * {@value #DEFAULT_BLOCK_COMMENT_END_DELIMITER} will be used as the
//     * <em>start</em> and <em>end</em> block comment delimiters: any text enclosed
//     * in a block comment will be omitted from the output. In addition, multiple
//     * adjacent whitespace characters will be collapsed into a single space.
//     * @param script the SQL script
//     * @param separator text separating each statement &mdash; typically a ';' or newline character
//     * @param statements the list that will contain the individual statements
//     * @throws ScriptException if an error occurred while splitting the SQL script
//     * @see #splitSqlScript(String, char, List)
//     * @see #splitSqlScript(EncodedResource, String, String, String, String, String, List)
//     */
//    public static void splitSqlScript(String script, String separator, List<String> statements) throws ScriptException {
//        splitSqlScript(null, script, separator, DEFAULT_COMMENT_PREFIX, DEFAULT_BLOCK_COMMENT_START_DELIMITER,
//                DEFAULT_BLOCK_COMMENT_END_DELIMITER, statements);
//    }
//
//    /**
//     * Split an SQL script into separate statements delimited by the provided
//     * separator string. Each individual statement will be added to the provided
//     * {@code List}.
//     * <p>Within the script, the provided {@code commentPrefix} will be honored:
//     * any text beginning with the comment prefix and extending to the end of the
//     * line will be omitted from the output. Similarly, the provided
//     * {@code blockCommentStartDelimiter} and {@code blockCommentEndDelimiter}
//     * delimiters will be honored: any text enclosed in a block comment will be
//     * omitted from the output. In addition, multiple adjacent whitespace characters
//     * will be collapsed into a single space.
//     * @param resource the resource from which the script was read
//     * @param script the SQL script; never {@code null} or empty
//     * @param separator text separating each statement &mdash; typically a ';' or
//     * newline character; never {@code null}
//     * @param commentPrefix the prefix that identifies SQL line comments &mdash;
//     * typically "--"; never {@code null} or empty
//     * @param blockCommentStartDelimiter the <em>start</em> block comment delimiter;
//     * never {@code null} or empty
//     * @param blockCommentEndDelimiter the <em>end</em> block comment delimiter;
//     * never {@code null} or empty
//     * @param statements the list that will contain the individual statements
//     * @throws ScriptException if an error occurred while splitting the SQL script
//     */
//    public static void splitSqlScript(EncodedResource resource, String script, String separator, String commentPrefix,
//                                      String blockCommentStartDelimiter, String blockCommentEndDelimiter, List<String> statements)
//            throws ScriptException {
//
//        Assert.hasText(script, "'script' must not be null or empty");
//        Assert.notNull(separator, "'separator' must not be null");
//        Assert.hasText(commentPrefix, "'commentPrefix' must not be null or empty");
//        Assert.hasText(blockCommentStartDelimiter, "'blockCommentStartDelimiter' must not be null or empty");
//        Assert.hasText(blockCommentEndDelimiter, "'blockCommentEndDelimiter' must not be null or empty");
//
//        StringBuilder sb = new StringBuilder();
//        boolean inSingleQuote = false;
//        boolean inDoubleQuote = false;
//        boolean inEscape = false;
//        for (int i = 0; i < script.length(); i++) {
//            char c = script.charAt(i);
//            if (inEscape) {
//                inEscape = false;
//                sb.append(c);
//                continue;
//            }
//            // MySQL style escapes
//            if (c == '\\') {
//                inEscape = true;
//                sb.append(c);
//                continue;
//            }
//            if (!inDoubleQuote && (c == '\'')) {
//                inSingleQuote = !inSingleQuote;
//            }
//            else if (!inSingleQuote && (c == '"')) {
//                inDoubleQuote = !inDoubleQuote;
//            }
//            if (!inSingleQuote && !inDoubleQuote) {
//                if (script.startsWith(separator, i)) {
//                    // We've reached the end of the current statement
//                    if (sb.length() > 0) {
//                        statements.add(sb.toString());
//                        sb = new StringBuilder();
//                    }
//                    i += separator.length() - 1;
//                    continue;
//                }
//                else if (script.startsWith(commentPrefix, i)) {
//                    // Skip over any content from the start of the comment to the EOL
//                    int indexOfNextNewline = script.indexOf("\n", i);
//                    if (indexOfNextNewline > i) {
//                        i = indexOfNextNewline;
//                        continue;
//                    }
//                    else {
//                        // If there's no EOL, we must be at the end of the script, so stop here.
//                        break;
//                    }
//                }
//                else if (script.startsWith(blockCommentStartDelimiter, i)) {
//                    // Skip over any block comments
//                    int indexOfCommentEnd = script.indexOf(blockCommentEndDelimiter, i);
//                    if (indexOfCommentEnd > i) {
//                        i = indexOfCommentEnd + blockCommentEndDelimiter.length() - 1;
//                        continue;
//                    }
//                    else {
//                        throw new ScriptParseException(
//                                "Missing block comment end delimiter: " + blockCommentEndDelimiter, resource);
//                    }
//                }
//                else if (c == ' ' || c == '\n' || c == '\t') {
//                    // Avoid multiple adjacent whitespace characters
//                    if (sb.length() > 0 && sb.charAt(sb.length() - 1) != ' ') {
//                        c = ' ';
//                    }
//                    else {
//                        continue;
//                    }
//                }
//            }
//            sb.append(c);
//        }
//        if (StringUtils.hasText(sb)) {
//            statements.add(sb.toString());
//        }
//    }
//
//
//    /**
//     * Read a script from the provided resource, using the supplied comment prefix
//     * and statement separator, and build a {@code String} containing the lines.
//     * <p>Lines <em>beginning</em> with the comment prefix are excluded from the
//     * results; however, line comments anywhere else &mdash; for example, within
//     * a statement &mdash; will be included in the results.
//     * @param resource the {@code EncodedResource} containing the script
//     * to be processed
//     * @param commentPrefix the prefix that identifies comments in the SQL script &mdash;
//     * typically "--"
//     * @param separator the statement separator in the SQL script &mdash; typically ";"
//     * @return a {@code String} containing the script lines
//     * @throws IOException in case of I/O errors
//     */
//    private static String readScript(EncodedResource resource, String commentPrefix, String separator)
//            throws IOException {
//
//        LineNumberReader lnr = new LineNumberReader(resource.getReader());
//        try {
//            return readScript(lnr, commentPrefix, separator);
//        }
//        finally {
//            lnr.close();
//        }
//    }
//
//    /**
//     * Read a script from the provided {@code LineNumberReader}, using the supplied
//     * comment prefix and statement separator, and build a {@code String} containing
//     * the lines.
//     * <p>Lines <em>beginning</em> with the comment prefix are excluded from the
//     * results; however, line comments anywhere else &mdash; for example, within
//     * a statement &mdash; will be included in the results.
//     * @param lineNumberReader the {@code LineNumberReader} containing the script
//     * to be processed
//     * @param commentPrefix the prefix that identifies comments in the SQL script &mdash;
//     * typically "--"
//     * @param separator the statement separator in the SQL script &mdash; typically ";"
//     * @return a {@code String} containing the script lines
//     * @throws IOException in case of I/O errors
//     */
//    public static String readScript(LineNumberReader lineNumberReader, String commentPrefix, String separator)
//            throws IOException {
//
//        String currentStatement = lineNumberReader.readLine();
//        StringBuilder scriptBuilder = new StringBuilder();
//        while (currentStatement != null) {
//            if (commentPrefix != null && !currentStatement.startsWith(commentPrefix)) {
//                if (scriptBuilder.length() > 0) {
//                    scriptBuilder.append('\n');
//                }
//                scriptBuilder.append(currentStatement);
//            }
//            currentStatement = lineNumberReader.readLine();
//        }
//        appendSeparatorToScriptIfNecessary(scriptBuilder, separator);
//        return scriptBuilder.toString();
//    }
//
//    private static void appendSeparatorToScriptIfNecessary(StringBuilder scriptBuilder, String separator) {
//        if (separator == null) {
//            return;
//        }
//        String trimmed = separator.trim();
//        if (trimmed.length() == separator.length()) {
//            return;
//        }
//        // separator ends in whitespace, so we might want to see if the script is trying
//        // to end the same way
//        if (scriptBuilder.lastIndexOf(trimmed) == scriptBuilder.length() - trimmed.length()) {
//            scriptBuilder.append(separator.substring(trimmed.length()));
//        }
//    }
//
//    /**
//     * Does the provided SQL script contain the specified delimiter?
//     * @param script the SQL script
//     * @param delim String delimiting each statement - typically a ';' character
//     */
//    public static boolean containsSqlScriptDelimiters(String script, String delim) {
//        boolean inLiteral = false;
//        for (int i = 0; i < script.length(); i++) {
//            if (script.charAt(i) == '\'') {
//                inLiteral = !inLiteral;
//            }
//            if (!inLiteral && script.startsWith(delim, i)) {
//                return true;
//            }
//        }
//        return false;
//    }
//
//    /**
//     * Execute the given SQL script.
//     * <p>Statement separators and comments will be removed before executing
//     * individual statements within the supplied script.
//     * <p><strong>Warning</strong>: this method does <em>not</em> release the
//     * provided {@link Connection}.
//     * @param connection the JDBC connection to use to execute the script; already
//     * configured and ready to use
//     * @param resource the resource (potentially associated with a specific encoding)
//     * to load the SQL script from
//     * @param continueOnError whether or not to continue without throwing an exception
//     * in the event of an error
//     * @param ignoreFailedDrops whether or not to continue in the event of specifically
//     * an error on a {@code DROP} statement
//     * @param commentPrefix the prefix that identifies single-line comments in the
//     * SQL script &mdash; typically "--"
//     * @param separator the script statement separator; defaults to
//     * {@value #DEFAULT_STATEMENT_SEPARATOR} if not specified and falls back to
//     * {@value #FALLBACK_STATEMENT_SEPARATOR} as a last resort; may be set to
//     * {@value #EOF_STATEMENT_SEPARATOR} to signal that the script contains a
//     * single statement without a separator
//     * @param blockCommentStartDelimiter the <em>start</em> block comment delimiter; never
//     * {@code null} or empty
//     * @param blockCommentEndDelimiter the <em>end</em> block comment delimiter; never
//     * {@code null} or empty
//     * @throws ScriptException if an error occurred while executing the SQL script
//     * @see #DEFAULT_STATEMENT_SEPARATOR
//     * @see #FALLBACK_STATEMENT_SEPARATOR
//     * @see #EOF_STATEMENT_SEPARATOR
//     * @see org.springframework.jdbc.datasource.DataSourceUtils#getConnection
//     * @see org.springframework.jdbc.datasource.DataSourceUtils#releaseConnection
//     */
//    public static void executeSqlScript(Connection connection, EncodedResource resource, boolean continueOnError,
//                                        boolean ignoreFailedDrops, String commentPrefix, String separator, String blockCommentStartDelimiter,
//                                        String blockCommentEndDelimiter) throws ScriptException {
//
//        try {
//            if (logger.isInfoEnabled()) {
//                logger.info("Executing SQL script from " + resource);
//            }
//            long startTime = System.currentTimeMillis();
//
//            String script;
//            try {
//                script = readScript(resource, commentPrefix, separator);
//            }
//            catch (IOException ex) {
//                throw new CannotReadScriptException(resource, ex);
//            }
//
//            if (separator == null) {
//                separator = DEFAULT_STATEMENT_SEPARATOR;
//            }
//            if (!EOF_STATEMENT_SEPARATOR.equals(separator) && !containsSqlScriptDelimiters(script, separator)) {
//                separator = FALLBACK_STATEMENT_SEPARATOR;
//            }
//
//            List<String> statements = new LinkedList<String>();
//            splitSqlScript(resource, script, separator, commentPrefix, blockCommentStartDelimiter,
//                    blockCommentEndDelimiter, statements);
//
//            int stmtNumber = 0;
//            Statement stmt = connection.createStatement();
////            if( "oracle".equalsIgnoreCase( connection.getMetaData().getDatabaseProductName() ) ){
////                return;
////            }
//            if (true) {
//                return;
//            }
//            //获取执行脚本
//            if( onceActionIng.get() ){
//                removeAlreadyExecuted( stmt, statements );
//            }
//            try {
//                filterStatements( connection, stmt, statements );
//                for (String statement : statements) {
//                    stmtNumber++;
//                    try {
//                        stmt.execute(statement);
//                        if( onceActionIng.get() ){
//                            recordAlreadyExecuted( connection, statement );
//                        }
//                        int rowsAffected = stmt.getUpdateCount();
//                        if (logger.isDebugEnabled()) {
//                            logger.debug(rowsAffected + " returned as update count for SQL: " + statement);
//                            SQLWarning warningToLog = stmt.getWarnings();
//                            while (warningToLog != null) {
//                                logger.debug("SQLWarning ignored: SQL state '" + warningToLog.getSQLState() +
//                                        "', error code '" + warningToLog.getErrorCode() +
//                                        "', message [" + warningToLog.getMessage() + "]");
//                                warningToLog = warningToLog.getNextWarning();
//                            }
//                        }
//                    }
//                    catch (SQLException ex) {
//                        boolean dropStatement = StringUtils.startsWithIgnoreCase(statement.trim(), "drop");
//                        if (continueOnError || (dropStatement && ignoreFailedDrops)) {
//                            if (logger.isDebugEnabled()) {
//                                logger.debug(ScriptStatementFailedException.buildErrorMessage(statement, stmtNumber, resource), ex);
//                            }
//                        }
//                        else {
//                            throw new ScriptStatementFailedException(statement, stmtNumber, resource, ex);
//                        }
//                    }
//                }
//            }
//            finally {
//                try {
//                    stmt.close();
//                }
//                catch (Throwable ex) {
//                    logger.debug("Could not close JDBC Statement", ex);
//                }
//            }
//
//            long elapsedTime = System.currentTimeMillis() - startTime;
//            if (logger.isInfoEnabled()) {
//                logger.info("Executed SQL script from " + resource + " in " + elapsedTime + " ms.");
//            }
//        }
//        catch (Exception ex) {
//            if (ex instanceof ScriptException) {
//                throw (ScriptException) ex;
//            }
//            throw new UncategorizedScriptException(
//                    "Failed to execute database script from resource [" + resource + "]", ex);
//        }
//    }
//
//    //TODO
//    private static void recordAlreadyExecuted(Connection connection, String statement) throws SQLException {
//
//        PreparedStatement preparedStatement = null;
//        try{
//            String v_sql=statement;
//            String k_sign=MD5Utils.signature( statement );
//            String sql = "insert into ks_sql_chg_note(k_sign,v_sql,cr_dm) values(?,?,?)";
//            preparedStatement = connection.prepareStatement( sql );
//            preparedStatement.setString(1, k_sign);
//            preparedStatement.setString(2, v_sql);
//            preparedStatement.setString(3, DateUtil.getNowDateTimeStr());
//            preparedStatement.executeUpdate();
//        }
//        finally {
//            try {
//                preparedStatement.close();
//            }
//            catch (Throwable ex) {
//                logger.debug("Could not close JDBC Statement", ex);
//                ex.printStackTrace();
//            }
//        }
//
//    }
//
//
//    //TODO
//    private static void removeAlreadyExecuted(Statement stmt, List<String> statements) throws SQLException {
//
//        if( null==statements||statements.isEmpty() ){
//            return;
//        }
//
//        ResultSet rs = stmt.executeQuery("select k_sign,v_sql from ks_sql_chg_note");
//        Set<String> alreadyExecutedSet = new HashSet<>();
//        //查询所有执行过的sql
//        while(rs.next()) {
//            String k_sign = rs.getString("k_sign");
//            alreadyExecutedSet.add( k_sign );
//        }
//
//        Iterator<String> iterator = statements.iterator();
//        while ( iterator.hasNext() ){
//            String next = iterator.next();
//            String signature = MD5Utils.signature(next);
//            if( alreadyExecutedSet.contains( signature )  ){
//                iterator.remove();
//                logger.info("忽略已经执行过的sql:{}",next);
//            }
//        }
//    }
//
//
//    /**
//     *   MySQL  过滤掉字段的重复增删字段  以及纠正改的操作（判断字段是否存在）
//     *
//     *   Microsoft SQL Server  不做任何处理
//     * @param statements
//     */
//    private static void filterStatements(Connection connection,Statement stmt, List<String> statements) throws SQLException {
//
//        if( !"MySQL".equals( connection.getMetaData().getDatabaseProductName() ) || statements.isEmpty() ){
//            return;
//        }
//        Iterator<String> iterator = statements.iterator();
//        while (iterator.hasNext()){
//            String nextScript = iterator.next();
//            if( isRemoveScript( stmt, nextScript ) ){
//                iterator.remove();
//                logger.info("忽略执行sql脚本{}",nextScript);
//            }
//        }
//
//    }
//
//    @Data
//    static class TableModifyAttr{
//        boolean isExistOldTable;
//        boolean isExistOldCol;
//        String tableOldName;
//        String colOldName;
//        TableModifyStyle modifyStyle;
//    }
//
//    enum TableModifyStyle{
//        addCol, updateCol, dorpCol,addIndex,dorpIndex,insertData,
//        addTable, updateTable, dorpTable
//    }
//
//    private static boolean isRemoveScript( Statement stmt,String nextScript) {
//        if( StringUtils.isEmpty(nextScript) ){
//            return true;
//        }
//        TableModifyAttr tableModifyAttr = getTableModifyAttr( stmt, nextScript );
//        if( StringUtils.isEmpty( tableModifyAttr  ) ||StringUtils.isEmpty( tableModifyAttr.tableOldName  ) ){
//            TableModifyStyle tableModifyStyle = getTableModifyStyle(nextScript);
//            if( !TableModifyStyle.insertData.equals( tableModifyStyle ) ){
//                logger.warn( "sql脚本{}未获取到表名",nextScript );
//            }
//            return false;
//        }
//        TableModifyStyle modifyStyle = tableModifyAttr.getModifyStyle();
//        if( TableModifyStyle.addCol.equals( modifyStyle ) ){
//            return tableModifyAttr.isExistOldCol && tableModifyAttr.isExistOldTable;
//        }
//        if( TableModifyStyle.updateCol.equals( modifyStyle ) ){
//            return !tableModifyAttr.isExistOldCol && tableModifyAttr.isExistOldTable;
//        }
//        if( TableModifyStyle.dorpCol.equals( modifyStyle ) ){
//            return !tableModifyAttr.isExistOldCol && tableModifyAttr.isExistOldTable;
//        }
//        if( TableModifyStyle.addIndex.equals( modifyStyle ) ){
//            return tableModifyAttr.isExistOldCol && tableModifyAttr.isExistOldTable;
//        }
//        if( TableModifyStyle.dorpIndex.equals( modifyStyle ) ){
//            return !tableModifyAttr.isExistOldCol && tableModifyAttr.isExistOldTable;
//        }
//        if( TableModifyStyle.addTable.equals( modifyStyle ) ){
//            return tableModifyAttr.isExistOldTable;
//        }
//        if( TableModifyStyle.dorpTable.equals( modifyStyle ) ){
//            return !tableModifyAttr.isExistOldTable;
//        }
//        return false;
//    }
//
//    private static TableModifyAttr getTableModifyAttr( Statement stmt, String nextScript) {
//
//        //空格分割字符串  再拼接成标准的空格
//        Iterable<String> split = Splitter.on(" ").omitEmptyStrings().split(nextScript);
//        Iterator<String> iterator = split.iterator();
//        StringBuffer nextScriptBuf = new StringBuffer();
//        while ( iterator.hasNext() ){
//            String next = iterator.next();
//            next = next.replace("`","");
//            next = next.replace("`","");
//            nextScriptBuf.append(" ").append( next );
//        }
//        String standardSqlScript = nextScriptBuf.toString();
//        TableModifyStyle tableModifyStyle = getTableModifyStyle( standardSqlScript );
//        //正则匹配获取表名
//        String oldTableName = getModifyOldTableName( standardSqlScript );
//        if( StringUtils.isEmpty(oldTableName) ){
//            return null;
//        }
//        //正则匹配获取列名
//        String oldColName = getModifyOldColName( standardSqlScript );
//        TableModifyAttr tableModifyAttr = new TableModifyAttr();
//
//        tableModifyAttr.setExistOldTable( isExistTable( stmt, oldTableName ) );
//        tableModifyAttr.setExistOldCol( isExistCol( stmt,oldTableName, oldColName ) );
//        tableModifyAttr.setTableOldName(oldTableName);
//        tableModifyAttr.setColOldName(oldColName);
//        tableModifyAttr.setModifyStyle(tableModifyStyle);
//
//        return tableModifyAttr;
//    }
//
//    private static boolean isExistCol(Statement stmt, String tableName, String colName) {
//        if( StringUtils.isEmpty(colName) ){
//            return false;
//        }
//        try {
//            StringBuffer sqlBuff = new StringBuffer( "select table_name from information_schema.columns where table_schema = DATABASE() and table_name = '" );
//            sqlBuff.append( tableName ).append( "'  and column_name='" )
//                    .append( colName ).append( "'" );
//            ResultSet resultSet = stmt.executeQuery(sqlBuff.toString());
//            if( resultSet.next() && !StringUtils.isEmpty(resultSet.getString("table_name")) ){
//                return true;
//            }
//        }
//        catch (SQLException ex) {
//            ex.printStackTrace();
//            logger.error( ex.getMessage(), ex );
//            throw new RuntimeException( ex.getMessage(), ex );
//        }
//        return false;
//
//    }
//
//    private static boolean isExistTable(Statement stmt, String oldTableName) {
//        try {
//            StringBuffer sqlBuff = new StringBuffer( "SELECT table_name FROM information_schema.TABLES WHERE table_name ='" );
//            sqlBuff.append( oldTableName ).append( "'" );
//            ResultSet resultSet = stmt.executeQuery(sqlBuff.toString());
//            if( resultSet.next() && !StringUtils.isEmpty(resultSet.getString("table_name")) ){
//                return true;
//            }
//        }
//        catch (SQLException ex) {
//            ex.printStackTrace();
//            logger.error( ex.getMessage(), ex );
//            throw new RuntimeException( ex.getMessage(), ex );
//        }
//        return false;
//    }
//
//
//    /**
//     * 获取需要修改的列名
//     * @param standardSqlScript
//     * @return
//     */
//    private static String getModifyOldColName(String standardSqlScript) {
//
//        // alter table   table1 add COLUMN id  ;
//        // alter table 表名称 change COLUMN 字段名称 字段名称 字段类型 [是否允许非空];
//        //alter table 表名称 modify COLUMN 字段名称 字段类型 [是否允许非空];
//        // ALTER TABLE mytable DROP 字段名;
//        String OldColName = null;
//        Pattern pattern = Pattern.compile("ALTER table (\\S*) (add|change|modify|DROP) (COLUMN|primary)?\\s*(\\S*)",Pattern.CASE_INSENSITIVE);
//        Matcher matcher = pattern.matcher( standardSqlScript );
//        while (matcher.find()) {
//            OldColName = matcher.group(4);
//            break;
//        }
//        if( null!=OldColName ){
//            OldColName = OldColName.replace("key","").
//                    replace("(","").
//                    replace("","").
//                    replace(")","").trim();
//        }
//        return OldColName;
//    }
//
//    /**
//     * 获取需要修改的表名
//     * @param standardSqlScript
//     * @return
//     */
//    private static String getModifyOldTableName(String standardSqlScript) {
//
//        if( haveIf( standardSqlScript ) ){
//            return null;
//        }
//        String oldTableName=null;
//        Pattern pattern = Pattern.compile("(create|ALTER|drop) table (\\S*)",Pattern.CASE_INSENSITIVE);
//        Matcher matcher = pattern.matcher( standardSqlScript );
//        while (matcher.find()) {
//            oldTableName = matcher.group(2);
//            break;
//        }
//        return oldTableName;
//    }
//
//    private static boolean haveIf(String standardSqlScript) {
//        Pattern pattern = Pattern.compile("if",Pattern.CASE_INSENSITIVE);
//        Matcher matcher = pattern.matcher( standardSqlScript );
//        return matcher.find();
//    }
//
////    public static void main(String[] args) {
////
////        String s1 = "drop table if exists ks_model_field_tmp_b_copy" ;
////        String s2 = "create table ks_model_field_tmp_b_copy ( id int )" ;
////        String s3 = "ALTER TABLE `ks_model_field_tmp_b_copy` ADD COLUMN `mmm` varchar(22) CHARACTER SET utf8 COL" ;
////        String s4 = "select 2;" ;
////        String s5 = "alter table employee add primary key(id);" ;
////
////        System.out.println( getModifyOldTableName(s1) );
////        System.out.println( getModifyOldTableName(s2) );
////        System.out.println( getModifyOldTableName(s3) );
////        System.out.println( getModifyOldTableName(s4) );
////        System.out.println( getModifyOldTableName(s5) );
////        System.out.println("----------------------------------------");
////        System.out.println( getModifyOldColName(s1) );
////        System.out.println( getModifyOldColName(s2) );
////        System.out.println( getModifyOldColName(s3) );
////        System.out.println( getModifyOldColName(s4) );
////        System.out.println( getModifyOldColName(s5) );
////
////    }
//
//    private static TableModifyStyle getTableModifyStyle(String standardSqlScript) {
//
//        standardSqlScript = CharMatcher.WHITESPACE.collapseFrom(standardSqlScript, ' ');
//
//        Pattern pattern = Pattern.compile("(create) table (\\S*)",Pattern.CASE_INSENSITIVE);
//        Matcher matcher = pattern.matcher( standardSqlScript );
//        while (matcher.find()) {
//            return TableModifyStyle.addTable;
//        }
//
//        pattern = Pattern.compile("(drop) table (\\S*)",Pattern.CASE_INSENSITIVE);
//        matcher = pattern.matcher( standardSqlScript );
//        while (matcher.find()) {
//            return TableModifyStyle.dorpTable;
//        }
//
//        pattern = Pattern.compile("ALTER table (\\S*) add (COLUMN|primary)?\\s*(\\S*)",Pattern.CASE_INSENSITIVE);
//        matcher = pattern.matcher( standardSqlScript );
//        while (matcher.find()) {
//            return TableModifyStyle.addCol;
//        }
//
//        pattern = Pattern.compile("ALTER table (\\S*) (change|modify) (COLUMN|primary)?\\s*(\\S*)",Pattern.CASE_INSENSITIVE);
//        matcher = pattern.matcher( standardSqlScript );
//        while (matcher.find()) {
//            return TableModifyStyle.updateCol;
//        }
//
//        pattern =  Pattern.compile("ALTER table (\\S*) DROP (COLUMN|primary)?\\s*(\\S*)",Pattern.CASE_INSENSITIVE);
//        matcher = pattern.matcher( standardSqlScript );
//        while (matcher.find()) {
//            return TableModifyStyle.dorpCol;
//        }
//        pattern =  Pattern.compile("INSERT (\\s*)INTO (\\s*)(\\S*)",Pattern.CASE_INSENSITIVE);
//        matcher = pattern.matcher( standardSqlScript );
//        while (matcher.find()) {
//            return TableModifyStyle.insertData;
//        }
//
//        return null;
//    }
//
//}
//
