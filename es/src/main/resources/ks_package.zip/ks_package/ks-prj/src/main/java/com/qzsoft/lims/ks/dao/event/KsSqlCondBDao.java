package com.qzsoft.lims.ks.dao.event;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlCondBDao extends BaseDao{

	/**
	 *  条件组
	 * @return
	 */
	List<Record> getByPCode(String pCode, Boolean jsonYn);
	
	/**
	 * 批量保存
	 * @param allCondList
	 * @return
	 */
	Boolean batchUpdate(List<Map<String, Object>> allCondList);

	Map<String, Object> getGroupConds(String pCode, Boolean jsonYn);

	Boolean saveGroupConds( List<List<Map<String, Object>>> groupConds, String pCode, String menuId);

	Map<String, Object> getGroupCondsByCode( List<String> codes );
}
