package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.dao.KsCompConfBDao;
import com.qzsoft.lims.ks.dao.KsCompConfParaBDao;
import com.qzsoft.lims.ks.dao.comp.KsCompConfActBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 组件管理-dao实现
 * @author hqp
 *
 */
@Repository
public class KsCompConfBDaoImpl extends BaseDaoImpl implements KsCompConfBDao {
	private static final String TABLE_NAME = "ks_comp_conf_b";

	@Autowired
	private KsCompConfActBDao ksCompConfActBDao;

	@Autowired
	private KsCompConfParaBDao ksCompConfParaBDao;

	/**
	 * 新增
	 * @param record
	 * @return
	 */
	@Override
	public Boolean save(Record record) {
		return super.save(TABLE_NAME,record);
	}
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	@Override
	public Boolean update(Record record) {
		return super.update(TABLE_NAME,record);
	}
	
	/**
	 * 删除
	 * @param infoCode INFO编码
	 * @return
	 */
	@Override
	public Boolean deleteByInfoCode(String infoCode) {
		return super.deleteByCustom(TABLE_NAME, "info_code", infoCode);
	}
	
	/**
	 * 根据INFO编码查询
	 * @return
	 */
	@Override
	public List<Record> getListByInfoCode(String infoCode) {
		return DbEx.find("select * from " + TABLE_NAME+" where info_code = ? order by conf_order ",infoCode);
	}
	
	/**
	 * 根据组件编码查询
	 * @return
	 */
	@Override
	public Record getOneByCompCode(String compCode) {
		List<Record> recs = DbEx.find("select * from " + TABLE_NAME+" where comp_code = ? ",compCode);
		if(recs != null && recs.size() > 0){
			return recs.get(0);
		}else{
			return null;
		}	 
	}
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	@Override
	public Record getOne(Long id) {
		return super.selectById(TABLE_NAME,id);
	}
	
	/**
	 * 查询下一个组件编码
	 * @param infoCode INFO编码
	 * @return
	 */
	@Override
	public String getNextCompCode(String infoCode) {
		List<Record> recs1 = DbEx.find("select comp_code from ks_comp_conf_b where info_code=? "
				+ " order by comp_code desc",infoCode);
		if(recs1 != null && recs1.size() > 0){
			Record rec1 = recs1.get(0);
			String compCode = rec1.getStr("comp_code");
			Integer index = compCode.lastIndexOf("_");
			if(index >= 0){
				String order = compCode.substring(index+1);
				Integer i = 0;
				try{
					i = Integer.valueOf(order);
				}catch(Exception e){
					
				}
				i ++;
				return compCode.substring(0, index+1) + i;
			}else{
				return compCode + "_1";
			}				
		}else{
			return infoCode + "$comp_code_1";
		}
	}

	@Override
	public Record getCompData(String compCode) {
		if (StringUtils.isBlank( compCode )){
			return null;
		}
		Record record = getOneByColumn(TABLE_NAME , "comp_code", compCode);
		if (null == record){
			return null;
		}
		List<Record> compParas = ksCompConfParaBDao.getListByCompCode(compCode);
		record.set("CompConfParaList", DataBaseUtil.record2Map( compParas ));
		List<Record> compEves = ksCompConfActBDao.getByCompCode( compCode );
		record.set("compEves", DataBaseUtil.record2Map( compEves ));
		return record;
	}

	@Override
	@JFinalTx
	public Boolean saveCompData(Map<String, Object> compDatas, String mCode, String infoCode, String menuId, String compCode) {
		boolean succYn = true;
		if (null == compDatas || compDatas.isEmpty() || StringUtils.isBlank(StringUtil.toString(compDatas.get("comp_type")))){
			BusinessException.throwBiz("外部组件不能为空");
		}
		List<Map<String, Object>> compParas = (List<Map<String, Object>>)compDatas.get("CompConfParaList");
		List<Map<String, Object>> compEves = (List<Map<String, Object>>)compDatas.get("compEves");
		compDatas.put("m_code", mCode);
		compDatas.put("info_code", infoCode);
		compDatas.put("comp_code", compCode);
		compDatas.put("menu_id", menuId);
		compDatas.put("cr_dm", DateUtil.getNowDateTimeStr());
		compDatas.put("up_ver", "1");
		compDatas.remove("CompConfParaList");
		compDatas.remove("compEves");
		save( TABLE_NAME, DataBaseUtil.map2Record( compDatas ));

		ksCompConfParaBDao.saveCompData( compParas, compCode, menuId);
		ksCompConfActBDao.saveCompConfAct(infoCode, compCode, menuId, compEves);
		return succYn;
	}
}
