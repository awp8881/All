package com.qzsoft.lims.ks.config.msg;

import lombok.*;

/**
 * 微信公众号配置
 *
 * @author yuanj
 * @since 2021/12/29
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WechatOfficialAccountConfig extends Config {
    private static final long serialVersionUID = -9206902816158196669L;

    private String appId = "当设置为appId(wx0d125e6f89111cscs),那么接收人应该为openid";
    private String secret = "密钥（022268b39b3292702183ccecc7636dsdsd）";

}
