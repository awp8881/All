package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.sign.SignService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 签章控制器
 * @author zf
 */
@Api(value = "签名控制器", tags = "签名控制器")
@RestController
@RequestMapping("/sign")
@Slf4j
public class SignController {

    @Autowired
    private SignService signService;

    @ApiOperation(value = "签名")
    @PostMapping("/signName")
    @ResponseAddHead
        public RequestResult<Long> signName(@RequestParam(value = "certId") String certId, @RequestParam(value = "img") String img) {
        RequestResult<Long> result = new RequestResult<>();
        result.setObj( signService.signName( certId, img) );
        return result;
    }

}
