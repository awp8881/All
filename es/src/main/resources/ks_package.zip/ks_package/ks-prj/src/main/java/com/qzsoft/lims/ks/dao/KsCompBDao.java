package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.lims.ks.entity.KsCompBEntity;

/**
 * 组件定义-dao接口
 * @author hqp
 *
 */
public interface KsCompBDao {
	/**
	 * 新增
	 * @param record
	 * @return
	 */
	Boolean save(Record record);
	
	
	/**
	 * 修改
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	
	/**
	 * 删除
	 * @param compType 组件类型
	 * @return
	 */
	Boolean deleteByCompType(String compType);
	
	/**
	 * 删除
	 * @param defCode 组件编码
	 * @return
	 */
	Boolean deleteByDefCode(String defCode);
	
	/**
	 * 删除
	 * @param compType 组件类型
	 * @return
	 */
	Boolean deleteById(Long id);
	
	/**
	 * 详情查询
	 * @param id 主键
	 * @return
	 */
	Record getOne(Long id);
	
	/**
	 * 根据组件类型查询组件定义
	 * @return
	 */
	Record getCompByCompType(String compType);
	
	/**
	 * 根据定义编码查询组件定义
	 * @return
	 */
	Record getCompByDefCode(String defCode);
	
	/**
	 * 查询所有组件定义
	 * @return
	 */
	List<Record> getAll();

	/**
	 * 查询当前组件的子节点数量
	 * @return
	 */
	List<Record> getChildCountById(String id);

	/**
	 * 查询除此Id外的所有组件
	 * @return
	 */
	List<Record> getAllCompsWithOutThisId(String id);


	/**
	 * 更新组件图片信息
	 * @param ksCompBEntity
	 */
	void updateComPic(KsCompBEntity ksCompBEntity);
}
