package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 列表字段属性-dao
 * @author zf
 *
 */
public interface KsModelListFieldDao extends BaseDao{
	
	/**
	 * 通过模板编码获取列表字段
	 * @param m_code
	 * @param m_code_type
	 * @return
	 */
	List<Record>  getFieldByMCode(String m_code,String m_code_type);


	/**
	 * 模板编码集合获取
	 * @param mCodeList
	 * @return
	 */
	List<Record> getFieldListByMcodeList(List<String> mCodeList,String m_code_type);
	
	/**
	 * 列表字段树结构
	 * @param mCode
	 * @param mType
	 * @return
	 */
	List<Record> getFieldsTreeByList(String mCode, String mType);

	/**
	 * 获取页面配置的显示字段
	 * @param mcode
	 * @param mType
	 * @return
	 */
	List<Record> getFeildIsShow(String mcode,String mType);

	/**
	 * 获取大列表页面配置的显示字段
	 * @param mcode
	 * @return
	 */
	List<Record> getFieldIsShow(String mcode);

	List<Record> getFieldIsLoad( String mCode, String mCodeType );
}
