package com.qzsoft.lims.ks.dao.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsMenuCDao;

/**
 * 菜单配置-dao实现
 * @author zf
 *
 */
@Repository
public class KsMenuCDaoImpl extends BaseDaoImpl implements KsMenuCDao{

	private static final String TABLE_NAME = "ks_menu_c";

	/**
	 * 新增
	 * @param record
	 * @return
	 */
	@Override
	public Boolean save(Record record) {
		return super.save(TABLE_NAME,record);
	}

	/**
	 * 修改
	 * @param record
	 * @return
	 */
	@Override
	public Boolean update(Record record) {
		return super.updateByVersionAndId(TABLE_NAME,record);
	}

	/**
	 * 删除
	 * @param id 主键
	 * @return
	 */
	@Override
	public Boolean delete(Long id) {
		return DbEx.delete("delete from "+TABLE_NAME+" where id=? or fa_res_no=?",id,id) > 0;
	}

	/**
	 * 菜单是否存在
	 * @param resNa 菜单名称
	 * @param menuId 菜单id
	 * @return
	 */
	@Override
	public List<Record> isExists(String resNa, Long menuId) {
		return super.selectListByCustom(TABLE_NAME, "res_na", menuId, resNa);
	}

	/**
	 * 树列表查询
	 */
	@Override
	public List<Record> getTreeList(String res_na,Boolean isAnalyze) {
		String table=TABLE_NAME;
		if(isAnalyze){
			table="ta_menu_c";
		}
		String str="select * from "+table;
		if(StringUtils.isNotBlank(res_na)){
			str+=" where locate(?,res_na)>0 or fa_res_no is null order by disp_or+0 asc ";
			return DbEx.find(str,res_na);
		}else{
			str+=" order by disp_or+0 asc ";
			return DbEx.find(str);
		}

	}

	/**
	 * 详情查询
	 * @param id 主键`
	 * @return
	 */
	@Override
	public Record getOne(Long id) {
		return super.selectById(TABLE_NAME,id);
	}

	/**
	 * 通过父id获取
	 * @param faResNo
	 * @return
	 */
	@Override
	public List<Record> getByFaResNo(Long faResNo) {
		if(!ObjectUtils.isEmpty(faResNo)){
			List<Record> recordList= super.selectListByCustom(TABLE_NAME, "fa_res_no", null, faResNo);
			return recordList;
		}
		return null;
	}

	@Override
	public Record selectMaxOrder() {
		return selectFirstOneBySql( "select * from ks_menu_c order by disp_or+0 desc" );
	}

	/**
	 * 菜单是否已有数据源
	 */
	@Override
	public Boolean isExistsModel(String menuId) {
		String sql = "select id from "+TABLE_NAME+" where id=? and (m_code is not  null and  m_code !='' )";
		Record record = selectFirstOneBySql(sql , menuId);
		return null != record;
	}

	/**
	 * 页面使用菜单
	 */
	@Override
	public List<Record> getUseList (String menuId) {

		if (StringUtils.isBlank(menuId)) {
			String sql = "select id,res_na, (select res_na from ks_menu_c where id = k1.fa_res_no) as faName from "+TABLE_NAME+" k1 " +
					" where m_code is not  null and  m_code !='' order by fa_res_no+0,id+0";
			return selectListBySqlNoParas( sql );
		}else {

			String sql = "select id,res_na,(select res_na from ks_menu_c where id = k1.fa_res_no) as faName from "+TABLE_NAME+" k1  where id=?";
			return selectListBySql( sql, menuId );
		}

	}

	@Override
	public List<Record> getNewUseList(String menuId) {
		if (StringUtils.isBlank(menuId)) {
			String sql = "select id ,res_na, fa_res_no,res_url_ca,m_code from "+ TABLE_NAME;
			return selectListBySqlNoParas( sql );
		}else {

			String sql = "select id ,res_na , fa_res_no,res_url_ca,m_code from "+ TABLE_NAME +" where id=? ";
			return selectListBySql( sql, menuId );
		}
	}

	@Override
	public List<Record> getTreeListOfRemove() {
		String sql ="select id as value,res_na as label,fa_res_no from "+TABLE_NAME +" order by disp_or+0 asc ";
		return selectListBySqlNoParas(sql);
	}

	@Override
	public List<Record> getParents(String menuId) {

		String sql = null;
		List<Record> records = null;
		if (DbEx.isMysql()){
//			sql = "select * from "+ TABLE_NAME+" where id != 1 and FIND_IN_SET(id,f_qz_ks_menu_tree(?)) > 0";
			sql = "select * from ks_menu_c where id in( select fa_res_no from ks_menu_c where id = ?) ";
			records = DbEx.find( sql, menuId);

		}else if (DbEx.isSqlserver()){
			sql = "with menuTree AS ( SELECT * from ks_menu_c where id=? UNION ALL SELECT ks_menu_c.* from menuTree " +
					" JOIN ks_menu_c on menuTree.fa_res_no = ks_menu_c.id where ks_menu_c.id != 1 ) SELECT * from menuTree";
			records = DbEx.find( sql, menuId);

		}else {
			sql = "select * from ks_menu_c where id != 1 start with  id=?  connect by id = prior FA_RES_NO ";
			records = DbEx.find( sql, menuId);
		}
		return records;
	}
}
