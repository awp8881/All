package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

import java.util.Set;

/**
 * 小列表数据源条件
 * */
public interface KsSqlSelectCSqlBDao extends BaseDao{
	
	/**
	 * 获取小列表脚本、where条件
	 * @param p_m_code
	 * @param m_code
	 * @param m_order
	 * @param event_type
	 * @return
	 */
	Record getScriptAndSqlOther(String p_m_code, String m_code, String m_order, String event_type, String selectCodeB);
	
	/**
	 * 保存
	 */
	Boolean save( String newSelectCodeB,String select_script, String sql_other, String menu_id, String mCode, String pCode);

	//更新小列表父级数据源
	Boolean updateBusCode(String selectCodeB, String mCode, Set<String> codeList);

	Record getBusCode(String selectCodeB);
	
}
