package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsMenuLogicContentBDao;
import com.qzsoft.lims.ks.eum.MTypeEnum;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

/**
 * 按钮的逻辑脚本
 *
 */
@Repository
public class KsMenuLogicContentBDaoImpl extends BaseDaoImpl implements KsMenuLogicContentBDao {
    private static final String TABLE_NAME_B = "ks_menu_logic_content_b";
    private static final String TABLE_NAME_C = "ks_menu_logic_content_c";

    /**
     * 列表或详情所有按钮脚本
     */
    @Override
    public List<Record> getLogicContentByMcode(String m_code, String info_code, String m_code_type) {
        String table = TABLE_NAME_B;
        if (McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)) {
            table = TABLE_NAME_C;
        }
        List<Record> recordList = null;
        String sql = "select * from " + table + " where 1=1 ";
        List<String> list = new ArrayList<>();
        if (StringUtils.isNotBlank(m_code)) {
            sql += " and m_code=? and (info_code is null or info_code ='') ";
            list.add(m_code);
        }
        if (StringUtils.isNotBlank(info_code)) {
            sql += " and info_code=? ";
            list.add(info_code);
        }
        sql += " order by cr_dm desc";
        recordList = DbEx.find(sql, list.toArray());
        return recordList;
    }

    /**
     * 删除后插入
     */
    @JFinalTx
    @Override
    public Boolean batchUpdate(List<Record> logicContentList, Integer isSaveAs, String old_m_code, String info_code, String menu_id) {
        Boolean isSucc = true;
        String table = isSaveAs == YnEnum.N.getCode() ? TABLE_NAME_B : TABLE_NAME_C;
        String sql = "delete from " + table + " where 1=1 ";
        String code = old_m_code;
        if (StringUtils.isNotBlank(info_code)) {
            sql += " and info_code=?";
            code = info_code;
        } else {
            sql += " and m_code=? and (info_code is null or info_code ='') ";
        }
        DbEx.delete(sql, code);
        if (null != logicContentList && logicContentList.size() > 0) {
            for (Record record : logicContentList) {
                record.set("menu_id", menu_id);
            }
            isSucc = saveList(table, logicContentList);
        }
        return isSucc;
    }

    @Override
    public List<Record> getEventValByMCode(String mCode, String type,String infoCode) {
        String sql = "";
        if (MTypeEnum.OUTER_LIST.getCode().equals(type)) {
			sql = "select event_val from "+TABLE_NAME_B+" where m_code = ? and info_code is null";
            return selectListBySql(sql,mCode);
        }else if(MTypeEnum.INNER_LIST.getCode().equals(type)){
            sql = "select event_val from "+TABLE_NAME_C+" where m_code = ? and info_code is null";
            return selectListBySql(sql,mCode);
        }else{
            sql = "select event_val from "+TABLE_NAME_B+" where m_code = ? and info_code = ?";
            return selectListBySql(sql,mCode,infoCode);
        }
    }

    @Override
    public List<Record> getAllEventValList(String type) {
        String sql;
        if(MTypeEnum.INNER_LIST.getCode().equals(type)){
            sql = "select event_val,m_code from "+TABLE_NAME_C;
            return selectListBySql(sql);
        }else{
            sql = "select event_val,m_code,info_code from "+TABLE_NAME_B;
            return selectListBySql(sql);
        }
    }
}
