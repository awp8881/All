package com.qzsoft.lims.ks.dao.comp.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.comp.KsSqlSelectGroBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @Author zf
 * @Description 条件组
 * @Date 2019/9/3
 */
@Repository
public class KsSqlSelectGroBDaoImpl extends BaseDaoImpl implements KsSqlSelectGroBDao {

    private static final String TABLE_NAME = "ks_sql_select_gro_b";

    /**
     * 条件组
     *
     * @param groSelectCode
     * @return
     */
    @Override
    public List<Record> getGroupConds(String groSelectCode) {

        String sql = "select * from "+TABLE_NAME+" where gro_select_code=? order by group_no+0";
        List<Record> records = selectListBySql( sql, groSelectCode );
        return records;
    }


    @Override
    @JFinalTx
    public Boolean saveGroupConds(List<Map<String, Object>> groupConds) {
        boolean isSucc = true;
        if (null == groupConds || groupConds.isEmpty()){
            return isSucc;
        }
        List<Record> records = DataBaseUtil.map2Record( groupConds );
        saveList( TABLE_NAME, records);
        return isSucc;
    }
}
