package com.qzsoft.lims.ks.dao;

import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.lims.ks.vo.KsTableFieldCVO;

import java.util.List;
import java.util.Map;

/**
 * 系统自动化SQL语句Dao
 * @author zf
 *
 */
public interface KsTableFieldCDao extends BaseDao{
	
	/**
	 * 列表分页查询
	 * @param ksTableFieldCO
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	Page<Record> getPageList(KsTableFieldCVO ksTableFieldCO,Integer pageNum,Integer pageSize);
	
	List<Map<String, Object>> getList(KsTableFieldCVO ksTableFieldCO);
	
	/**
	 * 表名集合获取字段
	 * @param list
	 * @return
	 */
	List<Record> getByTNameList(List<String> list);
	
	/**
	 * 表名集合获取字段
	 * @param tables
	 * @return
	 */
	List<Record> getByTNameList(String tables);
	
	/**
	 * 通过字段集合获取数据
	 * @param fieldList
	 * @param t_name
	 * @return
	 */
	List<Record> getByColumnList(List<String> fieldList,String t_name);
	
	List<Record> getAllFields();
	
	List<Record> getByTName(String tName);



}
