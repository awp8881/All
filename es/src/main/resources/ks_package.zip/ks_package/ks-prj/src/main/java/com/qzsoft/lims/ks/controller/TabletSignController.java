package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.tools.ConfigUtil;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.WebSocket;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Api(value = "平板签字控制器", tags = "平板签字控制器")
@Controller
@RequestMapping("/tablet")
@Slf4j
public class TabletSignController {


	@ApiOperation(value="获取链接地址",notes="关联表：无")
	@GetMapping("getServer")
	@ResponseBody
	public RequestResult<Map<String, Object>> getWebSocket(){
		RequestResult<Map<String, Object>> result = null;
		try {
			String server = ConfigUtil.getPropertyValue("websocket.url");
			Map<String, Object> m = new HashMap<>();
			m.put("server", server);
			result = new RequestResult<>(m);
		} catch (Exception e) {
			result = RequestResult.error(e);
			log.error(e.getMessage(), e);
		}
		return result;
	}


}
