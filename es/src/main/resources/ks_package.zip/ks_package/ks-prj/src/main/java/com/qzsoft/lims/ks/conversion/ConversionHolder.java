package com.qzsoft.lims.ks.conversion;

import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.lims.ks.eum.AfterFollowTypeEnum;
import com.qzsoft.lims.ks.eum.AfterTypeEventEnum;
import com.qzsoft.lims.ks.eum.ClickEventTypeEnum;
import com.qzsoft.lims.ks.eum.ColorEventTypeEnum;
import com.qzsoft.lims.ks.eum.FieldStyleEnum;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * @author pjh
 * @Title: ConversionHolder
 * @Description: TODO
 * @date 2018/9/7 14:00
 */
@Slf4j
public class ConversionHolder {

    //用于保存时，入库
    private static final Map<String,DataConversion> saveMap = new HashMap<>();
    //用于查询时，出库
    private static final Map<String,DataConversion> selectMap = new HashMap<>();

    static {
        saveMap.put( FieldStyleEnum.checkbox.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.multiSelect.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.searchMulti.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.searchMultiTree.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.searchMultiSelect.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.searchMultiLabel.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.linkPort.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( AfterTypeEventEnum.refresh_control.getCode(), new ArrayDataSaveConversionImpl() );
        saveMap.put( AfterFollowTypeEnum.but_active.getCode(), new ArrayDataSaveConversionImpl() );
        saveMap.put( ClickEventTypeEnum.SAVE_IGNORE.getCode(), new ArrayDataSaveConversionImpl() );
        saveMap.put( AfterTypeEventEnum.success_close.getCode(), new ArrayDataSaveConversionImpl() );
        saveMap.put( ColorEventTypeEnum.FONT_COLOR.getCode(), new ArrayDataSaveConversionImpl() );
        saveMap.put( AfterTypeEventEnum.details_close.getCode(), new ArrayDataSaveConversionImpl() );
        saveMap.put( CommonConstants.LIST_INFO, new ArrayDataSaveConversionImpl() );
        saveMap.put( AfterFollowTypeEnum.refresh_control.getCode(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.mergeField.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.searchMultiSelectCreate.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.searchMultiCreate.name(), new ArrayDataSaveConversionImpl() );
        saveMap.put( FieldStyleEnum.searchMultiCreateQuery.name(), new ArrayDataSaveConversionImpl() );

        selectMap.put( FieldStyleEnum.checkbox.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.multiSelect.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.searchMulti.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.searchMultiTree.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.searchMultiSelect.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.searchMultiLabel.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.linkPort.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( AfterTypeEventEnum.refresh_control.getCode(), new ArrayDataSelectConversionImpl() );
        selectMap.put( AfterFollowTypeEnum.but_active.getCode(), new ArrayDataSelectConversionImpl() );
        selectMap.put( ClickEventTypeEnum.SAVE_IGNORE.getCode(), new ArrayDataSelectConversionImpl() );
        selectMap.put( AfterTypeEventEnum.success_close.getCode(), new ArrayDataSelectConversionImpl() );
        selectMap.put( ColorEventTypeEnum.FONT_COLOR.getCode(), new ArrayDataSelectConversionImpl() );
        selectMap.put( AfterTypeEventEnum.details_close.getCode(), new ArrayDataSelectConversionImpl() );
        selectMap.put( CommonConstants.LIST_INFO, new ArrayDataSelectConversionImpl() );
        selectMap.put( AfterFollowTypeEnum.refresh_control.getCode(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.mergeField.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.searchMultiSelectCreate.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.searchMultiCreate.name(), new ArrayDataSelectConversionImpl() );
        selectMap.put( FieldStyleEnum.searchMultiCreateQuery.name(), new ArrayDataSelectConversionImpl() );
    }



    public static Object saveDataConversion(String fieldStyle,Object obj){

        DataConversion dataConversion = saveMap.get(fieldStyle);
        if( null==dataConversion ){
            return obj;
        }
        return dataConversion.conversion( obj );

    }

    public static Object selectDataConversion(String fieldStyle,Object obj){

        DataConversion dataConversion = selectMap.get(fieldStyle);
        if( null==dataConversion ){
            return obj;
        }
        return dataConversion.conversion( obj );

    }


}
