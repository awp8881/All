package com.qzsoft.lims.hlyy.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.hlyy.dao.SamplingDao;
import com.qzsoft.lims.hlyy.eum.ProgressEnum;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
public class SamplingDaoImpl extends BaseDaoImpl implements SamplingDao {

    private static final String PROJECT_TABLE_NAME = "yyky_project";
    private static final String GROUP_TABLE_NAME = "yyky_group";
    private static final String CYCLE_TABLE_NAME = "yyky_cycle";
    private static final String NODE_TABLE_NAME = "yyky_node";
    private static final String DONOR_TABLE_NAME = "yyky_donor";
    private static final String DON_CYCLE_TABLE_NAME = "yyky_don_cycle";
    private static final String SAMPLE_TABLE_NAME = "yyky_sample";
    private static final String SAMPLE_RULE_TABLE_NAME = "yyky_sample_rule";

    @Override
    public boolean addGroups(Record record) {
        return super.save(GROUP_TABLE_NAME,record);
    }

    @Override
    public List<Record> getAllGroupsByProjId(Long proj_id) {
        return DbEx.find("select * from " + GROUP_TABLE_NAME+" where proj_id = ?",proj_id);
    }

    @Override
    public boolean addCycle(Record record) {
        return super.save(CYCLE_TABLE_NAME,record);
    }

    @Override
    public List<Record> getAllCycleByProjId(Long proj_id) {
        return DbEx.find("select * from " + CYCLE_TABLE_NAME+" where proj_id = ?",proj_id);
    }

    @Override
    public List<Record> getAllCycleByProjAndGroupId(String id, String proj_id) {
        return DbEx.find("select * from " + CYCLE_TABLE_NAME+" where proj_id = ? and grop_id = ?",proj_id,id);
    }

    @Override
    public void delCycleByProjId(Long proj_id) {
        DbEx.delete("delete from " + CYCLE_TABLE_NAME+" where proj_id = ?",proj_id);
    }

    @Override
    public void delCycleByProjIdAndNo(String proj_id, int cycle_no) {
        DbEx.delete("delete from " + CYCLE_TABLE_NAME+" where proj_id = ? and cyc_no = ?",proj_id,cycle_no);
    }

    @Override
    public boolean delCycleByGropId(List<String> ids) {
        return DbEx.batchDelete(CYCLE_TABLE_NAME,"grop_id",ids);
    }

    @Override
    public boolean delGropsByIds(List<String> ids) {
        return DbEx.batchDelete(GROUP_TABLE_NAME,"id",ids);
    }

    @Override
    public Record findGroById(String groupId) {
        return DbEx.findById(GROUP_TABLE_NAME,groupId);
    }

    @Override
    public boolean updateGropInfo(Record record) {
        return DbEx.update(GROUP_TABLE_NAME,record);
    }

    @Override
    public Record findCycById(String cycleId) {
        return DbEx.findById(CYCLE_TABLE_NAME,cycleId);
    }

    @Override
    public boolean updateCycInfo(Record record) {
        return DbEx.update(CYCLE_TABLE_NAME,record);
    }

    @Override
    public boolean addType(Record info) {
        return super.save(NODE_TABLE_NAME,info);
    }

    @Override
    public List<Record> getAllNodeByCycId(String cycleId) {
        return DbEx.find("select * from " + NODE_TABLE_NAME+" where cyc_id = ?",cycleId);
    }

    @Override
    public Object getMaxNodeNo(String grop_id, String nd_type) {
        return DbEx.queryFirst("SELECT MAX(nd_no) FROM "+NODE_TABLE_NAME+" where grop_id = ? and nd_type = ?",grop_id,nd_type);
    }

    @Override
    public void delType(Record info) {
        String grop_id = info.get("grop_id");
        String nd_type = info.get("nd_type");
        DbEx.delete("delete from  "+NODE_TABLE_NAME+"  where grop_id = ? and nd_type = ?",grop_id,nd_type);
    }

    @Override
    public Boolean updateType(String cycleId, String original_type, String current_type) {
        DbEx.update("update "+NODE_TABLE_NAME+" set nd_type = ? where grop_id = ? and nd_type = ?",current_type,cycleId,original_type);
        return true;
    }

    @Override
    public boolean delNodeByIds(List<String> ids) {
        return DbEx.batchDelete(NODE_TABLE_NAME,"id",ids);
    }

    @Override
    public Record findNodeById(String nodeId) {
        return DbEx.findById(NODE_TABLE_NAME,nodeId);
    }

    @Override
    public boolean updateNodeVal(Record record) {
        return  DbEx.update(NODE_TABLE_NAME,record);
    }

    @Override
    public Object isHaveNode(Object id) {
        return DbEx.queryFirst("select count(1) from " + NODE_TABLE_NAME+" where grop_id = ?",id);
    }

    @Override
    public Object getMaxCycleNo(String proj_id) {
        return DbEx.queryFirst("SELECT MAX(cyc_no) FROM "+CYCLE_TABLE_NAME+" where proj_id = ? ",proj_id);
    }

    @Override
    public  void saveDonor(Record donor) {
        super.save(DONOR_TABLE_NAME,donor);
    }

    @Override
    public void saveSample(Record sample) {
        super.save(SAMPLE_TABLE_NAME,sample);
    }

    @Override
    public  void saveDonCycle(Record donCycle) {
        super.save(DON_CYCLE_TABLE_NAME,donCycle);
    }

    @Override
    public Record getProjectById(String projId) {
         return DbEx.findById(PROJECT_TABLE_NAME,projId);
    }

    @Override
    public void updateProj(Record proj_effect_yn) {
        DbEx.update(PROJECT_TABLE_NAME,proj_effect_yn);
    }

    @Override
    public List<Record> getTypeOrderByCTime(String cycleId) {
        return DbEx.find("select nd_type from " + NODE_TABLE_NAME+" where cyc_id = ? ORDER BY create_time ASC ",cycleId);
    }

    @Override
    public void delDonorByProjId(String projId) {
        DbEx.delete("delete from "+ DONOR_TABLE_NAME +" where proj_id = ?",projId);
    }

    @Override
    public void delDonCycByProjId(String projId) {
        DbEx.delete("delete from "+ DON_CYCLE_TABLE_NAME +" where proj_id = ?",projId);
    }

    @Override
    public void delSampByProjId(String projId) {
        DbEx.delete("delete from "+ SAMPLE_TABLE_NAME +" where p_flow_node = '"+ ProgressEnum.XMFAGL.getCode()+"' and proj_id = ?",projId);
    }

    @Override
    public Record getCycleById(String copiedCycId) {
        return DbEx.findById(CYCLE_TABLE_NAME,copiedCycId);
    }

    @Override
    public void batchPaste(List<Record> nodeList) {
        DbEx.batchSave(NODE_TABLE_NAME,nodeList,nodeList.size());
    }

    @Override
    public void delNodeByCycId(String targetCycId) {
        DbEx.delete("delete from "+ NODE_TABLE_NAME +" where cyc_id = ?",targetCycId);
    }

    @Override
    public Record getGroupsById(Object grop_id) {
        return DbEx.findById(GROUP_TABLE_NAME,grop_id);
    }

    @Override
    public List<Record> getAllSampleByProjIdAndGroupBy(String projId) {
        return DbEx.find("select * from "+SAMPLE_TABLE_NAME+" where proj_id = ? GROUP BY cyc_id ORDER BY disp_or ASC",projId);
    }

    @Override
    public List<Record> getAllSampleByProjId(String projId) {
        return DbEx.find("select * from "+SAMPLE_TABLE_NAME+" where proj_id = ? ORDER BY disp_or ASC",projId);
    }

    @Override
    public void updateSampInfo(Record res) {
        DbEx.update(SAMPLE_TABLE_NAME,res);
    }

    @Override
    public void saveSampleBatch(List<Record> records) {
        DbEx.batchSave(SAMPLE_TABLE_NAME,records,records.size());
    }

    @Override
    public void saveDonCycleBatch(List<Record> records) {
        DbEx.batchSave(DON_CYCLE_TABLE_NAME,records,records.size());
    }

    @Override
    public List<Record> getSampleCodeRule(Record project) {
        return DbEx.find("select * from "+SAMPLE_RULE_TABLE_NAME+" where proj_id = ? and sr_active_yn = 'Y' ORDER BY disp_or ASC",project.get("id")+"");
    }

    @Override
    public Object getSampleByNameAndProjId(String finName, Object proj_id) {
        return DbEx.queryFirst("SELECT count(1) FROM "+SAMPLE_TABLE_NAME+" where proj_id = ? and samp_na = ? ",proj_id,finName);
    }

    @Override
    public List<Record> getAllNodeByGroupId(String groupId) {
        return DbEx.find("select * from " + NODE_TABLE_NAME+" where grop_id = ?",groupId);
    }

    @Override
    public List<Record> getTypeOrderByCTime2(String groupId) {
        return DbEx.find("select nd_type from " + NODE_TABLE_NAME+" where grop_id = ? ORDER BY create_time ASC ",groupId);
    }

    @Override
    public void delNodeByGGroupId(String targetGroupId) {
        DbEx.delete("delete from "+ NODE_TABLE_NAME +" where grop_id = ?",targetGroupId);
    }
}
