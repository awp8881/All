package com.qzsoft.lims.ks.dao.impl;

import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsMenuLogicMultBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;

@Repository
public class KsMenuLogicMultBDaoImpl extends BaseDaoImpl implements KsMenuLogicMultBDao{
	private static final String TABLE_NAME = "ks_menu_logic_mult_b";

	/**
	 * 删除后插入
	 * */
	@JFinalTx
	@Override
	public Boolean batchUpdate(List<Map<String, Object>> allFollowList, String old_m_code,String info_code,String menu_id) {
		boolean isSucc = true;
		String code = StringUtils.isBlank(info_code) ? old_m_code+"$button_code" : info_code+"$button_code";
		if (StringUtils.isBlank(code)){
			return isSucc;
		}
		DbEx.delete("delete from "+TABLE_NAME+" where locate(?,val_code)>0 ",code);

		if (null == allFollowList || allFollowList.isEmpty()){
			return isSucc;
		}
		List<Record> recordList = DataBaseUtil.map2Record(allFollowList);
		for(Record record : recordList){
			record.set("menu_id", menu_id);
		}
		return super.saveList(TABLE_NAME, recordList);
	}

}
