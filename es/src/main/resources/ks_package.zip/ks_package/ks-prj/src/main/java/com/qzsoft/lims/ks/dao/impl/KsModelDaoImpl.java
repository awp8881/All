package com.qzsoft.lims.ks.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.qzsoft.lims.ks.eum.MTypeEnum;
import com.qzsoft.lims.ks.util.CodesUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.lims.ks.dao.KsModelDao;
import com.qzsoft.lims.ks.eum.McodeTypeEnum;
import com.qzsoft.lims.ks.eum.YnEnum;
import com.qzsoft.lims.ks.util.TableHelper;
import com.qzsoft.lims.ks.vo.SourceConfigVO;

/**
 * 模版定义dao实现
 * @author zf
 *
 */
@Repository
public class KsModelDaoImpl extends BaseDaoImpl implements KsModelDao{

	private static final String TABLE_NAME_B = "ks_model_b";
	private static final String TABLE_NAME_C = "ks_model_c";
	private static final String TABLE_NAME_A = "ks_model_a";
	
	/**
	 * 根据ID查询数据
	 * @param id
	 * @return
	 * */
	@Override
	public Record selectById(Long id){
		return super.selectById(TABLE_NAME_B,id);
	}

	/**
	 * 通过模板编码获取模板列表
	 * */
	@Override
	public List<Record> getListByMcode(String m_code,String m_type) {
		String sql="select * from "+TABLE_NAME_B+" where 1=1 ";
		List<String> list=new ArrayList<>();
		if(StringUtils.isNotBlank(m_code)){
			sql+=" and m_code=?";
			list.add(m_code);
		}
		if(StringUtils.isNotBlank(m_type)){
			sql+=" and m_type=?";
			list.add(m_type);
		}
		return DbEx.find(sql,list.toArray());
	}

	/**
	 * 页面配置新增保存模板
	 */
	@Override
	public Boolean save(SourceConfigVO sourceConfigVO,String new_m_code) {
		Record record=new Record();
		record.set("sql_name", sourceConfigVO.getSql_name()).set("m_name", sourceConfigVO.getM_name())
		.set("m_code", new_m_code).set("m_type", sourceConfigVO.getM_type()).set("cr_dm", DateUtil.getNowDateTimeStr())
		.set("up_ver", 1).set("menu_id", sourceConfigVO.getMenu_id());
		return DbEx.save(TABLE_NAME_B,record);
	}

	/**
	 * 通过名称获取模板列表
	 */
	@Override
	public List<Record> findAll(String m_name,String m_type) {
		String sql="SELECT k1.*,k2.sql_rev from "+TABLE_NAME_C+" k1 LEFT JOIN ks_table_sql_c k2 on k1.m_code=k2.m_code where 1=1 ";
		List<String> list=new ArrayList<>();
		if(StringUtils.isNotBlank(m_type)){
			sql+=" and k1.m_type=?";
			list.add(m_type);
		}
		if(StringUtils.isNotBlank(m_name)){
			sql+=" and locate(?,k1.m_name)>0 ";
			list.add(m_name);
		}
		sql+=" order by k1.cr_dm desc ";
		List<Record> recordList=DbEx.find(sql,list.toArray());
		return recordList;
		
	}

	/**
	 * 获取组件列表
	 * */
	@Override
	public List<Record> getCompList(String m_name) {
		String sql="SELECT k1.*,k2.sql_rev,k2.sql_all_log,k2.sql_desc,k2.sql_from,k2.sql_other,k2.sql_where from "+TABLE_NAME_C+" k1 LEFT JOIN ks_table_sql_c k2 on k1.m_code=k2.m_code where is_comp= "+YnEnum.Y.getCode();
		List<String> list=new ArrayList<>();
		if(StringUtils.isNotBlank(m_name)){
			sql+=" and locate(?,k1.m_name)>0 ";
			list.add(m_name);
		}
		sql+=" order by k1.cr_dm desc ";
		List<Record> recordList=DbEx.find(sql,list.toArray());
		TableHelper.buildTableSqlList(recordList);
		return recordList;
	}
	
	/**
	 * 按类型从abc表获取
	 */
	@Override
	public Record getByMcode( String m_code, String m_code_type) {
		String sqlTale=TABLE_NAME_A;
		if(McodeTypeEnum.ZJSJY.getCode().equals(m_code_type)){
			sqlTale=TABLE_NAME_C;
		}else if(McodeTypeEnum.YMSJY.getCode().equals(m_code_type)){
			sqlTale=TABLE_NAME_B;
		}
		String sql="select * from "+sqlTale+" where m_code=? ";
		return DbEx.findFirst(sql, m_code);
	}

	/**
	 * 关联保存model
	 *
	 */
	@Override
	public Boolean saveBySource(String sqlName, String oldSqlName, Boolean isEdit) {
		if (isEdit){//修改
			Record updateRecord = getOneByColumn(TABLE_NAME_A, "sql_name", oldSqlName);
			if (null != updateRecord){
				updateRecord.set("sql_name", sqlName);
				update(TABLE_NAME_A, updateRecord);

				updateModelBC( sqlName,  oldSqlName);
			}


		}else{
			String mCode = CodesUtil.createCommonCode("m_code");
			Record record = new Record();
			record.set("sql_name", sqlName).set("m_name", mCode).set("m_code", mCode)
					.set("m_type", MTypeEnum.INNER_LIST.getCode()).set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", 1);
			save(TABLE_NAME_A, record);
		}
		return true;
	}

	@Override
	public Record getByMeunId(String menu_id) {
		return DbEx.findFirst("select * from "+TABLE_NAME_B+" where menu_id = ?",menu_id);
	}

	private void updateModelBC( String sqlName, String oldSqlName ){

		List<Record> recordsB = selectListByCustom(TABLE_NAME_B, "sql_name", oldSqlName);
		if ( null != recordsB && !recordsB.isEmpty()){
			for (Iterator<Record> iterator = recordsB.iterator(); iterator.hasNext(); ) {
				Record record =  iterator.next();
				record.set("sql_name", sqlName);
			}
			updateList(TABLE_NAME_B, recordsB);
		}

		List<Record> recordsC = selectListByCustom(TABLE_NAME_C, "sql_name", oldSqlName);
		if ( null != recordsC && !recordsC.isEmpty()){
			for (Iterator<Record> iterator = recordsC.iterator(); iterator.hasNext(); ) {
				Record record =  iterator.next();
				record.set("sql_name", sqlName);
			}
			updateList(TABLE_NAME_C, recordsC);
		}
	}
}
