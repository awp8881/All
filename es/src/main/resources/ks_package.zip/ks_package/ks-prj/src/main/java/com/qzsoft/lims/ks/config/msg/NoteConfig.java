package com.qzsoft.lims.ks.config.msg;

import lombok.*;

/** 短信
 * ps:先设置默认值
 * @author yuanj
 * @since 2021/12/29
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NoteConfig extends Config {
    private static final long serialVersionUID = 3833630267273040696L;

    private String request_url="默认http://api.yunzhixin.com:11140/txp/sms/send?";
    private String tplId="模板id";
    private String phoneNumber="注册电话号码";
    private String trade_key="密钥";


}
