package com.qzsoft.lims.ks.config.msg;

import com.github.xiaoymin.swaggerbootstrapui.annotations.EnableSwaggerBootstrapUI;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@EnableSwaggerBootstrapUI
@Component
@EnableSwagger2
public class SwaggerConfig implements WebMvcConfigurer {
}
