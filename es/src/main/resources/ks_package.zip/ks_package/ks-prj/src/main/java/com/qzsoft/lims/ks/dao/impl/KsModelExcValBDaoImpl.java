package com.qzsoft.lims.ks.dao.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsDicBDao;
import com.qzsoft.lims.ks.dao.KsModelExcValBDao;
import com.qzsoft.lims.ks.eum.ButtonParaTypeEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;

@Repository
public class KsModelExcValBDaoImpl extends BaseDaoImpl implements KsModelExcValBDao{
	
	private static final String TABLE_NAME = "ks_model_exc_val_b";
	
	private static final String SUF ="$button_code";
	
	@Autowired
	private KsDicBDao ksDicBDao;
	
	/**
	   *   删除后插入
	 */
	@Override
	@JFinalTx
	public Boolean batchUpdate(List<Record> allExcValList, String old_m_code) {
		boolean succYn = true;
		if (StringUtils.isBlank(old_m_code)){
			return succYn;
		}
		DbEx.delete("delete from "+TABLE_NAME+" where locate(?,button_code)>0 ", old_m_code+SUF);
		if(null == allExcValList || allExcValList.isEmpty()){
			return succYn;
		}
		succYn= saveList(TABLE_NAME, allExcValList);
		return succYn;
	}
	
	/**
	 * 导入字段配置
	 */
	@Override
	public List<Record> getExcValListByButtonCode(String buttonCode, Boolean jsonYn) {
		String sql = "select * from "+TABLE_NAME+" where button_code=? order by para_order+0";
		List<Record> recordList = selectListBySql(sql, buttonCode);
		if (null == recordList || recordList.isEmpty()) {
			return recordList;
		}
		for (Record record : recordList) {
			String paraType = record.getStr("para_type");
			String paraVal = record.getStr("para_val");
			String diCd = record.getStr("di_cd");
			if (ButtonParaTypeEnum.ZDJ.getCode().equals(paraType)) {
				String dicDesc = ksDicBDao.getDicdDesc(diCd);
				record.set("dicDesc", dicDesc);
				String dicParaDesc = ksDicBDao.getDicdParaDesc(diCd, paraVal);
				record.set("dicParaDesc", dicParaDesc);
			}
			if (ButtonParaTypeEnum.ZD.getCode().equals(paraType) && jsonYn) {
				record.set("para_val", DataBaseUtil.buildFieldName(paraVal));
			}
			
		}
		return recordList;
	}

}
