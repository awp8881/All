package com.qzsoft.lims.hlyy.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value="yyky_group",description="分组表")
public class HLYYGroupEntity  extends  HLYYEntity {

    @ApiModelProperty(value="",dataType="Long",required=false)
    private Long id;

    @ApiModelProperty(value="分组号",dataType="int",required=false)
    private Integer grop_no;

    @ApiModelProperty(value="分组编码",dataType="String",required=false)
    private String grop_code;

    @ApiModelProperty(value="起始编号",dataType="String",required=false)
    private String grop_begin_code;

    @ApiModelProperty(value="数量",dataType="String",required=false)
    private String grop_num;

    @ApiModelProperty(value="外键，关联项目",dataType="String",required=true)
    private Long proj_id;


}
