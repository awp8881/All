package com.qzsoft.lims.ks.controller.config;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.lims.ks.service.groupCond.SelectDynCondService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 分组条件-控制器
 * @author zf
 */
@Api(value = "分组条件", tags = "分组条件")
@RestController
@RequestMapping("/groupCond")
@Slf4j
public class GroupCondController {

    @Autowired
    private SelectDynCondService selectDynCondService;

    @ApiOperation(value = "动态下拉选项 左侧树")
    @GetMapping("/getLeftSelectQuery")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getLeftSelectQuery(@RequestParam(value = "menuId") String menuId ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(selectDynCondService.getLeftSelectQuery( menuId));
        return result;
    }

    @ApiOperation(value = "动态下拉选项 右侧下拉")
    @GetMapping("/getRightSelectQuery")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> getRightSelectQuery(@RequestParam(value = "para_type") String rightParaType,
            @RequestParam(value = "but_di_cd", required = false) String butDicd,
            @RequestParam(value = "button_code", required = false) String buttonCode) {

        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList(selectDynCondService.getRightSelectQuery( rightParaType, butDicd, buttonCode));
        return result;
    }

}
