package com.qzsoft.lims.ks.dao.comp;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

import java.util.List;

public interface KsCompActBDao extends BaseDao{

    /**
     * 组件编码获取事件
     * @param defCode
     * @return
     */
    List<Record> getByDefCode( String defCode);
}
