package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.synConfig.SafeCheckService;
import com.qzsoft.lims.ks.vo.KsSysConfBVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 安全检查-控制器
 * @author zf
 *
 */
@Api(value = "安全检查", tags = "安全检查")
@RestController
@RequestMapping("/safe")
@Slf4j
public class SafeCheckController {

	@Autowired
	private SafeCheckService safeCheckService;

	@ApiOperation("检查")
	@PostMapping("/check")
	@ResponseAddHead
		public RequestResult<String> check() {
		RequestResult<String> result = new RequestResult<>();
		result.setList( safeCheckService.check());
		return result;
	}

	@ApiOperation("一键清除")
	@PostMapping("/clear")
		@ResponseAddHead
	public RequestResult<Boolean> clear(@RequestParam(value = "tables") String tablesStr) {
		RequestResult<Boolean> result = new RequestResult<>();
		result.setObj( safeCheckService.clear( tablesStr ));
		return result;
	}

	@ApiOperation("清除记录")
	@PostMapping("/getClearRecord")
	@ResponseAddHead
		public RequestResult<Map<String, Object>> getClearRecord() {
		RequestResult<Map<String, Object>> result = new RequestResult<>();
		result.setObj( safeCheckService.getClearRecord());
		return result;
	}

}
