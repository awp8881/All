package com.qzsoft.lims.ks.dao.impl;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.lims.ks.dao.KsModelOperLDao;
import org.springframework.stereotype.Repository;

import java.util.List;

/** 
 * 系统配置：系统自动化SQL语句
 * 创建时间:2018-08-15 10:00:52 
 */
@Repository
public class KsModelOperLDaoImpl extends BaseDaoImpl implements KsModelOperLDao {


    @Override
    public void batchSave(String tbName, List<Record> recordList) {

        if( recordList.isEmpty() ){
            return;
        }
        saveList( tbName, recordList );

    }

    @Override
    public Record findMaxOperOrderByInfoCodeAndTNameAndTNameKey(String info_code, String t_name, String t_name_key) {

        List<Record> records = DbEx.find(" select * from ks_model_oper_l where info_code=? and t_name=? and t_name_key=? order by cr_dm desc", info_code, t_name, t_name_key);
        if( !records.isEmpty() ){
            return records.get(0);
        }else{
            return null;
        }

    }

    @Override
    public Record findMaxOperCodeByInfoCodeAndTName(String info_code, String t_name ) {
        List<Record> records = DbEx.find(" select * from ks_model_oper_l where info_code=? and t_name=? order by cr_dm desc ", info_code, t_name);
        if( !records.isEmpty() ){
            return records.get(0);
        }else{
            return null;
        }
    }

    @Override
    public Record findTop1ByInfoCodeAndTNameAndFieldName(String m_code,String info_code, String t_name, String field_name,String t_name_key) {

        List<Record> records = DbEx.find(" select * from ks_model_oper_l where m_code=? and info_code=? " +
                "and t_name=? and field_name=? and t_name_key=? order by oper_order desc ", m_code,info_code, t_name,field_name,t_name_key);
        if( !records.isEmpty() ){
            return records.get(0);
        }else{
            return null;
        }
    }

    @Override
    public Record findMaxOperOrderByInfoCodeAndTNameAndFieldNameAndTNameKey(String info_code, String t_name, String fieldName, String t_name_key) {
        List<Record> records = DbEx.find(" select * from ks_model_oper_l where info_code=? and t_name=? and field_name=? " +
                "and t_name_key=? order by cr_dm desc", info_code, t_name, fieldName, t_name_key);
        if( !records.isEmpty() ){
            return records.get(0);
        }else{
            return null;
        }
    }
}
