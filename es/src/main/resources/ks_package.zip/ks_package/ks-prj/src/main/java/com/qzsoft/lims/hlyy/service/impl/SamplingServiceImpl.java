package com.qzsoft.lims.hlyy.service.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.annotation.CheckIdempotency;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.*;
import com.qzsoft.lims.hlyy.config.Fileds;
import com.qzsoft.lims.hlyy.dao.SampTypeDataDao;
import com.qzsoft.lims.hlyy.dao.SamplingDao;
import com.qzsoft.lims.hlyy.entity.HLYYCycleEntity;
import com.qzsoft.lims.hlyy.entity.HLYYGroupEntity;
import com.qzsoft.lims.hlyy.entity.vo.HLYYGroupVo;
import com.qzsoft.lims.hlyy.eum.*;
import com.qzsoft.lims.hlyy.service.SamplingService;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import com.qzsoft.lims.ks.util.QzAssert;
import com.qzsoft.lims.ks.util.UserDataUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class SamplingServiceImpl implements SamplingService {

    ThreadLocal<Integer> samp_disp_or = new ThreadLocal<>();
    private final String EX = "清单正在生成，请勿重复请求";
    private final String CREATESAMPMODEL = "生成样品清单";
    private final String BLOOD = "BLOOD";
    private final String PLASMA = "PLASMA";
    private final String TISSUES = "TISSUES";
    private final String URN = "URN";

    private final String group = "group";
    private final String cycle = "cycle";
    private final String node = "node";

    @Autowired
    SamplingDao samplingDao;

    @Autowired
    SampTypeDataDao sampTypeDataDao;

    @Autowired
    RedisTemplate redisTemplate;


    /**
     *新增分组
     */
    @Override
    @JFinalTx
    public Map<String,Object> addGroups(HLYYGroupVo groupVo) {
        Map<String,Object> result = new HashMap();
        HLYYGroupEntity hlyyGroupEntity = (HLYYGroupEntity) validate(groupVo,null);
        Record record = CustomDbRecordUtil.getRecord(hlyyGroupEntity);
        initData(record);
        //项目proj_grop_sum字段+1
        Record proj = samplingDao.getProjectById(hlyyGroupEntity.getProj_id()+"");
        proj.set("proj_grop_sum",Integer.parseInt(proj.get("proj_grop_sum"))+1);
        samplingDao.updateProj(proj);
        //分组信息入库
        samplingDao.addGroups(record);
        List<Record> recordList = samplingDao.getAllGroupsByProjId(hlyyGroupEntity.getProj_id());
//        int maxCycleNum = Integer.parseInt(groupVo.getMaxCycleNum());
//        if(maxCycleNum == 0) {
//            //无周期，返回分组信息和表头
//            result.put("data", DataBaseUtil.record2Map(recordList));
//            String filedStr = Fileds.groups.getCode();
//            List<Map<String, Object>> fileds = (List<Map<String, Object>>) JSON.parse(filedStr);
//            fileds = fileds.stream().filter(e -> !e.get("name").equals("周期")).collect(Collectors.toList());
//            result.put("field", fileds);
//            result.put("maxCycleNum", 0);
//            return result;
//        }
//        //有最大周期数，添加周期，返回分组和周期信息以及表头
//        if(recordList.size() == 1)
//            samplingDao.delCycleByProjId(hlyyGroupEntity.getProj_id());
//
//        for(int i = 1 ;i<=maxCycleNum;i++){
//            HLYYCycleEntity cycleEntity = new HLYYCycleEntity();
//            cycleEntity.setCyc_no(i);
//            cycleEntity.setProj_id(hlyyGroupEntity.getProj_id());
//            cycleEntity.setGrop_id(record.get("id"));
//            Record record1 = CustomDbRecordUtil.getRecord(cycleEntity);
//            initData(record1);
//            samplingDao.addCycle(record1);
//        }
        //组装数据
        List<Map<String, Object>> gropAndCycList = makeGroupAndCycleData(DataBaseUtil.record2Map(recordList));
        result.put("data",gropAndCycList);
        result.put("field",makeField(0));
//        result.put("maxCycleNum",maxCycleNum);
        innerDiction(result);
        return result;
    }


    /**
     *删除分组
     */
    @Override
    @JFinalTx
    public Map<String,Object> delGroups(String[] groups,int maxCycleNum,String proj_id) {
        Map<String,Object> result = new HashMap();
        List<String> ids = new ArrayList<>(groups.length);
        Collections.addAll(ids,groups);
        samplingDao.delCycleByGropId(ids);
        samplingDao.delGropsByIds(ids);
        //项目proj_grop_sum字段 - groups.length
        Record proj = samplingDao.getProjectById(proj_id);
        proj.set("proj_grop_sum",Integer.parseInt(proj.get("proj_grop_sum"))-groups.length);
        samplingDao.updateProj(proj);
        //组装数据
        List<Record> recordList = samplingDao.getAllGroupsByProjId(Long.parseLong(proj_id));
        List<Map<String, Object>> gropAndCycList = makeGroupAndCycleData(DataBaseUtil.record2Map(recordList));
        result.put("data",gropAndCycList);
        result.put("field",makeField(0));
        //result.put("maxCycleNum",0);
        innerDiction(result);
        return result;
    }

    /**
     *修改分组信息
     */
    @Override
    @JFinalTx
    public boolean updateGroupInfo(String groupId, String groupInfo) {
        Map info = (Map) JSON.parse(groupInfo);
        Record record  = samplingDao.findGroById(groupId);
        if(record != null){
//            if(null != info.get("grop_no")) {
//                if (!isInteger(info.get("grop_no").toString(),false))
//                    throw BusinessException.buildBiz("分组序号必须为整数");
//            }
            record.set("grop_no",StringUtils.isEmpty(info.get("grop_no")+"")?null:info.get("grop_no"));
            record.set("grop_code",info.get("grop_code"));
            if(!StringUtils.isEmpty(info.get("grop_num").toString())) {
                if (!isInteger(info.get("grop_num").toString(),true))
                    throw BusinessException.buildBiz("组数量必须为正整数");
            }
            record.set("grop_num",info.get("grop_num"));
            if(null != info.get("grop_begin_code")){
                if(!StringUtils.isEmpty(info.get("grop_begin_code").toString())){
                    if (!isInteger(info.get("grop_begin_code").toString(),true))
                        throw BusinessException.buildBiz("起始编号必须为正整数");
                    if(Integer.parseInt(info.get("grop_begin_code").toString()) > 99){
                        throw BusinessException.buildBiz("起始编号不可大于99");
                    }
                }
            }
            record.set("grop_begin_code",info.get("grop_begin_code"));
            record.set("grop_no_type",info.get("grop_no_type"));
            record.set("grop_get_val",info.get("grop_get_val"));
            chageData(record);
            return samplingDao.updateGropInfo(record);
        }
        return false;
    }


    /**
     *新增或删除周期
     */
    @Override
    @JFinalTx
    public Map<String, Object> addCycle(int cycle_no, String proj_id, String delSt) {
        HLYYCycleEntity cycleEntity = new HLYYCycleEntity();
        Map<String,Object> result = new HashMap();
        cycleEntity.setCyc_no(cycle_no);
        cycleEntity.setProj_id( Long.parseLong(proj_id));
        List<Record> GroupRecordList = samplingDao.getAllGroupsByProjId( Long.parseLong(proj_id));
        List<Map<String, Object>> groupList = DataBaseUtil.record2Map(GroupRecordList);
        if(delSt.equals("N")){
            //新增
            if(GroupRecordList.isEmpty()){
                //说明没有分组，先添加的周期
                Record record = CustomDbRecordUtil.getRecord(cycleEntity);
                initData(record);
                samplingDao.addCycle(record);
                result.put("field",makeField(cycle_no));
                result.put("maxCycleNum",cycle_no);
                return result;
            }
            //有分组
            for (Map<String, Object> objectMap : groupList) {
                cycleEntity.setGrop_id((Long) objectMap.get("id"));
                Record record = CustomDbRecordUtil.getRecord(cycleEntity);
                initData(record);
                samplingDao.addCycle(record);
            }
        }else {
            //删除,删除当前项目所有序号为cycle_no的周期
            samplingDao.delCycleByProjIdAndNo(proj_id,cycle_no);
            --cycle_no;
        }
        //组装数据
        List<Map<String, Object>> gropAndCycList = makeGroupAndCycleData(groupList);
        result.put("data",gropAndCycList);
        result.put("field",makeField(cycle_no));
        result.put("maxCycleNum",cycle_no);
        return result;
    }

    /**
     *修改周期信息
     */
    @Override
    @JFinalTx
    public boolean updateCycleInfo(String cycleId, String cycleVal) {
        Record record  = samplingDao.findCycById(cycleId);
        if(record != null){
            record.set("cyc_val",cycleVal);
            chageData(record);
            return samplingDao.updateCycInfo(record);
        }
        return false;
    }

    /**
     *添加种类
     */
    @Override
    @JFinalTx
    public Map<String, Object> addOrDelTypeNode(String groupId, String nd_type, String delSt) {
        Map<String,Object> result = new HashMap();
        Record record  = samplingDao.findGroById(groupId);
        if(record == null)
            QzAssert.isTrue(false, BusinessException.buildBiz("未能查询到信息"));
        //throw BusinessException.buildBiz("未能查询到周期信息");
        //throw new BusinessException(11003, ConfigUtil.getMessage(11003,"未能查询到周期信息"));
        Record info = new Record();
        if (delSt.equals("N")) {
            info.set("grop_id", groupId).set("proj_id", record.get("proj_id"))
                    .set("nd_type", nd_type).set("nd_no", maxNodeNo(groupId,nd_type));
            initData(info);
            samplingDao.addType(info);
        } else {
            //删除
            info.set("grop_id", groupId).set("nd_type", nd_type);
            samplingDao.delType(info);
        }

        //组装数据
        List<Map<String, Object>> nodeList = makeNodeDataWithField(groupId,null,null,true);
        result.put("data",nodeList);
        return result;
    }

    /**
     *修改种类
     */
    @Override
    @JFinalTx
    public Map<String,Object> updateType(String groupId, String original_type, String current_type) {
        Map<String,Object> result = new HashMap();
        samplingDao.updateType(groupId,original_type,current_type);
        //组装数据
        List<Map<String, Object>> nodeList = makeNodeDataWithField(groupId,null,null,true);
        result.put("data",nodeList);
        return result;
    }

    /**
     *删除节点
     */
    @Override
    @JFinalTx
    public Map<String, Object> delNode(String[] nodeIds,String groupId) {
        Map<String,Object> result = new HashMap();
        List<String> ids = new ArrayList<>(nodeIds.length);
        Collections.addAll(ids,nodeIds);
        samplingDao.delNodeByIds(ids);
        //删除后，重新定义节点号
        //List<Record> nodes = samplingDao.getAllNodeByCycId(cycleId);
        List<Record> nodes = samplingDao.getAllNodeByGroupId(groupId);
        for(int i = 0 ;i<nodes.size();i++){
            nodes.get(i).set("nd_no",i+1);
            samplingDao.updateNodeVal(nodes.get(i));
        }
        //组装数据
        List<Map<String, Object>> nodeList = makeNodeDataWithField(groupId,null,null,true);
        result.put("data",nodeList);
        return result;
    }

    /**
     *修改节点值
     */
    @Override
    @JFinalTx
    public boolean updateNodeVal(String nodeId, String nodeInfo) {
        Map info = (Map) JSON.parse(nodeInfo);
        Record record  = samplingDao.findNodeById(nodeId);
        if(record != null){
            record.set("nd_start_day",info.get("nd_start_day"));
//            record.set("nd_start_hour",info.get("nd_start_hour"));
//            record.set("nd_start_min",info.get("nd_start_min"));
            record.set("nd_start_remark",info.get("nd_start_remark"));
//            if(record.get("nd_type").equals(URN)){
//                record.set("nd_end_day",info.get("nd_end_day"));
//                record.set("nd_end_hour",info.get("nd_end_hour"));
//                record.set("nd_end_min",info.get("nd_end_min"));
//                record.set("nd_end_remark",info.get("nd_end_remark"));
//            }
            chageData(record);
            return samplingDao.updateNodeVal(record);
        }
        return false;
    }

    /**
     *返回采样详情
     */
    @Override
    public Map<String, Object> getProjSampInfo(String proj_id) {
        Map<String,Object> result = new HashMap();
        List<Record> GroupRecordList = samplingDao.getAllGroupsByProjId( Long.parseLong(proj_id));
        List<Map<String, Object>> groupList = DataBaseUtil.record2Map(GroupRecordList);
        if(!groupList.isEmpty()){
            List<Map<String, Object>> gropAndCycList = makeGroupAndCycleData(groupList);
            int cycle_no = 0;
            //Object obj = samplingDao.getMaxCycleNo(proj_id);
//            if(obj != null)
//                cycle_no = (int)obj;
            result.put("data",gropAndCycList);
            result.put("field",makeField(cycle_no));
            //result.put("maxCycleNum",cycle_no);
        }else {
            result.put("data",null);
            result.put("field",makeField(0));
            //result.put("maxCycleNum",0);
        }
        innerDiction(result);
        return result;
    }


    /**
     *根据周期Id返回节点信息
     */
    @Override
    public Map<String, Object> getNodeInfoByClick(String groupId) {
        Map<String, Object> result = new HashMap<>();
        //组装数据
        List<Map<String, Object>> nodeList = makeNodeDataWithField(groupId,null,null,true);
        result.put("data",nodeList);
        return result;
    }


    /**
     *生成样品清单
     *
     */
    @Override
    @JFinalTx
    @CheckIdempotency(model = CREATESAMPMODEL,timeOut = 35,ex = EX,delLock = false)
    public boolean createSamples(String projId) {
        samp_disp_or.set(0);
        List<Record> sampWaitInsert = new ArrayList<>();
        //字典表记录
        List<Map<String,Object>> typeDataList = DataBaseUtil.record2Map(sampTypeDataDao.getAllType());
        //项目详情
        Record project = samplingDao.getProjectById(projId);
        if(project == null)
            throw new BusinessException(11003, ConfigUtil.getMessage(11003,"未能查询到项目信息"));
        QzAssert.isTrue(!StringUtils.isEmpty(project.get("proj_code")), BusinessException.buildBiz("项目编号不能为空"));

        //一组一组地生成
        List<Record> groRecords = samplingDao.getAllGroupsByProjId(Long.parseLong(projId));
        QzAssert.isTrue(!groRecords.isEmpty(), BusinessException.buildBiz("分组不能为空"));
        List<Map<String,Object>> groupList = DataBaseUtil.record2Map(groRecords);

        for (Map<String, Object> groupMap : groupList) {
            validate(groupMap,group);
            String groupId = groupMap.get("id").toString();
            int groupNum = Integer.parseInt(groupMap.get("grop_num").toString());
            //查出当前分组对应地种类节点
            Map<String,Object> allNodes = makeNodeDataWithField(groupId,null,groupMap.get("grop_no").toString(),false).get(0);
            Set<String> types = allNodes.keySet();
            for (String type : types) {
                //通过type查到所有节点
                List <Map<String,Object>> nodeInfoList = (List<Map<String, Object>>) allNodes.get(type);
                checkRepeat(nodeInfoList);
                for (Map<String, Object> nodeInfoMap : nodeInfoList) {
                    nodeInfoMap.put("group_no",groupMap.get("grop_no"));
                    for(int i = 1; i <= groupNum ; i++){
                    createSampInfoAndSave(project,groupMap,nodeInfoMap,typeDataList,type,i,sampWaitInsert);
                    }
                }
            }

        }

        //全量数据
        List<Record> samps = sampWaitInsert.stream().sorted(Comparator.comparing(e->e.get("samp_get_num")+"_"+e.get("samp_node_no")+"_"+e.get("grop_id"))).collect(Collectors.toList());
        Map<Object, List<Record>> gropSamps = samps.stream().collect(Collectors.groupingBy(e->e.get("samp_get_num")));
        List<Record> res = new ArrayList<>();
        //修改项目表中是否只读字段以及样本数量
        samplingDao.updateProj(project.set("proj_effect_yn",YnEnum.Y.getCode()).set("proj_samp_sum",samplingDao.getAllSampleByProjId(projId).size()+samps.size()));
        samp_disp_or.set(0);
        for (Map.Entry<Object, List<Record>> objectListEntry : gropSamps.entrySet()) {
            for (Record record : objectListEntry.getValue()) {
                samp_disp_or.set(samp_disp_or.get()+1);
                record.set("disp_or",samp_disp_or.get());
                res.add(record);
            }
        }
        if(res.size() <1000)
            samplingDao.saveSampleBatch(res);
        else {
            ExecutorService exe3 = Executors.newCachedThreadPool();
            List<List<Record>> sampLists = Lists.partition(res, 1000);
            for (List<Record> recordList : sampLists) {
                try {
                    exe3.submit(() -> {
                        samplingDao.saveSampleBatch(recordList);
                    });
                } catch (Exception e) {
                    throw BusinessException.buildBiz(e.getCause().getMessage());
                }
            }
            exe3.shutdown();
            while (!exe3.isTerminated()) {
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        return true;
    }


    /**
     *撤销
     */
    @Override
    @JFinalTx
    public boolean revoke(String projId) {
        //删除此projId的  yyky_donor,yyky_don_cycle,yyky_sample, 修改项目表 是否只读字段
        Record project = samplingDao.getProjectById(projId);
        if(project == null)
            throw new BusinessException(11003, ConfigUtil.getMessage(11003,"未能查询到项目信息"));
        samplingDao.delDonorByProjId(projId);
        samplingDao.delDonCycByProjId(projId);
        samplingDao.delSampByProjId(projId);

        //修改项目表中是否只读字段,样本数量重新计算
        samplingDao.updateProj(project.set("proj_effect_yn",YnEnum.N.getCode()).set("proj_samp_sum",samplingDao.getAllSampleByProjId(projId).size()));
        //删除锁
        redisTemplate.delete(projId+CREATESAMPMODEL);
        return true;
    }

    /**
     *复制粘贴
     */
    @Override
    @JFinalTx
    public Map<String, Object> copyAndPaste(String copiedGroupId, String targetGroupId) {
        Map<String,Object> result = new HashMap();
        Record copied = samplingDao.getGroupsById(copiedGroupId);
        if(copied == null)
            throw new BusinessException(11003, ConfigUtil.getMessage(11003,"分组"));

        //List<Record> nodeList =  samplingDao.getAllNodeByCycId(copiedCycId);
        List<Record> nodeList = samplingDao.getAllNodeByGroupId(copiedGroupId);
        for (Record record : nodeList) {
            record.remove("id");
            record.set("grop_id",targetGroupId);
            initData(record);
        }
        //samplingDao.delNodeByCycId(targetGroupId);
        samplingDao.delNodeByGGroupId(targetGroupId);
        samplingDao.batchPaste(nodeList);
        //组装数据
        List<Map<String, Object>> nodeListRes = makeNodeDataWithField(targetGroupId,null,null,true);
        result.put("data",nodeListRes);
        return result;
    }


    private void checkRepeat(List<Map<String, Object>> nodeInfoList) {
        Set<String> set = new HashSet();
        try {
            for (Map<String, Object> map : nodeInfoList) {
                String res = checkNull(map.get("nd_start_day"));
                set.add(res);
            }
        }catch (Exception e){
            throw BusinessException.buildBiz("请先补全所有节点信息");
        }

        if(set.size() != nodeInfoList.size())
            throw BusinessException.buildBiz("同一周期下同一类型的样本的多个节点中的节点值不能相同");
    }

    private String checkNull(Object object){

        return  object == null?"null":object.toString();
    }

    private void createSampInfoAndSave(Record project,
                                       Map<String, Object> groupMap,
                                       Map<String, Object> nodeInfoMap, List<Map<String, Object>> typeDataList,
                                       String type,int i,List<Record> sampWaitInsert) {
        //查询自定义编号生成规则
        List<Record> sampRule = samplingDao.getSampleCodeRule(project);
        StringBuilder sampName = new StringBuilder();
        String samp_begin_code;
        String grop_begin_code = groupMap.get("grop_begin_code").toString();

        char c = grop_begin_code.toCharArray()[0];
        char zero = '0';
        int res = Integer.parseInt(grop_begin_code) + i -1;
        samp_begin_code = res+"";
        if(c == zero && res <10)
            samp_begin_code = "0"+res;

        String sampCode = groupMap.get("grop_code").toString()+groupMap.get("grop_no").toString()+samp_begin_code;
        StringBuilder samp_na_type = new StringBuilder();
        if(sampRule.isEmpty()){
            //使用默认规则
            String grop_no_type = (String) groupMap.get("grop_no_type");
            sampName.append(SampZSEnum.valueOf(grop_no_type).getCode()+" ");

            samp_na_type.append(SampZSEnum.valueOf(grop_no_type).getCode()+" ");


            Map<String, Object> map= typeDataList.stream().filter(e->e.get("key").equals(type)).findFirst().orElse(typeDataList.get(typeDataList.size() - 1));
            sampName.append(map.get("remark")).append(" ");
            samp_na_type.append(map.get("remark")).append(" ");

            sampName.append(sampCode).append(" ");
            samp_na_type.append(sampCode).append(" ");
            //E0101 HT-A123-Test
            sampName.append(project.get("proj_code").toString()).append(" ")
                    //E0101 HT-A123-Test 250mg
                    .append(groupMap.get("grop_get_val")).append(" ")
                    //E0101 HT-A123-Test 250mg Day 1
                    .append(nodeInfoMap.get("nd_start_day")==null?"":nodeInfoMap.get("nd_start_day")).append(" ");

            samp_na_type.append(project.get("proj_code").toString()).append(" ") .append(groupMap.get("grop_get_val")).append(" ");


        }else {
            //使用自定以规则
            for (Record record : sampRule) {
                String field = record.get("sr_rule_field").toString();
                String space = record.get("sr_space_yn").toString().equals("Y")?" ":"";
                Boolean isUse = record.get("sr_use_yn").toString().equals("Y");
                String text = record.get("sr_def_val")==null?null:record.get("sr_def_val").toString();
                Boolean isBefore = (record.get("sr_text_position").toString().equals("QZ") && !record.get("sr_text_position").toString().equals("W"));
                String sr_display_rule = record.get("sr_display_rule").toString();
                Object bean = new Object();
                if ("grop_code".equals(field) || "grop_no".equals(field) || "grop_no_type".equals(field) || "grop_get_val".equals(field)) {
                    bean = groupMap;
                }else if("proj_code".equals(field)){
                    bean = DataBaseUtil.record2Map(project);
                }else if("nd_start_day".equals(field)){
                    bean = nodeInfoMap;
                }else if("remark".equals(field)){
                    Map<String, Object> map= typeDataList.stream().filter(e->e.get("key").equals(type)).findFirst().orElse(typeDataList.get(typeDataList.size() - 1));
                    bean = map;
                }
                if(isUse){
                    if(field.equals("i")){
                        if(!record.get("sr_text_position").toString().equals("W") && !record.get("sr_display_rule").toString().equals("QZZD") && null != text){
                            if(isBefore){
                                sampName.append(text).append(samp_begin_code).append(space);
                                samp_na_type.append(text).append(samp_begin_code).append(space);
                            }else {
                                sampName.append(samp_begin_code).append(text).append(space);
                                samp_na_type.append(samp_begin_code).append(text).append(space);
                            }
                        }else {
                            sampName.append(samp_begin_code).append(space);
                            samp_na_type.append(samp_begin_code).append(space);
                        }
                    }
                    else {
                        Map<String, Object> a = (Map<String, Object>) bean;
                        String result  = a.get(field) == null?"":a.get(field).toString();
                        Boolean rule = !(sr_display_rule.equals("WKHZSZBXS") && (StringUtils.isEmpty(result)|| result.equals("0")));//为空Or0数字不显示
                        if(sr_display_rule.equals("WKXSZSZ") && StringUtils.isEmpty(result)){ //为空显示0数字
                            result = "0";
                        }
                        if(!record.get("sr_text_position").toString().equals("W") && !record.get("sr_display_rule").toString().equals("QZZD") && null != text){
                             if(isBefore){
                                sampName.append(text).append(rule?result:"").append(space);
                                 if(!"nd_start_day".equals(field)&&!"nd_start_hour".equals(field)&&!"nd_start_min".equals(field)){
                                     samp_na_type.append(text).append(rule?result:"").append(space);
                                 }
                            }else {
                                sampName.append(rule?result:"").append(text).append(space);
                                 if(!"nd_start_day".equals(field)&&!"nd_start_hour".equals(field)&&!"nd_start_min".equals(field)){
                                     samp_na_type.append(text).append(rule?result:"").append(space);
                                 }
                            }
                        }else {
                            sampName.append(rule?result:"").append(space);
                            if(!"nd_start_day".equals(field)&&!"nd_start_hour".equals(field)&&!"nd_start_min".equals(field)) {
                                samp_na_type.append(rule ? result : "").append(space);
                            }
                        }
                    }
                }
            }
        }
        String finName = sampName.toString();
        String samp_na_typeStr = samp_na_type.toString();
        if(StringUtils.isEmpty(finName))
            throw BusinessException.buildBiz("生成的样本名称为空，请检查自定义规则");

        String spaceYn  = finName.substring(finName.length() - 1);
        if(spaceYn.equals(" ")){
            finName =finName.substring(0, finName.length() -1);
        }
        Object sampNameCount = samplingDao.getSampleByNameAndProjId(finName,groupMap.get("proj_id"));
        if((Long)sampNameCount == 0) {
            Record sample = new Record();
            initData(sample.set("samp_na", finName).set("node_id", nodeInfoMap.get("id")).set("samp_no_type",groupMap.get("grop_no_type"))
                    .set("grop_id", groupMap.get("id")).set("proj_id", groupMap.get("proj_id")).set("samp_type", type).set("samp_progr", ProgressEnum.XMFAGL.getCode())
                    .set("samp_st", SampExeEnum.YPZT_ZC.getCode()).set("samp_grop_no", groupMap.get("grop_no")).set("samp_node_no", nodeInfoMap.get("nd_no"))
                    .set("samp_has_end_yn", type.equals(URN) ? YnEnum.Y.getCode() : YnEnum.N.getCode())
                    .set("samp_code", sampCode).set("samp_progr_b", ProgressEnumB.XMFAGL.getDesc()).set("samp_rec_st", SampSFstEnum.DSR.getCode())
                    .set("samp_attr", SampAttrEnum.SX_PT.getCode()).set("samp_get_num", groupMap.get("grop_get_val")).set("p_flow_node", ProgressEnum.XMFAGL.getCode()).set("samp_begin_code", samp_begin_code)
                    .set("samp_na_type", samp_na_typeStr));
            sampWaitInsert.add(sample);
        }else {
            throw BusinessException.buildBiz("样品名称重复，请正确填写");
        }
    }

//    private Object getTimeType(Map<String, Object> groupMap,Map<String, Object> cycMap,Map<String, Object> nodeInfoMap) {
//        if(nodeInfoMap.get("nd_start_day") != null && !nodeInfoMap.get("nd_start_day").equals("0")){
//            return TimeEnum.DAY.getCode();
//        }
//        else if( nodeInfoMap.get("nd_start_hour") != null && !nodeInfoMap.get("nd_start_hour").equals("0")){
//            return TimeEnum.HOUR.getCode();
//        }
//        else if( nodeInfoMap.get("nd_start_min") != null &&!nodeInfoMap.get("nd_start_min").equals("0")){
//            return TimeEnum.MINT.getCode();
//        }else
////            throw BusinessException.buildBiz("第"+groupMap.get("grop_no")+"组第"+cycMap.get("cyc_no")+"周期中"+SampleEnum.valueOf(nodeInfoMap.get("nd_type").toString()).getDesc()+"类型样本中第"+nodeInfoMap.get("nd_no")+"号节点开始天、时、分不能都为0");
//            return "";
//    }

    private int maxNodeNo(String grop_id, String nd_type) {
        int maxNodeNo = 0;
        Object obj =  samplingDao.getMaxNodeNo(grop_id,nd_type);
        if(obj == null)
            return  ++maxNodeNo;
        return  (int)obj+1;
    }


    private Object validate(Object object,String type){
        if(ObjectUtils.isEmpty(object)){
            throw new BusinessException(11003, ConfigUtil.getMessage(11003,"参数对象"));
        }
        if(object instanceof HLYYGroupVo){
            HLYYGroupEntity hlyyGroupEntity= VOUtils.po2vo(object, HLYYGroupEntity.class);
            if(hlyyGroupEntity.getProj_id() == null)
                throw new BusinessException(11003, ConfigUtil.getMessage(11003,"项目id"));
//            if(StringUtils.isEmpty(((HLYYGroupVo) object).getMaxCycleNum()))
//                throw new BusinessException(11003, ConfigUtil.getMessage(11003,"最大周期数"));
            return hlyyGroupEntity;
        }else if(type.equals(group)){
            Map map  = (Map)object;
            String groupNum = (String) map.get("grop_num");
            String gropCode = (String) map.get("grop_code");
            String grop_begin_code = (String) map.get("grop_begin_code");
            QzAssert.isTrue(!(map.get("grop_no")==null), BusinessException.buildBiz("分组号不能为空"));
            QzAssert.isTrue(!StringUtils.isEmpty(groupNum), BusinessException.buildBiz(map.get("grop_no")+"组数量不能为空"));
            QzAssert.isTrue(!StringUtils.isEmpty(grop_begin_code), BusinessException.buildBiz(map.get("grop_no")+"起始编号不能为空"));
            QzAssert.isTrue(!StringUtils.isEmpty(gropCode), BusinessException.buildBiz(map.get("grop_no")+"组代号不能为空"));
            QzAssert.isTrue(!StringUtils.isEmpty((String) map.get("grop_no_type")), BusinessException.buildBiz(map.get("grop_no")+"组种属不能为空"));
            QzAssert.isTrue(!StringUtils.isEmpty((String) map.get("grop_get_val")), BusinessException.buildBiz(map.get("grop_no")+"组采样量不能为空"));
            try {
                Integer.parseInt(groupNum);
            }catch (Exception e){
                throw BusinessException.buildBiz(map.get("grop_no")+"组数量必须为数字");
            }
        }else if(type.equals(cycle)){
            Map map  = (Map)object;
            String cycVal = (String) map.get("cyc_val");
            QzAssert.isTrue(!StringUtils.isEmpty(cycVal), BusinessException.buildBiz("第"+map.get("group_no")+"组第"+map.get("cyc_no")+"周期值不能为空"));
        }else if(type.equals(node)) {
//            Map map = (Map) object;
//            String nd_start_day = (String) map.get("nd_start_day");
//            String nd_start_hour = (String) map.get("nd_start_hour");
//            String nd_start_min = (String) map.get("nd_start_min");
//            String nd_end_day = (String) map.get("nd_end_day");
//            String nd_end_hour = (String) map.get("nd_end_hour");
//            String nd_end_min = (String) map.get("nd_end_min");
//            QzAssert.isTrue(!StringUtils.isEmpty(nd_start_day), BusinessException.buildBiz(buildErrorStrForNode("开始天不能为空", map)));
//            QzAssert.isTrue(!StringUtils.isEmpty(nd_start_hour), BusinessException.buildBiz(buildErrorStrForNode("开始时不能为空", map)));
//            QzAssert.isTrue(!StringUtils.isEmpty(nd_start_min), BusinessException.buildBiz(buildErrorStrForNode("开始分不能为空", map)));
//            if (map.get("nd_type").equals(URN)) {
//                QzAssert.isTrue(!StringUtils.isEmpty(nd_end_day), BusinessException.buildBiz(buildErrorStrForNode("开始天不能为空", map)));
//                QzAssert.isTrue(!StringUtils.isEmpty(nd_end_hour), BusinessException.buildBiz(buildErrorStrForNode("开始时不能为空", map)));
//                QzAssert.isTrue(!StringUtils.isEmpty(nd_end_min), BusinessException.buildBiz(buildErrorStrForNode("开始分不能为空", map)));
//            }
//            try {
//                Double.parseDouble(nd_start_day);
//            } catch (Exception e) {
//                throw BusinessException.buildBiz(buildErrorStrForNode("开始天必须为数字", map));
//            }
//            try {
//                Double.parseDouble(nd_start_hour);
//            } catch (Exception e) {
//                throw BusinessException.buildBiz(buildErrorStrForNode("开始时必须为数字", map));
//            }
//            try {
//                Double.parseDouble(nd_start_min);
//            } catch (Exception e) {
//                throw BusinessException.buildBiz(buildErrorStrForNode("开始分必须为数字", map));
//            }
//            if (map.get("nd_type").equals(URN)) {
//                try {
//                    Double.parseDouble(nd_end_day);
//                } catch (Exception e) {
//                    throw BusinessException.buildBiz(buildErrorStrForNode("结束天必须为数字", map));
//                }
//                try {
//                    Double.parseDouble(nd_end_hour);
//                } catch (Exception e) {
//                    throw BusinessException.buildBiz(buildErrorStrForNode("结束时必须为数字", map));
//                }
//                try {
//                    Double.parseDouble(nd_end_min);
//                } catch (Exception e) {
//                    throw BusinessException.buildBiz(buildErrorStrForNode("结束分必须为数字", map));
//                }
//            }
        }
        return null;
    }

    private String buildErrorStrForNode(String msg,Map<String, Object> nodeInfoMap){
        String res = "第"+nodeInfoMap.get("group_no")+"组第"+nodeInfoMap.get("cyc_no")+"周期中"+SampleEnum.valueOf(nodeInfoMap.get("nd_type").toString()).getDesc()+"类型样本中第"+nodeInfoMap.get("nd_no")+"号节点"+msg;
        return res;
    }
    private void initData(Record record){
        record.set("create_time", DateUtil.getNowDateTimeStr());
        record.set("create_lname", UserDataUtil.getUserName());
        record.set("up_ver",0);
    }

    private void chageData(Record record){
        record.set("update_time", DateUtil.getNowDateTimeStr());
        record.set("update_lname", UserDataUtil.getUserName());
        record.set("up_ver",record.get("up_ver"));
    }

    private List<Map<String, Object>> makeField(int maxCycNo){
//        int initVal = maxCycNo;
        String filedStr = Fileds.groups.getCode();
        List<Map<String, Object>> fileds = ( List<Map<String, Object>>)JSON.parse(filedStr);
//        for (Map<String, Object> objectMap : fileds) {
//            if(objectMap.get("key").equals("cycle")){
//                List<Map<String, Object>> cycFieldList = new ArrayList();
//                int a = 1;
//                while (a<=maxCycNo){
//                    Map<String, Object> map1 = new HashMap();
//                    map1.put("key","cyc_no");
//                    map1.put("name",a);
//                    cycFieldList.add(map1);
//                    a++;
//                }
//                if(initVal==0){
//                    //fileds = fileds.stream().filter(e -> !e.get("name").equals("周期")).collect(Collectors.toList());
//                }else
//                    objectMap.put("children",cycFieldList);
//            }
//        }
        return fileds;
    }

    private List<Map<String, Object>> makeGroupAndCycleData(List<Map<String, Object>> groupList){
        for (Map<String, Object> objectMap : groupList) {
            //Object count =  samplingDao.isHaveNode(objectMap.get("id"));
            objectMap.put("isHaveNode","Y");
//            if((Long)count != 0)
//                objectMap.put("isHaveNode","Y");
//            List<Record> CycleRecordList = samplingDao.getAllCycleByProjAndGroupId(objectMap.get("id").toString(),objectMap.get("proj_id").toString());
//            for (int i = 0; i< CycleRecordList.size();i++) {
//                Map<String, Object> map = new HashMap();
//                map.put("id",CycleRecordList.get(i).get("id"));
//                map.put("val",CycleRecordList.get(i).get("cyc_val"));
//                map.put("isHaveNode","N");
//                Object count =  samplingDao.isHaveNode(CycleRecordList.get(i).get("id"));
//                if((Long)count != 0)
//                    map.put("isHaveNode","Y");
//                objectMap.put(i+1+"",map);
//            }
        }

        return  groupList;
    }

    private List<Map<String, Object>> makeNodeDataWithField(String groupId,String cycleNo,String groupNo,boolean getField) {
        //List<Map<String, Object>> nodeDataList  = DataBaseUtil.record2Map(samplingDao.getAllNodeByCycId(groupId));
        List<Map<String, Object>> nodeDataList  = DataBaseUtil.record2Map(samplingDao.getAllNodeByGroupId(groupId));
        if(!getField && nodeDataList.isEmpty())
            throw BusinessException.buildBiz(groupNo+"组周期未设置样品节点信息");

        List<Map<String, Object>> resList = new ArrayList<>();

        List<Map<String, Object>> ZLList = new ArrayList<>();
        List<Map<String, Object>> XYList = new ArrayList<>();
        List<Map<String, Object>> XJList = new ArrayList<>();
        List<Map<String, Object>> ZZList = new ArrayList<>();
        List<Map<String, Object>> NYList = new ArrayList<>();

        Map<String,List> keyList = new HashMap<>();
        keyList.put("",ZLList);
        keyList.put(BLOOD,XYList);
        keyList.put(PLASMA,XJList);
        keyList.put(TISSUES,ZZList);
        keyList.put(URN,NYList);
        for (Map<String, Object> map : nodeDataList) {
            String type = (String) map.get("nd_type");
            switch (StringUtils.isEmpty(type)?"":type){
                case "":{
                    ZLList.add(map);
                    break;
                }
                case BLOOD:{
                    XYList.add(map);
                    break;
                }
                case PLASMA:{
                    XJList.add(map);
                    break;
                }
                case TISSUES:{
                    ZZList.add(map);
                    break;
                }
                case URN:{
                    NYList.add(map);
                    break;
                }
            }
        }
        if(getField){
            //按添加顺序返回
            //List<Map<String, Object>> types =  DataBaseUtil.record2Map(samplingDao.getTypeOrderByCTime(cycleId)).stream().distinct().collect(Collectors.toList());
            List<Map<String, Object>> types =  DataBaseUtil.record2Map(samplingDao.getTypeOrderByCTime2(groupId)).stream().distinct().collect(Collectors.toList());
            for (Map<String, Object> type : types) {
                buildList(keyList.get(type.get("nd_type").toString()),resList,type.get("nd_type").toString());
            }
        }else {
            if(!ZLList.isEmpty())
                throw new BusinessException(11003, ConfigUtil.getMessage(11003,groupNo+"组存在未确定样品种类的节点，节点类型"));
            Map<String,Object> dataMap = new HashMap<>();
            if(!XYList.isEmpty())
                dataMap.put(BLOOD,XYList);
            if(!XJList.isEmpty())
                dataMap.put(PLASMA,XJList);
            if(!ZZList.isEmpty())
                dataMap.put(TISSUES,ZZList);
            if(!NYList.isEmpty())
                dataMap.put(URN,NYList);
            resList.add(dataMap);
        }

        return resList;
    }


    private boolean buildList(List<Map<String, Object>> dataList,List<Map<String, Object>> resultList,String type){
        if(dataList.isEmpty())
            return false;
//        String nodeStrNorm = Fileds.node.getCode();
//        List<Map<String, Object>> nodeFieldNorm = ( List<Map<String, Object>>)JSON.parse(nodeStrNorm);
//        String nodeStrSpe = Fileds.node2.getCode();
//        List<Map<String, Object>> nodeFieldSpe = ( List<Map<String, Object>>)JSON.parse(nodeStrSpe);
        List<Map<String, Object>> nodeFieldNorm = ( List<Map<String, Object>>)JSON.parse(Fileds.node3.getCode());
        //List<Map<String,Object>> typeDataList = DataBaseUtil.record2Map(sampTypeDataDao.getAllType());
        Map<String,Object> nodeResult = new HashMap<>();
        nodeResult.put("type",type);
        nodeResult.put("nodes",dataList);
        nodeResult.put("field",nodeFieldNorm);
        //nodeResult.put("sampTypes",typeDataList);
        resultList.add(nodeResult);

        return true;
    }

    public boolean isInteger(String str,boolean isPositive) {
//        return true;
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        if (!isPositive)//不继续检查是否是正整数
        return pattern.matcher(str).matches();
       //继续检查是否是正整数
        if(pattern.matcher(str).matches()){
            return Integer.parseInt(str) >0;
        }
        return pattern.matcher(str).matches();
    }

    private void innerDiction(Map<String, Object> result) {
        List enVals = new ArrayList();
        for (SampZSEnum value : SampZSEnum.values()) {
            Map map = new HashMap();
            map.put("label",value.getCode());
            map.put("key",value);
            enVals.add(map);
        }
        List<Map<String,Object>> list = (List) result.get("field");
        for (Map<String, Object> stringStringMap : list) {
            if(stringStringMap.get("key").equals("grop_no_type")) {
                stringStringMap.put("type", "select");
                stringStringMap.put("values", enVals);
            }
        }
    }
}
