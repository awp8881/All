package com.qzsoft.lims.ks.dao.impl;

import com.google.common.collect.Lists;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.dao.KsModelCountBDao;
import com.qzsoft.lims.ks.dao.event.KsSqlCondBDao;
import com.qzsoft.lims.ks.util.CodesUtil;
import com.qzsoft.lims.ks.util.DataBaseUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @Author zf
 * @Description 列表统计配置
 * @Date 2020/6/22
 */
@Repository
public class KsModelCountBDaoImpl extends BaseDaoImpl implements KsModelCountBDao{
    private static final String TABLE_NAME = "ks_model_count_b";

    @Autowired
    private KsSqlCondBDao ksSqlCondBDao;

    @Override
    public List<Record> getCountConfig(String pCode) {
        String sql = "select * from "+TABLE_NAME+" where p_code=? order by disp_or+0";
        List<Record> counts = DbEx.find(sql, pCode);
        if (null == counts){
            return null;
        }
        counts.stream().forEach( countRecord -> {
            String condCode = countRecord.getStr("cond_code");
            if(StringUtils.isBlank( condCode)){
                countRecord.set("groupConds", Lists.newArrayList());
                return;
            }
            Map<String, Object> condMap = ksSqlCondBDao.getGroupCondsByCode( Lists.newArrayList(condCode));
            countRecord.set("groupConds", condMap.get(condCode));
        });
        return counts;
    }

    @Override
    public Boolean saveCount(List<Map<String, Object>> countConfDatas, String newMCode, String menuId) {
        DbEx.delete("delete from "+TABLE_NAME+" where p_code=?", newMCode);

        if (null == countConfDatas || countConfDatas.isEmpty()){
            return true;
        }
        int count = 0;
        for (Iterator<Map<String, Object>> iterator = countConfDatas.iterator(); iterator.hasNext(); ) {
            Map<String, Object> countConfData =  iterator.next();
            count++;

            countConfData.put("p_code", newMCode);
            countConfData.put("menu_id", menuId);
            countConfData.put("disp_or", count);
            countConfData.put("cr_dm", DateUtil.getNowDateTimeStr());
            countConfData.put("up_ver", 1);
            List<List<Map<String, Object>>> groupConds = (List<List<Map<String, Object>>>)countConfData.get("groupConds");
            countConfData.remove("groupConds");
            if(null == groupConds || groupConds.isEmpty()){
                continue;
            }
            String condCode = CodesUtil.createCommonCode("gro_cond_code");
            countConfData.put("cond_code", condCode);
            groupConds.stream().forEach( groupCond -> {
                groupCond.stream().forEach( cond -> {
                    cond.put("gro_cond_code", condCode);
                });
            });
            ksSqlCondBDao.saveGroupConds( groupConds, newMCode, menuId);
        }
        List<Record> records = DataBaseUtil.map2Record( countConfDatas);
        DbEx.batchSave(TABLE_NAME, records, records.size());
        return true;
    }
}
