package com.qzsoft.lims.ks.base;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.Map;

/**
 * 消息基类
 *
 * @author yuanj
 * @date 2021/12/31
 **/
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BaseMessage extends BaseParam {
    private static final long serialVersionUID = 437493036483567460L;

    /**
     * 指定clientId发送
     */
    private String clientId;
    /**
     * 配置
     */
    private List<Long> configIds;

    /**
     * 接收人列表
     */
    private String messLogins;

    /**
     * kb_msg_opt主键id
     */
    private Long ids;

    /**
     * ks_msg_template主键id
     */
    private Long id;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 参数配置
     */
    private Map<String, Object>  paramConfigMap;

    /**
     * 附件（可为空,暂时只为邮件提供）
     * @return
     */
    private String messFiles;


    public String getMessFiles() {
        return messFiles;
    }

    public void setMessFiles(String messFiles) {
        this.messFiles = messFiles;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Map<String, Object> getParamConfigMap() {
        return paramConfigMap;
    }

    public void setParamConfigMap(Map<String, Object> paramConfigMap) {
        this.paramConfigMap = paramConfigMap;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }



    public Long getIds() {
        return ids;
    }

    public void setIds(Long ids) {
        this.ids = ids;
    }

    public String getMessLogins() {
        return messLogins;
    }

    public void setMessLogins(String messLogins) {
        this.messLogins = messLogins;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public List<Long> getConfigIds() {
        return configIds;
    }

    public void setConfigIds(List<Long> configIds) {
        this.configIds = configIds;
    }
}
