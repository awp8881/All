package com.qzsoft.lims.ks.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.dao.BaseDao;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.ConfigUtil;
import com.qzsoft.lims.ks.dao.KsPortDicParaBDao;
import com.qzsoft.lims.ks.util.DataBaseUtil;

/**
 * 后端动作参数
 * @author zf
 * */
@Repository
public class KsPortDicParaBDaoImpl extends BaseDaoImpl implements KsPortDicParaBDao{
	private static final String TABLE_NAME = "ks_port_dic_para_b";


	/**
	 * 获取后端动作参数列表
	 */
	@Override
	public List<Map<String, Object>> getActionParamsList(String action_type_code, String port_code) {
		if(StringUtils.isBlank(action_type_code) || StringUtils.isBlank(port_code)){
			throw new BusinessException(11003,ConfigUtil.getMessage(11003, "类型或后端动作"));
		}
		String sql="select * from "+TABLE_NAME+" k1 where exists (select 1 from ks_port_dic_b k2 where action_type_code=? and port_code=? and k2.port_code=k1.port_code  )"
				+ " order by para_order+0";
		List<Record> recordList=DbEx.find(sql,action_type_code,port_code);
		//追加上级描述
		for( Record record : recordList ){
			String para_code = record.getStr("para_up");
			if( StringUtils.isNotBlank( para_code ) ){
				Record temp = DbEx.findFirst(" select * from ks_port_dic_para_b where para_code=? ", para_code);
				if( null!=temp ){
					record.set("para_up_desc",temp.getStr( "para_desc"));
				}
			}
		}
		return DataBaseUtil.record2Map(recordList);
	}

	@Override
	public List<Map<String, Object>> getTmpConstantList(String m_code, String info_code) {

		List<Map<String, Object>> list = new ArrayList();

		if( StringUtils.isBlank(m_code) ){
			throw new BusinessException(11003,ConfigUtil.getMessage(11003, "m_code"));
		}
		StringBuffer buffer = new StringBuffer(" select * from ks_model_field_tmp_b ");
		buffer.append( " where m_code=? " );
		if( StringUtils.isNotBlank( info_code ) ){
			buffer.append( " and info_code=? " );
		}
		List<Record> recordList = null;
		if( StringUtils.isNotBlank( info_code ) ){
			recordList = DbEx.find( buffer.toString(),m_code,info_code );
		}else{
			recordList = DbEx.find( buffer.toString(),m_code );
		}
		if( recordList.isEmpty() ){
			return new ArrayList();
		}
		List<String> tmpCodeList = new ArrayList<>();
		for( Record record : recordList ){
			tmpCodeList.add( record.getStr( "tmp_code" ) );
		}

		//ks_model_info_field_b  ks_model_list_field_b  ks_model_list_field_c
		List<Record> ks_model_info_field_bList = this.getByColumnList("ks_model_info_field_b", "tmp_code", tmpCodeList);
		setTmpCodeInfoToListFromRecords( ks_model_info_field_bList, list );

		List<Record> ks_model_list_field_bList = this.getByColumnList("ks_model_list_field_b", "tmp_code", tmpCodeList);
		setTmpCodeInfoToListFromRecords( ks_model_list_field_bList, list );

		List<Record> ks_model_list_field_cList = this.getByColumnList("ks_model_list_field_c", "tmp_code", tmpCodeList);
		setTmpCodeInfoToListFromRecords( ks_model_list_field_cList, list );

		return list;
	}

	/**
	 *
	 * @param sourceList
	 * @param targetList
	 */
	private void setTmpCodeInfoToListFromRecords(List<Record> sourceList, List<Map<String, Object>> targetList) {

		if( null==sourceList || sourceList.isEmpty() ){
			return;
		}

		for( Record record : sourceList ){
			Map<String, Object> hashMap = new HashMap<>();
			hashMap.put( "field_name", record.getStr( "field_name" ));
			hashMap.put( "field_desc", record.getStr( "field_desc" ));
			hashMap.put( "default_value", record.getStr( "default_value" ));
			targetList.add( hashMap );
		}

	}


}
