package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.dao.BaseDao;

public interface KsMenuLogicMultBDao extends BaseDao{
	
	Boolean batchUpdate(List<Map<String, Object>> allFollowList,String old_m_code,String info_code,String menu_id);

}
