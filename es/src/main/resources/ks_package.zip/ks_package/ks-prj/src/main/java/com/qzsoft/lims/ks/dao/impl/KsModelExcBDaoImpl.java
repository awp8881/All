package com.qzsoft.lims.ks.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.dao.impl.BaseDaoImpl;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.lims.ks.conversion.ConversionHolder;
import com.qzsoft.lims.ks.dao.KsModelExcBDao;
import com.qzsoft.lims.ks.dao.KsModelExcValBDao;
import com.qzsoft.lims.ks.eum.FieldStyleEnum;
import com.qzsoft.lims.ks.util.DataBaseUtil;

@Repository
public class KsModelExcBDaoImpl extends BaseDaoImpl implements KsModelExcBDao{
	
	private static final String TABLE_NAME = "ks_model_exc_b";
	private static final String SUF ="$button_code";

	@Autowired
	private KsModelExcValBDao ksModelExcValBDao;
	
	/**
	   *   删除后插入
	 */
	@Override
	@JFinalTx
	public Boolean batchUpdate(List<Map<String, Object>> allExcList,  String old_m_code) {
		Boolean succYn=true;
		if (StringUtils.isBlank(old_m_code)){
			return succYn;
		}
		DbEx.delete("delete from "+TABLE_NAME+" where locate(?,button_code)>0 ", old_m_code+SUF);
		DbEx.delete("delete from ks_model_exc_val_b where locate(?,button_code)>0 ", old_m_code+SUF);
		if(null == allExcList || allExcList.isEmpty()){
			return succYn;
		}
		List<Record> excList = new ArrayList<>();
		List<Record> allExcValList = new ArrayList<>();
		for(Map<String, Object> map : allExcList){
			Object menuId = map.get("menu_id");
			Object buttonCode = map.get("button_code");
			Object paraName = map.get("para_name");
			
			if (!ObjectUtils.isEmpty(paraName)) {
				Record excRecord = new Record();
				paraName = ConversionHolder.saveDataConversion(FieldStyleEnum.multiSelect.name(),paraName );
				excRecord.set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1").set("menu_id", menuId).set("para_name", paraName)
				.set("button_code", buttonCode);
				excList.add(excRecord);
			}
			
			List<Map<String, Object>> excValList = (List<Map<String, Object>>) map.get("excValList");
			if(null == excValList || excValList.isEmpty()){
				continue;
			}
			List<Record> list = new ArrayList<>();
			int count = 1;
			for (Map<String, Object> excValMap : excValList) {
				Record excValRecord = DataBaseUtil.map2Record(excValMap);
				excValRecord.set("cr_dm", DateUtil.getNowDateTimeStr()).set("up_ver", "1").set("menu_id", menuId).set("button_code", buttonCode)
				.set("para_order", count).remove("dicDesc").remove("dicParaDesc").remove("id");
				list.add(excValRecord);
				count++;
				
			}
			allExcValList.addAll(list);
		}
		if (!excList.isEmpty()) {
			succYn= saveList(TABLE_NAME, excList);
		}
		ksModelExcValBDao.batchUpdate(allExcValList, old_m_code);
		return succYn;
	}

	/**
	 *  导入去重列表
	 */
	@Override
	public Map<String,Object> getExcListByButtonCode(String buttonCode, Boolean jsonYn) {
		Map<String,Object> map = new HashMap<>();
		String sql = "select button_code,para_name from "+TABLE_NAME+" where button_code=?";
		Record excRecord = selectFirstOneBySql(sql, buttonCode);
		List<Record> exValList = ksModelExcValBDao.getExcValListByButtonCode(buttonCode, jsonYn);
		map.put("para_name", new ArrayList<>());
		if(null != excRecord ) {
			Object paraName = excRecord.get("para_name");
			paraName = ConversionHolder.selectDataConversion(FieldStyleEnum.multiSelect.name(),paraName );
			map.put("para_name", paraName);
			if (jsonYn) {
				String paraNameStr = excRecord.getStr("para_name");
				map.put("para_name", StringUtil.toArr(paraNameStr));
			}
		}
		map.put("excValList", DataBaseUtil.record2Map(exValList));
		return map;
	}

	
}
