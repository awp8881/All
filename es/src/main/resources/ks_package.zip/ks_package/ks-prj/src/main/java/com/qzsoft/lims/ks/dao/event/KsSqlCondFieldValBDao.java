package com.qzsoft.lims.ks.dao.event;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

public interface KsSqlCondFieldValBDao extends BaseDao{

	/**
	 * 事件字段赋值
	 * @param pCode
	 * @return
	 */
	List<Record> getByPCode(String pCode, Boolean jsonYn);
	
	/**
	 * 批量插入
	 * @param allFieldValList
	 * @return
	 */
	boolean batchUpdate(List<Map<String, Object>> allFieldValList);
}
