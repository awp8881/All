package com.qzsoft.lims.ks.controller;

import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.annotation.TagResource;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.KsMenuJsonStepBService;
import com.qzsoft.lims.ks.service.KsMenuJsonVerBService;
import com.qzsoft.lims.ks.service.backRevert.JsonBackRevertService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

/**
 * json版本备份还原-控制器
 * @author zf
 *
 */
@Api(value = "json版本备份还原+阶段管理", tags = "json版本备份还原+阶段管理")
@RestController
@RequestMapping("/backRevert")
@Slf4j
public class JsonBackRevertController {
	
	@Autowired
	private JsonBackRevertService jsonBackRevertService;
	
	@Autowired
	private KsMenuJsonVerBService ksMenuJsonVerBService;
	
	@Autowired
	private KsMenuJsonStepBService ksMenuJsonStepBService;


    @ApiOperation(value = "菜单历史版本")
    @GetMapping("/getPageList")
	    @ApiImplicitParams({
    	@ApiImplicitParam(name="menuId",value="菜单主键",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="ver_order",value="版本序号",required=false,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="cr_dm",value="创建时间",required=false,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="is_cur_use",value="是否在用",required=false,dataType="String",paramType="query"),
		@ApiImplicitParam(name="pageNum",value="页码",required=false,dataType="Integer",paramType="query"),
		@ApiImplicitParam(name="pageSize",value="每页显示条数",required=false,dataType="Integer",paramType="query")
	})
    @ResponseAddHead
    public RequestResult<Map<String, Object>> getPageList(
    		@RequestParam(value = "menuId") String menuId,
    		@RequestParam(value = "ver_order", required = false) String ver_order,
    		@RequestParam(value = "cr_dm", required = false) String cr_dm,
    		@RequestParam(value = "is_cur_use", required = false) String is_cur_use,
    		@RequestParam(value = "pageNum", defaultValue = CommonConstants.PAGE_NUM, required = false) Integer pageNum,
			@RequestParam(value = "pageSize", defaultValue = CommonConstants.PAGE_SIZE, required = false) Integer pageSize) {
        RequestResult<Map<String, Object>> result = null;
		try {
			result=ksMenuJsonVerBService.getPageList(menuId,ver_order,cr_dm,is_cur_use,pageNum,pageSize);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getPageList()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			log.error(this.getClass().getSimpleName() + ".getPageList()", e);
		}
		return result;
    }
	
    @ApiOperation(value = "删除")
    @PostMapping("/delete")
	    @ApiImplicitParam(name="ids",value="主键:多个逗号隔开",required=true,dataType="String",paramType="query")
    @ResponseAddHead
    public RequestResult<Boolean> delete(@RequestParam(value="ids") String ids) {
    	RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
			boolean delete = ksMenuJsonVerBService.delete(ids);
			result.setObj(delete);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".delete()", e);
		}
		return result;
    }
    
    @ApiOperation(value = "菜单版本还原 ")
    @PostMapping("/revertMenuJson")
		@ApiImplicitParam(name="id",value="主键",required=true,dataType="String",paramType="query")
    @ResponseAddHead
    public RequestResult<Boolean> revertMenuJson(@RequestParam(value="id") String id ,  HttpServletRequest request) {
    	RequestResult<Boolean> result = new RequestResult<Boolean>();
		try {
//			boolean delete = jsonBackRevertService.revertMenuJson(id , request);
//			result.setObj(delete);
		}catch (BusinessException e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".revertMenuJson()", e);
		}catch (Exception e) {
			result = RequestResult.error(e);
			result.setObj(false);
			log.error(this.getClass().getSimpleName() + ".revertMenuJson()", e);
		}
		return result;
    }
    
    @ApiOperation(value = "菜单版本导出客户端 ")
    @PostMapping("/exportMenuJson")
	    @ApiImplicitParam(name="id",value="主键",required=true,dataType="String",paramType="query")
    @ResponseAddHead
    public void exportMenuJson(@RequestParam(value="id") String id, HttpServletResponse response) {
		try {
			String jsonStr = jsonBackRevertService.exportMenuJson(id);
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write(jsonStr);

		}catch (BusinessException e) {
			log.error(this.getClass().getSimpleName() + ".exportMenuJson()", e);
		}catch (Exception e) {
			log.error(this.getClass().getSimpleName() + ".exportMenuJson()", e);
		}
    }
    
    @ApiOperation(value = "菜单版本导入 ")
    @PostMapping("/importMenuJson")
	    @ApiImplicitParams({
    	@ApiImplicitParam(name="menu_id",value="菜单主键",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="file",value="文件",required=true,dataType="String",paramType="query")
    })
    @ResponseAddHead
    public RequestResult<Boolean> importMenuJson(@RequestParam(value="menu_id") String menu_id, @RequestParam("file") MultipartFile file,
												  HttpServletRequest request) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	//暂时注释
//		boolean importYn = jsonBackRevertService.importMenuJson( menu_id,  file, request);
//		result.setObj(importYn);
		return result;
    }
    
    @ApiOperation(value = "阶段列表")
    @GetMapping("/getStepList")
    @ResponseAddHead
	    public RequestResult<Map<String,Object>> getStepList( ) {
        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> stepList = ksMenuJsonStepBService.getStepList();
        result.setList( stepList );
        return result;
    }
    
    @ApiOperation(value = "阶段新增 ")
    @PostMapping("/saveStep")
    @ResponseAddHead
	    @ApiImplicitParams({
    	@ApiImplicitParam(name="step_name",value="阶段名称",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="remark",value="描述",required=false,dataType="String",paramType="query")
    })
    public RequestResult<Boolean> saveStep(@RequestParam(value="step_name") String stepName,@RequestParam(value="remark",required=false) String remark) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean saveYn = ksMenuJsonStepBService.saveStep( stepName, remark);
    	result.setObj(saveYn);
		return result;
    }
    
    @ApiOperation(value = "阶段修改 ")
    @PostMapping("/updateStep")
    @ResponseAddHead
	    @ApiImplicitParams({
    	@ApiImplicitParam(name="id",value="主键",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="step_name",value="阶段名称",required=true,dataType="String",paramType="query"),
    	@ApiImplicitParam(name="remark",value="描述",required=false,dataType="String",paramType="query")
    })
    public RequestResult<Boolean> updateStep(@RequestParam(value="id") String id,
    		@RequestParam(value="step_name") String stepName,@RequestParam(value="remark",required=false) String remark) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean updateYn = ksMenuJsonStepBService.updateStep(id, stepName, remark);
    	result.setObj(updateYn);
		return result;
    }

    @ApiOperation(value = "阶段详情")
    @GetMapping("/getStepOne")
	    @ApiImplicitParam(name="id",value="主键",required=true,dataType="String",paramType="query")
    @ResponseAddHead
    public RequestResult<Map<String,Object>> getStepOne( @RequestParam(value="id") String id) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        Map<String, Object> stepMap = ksMenuJsonStepBService.getStepOne(id);
        result.setObj( stepMap );
        return result;
    }
    
    @ApiOperation(value = "阶段删除 ")
    @PostMapping("/deleteStep")
    @ResponseAddHead
	    @ApiImplicitParam(name="id",value="主键",required=true,dataType="String",paramType="query")
    public RequestResult<Boolean> deleteStep(@RequestParam(value="id") String id) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean deleteYn = ksMenuJsonStepBService.deleteStep(id);
    	result.setObj(deleteYn);
		return result;
    }
    
    @ApiOperation(value = "在用菜单列表")
    @GetMapping("/getCurrUseMenuList")
    @ResponseAddHead
	    public RequestResult<Map<String,Object>> getCurrUseMenuList( ) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> stepList = ksMenuJsonVerBService.getCurrUseMenuList();
        result.setList( stepList );
        return result;
    }
    
    @ApiOperation(value = "阶段配置菜单列表")
    @GetMapping("/getStepConfigMenuList")
    @ResponseAddHead
	    @ApiImplicitParam(name="json_ver",value="阶段版本",required=true,dataType="String",paramType="query")
    public RequestResult<Map<String,Object>> getStepConfigMenuList( @RequestParam(value="json_ver") String jsonVer) {

        RequestResult<Map<String,Object>> result = new RequestResult<>();
        List<Map<String, Object>> stepList = ksMenuJsonVerBService.getStepConfigMenuList(jsonVer);
        result.setList( stepList );
        return result;
    }
    
    @ApiOperation(value = "删除无效配置 ")
    @PostMapping("/deleteInvalidConfig")
    @ResponseAddHead
	    @ApiImplicitParam(name="id",value="阶段主键",required=true,dataType="String",paramType="query")
    public RequestResult<Boolean> deleteInvalidConfig(@RequestParam(value="id") String stepId) {
    	RequestResult<Boolean> result = new RequestResult<>();
    	boolean saveYn = ksMenuJsonVerBService.deleteInvalidConfig( stepId);
    	result.setObj(saveYn);
		return result;
    }
    
    @ApiOperation(value = "阶段的菜单导出客户端 ")
    @PostMapping("/exportStepMenuJson")
    @ApiImplicitParam(name="id",value="阶段主键",required=true,dataType="String",paramType="query")
    @ResponseAddHead
	    public void exportStepMenuJson(@RequestParam(value="id") String stepId, HttpServletResponse response) {
		OutputStream out = null;
    	try {
    		response.setContentType("application/octet-stream");
    		response.setHeader("Content-disposition","attachment");
    		response.setCharacterEncoding("utf-8");
			out = response.getOutputStream();
			jsonBackRevertService.exportStepMenuJson(out, stepId);

			
		} catch (IOException e) {
			log.error("导出失败");

		}finally {
			try {
				out.flush();
				out.close();
			} catch (IOException e) {
				log.error("导出失败");
			}

		}
	}
    
    @ApiOperation(value = "阶段还原 ",notes="还原阶段最新版本")
    @PostMapping("/revertStepJson")
    @ApiImplicitParam(name="id",value="阶段主键",required=true,dataType="String",paramType="query")
    @ResponseAddHead
	    public RequestResult<Boolean> revertStepJson(@RequestParam(value="id") String id, HttpServletRequest request ) {

    	RequestResult<Boolean> result = new RequestResult<Boolean>();
    	boolean stepYn = jsonBackRevertService.revertStepJson( id,  request);
    	result.setObj(stepYn);
		return result;
    }

	@ApiOperation(value = "菜单恢复脚本")
	@PostMapping("/menuRestoreScript")
	@ResponseAddHead
		public RequestResult<String> menuRestoreScript(@RequestParam(value="menuId") String menuId) {

		RequestResult<String> result = new RequestResult<>();
		result.setList(jsonBackRevertService.menuRestoreScript( menuId));
		return result;
	}
}
