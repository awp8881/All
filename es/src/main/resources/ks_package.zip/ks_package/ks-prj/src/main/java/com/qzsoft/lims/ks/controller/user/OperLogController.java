package com.qzsoft.lims.ks.controller.user;

import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.user.OperLogService;
import com.qzsoft.lims.ks.vo.KsMenuCVO;
import com.qzsoft.lims.ks.vo.KsMenuFeVO;
import com.qzsoft.lims.ks.vo.user.OperLogRespVO;
import com.qzsoft.lims.ks.vo.user.PageOperLogVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Description:
 * @author: zhouyou
 * @date: 2022/02/25 15:45
 **/
@RestController
@Api(tags = "操作日志记录")
@RequestMapping("/operLog")
public class OperLogController {


    @Autowired
    private OperLogService operLogService;

    @ApiOperation("日志列表展示")
    @PostMapping("/pageOperLog")
    public RequestResult<OperLogRespVO> pageOperLog(@RequestBody PageOperLogVO vo) {
        return operLogService.pageOperLog(vo);
    }


    @ApiOperation("查看对应菜单id")
    @PostMapping("/findRelationMenu")
    public RequestResult<String> findRelationMenu(@RequestBody PageOperLogVO vo) {
        RequestResult<String> result = new RequestResult();
        List<String> menuId = operLogService.findRelationMenu(vo);
        result.setList(menuId);
        return result;
    }


}
