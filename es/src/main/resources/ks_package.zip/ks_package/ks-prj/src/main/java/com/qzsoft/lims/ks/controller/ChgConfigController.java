package com.qzsoft.lims.ks.controller;

import com.google.common.base.Splitter;
import com.qzsoft.common.annotation.ResponseAddHead;
import com.qzsoft.common.ui.RequestResult;
import com.qzsoft.lims.ks.service.CommonService;
import com.qzsoft.lims.ks.service.chg.ChgConfigService;
import com.qzsoft.lims.ks.vo.chg.ChgPlanTableFieldVO;
import com.qzsoft.lims.ks.vo.chg.ChgPlanVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 变更记录配置数据控制层
 */
@Api(value = "变更记录配置数据控制层", tags = "变更记录配置数据控制层")
@RestController
@RequestMapping("/chgConfig")
@Slf4j
public class ChgConfigController {

    @Autowired
    ChgConfigService chgConfigService;

    @Autowired
    private CommonService commonService;

    @ApiOperation("保存记录方案")
    @PostMapping("/saveChgPlan")
    @ResponseAddHead
        public RequestResult<ChgPlanVO> saveChgPlan( @RequestBody ChgPlanVO chgPlanVO ) {
        RequestResult<ChgPlanVO> chgPlanVOResult = new RequestResult<>();
        chgConfigService.saveChgPlan( chgPlanVO );
        chgPlanVOResult.setObj( chgPlanVO );
        return chgPlanVOResult;
    }


    @ApiOperation("删除记录方案")
    @PostMapping("/delChgPlan")
    @ResponseAddHead
        public RequestResult<Boolean> delChgPlan( Long planId ) {
        boolean isSucess = chgConfigService.delChgPlan( planId );
        RequestResult<Boolean> booleanRequestResult = new RequestResult<>();
        booleanRequestResult.setObj( isSucess );
        return booleanRequestResult;
    }

    @ApiOperation("获取方案数据列表")
    @GetMapping("/chgPlanDataList")
    @ResponseAddHead
        public RequestResult<ChgPlanVO> chgPlanDataList(  ) {
        RequestResult<ChgPlanVO> chgPlanVORequestResult = new RequestResult<>();
        List<ChgPlanVO> chgPlanVOList = chgConfigService.findChgPlanDataList();
        chgPlanVORequestResult.setList( chgPlanVOList );
        return chgPlanVORequestResult;
    }

    @ApiOperation("批量删除变更记录配置列表")
    @GetMapping("/batchDelGhgPlanDataList")
    @ResponseAddHead
        public RequestResult<Boolean> batchDelGhgPlanDataList( String planIds ) {
        RequestResult<Boolean> requestResult = new RequestResult<>();
        requestResult.setObj(true);
        if(StringUtils.isBlank( planIds )){
            return requestResult;
        }
        List<String> planIdStrs = Splitter.on(",").splitToList(planIds);
        List<Long> planIdLongs = planIdStrs.stream().map(str -> Long.parseLong(str)).collect(Collectors.toList());
        chgConfigService.batchDelGhgPlanDataList( planIdLongs );
        return requestResult;
    }

    @ApiOperation("获取方案table列表")
    @GetMapping("/chgPlanTableList")
    @ResponseAddHead
        public RequestResult<Map<String, Object>> chgPlanTableList( ) {
        RequestResult<Map<String, Object>> result = new RequestResult<>();
        result.setList( commonService.getBusFieldsTreeByTables(null,false) );
        return result;
    }

    @ApiOperation("获取方案table字段列表")
    @GetMapping("/chgPlanTableFieldList")
    @ResponseAddHead
        public RequestResult<ChgPlanTableFieldVO> chgPlanTableFieldList(Long planId, String tableName ) {
        List<ChgPlanTableFieldVO> planTableFieldList = chgConfigService.findChgPlanTableFieldList(planId, tableName);
        RequestResult<ChgPlanTableFieldVO> requestResult = new RequestResult<>();
        requestResult.setList( planTableFieldList );
        return requestResult;
    }

    @ApiOperation("获取方案table字段保存")
    @PostMapping("/saveChgPlanTableField")
    @ResponseAddHead
        @ApiImplicitParams({
            @ApiImplicitParam(name="chgPlanTableFieldVOListStr",value="需要记录的字段",required=true,dataType="String",paramType="query")})
    public RequestResult<Boolean> saveChgPlanTableField( @RequestBody List<ChgPlanTableFieldVO> chgPlanTableFieldVOList  ) {
        RequestResult<Boolean> booleanRequestResult = new RequestResult<>();
        chgConfigService.saveChgPlanTableField( chgPlanTableFieldVOList );
        booleanRequestResult.setObj(true);
        return booleanRequestResult;
    }
}
