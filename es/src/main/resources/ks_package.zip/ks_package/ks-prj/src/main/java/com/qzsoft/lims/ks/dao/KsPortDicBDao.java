package com.qzsoft.lims.ks.dao;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.dao.BaseDao;

/**
 * 后端动作
 * @author zf
 * */
public interface KsPortDicBDao extends BaseDao{
	/**
	 * 获取后端类型列表
	 * @return
	 */
	List<Map<String,Object>> getActionTypeList(String sy_id);
	
	/**
	 * 获取后端动作列表
	 * @param action_type_code
	 * @return
	 */
	List<Map<String,Object>> getActionList(String action_type_code,String sy_id);
}
