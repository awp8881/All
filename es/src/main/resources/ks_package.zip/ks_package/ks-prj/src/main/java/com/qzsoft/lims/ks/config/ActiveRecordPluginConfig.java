package com.qzsoft.lims.ks.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.google.common.base.Splitter;
import com.google.common.collect.Maps;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.activerecord.Config;
import com.jfinal.plugin.activerecord.dialect.Dialect;
import com.jfinal.plugin.activerecord.dialect.OracleDialect;
import com.jfinal.plugin.activerecord.dialect.SqlServerDialect;
import com.jfinal.plugin.druid.DruidPlugin;
import com.qzsoft.common.activerecord.DataSourceHolder;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.activerecord.DbMetaService;
import com.qzsoft.common.activerecord.KsTransactionUtil;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.mvc.configuration.properties.DruidDataSourceProperties;
import com.qzsoft.lims.ks.interceptor.PrintSqlParamInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
//import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.BindResult;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.boot.context.properties.bind.PropertySourcesPlaceholdersResolver;
import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Configuration
@Slf4j
public class ActiveRecordPluginConfig implements EnvironmentAware {

    @Autowired
    DbMetaService dbMetaService;

    private static AtomicBoolean existTryCon = new AtomicBoolean(false);


    @Override
    public void setEnvironment(Environment environment) {

        Iterable<ConfigurationPropertySource> sources = ConfigurationPropertySources.get(environment);
        Binder binder = new Binder(sources, new PropertySourcesPlaceholdersResolver(environment));
//        BindResult<Properties> bindResult = binder.bind("spring.datasource", Properties.class);
//        Properties properties= bindResult.get();

//        RelaxedPropertyResolver springPropertyResolver = new RelaxedPropertyResolver(environment, "spring.");
//        Map<String, Object> subProperties = springPropertyResolver.getSubProperties("datasource.");

        Map subProperties= binder.bind("spring.datasource", Map.class).get();
        if( null==subProperties || subProperties.isEmpty() ){
            BusinessException.throwBiz("数据源配置不能为空");
        }
        DataSourceHolder.init( dbMetaService );
        DbEx.setDbMetaService( dbMetaService );

        String dataSourceName = DbEx.defaultDbConfigName;
        initDataSource( dataSourceName, subProperties,false );
        DataSourceHolder.setDbPropertyHolders(subProperties);
        DataSourceHolder.addMasterDataSource( dataSourceName );
//        //加载多数据spring.datasources配置
        //============================================多数据源加载开始  目前没有作用，配合DbEx.useDb方法切换数据源 =====================================================
        subProperties = binder.bind("spring.datasources", Map.class).orElse(Maps.newHashMap() );
        if( null!=subProperties && !subProperties.isEmpty() ){
            String masterDses = binder.bind("spring.datasources.master-ds", String.class).orElse("");
            if(StringUtils.isNotBlank( masterDses )){
                List<String> masterList = Splitter.on(",").omitEmptyStrings().splitToList(masterDses);
                for (String dsName : masterList) {
                    Map<String, Object> dsConf = binder.bind("spring.datasources."+dsName, Map.class).get();
                    initDataSource( dsName, dsConf,false);
                    DataSourceHolder.addMasterDataSource( dsName );
                }
            }
            String slaveDses = binder.bind("spring.datasources.slave-ds", String.class).orElse("");
            if(StringUtils.isNotBlank( slaveDses )){
                List<String> slaveList = Splitter.on(",").omitEmptyStrings().splitToList(slaveDses);
                for (String dsName : slaveList) {
                    Map<String, Object> dsConf = binder.bind("spring.datasources."+dsName, Map.class).get();
                    initDataSource( dsName, dsConf,false);
                    DataSourceHolder.addSlaveDataSource( dsName );
                }
            }

            String outerDses = binder.bind("spring.datasources.outer-ds", String.class).orElse("");
            if(StringUtils.isNotBlank( outerDses )){
                List<String> outerList = Splitter.on(",").omitEmptyStrings().splitToList(outerDses);
                for (String dsName : outerList) {
                    try{
                        Map<String, Object> dsConf = binder.bind("spring.datasources."+dsName, Map.class).get();
                        initDataSource( dsName, dsConf,true);
                        DataSourceHolder.addOuterDataSource( dsName );
                    }catch (Throwable t){
                        log.error("外部数据源加载失败",t);
                        //设置定时任务   加载配置
                        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
                        executor.scheduleAtFixedRate(() -> {
                            final Set<Map.Entry<String, Config>> configSet = KsTransactionUtil.getConfigSet();
                            if (!configSet.contains( dsName ) && !existTryCon.get() ) {
                                try {
                                    existTryCon.set(true);
                                    Map<String, Object> dsConf = binder.bind("spring.datasources."+dsName, Map.class).get();
                                    log.info("定时加载失败的数据源:{}", dsConf);
                                    initDataSource( dsName, dsConf,true);
                                    DataSourceHolder.addOuterDataSource( dsName );
                                }catch (Throwable throwable){
                                    log.error(throwable.getMessage(),throwable);
                                }finally {
                                    existTryCon.set(false);
                                }
                            }

                        }, 5, 10, TimeUnit.MINUTES);
                    }
                }
            }
        }
        //============================================多数据源加载结束=====================================================
        dbMetaService.loadFieldMappingFromMeta( DataSourceHolder.getColMetaRecordListFromMasterDbMetas() );


    }

    /**
     * 初始化数据源
     *
     * 2021-09-18 改造： 如果是外部数据源，设置失败后重试次数为3次，这个是为了保证系统的基本可用性
     *
     * @param dataSourceName  数据源名字
     * @param datasourcePropertyMap
     */
    private void initDataSource(String dataSourceName, Map<String, Object> datasourcePropertyMap,boolean isOuterDs) {

        if( datasourcePropertyMap.isEmpty() ){
            BusinessException.throwBiz("数据源"+dataSourceName+"配置未发现");
        }
        DruidPlugin druidPlugin = createDruidPlugin(datasourcePropertyMap,isOuterDs);
        ActiveRecordPlugin arp = new ActiveRecordPlugin( dataSourceName,druidPlugin);
//        boolean isShowSql = isShowSql( datasourcePropertyMap );
//        arp.setShowSql( isShowSql );
        Dialect dialect = getDialect(datasourcePropertyMap);
        if( dialect!=null ){
            arp.setDialect( dialect );
        }
        if( isOracle(datasourcePropertyMap) ){
            arp.setContainerFactory(new QzContainerFactory());
        }
        arp.start();
    }

    private boolean isShowSql(Map<String, Object> datasourcePropertyMap) {

        Object showSql = datasourcePropertyMap.get("jpa.hibernate.show-sql"); //兼容曾经配置打sql 日志
        if( null!=showSql ){
            return Boolean.valueOf( showSql.toString() );
        }else{
            showSql = datasourcePropertyMap.get("show-sql");
            if( null!=showSql ){
                return Boolean.valueOf( showSql.toString() );
            }
        }
        return false;
    }

    private DruidPlugin createDruidPlugin(Map<String, Object> datasourcePropertyMap,boolean isOuterDs) {
        String url = (String) datasourcePropertyMap.get("url");
        String password = (String) datasourcePropertyMap.get("password");
        String driverClassName = (String) datasourcePropertyMap.get("driverClassName");
        String userName = (String) datasourcePropertyMap.get("username");

        DruidPlugin druidPlugin;
        if( isOuterDs ){
            //如果是外部数据源，设置失败后重试次数为3次，这个是为了保证系统的基本可用性
            druidPlugin = new DruidPlugin(url, userName,password,driverClassName){
                @Override
                public boolean start(){
                    boolean startBool = super.start();
                    DruidDataSource dataSource = (DruidDataSource)getDataSource();
                    dataSource.setConnectionErrorRetryAttempts( 3 );
                    return startBool;
                }
            };

        }else{
            druidPlugin = new DruidPlugin(url, userName,password,driverClassName);
        }
        DruidDataSourceProperties properties = new DruidDataSourceProperties() ;
        try {
            BeanUtils.populate( properties,datasourcePropertyMap);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("init dataSource error");
        }
        //configuration
        druidPlugin.setInitialSize(properties.getInitialSize());
        druidPlugin.setMinIdle(properties.getMinIdle());
        druidPlugin.setMaxWait( properties.getMaxWait() );
        druidPlugin.setMaxActive(properties.getMaxActive());
        druidPlugin.setTimeBetweenEvictionRunsMillis(properties.getTimeBetweenEvictionRunsMillis());
        druidPlugin.setMinEvictableIdleTimeMillis(properties.getMinEvictableIdleTimeMillis());
        druidPlugin.setValidationQuery(properties.getValidationQuery());
        druidPlugin.setTestWhileIdle(properties.getTestWhileIdle());
        druidPlugin.setTestOnBorrow(properties.getTestOnBorrow());
        druidPlugin.setTestOnReturn(properties.getTestOnReturn());
        druidPlugin.setMaxPoolPreparedStatementPerConnectionSize(properties.getMaxPoolPreparedStatementPerConnectionSize());
        druidPlugin.setFilters(properties.getFilters());
        boolean showSql = isShowSql(datasourcePropertyMap);
        druidPlugin.addFilter( new PrintSqlParamInterceptor( showSql ) );
        druidPlugin.start();
        return druidPlugin;
    }

    private Dialect getDialect(Map<String, Object> datasourcePropertyMap){

        Dialect result = new QzMysqlDialect();
        String driverClassName = (String)datasourcePropertyMap.get("driverClassName");
        if( driverClassName.contains("sqlserver") ){
            result = new SqlServerDialect();
        }else if( driverClassName.contains("OracleDriver") ){
            result = new OracleDialect();
        }

        return result;

    }

    private boolean isOracle( Map<String, Object> datasourcePropertyMap ){
        String driverClassName = (String)datasourcePropertyMap.get("driverClassName");
        return driverClassName.contains("OracleDriver");
    }


    /**
     * 判断是否需要全部转为小写
     * @param str
     * @return
     */
    private static Boolean isNeedCovLowerCase( String str ) {
        //是否包含小写字母，包含全是小写字母不需要转换大写字母
        String regEx = "[a-z]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        return !m.find();
    }

}
