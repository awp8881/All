package com.qzsoft.lims.ks.dao;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.dao.BaseDao;

/**
 * 字典dao
 * @author zf
 *
 */
public interface KsDicBDao extends BaseDao{
	/**
	 * 通过字典代码获取
	 * @param di_cd
	 * @return
	 */
	List<Record> getByDicd(String di_cd);
	
	/**
	 * 获取父子节点字典代码
	 * @param di_cd
	 * @return
	 */
	List<Record> getByParentCode(String di_cd);
	
	/**
	 * 获取字典树
	 * @return
	 */
	List<Record> getAllList();
	
	/**
	 * 通过根节点获取列表
	 * @return
	 */
	List<Record> getByRoot();
	
	/**
	 * 获取字典分类
	 * @param di_cd
	 * @return
	 */
	Record getCode(String di_cd);
	
	//字典描述
	String getDicdDesc(String diCd);
	
	//字典分类描述
	String getDicdParaDesc(String dicd, String dicdPara);
	
}
