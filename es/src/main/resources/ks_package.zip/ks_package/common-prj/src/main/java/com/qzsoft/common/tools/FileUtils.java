package com.qzsoft.common.tools;

import com.qzsoft.common.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class FileUtils {
	private static final Logger LOG = LoggerFactory.getLogger(FileUtils.class);

//	public static String saveFile(File file, String targetPathStr, String fileName) throws IOException {
//		InputStream input = new FileInputStream(file);
//		return saveFile(input, targetPathStr, fileName);
//	}
//
//	public static String saveFile(InputStream input, String targetPathStr, String fileName) throws IOException {
//		byte[] content = IOUtils.toByteArray(input);
//		return saveFile(content, targetPathStr, fileName);
//	}
//
//	public static String saveFile(byte[] content, String targetPathStr, String fileName) throws IOException {
//		if (StringUtils.isBlank(fileName)) {
//			throw new BusinessException("The fileName is null");
//		}
//		File targetPath = new File(targetPathStr);
//		if (!targetPath.exists()) {
//			targetPath.mkdirs();
//		}
//		RandomAccessFile raf = null;
//		File file = new File(targetPathStr + "/" + fileName);
//		try {
//			raf = new RandomAccessFile(file, "rw");
//			raf.write(content);
//		} catch (IOException e) {
//			if (file.exists()) {
//				file.delete();
//			}
//			throw e;
//		} finally {
//			if (raf != null) {
//				raf.close();
//				raf = null;
//			}
//		}
//		return fileName;
//	}

//	public static String parseFileUri(String uri) {
//		String serverName = Utils.getServerName();
//		FileTypeVO fileType = getFileType(uri);
//		StringBuffer sBuffer = new StringBuffer();
//		sBuffer.append(ConfigUtil.getPropertyValue("fs.formal.mapping")).append("/").append(serverName).append("/")
//				.append(fileType.getFileType()).append("/").append(uri);
//		return sBuffer.toString();
//	}


//	public static String copyFile2Formal(String uri) throws IOException {
//		if (StringUtils.isBlank(uri)) {
//			return null;
//		}
//		String tempMapping = ConfigUtil.getPropertyValue("fs.temp.mapping");
//		if (!uri.contains(tempMapping)) {
//			return uri;
//		}
//		String serverName = Utils.getServerName();
//		String fileName = uri.substring(uri.lastIndexOf("/") + 1);
//		String tempDir = ConfigUtil.getPropertyValue("fs.temp.dir");
//		LOG.info(tempDir + "+++++");
//
//		File file = new File(tempDir + "/" + fileName);
//		if (!file.exists()) {
//			throw new BusinessException("copyFile2Formal:" + uri + ". 文件不存在！");
//		}
//		FileTypeVO fileType = getFileType(fileName);
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
//		String month = sdf.format(new Date());
//		StringBuffer sBuffer = new StringBuffer();
//		sBuffer.append(ConfigUtil.getPropertyValue("fs.formal.dir")).append("/").append(serverName).append("/")
//				.append(fileType.getFileType()).append("/").append(month);
//		saveFile(file, sBuffer.toString(), fileName);
//		return month + "/" + fileName;
//	}

//	public static FileTypeVO getFileType(String uri) {
//		String fileType = uri;
//		if (uri.lastIndexOf(".") > -1) {
//			fileType = uri.substring(uri.lastIndexOf(".") + 1);
//		}
//
//		Pattern p = Pattern.compile(RegexConstant.pic);
//		Matcher m = p.matcher(fileType);
//		if (m.find()) {
//			return new FileTypeVO("pic", CommonConstants.PIC_S);
//		}
//
//		p = Pattern.compile(RegexConstant.doc);
//		m = p.matcher(fileType);
//		if (m.find()) {
//			return new FileTypeVO(fileType, CommonConstants.DOC_S);
//		}
//
//		return new FileTypeVO("oth", CommonConstants.OTH_S);
//	}

	public static String readFile(String path) {
		String laststr = "";
		File file = new File(path);
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(file),"utf-8"));
			String tempString = null;
			while ((tempString = reader.readLine()) != null) {
				laststr = laststr + tempString;
			}
			reader.close();
		} catch (IOException e) {
			throw new BusinessException("菜单配置文件不存在。");

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException el) {
					throw new BusinessException("菜单配置文件不存在。");
				}
			}
		}
		return laststr;
	}


	public static String getFileDatas(MultipartFile file){
		if(file.isEmpty()){
			throw new BusinessException("文件不能为空。");
		}
		String jsonStr = "";
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(file.getInputStream(),"utf-8"));
			String tempStr = null;
			while ((tempStr = reader.readLine()) != null) {
				jsonStr = jsonStr + tempStr;
			}
			reader.close();
		} catch (IOException e) {
			throw new BusinessException("文件不存在。");

		}finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException el) {
					throw new BusinessException("文件不存在。");
				}
			}
		}

		return jsonStr;

	}

//	public static String getFileSize(String path){
//		File file = new File(path);
//		BigDecimal length = NumberUtils.getBigDecimal(file.length());
//		BigDecimal size = NumberUtils.div(length, new BigDecimal(1024),0);
//		return StringUtil.toString(size);
//	}
//    /**
//     * 删除文件，可以是文件或文件夹
//     *
//     * @param fileName
//     *            要删除的文件名
//     * @return 删除成功返回true，否则返回false
//     */
//    public static boolean delete(String fileName) {
//        File file = new File(fileName);
//        if (!file.exists()) {
//            return false;
//        } else {
//            if (file.isFile())
//                return deleteFile(fileName);
//            else
//                return deleteDirectory(fileName);
//        }
//    }

//    /**
//     * 删除单个文件
//     *
//     * @param fileName
//     *            要删除的文件的文件名
//     * @return 单个文件删除成功返回true，否则返回false
//     */
//    public static boolean deleteFile(String fileName) {
//        File file = new File(fileName);
//        // 如果文件路径所对应的文件存在，并且是一个文件，则直接删除
//        if (file.exists() && file.isFile()) {
//            if (file.delete()) {
//                return true;
//            } else {
//                return false;
//            }
//        } else {
//            return false;
//        }
//    }

//    public static boolean deleteFileByList(List<String> fileNameList){
//    	boolean deleteSucc = true;
//    	if(null == fileNameList || fileNameList.isEmpty()){
//    		return deleteSucc;
//    	}
//    	for(String str : fileNameList){
//    		deleteSucc = deleteFile(str);
//    		if(!deleteSucc){
//    			break;
//    		}
//    	}
//    	return deleteSucc;
//    }

//    /**
//     * 删除目录及目录下的文件
//     *
//     * @param dir
//     *            要删除的目录的文件路径
//     * @return 目录删除成功返回true，否则返回false
//     */
//    public static boolean deleteDirectory(String dir) {
//        // 如果dir不以文件分隔符结尾，自动添加文件分隔符
//        if (!dir.endsWith(File.separator))
//            dir = dir + File.separator;
//        File dirFile = new File(dir);
//        // 如果dir对应的文件不存在，或者不是一个目录，则退出
//        if ((!dirFile.exists()) || (!dirFile.isDirectory())) {
//            out.println("删除目录失败：" + dir + "不存在！");
//            return false;
//        }
//        boolean flag = true;
//        // 删除文件夹中的所有文件包括子目录
//        File[] files = dirFile.listFiles();
//        for (int i = 0; i < files.length; i++) {
//            // 删除子文件
//            if (files[i].isFile()) {
//                flag = deleteFile(files[i].getAbsolutePath());
//                if (!flag)
//                    break;
//            }
//            // 删除子目录
//            else if (files[i].isDirectory()) {
//                flag = deleteDirectory(files[i].getAbsolutePath());
//                if (!flag)
//                    break;
//            }
//        }
//        if (!flag) {
//            out.println("删除目录失败！");
//            return false;
//        }
//        // 删除当前目录
//        if (dirFile.delete()) {
//            out.println("删除目录" + dir + "成功！");
//            return true;
//        } else {
//            return false;
//        }
//    }

	public static class FileTypeVO {
		private String fileType;
		private String fileFlag;

		FileTypeVO(String fileType, String fileFlag) {
			this.fileType = fileType;
			this.fileFlag = fileFlag;
		}

		public String getFileType() {
			return fileType;
		}

		public void setFileType(String fileType) {
			this.fileType = fileType;
		}

		public String getFileFlag() {
			return fileFlag;
		}

		public void setFileFlag(String fileFlag) {
			this.fileFlag = fileFlag;
		}
	}


	/**
	 * 打包成zip包
	 */
	public static void generateZip(OutputStream out, List<File> files, String zipFileName)  {
		if (null == files || files.isEmpty()) {
			return;
		}
		ZipOutputStream zip = null;
		try {
			byte[] buffer = new byte[1024];
			zip = new ZipOutputStream( out);
			zip.setEncoding("utf-8");

			for (File file : files) {
				String fileName = file.getName();
				if (StringUtils.isNotBlank( zipFileName )){
					fileName = zipFileName;
				}

				BufferedInputStream dataFile = new BufferedInputStream(new FileInputStream(file));
				zip.putNextEntry(new ZipEntry(fileName));
				int len;
				while ((len = dataFile.read(buffer)) != -1) {
					zip.write(buffer, 0, len);
					zip.flush();
				}
				zip.closeEntry();
				dataFile.close();
			}
		} catch (IOException e) {
			BusinessException.throwBiz("json文件打包失败："+ e.getMessage());

		} finally {
			if (zip != null) {
				try {
					zip.close();
				} catch (IOException e) {
					LOG.error(e.toString());
					BusinessException.throwBiz("json文件打包失败"+ e.getMessage());
				}
			}
		}
	}

	/**
	 * 打包成zip包
	 */
	public static void generateZip(OutputStream out, InputStream inputStream, String zipFileName)  {
		ZipOutputStream zip = null;
		BufferedInputStream dataFile = new BufferedInputStream(inputStream);
		try {
			byte[] buffer = new byte[1024];
			zip = new ZipOutputStream( out);
			zip.setEncoding("utf-8");
			zip.putNextEntry(new ZipEntry(zipFileName));
			int len;
			while ((len = dataFile.read(buffer)) != -1) {
				zip.write(buffer, 0, len);
				zip.flush();
			}
			zip.closeEntry();
			inputStream.close();
			dataFile.close();

		} catch (IOException e) {
			BusinessException.throwBiz("json文件打包失败："+ e.getMessage());
		} finally {
			if (zip != null) {
				try {
					zip.close();
					inputStream.close();
					dataFile.close();
				} catch (IOException e) {
					LOG.error(e.toString());
					BusinessException.throwBiz("json文件打包失败"+ e.getMessage());
				}
			}
		}
	}


//	public static void fileToZip( File file)  {
//		FileOutputStream fielOutputStream = null;
//		try {
//			fielOutputStream = new FileOutputStream(file);
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		ZipOutputStream zip = null;
//		try {
//			byte[] buffer = new byte[1024];
//			zip = new ZipOutputStream( fielOutputStream);
//			zip.setEncoding("utf-8");
//
//			BufferedInputStream dataFile = new BufferedInputStream(new FileInputStream(file));
//			zip.putNextEntry(new ZipEntry(file.getName()));
//			int len;
//			while ((len = dataFile.read(buffer)) != -1) {
//				zip.write(buffer, 0, len);
//				zip.flush();
//			}
//			zip.closeEntry();
//			dataFile.close();
//		} catch (IOException e) {
//			BusinessException.throwBiz("json文件打包失败"+ e.getMessage());
//			LOG.error("json文件打包失败");
//
//		} finally {
//			if (zip != null) {
//				try {
//					zip.close();
//				} catch (IOException e) {
//					BusinessException.throwBiz("json文件打包失败"+ e.getMessage());
//					LOG.error("json文件打包失败");
//				}
//			}
//		}
//	}

    public static List<File> getFileByList(List<String> fileNameList) {
    	List<File> files = new ArrayList<>();
    	if (null == fileNameList || fileNameList.isEmpty()) {
			return files;
		}
    	for (String fileName : fileNameList) {
    		File file = new File(fileName);

    		if (file.exists() && file.isFile()) {
    			files.add(file);
			}
		}

    	return files;
    }

	public static File getJsonFile(String path){
		File file = new File(path);
		if (!file.exists() || !file.isFile()) {
			BusinessException.throwBiz("文件不存在。");
		}
		return file;
	}

}
