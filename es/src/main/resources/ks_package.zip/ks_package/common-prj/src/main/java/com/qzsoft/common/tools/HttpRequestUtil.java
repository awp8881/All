package com.qzsoft.common.tools;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.jdialects.springsrc.utils.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author pjh
 * @Title: HttpRequestUtil
 * @Description: TODO
 * @date 2018/12/17 22:00
 */
public class HttpRequestUtil {

    private static Logger log = LoggerFactory.getLogger(HttpRequestUtil.class);

    private static CloseableHttpClient httpclient;;


    public static RequestConfig getRequestConfig(Integer connectTimeout) {
        if (ObjectUtils.isEmpty( connectTimeout)){
            connectTimeout = 5000;
        }
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout( connectTimeout ).setConnectionRequestTimeout(5000).build();
        return requestConfig;
    }


    static {
        try {
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                    return true;
                }
            }).build();
            //创建httpClient
            httpclient = HttpClients.custom().setSSLContext(sslContext).
                    setSSLHostnameVerifier(new NoopHostnameVerifier()).setMaxConnTotal(600).setMaxConnPerRoute(600).build();
        } catch (Exception e) {
            log.error( e.getMessage(), e );
        }

    }

    public static CloseableHttpClient getNoVerifyHttpsHttpClient( ) {

        return httpclient;
    }

    /**
     * 发送HttpGet请求
     * @param url
     * @return
     */
    public static String sendGet(String url,Integer connectTimeout) {

        HttpGet httpget = new HttpGet(url);
        httpget.setConfig( getRequestConfig( connectTimeout ) );
        CloseableHttpResponse response = null;
        String result = null;
        try {
            response = httpclient.execute(httpget);
            if (response.getStatusLine().getStatusCode() == 404){
                BusinessException.throwBiz("接口请求失败：服务宕机或未启动，地址："+url);
            }
            try {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    result = EntityUtils.toString(entity, "utf-8");
                }
            } catch (ParseException | IOException e) {
                BusinessException.throwBiz("接口异常："+e.getMessage());

            } finally {
                try {
                    response.close();
                } catch (IOException e) {
                    BusinessException.throwBiz("接口异常："+e.getMessage());
                }
            }
        } catch (Exception e) {
            BusinessException.throwBiz("接口异常："+e.getMessage());

        } finally {
            httpget.releaseConnection();
        }
        return result;
    }

    /**
     * 发送HttpPost请求，参数为map
     * @param url
     * @param map
     * @return
     */
    public static String sendPost(String url, Map<String, String> map, Integer connectTimeout) {
        List<NameValuePair> formparams = new ArrayList<NameValuePair>();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            formparams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
        }
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams, Consts.UTF_8);
        HttpPost httppost = new HttpPost(url);
        httppost.setConfig( getRequestConfig( connectTimeout ) );
        httppost.setEntity(entity);
        CloseableHttpResponse response = null;
        String result = null;
        try {
            response = httpclient.execute(httppost);
            if (response.getStatusLine().getStatusCode() == 404){
                BusinessException.throwBiz("接口请求失败：服务宕机或未启动，地址："+url);
            }
            HttpEntity entity1 = response.getEntity();
            try {
                result = EntityUtils.toString(entity1, "utf-8");
            } catch (ParseException | IOException e) {
                log.error(e.getMessage(),e);
                BusinessException.throwBiz("接口异常："+e.getMessage());
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            BusinessException.throwBiz("接口异常："+e.getMessage());

        } finally {
            httppost.releaseConnection();
            return result;
        }
    }

    public static String sendPostBody(String url, Map<String, Object> map, Integer connectTimeout) {
        String jsonStr = JSON.toJSONString(map);
        HttpPost httpPost = new HttpPost(url);
        httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
        httpPost.setConfig( getRequestConfig( connectTimeout ) );

        CloseableHttpResponse response = null;
        String result = null;
        try {
            StringEntity se = new StringEntity(jsonStr);
            se.setContentType("text/json");
            httpPost.setEntity(se);

            response = httpclient.execute(httpPost);
            if (response.getStatusLine().getStatusCode() == 404){
                BusinessException.throwBiz("接口请求失败：服务宕机或未启动，地址："+url);
            }
            HttpEntity entity1 = response.getEntity();
            try {
                result = EntityUtils.toString(entity1, "utf-8");
            } catch (ParseException | IOException e) {
                log.error(e.getMessage(),e);
                BusinessException.throwBiz("接口异常："+e.getMessage());
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            BusinessException.throwBiz("接口异常："+e.getMessage());

        } finally {
            httpPost.releaseConnection();
            return result;
        }
    }

    /**
     * 发送HttpPost请求，参数为map
     * @param url
     * @param params
     * @return
     */
    public static String sendPost(String url, Map<String, Object> params, Map<String, String> headers, Integer connectTimeout, boolean isAppJson) {
        HttpPost httppost = new HttpPost(url);
        httppost.setConfig( getRequestConfig( connectTimeout ) );
        if (null != headers){
            headers.forEach((key, value) -> {
                httppost.setHeader(key, value);
            });
        }
        if( isAppJson ){
            httppost.addHeader("Content-Type", "application/json;charset=utf-8"); //添加请求头
            StringEntity entity = new StringEntity(JSON.toJSONString(params), "UTF-8");
            entity.setContentEncoding("UTF-8");
            httppost.setEntity(entity);
        }else{
            List<NameValuePair> formparams = new ArrayList<NameValuePair>();
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                formparams.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }
            UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams, Consts.UTF_8);
            httppost.setEntity(entity);
        }
        CloseableHttpResponse response = null;
        String result = null;
        try {
            response = httpclient.execute(httppost);
            if (response.getStatusLine().getStatusCode() == 404){
                BusinessException.throwBiz("接口请求失败：服务宕机或未启动，地址："+url);
            }
            HttpEntity entity1 = response.getEntity();
            try {
                result = EntityUtils.toString(entity1, "utf-8");
            } catch (ParseException | IOException e) {
                log.error(e.getMessage(),e);
                BusinessException.throwBiz("接口异常："+e.getMessage());
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            BusinessException.throwBiz("接口异常："+e.getMessage());

        } finally {
            httppost.releaseConnection();
            return result;
        }
    }

//    public static void main(String[] args) {
//
//        //{"package":"unitauto.test","class":"TestUtil","method":"divide","methodArgs":[{"type":"long","value":1},{"type":"long","value":2}],"static":true}
//        String str = "{\"package\":\"unitauto.test\",\"class\":\"TestUtil\",\"method\":\"divide\",\"methodArgs\":[{\"type\":\"long\",\"value\":1},{\"type\":\"long\",\"value\":2}],\"static\":true}";
//        JSONObject jsonObject = JSONObject.parseObject(str);
//        String s = HttpRequestUtil.sendPost("http://apijson.cn:8080/method/invoke", jsonObject, 8000, true);
//        System.out.println( "****"+s );
//        Map<String, Object> map = Maps.newHashMap();
//        map.put("username","admin");
//        map.put("password","AXyidp99LP+3+YHX02sJzx4zXGRSmj/NFeST+ASiw6w7miIGp8UBRpA9sO9GpX1z32CU2Y74OnoecjywX1D25/sW0D0t+qXOGH7CpZaRczenjbN4gD1FIhI4o6Ui59Aipv/hBZ0D4SZ8Ye9tIkXkV1k9hpNNPSdENQft2qhq7rM=");
//        s = HttpRequestUtil.sendPost("https://192.168.2.226:20200/tu-prj/userLoginJson", map, 8000, false);
//        System.out.println( s );
//    }

    /**
     * 发送不带参数的HttpPost请求
     * @param url
     * @return
     */
    public static String sendPost(String url,Integer connectTimeout) {
        String result = null;
        HttpPost httppost = new HttpPost(url);
        httppost.setConfig( getRequestConfig( connectTimeout ) );
        CloseableHttpResponse response = null;
        try {
            response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            try {
                result = EntityUtils.toString(entity, "utf-8");
            } catch (ParseException | IOException e) {
                log.error(e.getMessage(), e);
            }
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        } finally {
            httppost.releaseConnection();
        }
        return result;
    }

    public static Map<String, Object> getResult(String value, String url){
        if (StringUtils.isBlank(value)){
            BusinessException.throwBiz(url+"接口请求异常：服务宕机或未启动");
            return Maps.newHashMap();
        }
        Map<String, Object> resultMap = JSON.parseObject( value );
        String status = StringUtil.toString(resultMap.get("status"));
        if ("false".equals( status)){
            BusinessException.throwBiz(StringUtil.toString(resultMap.get("error")));
        }
        return resultMap;
    }
}
