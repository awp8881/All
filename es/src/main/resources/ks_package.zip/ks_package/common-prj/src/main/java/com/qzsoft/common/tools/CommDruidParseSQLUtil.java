package com.qzsoft.common.tools;

import com.alibaba.druid.sql.SQLUtils;
import com.alibaba.druid.sql.ast.SQLStatement;
import com.alibaba.druid.sql.ast.statement.*;
import com.alibaba.druid.sql.parser.ParserException;
import com.alibaba.druid.sql.parser.SQLParserUtils;
import com.alibaba.druid.sql.parser.SQLStatementParser;
import com.alibaba.druid.sql.visitor.SQLASTOutputVisitor;
import com.alibaba.druid.sql.visitor.SchemaStatVisitor;
import com.alibaba.druid.stat.TableStat;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.jdialects.springsrc.utils.Assert;
import org.apache.commons.lang3.StringUtils;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *  使用Parser解析生成AST（抽象语法树），SQLStatement就是AST
 *  使用visitor来访问AST
 *  visitor获取相关数据
 *
 * @Author zf
 * @Description druide sql解析
 * @Date 2019/6/11
 */
public class CommDruidParseSQLUtil {

    /**
     * sql解析ast抽象语法树
     * @param sql
     * @return
     */
    public static  SQLStatement parseSqlStatement( String sql ){
        String dbType = DbEx.getDataSource();
//        String dbType = JdbcConstants.SQL_SERVER;//测试用
        SQLStatementParser parser = SQLParserUtils.createSQLStatementParser(sql, dbType);
        List<SQLStatement> sqlStatements = null;

        try {
            sqlStatements = parser.parseStatementList();

        }catch (ParserException e){
            BusinessException.throwBiz("SQ语法错误："+e.getMessage());
        }
        if (null == sqlStatements || sqlStatements.isEmpty()){
            BusinessException.throwBiz("sql语法错误");
        }
        if (sqlStatements.size() > 1){
            BusinessException.throwBiz("sql不支持的语法类型，仅支持单条sql");
        }
        return sqlStatements.get(0);
    }


    /**
     * 操作的所有表
     * @param sql
     * @return
     */
    public static Set<String> parseFromTables(String sql ){
        String dbType = DbEx.getDataSource();
//        String dbType = JdbcConstants.SQL_SERVER;//测试用
        SQLStatement sqlStatement = parseSqlStatement( sql );
        SchemaStatVisitor statVisitor = SQLUtils.createSchemaStatVisitor(dbType);
        sqlStatement.accept(statVisitor);

        Map<TableStat.Name, TableStat> tableMaps = statVisitor.getTables();
        if (null == tableMaps){
           return Sets.newHashSet();
        }
        Set<String> tables = Sets.newHashSet();
        Iterator<Map.Entry<TableStat.Name, TableStat>> iter = tableMaps.entrySet().iterator();
        while ( iter.hasNext() ){
            Map.Entry<TableStat.Name, TableStat> entry = iter.next();
            String name = StringUtil.toString (entry.getKey());
            tables.add( name );
        }
        return tables;
    }

    /**
     * sql相关数据
     * @param sql
     * @return
     */
    public static Map<String, Object> parseSQLDatas( String sql ){
        Map<String, Object> map = Maps.newHashMap();
        SQLStatement sqlStatement = parseSqlStatement( sql );

        if (sqlStatement instanceof SQLSelectStatement){
            map.put("sqlType", OperateEnum.SELECT.getType());
            SQLSelectStatement sqlSelectStatement = (SQLSelectStatement)sqlStatement;
            parseSelectSql(sqlSelectStatement, map);

        }else if (sqlStatement instanceof SQLInsertStatement){
            map.put("sqlType", OperateEnum.INSERT.getType());
            SQLInsertStatement sqlInsertStatement = (SQLInsertStatement)sqlStatement;
            parseInsertSql(sqlInsertStatement, map);

        }else if (sqlStatement instanceof SQLUpdateStatement){
            map.put("sqlType", OperateEnum.UPDATE.getType());
            SQLUpdateStatement sqlUpdateStatement = (SQLUpdateStatement)sqlStatement;
            parseUpdateSql(sqlUpdateStatement, map);

        }else if (sqlStatement instanceof SQLDeleteStatement){
            map.put("sqlType", OperateEnum.DELETE.getType());
            SQLDeleteStatement sqlDeleteStatement =  (SQLDeleteStatement)sqlStatement;
            parseDeleteSql(sqlDeleteStatement, map);

        }else {
            BusinessException.throwBiz("sql语法错误");
        }
        return map;
    }

    /**
     * 查询select
     * @param sqlSelectStatement
     * @param map
     */
    private static void parseSelectSql(SQLSelectStatement sqlSelectStatement, Map<String, Object> map){
         String dbType = DbEx.getDataSource();
//        String dbType = JdbcConstants.SQL_SERVER; //测试用
        SQLSelect sqlSelect = sqlSelectStatement.getSelect();
        SQLSelectQuery sqlSelectQuery = sqlSelect.getQuery() ;

        if (sqlSelectQuery instanceof SQLSelectQueryBlock){// 非union的查询语句
            SQLSelectQueryBlock sqlSelectQueryBlock = (SQLSelectQueryBlock)sqlSelectQuery;

            List<String> columns = getColumns( sqlSelectQueryBlock );
            map.put("columns", columns);

            SQLTableSource tableSource = sqlSelectQueryBlock.getFrom();//表关联
            map.put("tableSource", StringUtil.toString(tableSource));

//            SQLBinaryOpExpr sqlExpr = (SQLBinaryOpExpr)sqlSelectQueryBlock.getWhere();


        } else if (sqlSelectQuery instanceof SQLUnionQuery) {//union的查询语句

        }

    }

    public static List<String> getColumns(SQLSelectQueryBlock sqlSelectQueryBlock) {
        String dbType = DbEx.getDataSource();
        List<SQLSelectItem> selectItems = sqlSelectQueryBlock.getSelectList();//字段
        List<String> columns = Lists.newArrayList();
        for (SQLSelectItem selectItem : selectItems) {
            StringBuffer column = new StringBuffer() ;
            SQLASTOutputVisitor statVisitor = SQLUtils.createOutputVisitor(column, dbType);
            selectItem.accept(statVisitor);
            columns.add(column.toString());
        }
        return columns;
    }

    public static Map<String,String> getAlias2Columns(SQLSelectQueryBlock sqlSelectQueryBlock) {
        Map<String,String> aliasColumns = Maps.newHashMap();
        List<SQLSelectItem> selectItems = sqlSelectQueryBlock.getSelectList();//字段
        for (SQLSelectItem selectItem : selectItems) {
            String fieldName = selectItem.getExpr().toString();
            String alias = selectItem.getAlias();
            if( StringUtils.isBlank(alias) ){
                alias = fieldName;
            }
            aliasColumns.put( alias, fieldName );
        }
        return aliasColumns;
    }
    public static Map<String,String> getColumns2Alias(SQLSelectQueryBlock sqlSelectQueryBlock) {
        Map<String,String> aliasColumns = Maps.newHashMap();
        List<SQLSelectItem> selectItems = sqlSelectQueryBlock.getSelectList();//字段
        for (SQLSelectItem selectItem : selectItems) {
            String fieldName = selectItem.getExpr().toString();
            String alias = selectItem.getAlias();
            if( StringUtils.isBlank(alias) ){
                alias = fieldName;
            }
            aliasColumns.put( fieldName, alias );
        }
        return aliasColumns;
    }

    /**
     * 插入insert
     * @param sqlInsertStatement
     * @param map
     */
    private static void parseInsertSql(SQLInsertStatement sqlInsertStatement, Map<String, Object> map){

    }

    /**
     * 更新update
     * @param sqlUpdateStatement
     * @param map
     */
    private static void parseUpdateSql(SQLUpdateStatement sqlUpdateStatement, Map<String, Object> map){

    }

    /**
     * 删除delete
     * @param sqlDeleteStatement
     * @param map
     */
    private static void parseDeleteSql(SQLDeleteStatement sqlDeleteStatement, Map<String, Object> map){

    }


    /**
     * 获取动态sql的列名 排除通配符列  仅能用于select语法分析
     * @param sql
     * @return
     */
    public static Set<String> findColumsAndExcludeWildcardColum(String sql){

        Set<String> columSet = Sets.newHashSet();
        SQLStatement sqlStatement = parseSqlStatement(sql);
        Assert.isTrue( sqlStatement instanceof SQLSelectStatement, "只支持查询sql分析" );
        SQLSelectStatement selectStatement = (SQLSelectStatement) sqlStatement;
        List<SQLSelectItem> selectList = ((SQLSelectQueryBlock) selectStatement.getSelect().getQuery()).getSelectList();
        for( int i=0;i<selectList.size();i++ ){
            SQLSelectItem selectItem = selectList.get(i);
            String colName = getColumnsAlias( selectItem, i );
            if( StringUtils.isNotBlank(colName) && !colName.equals("*") ){
                columSet.add( colName );
            }
        }
        return columSet;
    }


    /**
     *  将可执行的动态sql别名化
     * @param sql
     * @param aliesPrefix
     * @return
     */
    public static String transDynSql2AliesSql(String sql,String aliesPrefix) {
        SQLStatement sqlStatement = parseSqlStatement( sql );
        Assert.isTrue( sqlStatement instanceof SQLSelectStatement, "只支持查询sql分析" );
        SQLSelectStatement selectStatement = (SQLSelectStatement) sqlStatement;
        SQLSelectQueryBlock sqlSelectQueryBlock = (SQLSelectQueryBlock) selectStatement.getSelect().getQuery();
        resetColumnsAlias( sqlSelectQueryBlock, aliesPrefix );
        return sqlStatement.toString();
    }


    /**
     * 将别名列设置为表名.字段名
     * @param sqlSelectQueryBlock
     * @param table
     */
    private static void resetColumnsAlias(SQLSelectQueryBlock sqlSelectQueryBlock,String table) {
        List<SQLSelectItem> selectItems = sqlSelectQueryBlock.getSelectList();//字段
        for( int i=0;i<selectItems.size();i++ ){
            SQLSelectItem selectItem = selectItems.get(i);
            String colName = getColumnsAlias(selectItem, i);
            colName = table+"."+colName;
            colName = "\""+colName+"\"";
            selectItem.setAlias( colName );
        }
    }

    /**
     *
     * @param idx  SQLSelectItem在sql的位置
     * @param selectItem
     * @return
     */
    private static String getColumnsAlias(SQLSelectItem selectItem, int idx) {
        String alias = selectItem.getAlias();
        String expr = selectItem.getExpr().toString();
        String colName="";
        if( StringUtils.isBlank( alias ) ){
            if( !expr.contains("(") ){
                colName = expr;
                if( colName.contains(".") ){
                    colName = colName.split("\\.")[1];
                }
            }else{
                colName="idx_" + idx;
            }
        }else{
            colName = alias;
        }
        return colName;
    }

    public static String parserSqlFirstTableName( String sql ) {
        SQLStatement sqlStatement = parseSqlStatement( sql );
        Assert.isTrue( sqlStatement instanceof SQLSelectStatement, "只支持查询sql分析" );
        SchemaStatVisitor statVisitor = SQLUtils.createSchemaStatVisitor( DbEx.getDataSource() );
        sqlStatement.accept(statVisitor);
        Map<TableStat.Name, TableStat> tables = statVisitor.getTables();
        String table = tables.keySet().toArray()[0].toString();
        return table;
    }
}

enum OperateEnum {

    SELECT(1, "select", "查询"),
    UPDATE(2, "update", "更新"),
    INSERT(3, "insert", "增加"),
    DELETE(4, "delete", "删除"),
    ;
    public int number;
    public String type;
    public String description;

    OperateEnum(int number, String type, String description) {
        this.number = number;
        this.type = type;
        this.description = description;
    }
    public int getNumber() {
        return number;
    }
    public String getType() {
        return type;
    }
    public String getDescription() {
        return description;
    }
}

