package com.qzsoft.common.mvc.aspect;
import com.qzsoft.common.annotation.CheckIdempotency;
import com.qzsoft.common.exception.BusinessException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.CodeSignature;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisStringCommands;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.types.Expiration;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Aspect
@Component
public class CheckIdempotencyAop {

    @Autowired
    RedisTemplate redisTemplate;


    @Pointcut("@annotation(com.qzsoft.common.annotation.CheckIdempotency)")
    private void method() {
    }

    @Around(value = "method()")
    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
        Signature signature = pjp.getSignature();
        MethodSignature methodSignature = (MethodSignature) signature;
        Method targetMethod = methodSignature.getMethod();
        CheckIdempotency checkIdempotency = targetMethod.getAnnotation(CheckIdempotency.class);
        String model = checkIdempotency.model();
        int timeOut = checkIdempotency.timeOut();
        String ex = checkIdempotency.ex();
        Object[] values = pjp.getArgs();
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < values.length; i++) {
            stringBuffer.append(values[i]);
        }
        boolean success = setNx(stringBuffer+model,"java",timeOut,TimeUnit.SECONDS);
        if(!success){
            throw BusinessException.buildBiz(ex);
        }
        pjp.proceed(values);
        if(checkIdempotency.delLock())
        redisTemplate.delete(stringBuffer+model);
        return true;
    }

    @AfterThrowing(value = "method()", throwing="throwinfo")
     public void afterThrowing(JoinPoint pjp, Throwable  throwinfo) {
        Signature signature = pjp.getSignature();
        MethodSignature methodSignature = (MethodSignature) signature;
        Method targetMethod = methodSignature.getMethod();
        CheckIdempotency checkIdempotency = targetMethod.getAnnotation(CheckIdempotency.class);
        String model = checkIdempotency.model();
        String ex = checkIdempotency.ex();
        Object[] values = pjp.getArgs();
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < values.length; i++) {
            stringBuffer.append(values[i]);
        }
        if(!ex.equals(throwinfo.getMessage()))
            //如果程序逻辑报错，则删除锁。 如果错误信息是自定义的幂等性提示信息，说明出现了幂等性问题（多并发，或多次请求）则不删除锁。
        redisTemplate.delete(stringBuffer+model);
     }

    private boolean setNx(String key, String value, long expires, TimeUnit timeUnit) {
        boolean flag = false;
        try {
            flag = (boolean) redisTemplate.execute((RedisCallback<Boolean>) connection -> connection.set(key.getBytes(), value.getBytes(), Expiration.from(expires, timeUnit), RedisStringCommands.SetOption.ifAbsent()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}
