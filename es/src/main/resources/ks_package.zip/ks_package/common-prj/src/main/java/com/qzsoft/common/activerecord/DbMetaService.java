package com.qzsoft.common.activerecord;


import com.jfinal.plugin.activerecord.Record;

import java.util.List;
import java.util.Set;

public interface DbMetaService {

    /**
     *
     * @param dsNames 数据源列表
     * @param tableName
     * @return  指定表的元数据
     */
    List<Record> getColMetaByTableName(Set<String> dsNames, String tableName);

    /**
     * 获取表所属数据源
     * @param dsNames
     * @param tableName
     * @param readOrWrite
     * @return 返回表的所属数据源
     */
    String getDataSourceNameByTableName(Set<String> dsNames, String tableName, String readOrWrite);

    /**
     *
     * @param dsNames
     * @return  返回多数据源的所有表结构
     */
    List<Record> geTableMetaRecordListFromMasterDbMetas(Set<String> dsNames);

    /**
     *
     * @param dsNames
     * @return 返回多数据源的所有列结构
     */
    List<Record> getColMetaRecordListFromMasterDbMetas(Set<String> dsNames);

    /**
     * 将列元数据放入redis
     * @param colMetaRecordList
     */
    void loadFieldMappingFromMeta(List<Record> colMetaRecordList);

    /**
     * oracle场景下的别名
     * @param originalSQLField
     * @return
     */
    String getAliasSqlField(String originalSQLField);

    /**
     * 一般用于oracle数据库
     * @param originalSQLField
     * @return
     */
    String getCorrectSqlField(String originalSQLField);

    /**
     * 一般用于oracle数据库
     * @param alias
     * @return
     */
    String aliasToReal(String alias);

    /**
     * 一般用于oracle数据库
     * @param realName
     * @return
     */
    String realToAlias(String realName);

    /**
     * 一般用于oracle数据库
     * @param realTablePointFieldName
     * @return
     */
    String correctRealTableField(String realTablePointFieldName);
}
