package com.qzsoft.common.config;

import com.qzsoft.common.log.OptLogService;
import com.qzsoft.common.log.OptLogServiceImpl;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author pjh
 * @Title: BeanConfig
 * @Description: TODO
 * @date 2018/11/7 14:38
 */

@Configuration
public class BeanConfig {


    @Bean
    @ConditionalOnMissingBean(OptLogService.class)
    public OptLogService getOptLogService(){

        return new OptLogServiceImpl();
    }


}
