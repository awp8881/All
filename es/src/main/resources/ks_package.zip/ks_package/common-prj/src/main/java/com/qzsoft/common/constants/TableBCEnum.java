package com.qzsoft.common.constants;

/**
 * bc表
 * @author zf
 *
 */
public enum TableBCEnum {
	a,b,c;
}
