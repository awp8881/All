package com.qzsoft.common.annotation;

import java.lang.annotation.*;

@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface LogicFnAnn {

	String desc() default "";
	
	String parasDesc() default "";

	boolean isDynamicParas() default false;
	
}