package com.qzsoft.common.constants;

public enum OptTypeEnum {

    SELECT(1, "select", "查询"),
    UPDATE(2, "update", "更新"),
    INSERT(3, "insert", "增加"),
    DELETE(4, "delete", "删除"),
    NONE(5, "none", "无任何操作"),
    ;

    public int number;
    public String type;
    public String description;

    OptTypeEnum(int number, String type, String description) {
        this.number = number;
        this.type = type;
        this.description = description;
    }
}