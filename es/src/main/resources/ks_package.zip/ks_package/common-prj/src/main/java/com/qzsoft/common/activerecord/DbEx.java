package com.qzsoft.common.activerecord;

import com.alibaba.druid.util.JdbcConstants;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.jfinal.plugin.activerecord.*;
import com.jfinal.plugin.activerecord.dialect.Dialect;
import com.jfinal.plugin.activerecord.dialect.MysqlDialect;
import com.jfinal.plugin.activerecord.dialect.OracleDialect;
import com.jfinal.plugin.activerecord.dialect.SqlServerDialect;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.log.OptLogService;
import com.qzsoft.common.log.OptLogServiceImpl;
import com.qzsoft.common.tools.*;
import com.qzsoft.common.vo.KsUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author pjh
 * @Title: DbEx
 * @Description: 扩展jfinal的Db工具类，实现特殊sql的替换
 * @date 2018/7/12 10:27
 */
@Slf4j
public class DbEx extends Db {

    public static final String defaultDbConfigName = "__ks_config__";

    public static final String USER_INFO = "ksUserInfo";

    private static DbMetaService dbMetaService;
    /**
     * 修改后的表名
     */
    private static ThreadLocal<String> dnySqlTable = new ThreadLocal<>();
    //动态sql字段缩短取别名时的前缀
    private static String DNY_SQL_ALIAS_PRE = "kds_";

    private static final String errorMsg = "表: %s ->>>> 错误信息%s";

//    private static final Pattern asSqlPattern = Pattern.compile("(.{1,})\\s{1,}as\\s{1,}['\"]\\1['\"]",Pattern.CASE_INSENSITIVE);
    private static final Pattern asSqlPattern = Pattern.compile("([a-zA-Z0-9_.()\u4e00-\u9fa5]{1,})\\s{1,}as\\s{1,}\"([a-zA-Z0-9_.\u4e00-\u9fa5]{1,})\"",Pattern.CASE_INSENSITIVE);

    private static final Pattern keyWordEqSqlPattern = Pattern.compile("\\s{1,}\\S{1,}\\s*=",Pattern.CASE_INSENSITIVE);

    public static final Pattern isContainGroupBy = Pattern.compile("\\s{1,}group\\s{1,}by\\s{1,}[\\sa-zA-Z0-9_.\u4e00-\u9fa5,()`'\\\"]{1,}$",Pattern.CASE_INSENSITIVE);

    private static OptLogService logService;
    
    static List<String> filter = new ArrayList<>();
    
    static {
        filter.add("/ks-prj/dic/refreshDicdListToCache");
    }

    //系统初始化时要先执行
    public static void setDbMetaService(DbMetaService dbMetaService) {
        DbEx.dbMetaService = dbMetaService;
    }

    public static void initOptLogService(){
        List<String> configNameList = new ArrayList<>();
        Set<Map.Entry<String, Config>> configSet = DbKit.getConfigSet();
        for( Map.Entry<String, Config> config :  configSet ){
            configNameList.add( config.getKey() );
        }
        SqlManager.initSpecialSqlMapping( configNameList );
        OptLogService bean = SpringUtil.getBean(OptLogService.class);
        if( null!=bean ){
            logService = bean;
        }else{
            logService = new OptLogServiceImpl();
        }
    }

    /**
     * 清除线程变量
     */
    public static void cleanDnyTable( ){
        dnySqlTable.remove();
    }

    /**
     *获取别名字段
     * @param originalSQLField  表名.字段名
     * @return
     */
    public static String getAliasSqlField( String originalSQLField ){

        return dbMetaService.getAliasSqlField(originalSQLField);
    }
//
//
    /**
     *
     * @param originalSQLField  表名.字段名
     * @return oracle可能存在关键字  需要加上引号
     */
    public static String getCorrectSqlField( String originalSQLField ){
        return dbMetaService.getCorrectSqlField( originalSQLField );
    }




    private static DbPro useDb( String tableName ){
        //多数据源部分  目前没用
        if( StringUtils.isBlank( tableName ) ){
            return Db.use( DbEx.defaultDbConfigName );
        }else{
            DbPro use;
            try{
                String dataSourceName = DataSourceHolder.getDataSourceNameByTableName(tableName);
                use = Db.use(dataSourceName);
            }catch (Exception e){
                use = Db.use( DbEx.defaultDbConfigName );
                log.error(e.getMessage(), e);
            }
            return use;
        }
    }


    /**
     * 通过别名获取真实字段
     * @param aliasField
     * @return
     */
    public static String getRealFieldByAliasField( String aliasField ){
//        String realField =  aliasToRealMapping.get(aliasField);
        String realField = dbMetaService.aliasToReal( aliasField );
        if( null==realField ){
//            realField = aliasToRealMapping.get(aliasField.toLowerCase());
            realField = dbMetaService.aliasToReal(aliasField.toLowerCase());
        }
        //如果是空 考虑自定义sql
        if( null==realField &&  aliasField.startsWith( DNY_SQL_ALIAS_PRE )){
            return dnySqlTable.get()+"."+aliasField.replace(DNY_SQL_ALIAS_PRE,"");
        }
        return realField;
    }

    public static List<Record> find(String sql) {
        sql = SqlManager.handleSpecialSql( sql );
        if( isOracle() ){//如果是oracle缩短sql
            sql = transformShortenSqlAndKey( sql );
        }
        String tableName = getTableNameBySelectSql( sql );
        return useDb(tableName).find(sql);
    }

    /**
     * oracle查询字段长度限制，需要缩短列
     * @param sql
     * @return
     */
    private static String transformShortenSqlAndKey(String sql) {
        if( StringUtils.isBlank( sql ) ){
            return sql;
        }
        Set<String> aliasDefinSet = new HashSet<>();
        Matcher matcher = asSqlPattern.matcher( sql );
        while (matcher.find()) {
            String group = matcher.group();
            aliasDefinSet.add( group.trim() );
        }
        //创建别名映射sql
        Map<String,String> aliasSqlMapping = createAliasSqlMapping( aliasDefinSet );
        for( String aliasDefin : aliasDefinSet ){
            sql = sql.replace( aliasDefin, aliasSqlMapping.get( aliasDefin ));
        }

        return sql;
    }

    /**
     * 创建别名参数映射
     * @param aliasDefinSet
     * @return
     */
    private static Map<String, String> createAliasSqlMapping(Set<String> aliasDefinSet) {
        Map<String, String> aliasSqlMapping = new HashMap<>();
        StringBuffer aliasSqlBuff = new StringBuffer();
        //判断是否是自定义sql
        boolean isCustomizeSql = false;
        for( String aliasDefin : aliasDefinSet ){
            String[] split = aliasDefin.split("( as )|( AS )|( As )|( aS )");
            String fieldName = split[1].trim();
            if( fieldName.contains( CommonConstants.DYN_SQL_TABLE ) ){
                isCustomizeSql = true;
            }
        }
        for( String aliasDefin : aliasDefinSet ){
            aliasSqlBuff.setLength(0);
            String alias = "";
            String realName = aliasDefin.split(" ")[0];
            //如果是自定义sql
            if( isCustomizeSql ){
                //aliasDefin的格式  ks_dic_b.val AS "ks_dyn_s_484307836064.order_type"
                String[] split = aliasDefin.split("( as )|( AS )|( As )|( aS )");
                if (split.length!=2) {
                    log.error("字段别名解析{}出错",aliasDefin);
                    BusinessException.throwBiz("oracle没有找到字段别名，联系管理员");
                }
                String totalAlias = split[1].trim();
                dnySqlTable.set(totalAlias.split("\\.")[0]);
                alias = "\""+ totalAlias.split("\\.")[1].trim();
                //目的是为了缩短表名，动态sql的表太长了，此处添加了标识，查询结果后进行替换
                alias = DNY_SQL_ALIAS_PRE+alias.replace("\"","");
                realName = aliasDefin.split(" ")[0].trim();
            }else{
                alias = dbMetaService.realToAlias(realName);
                if ( null == alias ) {
                    alias = dbMetaService.realToAlias(realName.toLowerCase());
                }
                realName = dbMetaService.correctRealTableField( realName );
            }
            if( StringUtils.isBlank(alias) ){
                log.error("oracle没有找到字段别名{}",alias);
                BusinessException.throwBiz("oracle没有找到字段别名，联系管理员");
            }

            aliasSqlBuff.append(realName);
            aliasSqlBuff.append(" AS \"").append(alias).append("\" ");
            aliasSqlMapping.put( aliasDefin, aliasSqlBuff.toString());
        }
        return aliasSqlMapping;
    }



    /**
     * 通过表名获取列的元数据，首先会从缓存中取
     * @param tableName
     * @return
     */
    public static List<Record> getColMetaByTableName( String tableName ){
        List<Record> colMeta = DataSourceHolder.getColMetaByTableName(tableName);
        if( null==colMeta || colMeta.isEmpty() ){
            BusinessException.throwBiz("未发现表:"+tableName+"配置");
//            return  DbEx.find("show full COLUMNS from " +tableName);
        }
        return colMeta;
    }

    public static List<Record> find(String sql, Object... paras) {
        sql = SqlManager.handleSpecialSql( sql );
        if( isOracle() ){//如果是oracle缩短sql
            sql = transformShortenSqlAndKey( sql );
        }
        List<Record> records = null;
        try {
            String tableName = getTableNameBySelectSql(sql);
            records = useDb(tableName).find(sql, paras);
        } catch (Exception e) {
            String[] split = sql.toLowerCase().split(" from ");
            handleException( split.length>1?split[1]:split[0], e, paras );
        }
        return records;
    }


    public static List<Record> getByColumnList(String tableName, String column, List values) {
        if (StringUtils.isBlank(tableName) || StringUtils.isBlank(column)
                || null == values || values.isEmpty()){
            return null;
        }
        String inSql = CustomDbRecordUtil.getInSql(column, values);
        String sql = "select * from "+tableName+" where 1=1 "+inSql;
        List<Record> recordList = DbEx.find(sql, values.toArray());
        return recordList;
    }

    /**
     * 检查局部内存变量里是否有值以及是否为true,true说明是只读
     * @return
     */
    private static void checkIsReadOnly(){
        KsUserInfo userInfo = ThreadLocalUtil.get(USER_INFO);
        // userInfo == null不会执行第二个方法
        if (userInfo == null ? false : CommonConstants.PAGE_NUM.equals(userInfo.getUser_type())
                && !UrlMatchUtil.checkPath(filter,userInfo.getRequestURI())){
            BusinessException.throwBiz("当前用户为只读用户");
        }
    }

    public static boolean save(String tableName, String primaryKey, Record record) {
        // 检查只读用户
        checkIsReadOnly();
        if( isRemoveIdPram() ){
            record.remove("id");
        }
        setMainKeyIfNeedForSave(tableName, record );
        logService.recordInsertChange( tableName, getFixSizeList( 1 )  , Lists.newArrayList( record ) );
        updateKeyWord( record );
        boolean save = false;
        try {
            save = useDb( tableName ).save(tableName, primaryKey, record);
        } catch (Exception e) {
            handleException(tableName, e, record);
        }

        return save;
    }

    public static boolean save(String tableName, Record record) {
        // 检查只读用户
        checkIsReadOnly();
        if( isRemoveIdPram() ){
            record.remove("id");
        }
        setMainKeyIfNeedForSave(tableName, record );
        logService.recordInsertChange( tableName, getFixSizeList( 1 ) , Lists.newArrayList( record ) );
        updateKeyWord( record );
        boolean save = false;
        try {
            save = useDb( tableName ).save(tableName, record);
        } catch (Exception e) {
            handleException(tableName, e, record);
        }

        return save;
    }

    public static boolean saveUseOldId(String tableName, Record record) {
        // 检查只读用户
        checkIsReadOnly();
        if( record.get( CommonConstants.IDCOLUMN )==null || StringUtils.isBlank(record.get( CommonConstants.IDCOLUMN  ).toString()) ){
            record.set( CommonConstants.IDCOLUMN.toLowerCase(), UIDGenerator.getUID()  );
        }
        logService.recordInsertChange( tableName, getFixSizeList( 1 ) , Lists.newArrayList( record ) );
        updateKeyWord( record );
        boolean save = false;
        try {
            save = useDb( tableName ).save(tableName, record);
        } catch (Exception e) {
            handleException(tableName, e, record);
        }

        return save;
    }

    private static void setMainKeyIfNeedForSave(String tableName, Record record) {
//        if( record.get( CommonConstants.IDCOLUMN )==null || StringUtils.isBlank(record.get( CommonConstants.IDCOLUMN  ).toString()) ){
//            record.set( CommonConstants.IDCOLUMN.toLowerCase(), UIDGenerator.getUID()  );
//        }

        record.set( CommonConstants.IDCOLUMN.toLowerCase(), UIDGenerator.getUID()  );
    }

    public static int[] batchSave(String tableName, List<Record> recordList, int batchSize) {
        // 检查只读用户
        checkIsReadOnly();
        for( Record record : recordList ){
            if( isRemoveIdPram() ) {
                record.remove("id");
            }
            setMainKeyIfNeedForSave( tableName, record );
        }
        alignOfColumn(recordList);
        logService.recordInsertChange( tableName, getFixSizeList( recordList.size() ) , recordList );
        //更新关键字
       updateKeyWords( recordList );
        int[] ints = new int[0];
        try {
            ints = useDb( tableName ).batchSave(tableName, recordList, batchSize);
        } catch (Exception e) {
            handleException(tableName, e, recordList);
        }
        return ints;
    }

    public static int[] batchSaveUseOldId(String tableName, List<Record> recordList, int batchSize) {
        // 检查只读用户
        checkIsReadOnly();
        for( Record record : recordList ){
            if(  record.get("id")==null || StringUtils.isBlank( record.get("id").toString() )  ) {
                record.set( CommonConstants.IDCOLUMN.toLowerCase(), UIDGenerator.getUID()  );
            }
        }
        alignOfColumn(recordList);
        logService.recordInsertChange( tableName, getFixSizeList( recordList.size() ) , recordList );
        //更新关键字
        updateKeyWords( recordList );
        int[] ints = new int[0];
        try {
            ints = useDb( tableName ).batchSave(tableName, recordList, batchSize);
        } catch (Exception e) {
            handleException(tableName, e, recordList);
        }
        return ints;
    }

    public static int[] batchAdd(String tableName, List<Record> recordList, int batchSize) {
        // 检查只读用户
        checkIsReadOnly();
        alignOfColumn(recordList);
        logService.recordInsertChange( tableName, getFixSizeList( recordList.size() ) , recordList );
        //更新关键字
        updateKeyWords( recordList );
        int[] ints = new int[0];
        try {
            ints = useDb( tableName ).batchSave(tableName, recordList, batchSize);
        } catch (Exception e) {
            handleException(tableName, e, recordList);
        }
        return ints;
    }

    public static void handleException(String tableName, Exception e,Object objData) {
        log.info(e.getMessage(),e);
        String message = e.getMessage();
        log.error("表{} error{},操作数据是{}", tableName, e.getMessage(), objData);
        BusinessException.throwBiz(String.format(errorMsg, tableName, message));
    }

    private static void updateKeyWords(List<Record> recordList) {
        if( !isOracle() ){
            return ;
        }
        if( null==recordList ){
            return ;
        }
        for( Record record : recordList ){
            updateKeyWord(record );
        }
    }

    private static void updateKeyWord(Record record) {
        // 检查只读用户
        checkIsReadOnly();
        if( null==record || !isOracle() ){
            return;
        }
        Set<String> keyWordsSet = OracleKeyWord.getKeyWordsSet();
        Map<String, Object> columns = record.getColumns();
        Record transKeyRecord = new Record();
        Iterator<Map.Entry<String, Object>> iterator = columns.entrySet().iterator();
        while ( iterator.hasNext() ){
            Map.Entry<String, Object> next = iterator.next();
            String key = next.getKey();
            Object value = next.getValue();
            if( keyWordsSet.contains( key.toUpperCase() ) && !"ID".equals( key.toUpperCase() ) ){
                key = "\""+key.toUpperCase()+"\"";
            }
            transKeyRecord.set( key, value );
        }
        //将transKeyRecord更新到record
        record.clear();
        record.setColumns( transKeyRecord.getColumns() );

    }

    /**
     *对齐Record中的列
     * @param recordList
     */
    public static void alignOfColumn(List<Record> recordList){
		if(null == recordList || recordList.isEmpty()){
			return;
		}
		Set<String> cols = new HashSet<>();
		for( Record record : recordList ){
			cols.addAll( Arrays.asList( record.getColumnNames() ) );
		}
		Record record = recordList.get(0);
		List<String> asList = Arrays.asList( record.getColumnNames() );
		for( String col : cols ){
			if( !asList.contains( col ) ){
				record.set( col , null);
			}
		}
	}

    /**
     *
     * @param tableName
     * @param column  条件列
     * @param list
     * @return
     */
    public static Boolean batchDelete(String tableName, String column, List list) {
        // 检查只读用户
        checkIsReadOnly();
        if (StringUtils.isBlank( tableName) || StringUtils.isBlank( column)
                || null == list || list.isEmpty()){
            return false;
        }
        StringBuffer sb = new StringBuffer("");
        sb.append(" and ").append(column).append(" in(");
        for(int i = 0, length = list.size();i < length;i++){
            sb.append("?");
            if(i != list.size()-1){
                sb.append(",");
            }
        }
        sb.append(")");
        String sql = "delete from "+tableName+" where 1=1 ";
        sql += sb.toString();
        logService.recordDelChange( sql );
        try {
            DbEx.delete(sql, list.toArray());
        } catch (Exception e) {
            handleException( tableName, e, list );
        }
        return true;
    }

    public static Boolean batchDeleteByIds(String tableName, List<Object> ids) {
        // 检查只读用户
        checkIsReadOnly();
        if(StringUtils.isNotBlank(tableName) && null != ids && !ids.isEmpty() ){
            StringBuffer sb=new StringBuffer("");
            sb.append(" and id").append(" in(");
            for(int i=0;i < ids.size();i++){
                sb.append("?");
                if(i != ids.size()-1){
                    sb.append(",");
                }
            }
            sb.append(")");
            String sql="delete from "+tableName+" where 1=1 ";
            sql+=sb.toString();
            logService.recordDelChange( sql );
            try {
                DbEx.delete(sql, ids.toArray());
            } catch (Exception e) {
                handleException( tableName, e, ids );
            }
        }
        return true;
    }

    public static Boolean batchDelete(String tableName, List<Record> beyondRecords) {
        // 检查只读用户
        checkIsReadOnly();

        if( StringUtils.isBlank(tableName) || beyondRecords==null || beyondRecords.isEmpty() ){
            log.error("删除参数错误:{}   {}", tableName, beyondRecords);
            return false;
        }
        //list可能过多  拆小
        List<List<Record>> recordPartition = Lists.partition(beyondRecords, 100);
        for (List<Record> recordList : recordPartition) {
            List<Object> ids = beyondRecords.stream().filter(record -> {
                return StringUtils.isNotBlank( StringUtil.toString(record.get("id"))) || StringUtils.isNotBlank( StringUtil.toString(record.get("ID")));
            } ).map(record -> record.get("id")).collect(Collectors.toList());
            if( ids.isEmpty() ){
                ids = beyondRecords.stream().filter(record -> {
                    return StringUtils.isNotBlank( StringUtil.toString(record.get("id"))) || StringUtils.isNotBlank( StringUtil.toString(record.get("ID")));
                } ).map(record -> record.get("ID")).collect(Collectors.toList());
            }
            Assert.notEmpty( ids, "未找到主键列" + recordList.get(0).getColumns()  );
            batchDeleteByIds( tableName, ids );
        }
        return true;
    }


    //是否移除Id参数   对于sqlserver 在组件自增长情况下需要移除Id参数
    private static boolean isRemoveIdPram(){
//        Dialect dialect = DbKit.getConfig().getDialect();
//        return dialect instanceof SqlServerDialect ;
        return true;
    }

    public static boolean isOracle(){
        Dialect dialect = DbKit.getConfig().getDialect();
        return dialect instanceof OracleDialect;
    }


    public static boolean isMysql(){
        Dialect dialect = DbKit.getConfig().getDialect();
        return dialect instanceof MysqlDialect;
    }


    public static boolean isSqlserver(){
        Dialect dialect = DbKit.getConfig().getDialect();
        return dialect instanceof SqlServerDialect;
    }
    public static boolean isOracle( String dataSourceName ){
        Dialect dialect = DbKit.getConfig(dataSourceName).getDialect();
        return dialect instanceof OracleDialect;
    }


    public static boolean isMysql( String dataSourceName ){
        Dialect dialect = DbKit.getConfig(dataSourceName).getDialect();
        return dialect instanceof MysqlDialect;
    }


    public static boolean isSqlserver( String dataSourceName ){
        Dialect dialect = DbKit.getConfig(dataSourceName).getDialect();
        return dialect instanceof SqlServerDialect;
    }



    public static int delete(String sql, Object... paras) {
        // 检查只读用户
        checkIsReadOnly();
        sql = SqlManager.handleSpecialSql( sql );
        sql = keyWordEqCondHandle( sql );
        logService.recordDelChange( sql, paras );
        int delete = 0;
        try {
            String sqlTmp = sql.toLowerCase().split(" from ")[1].trim();
            delete = useDb( sqlTmp.split(" ")[0].trim() ).delete(sql, paras);
        } catch (Exception e) {
            handleException( sql, e, paras );
        }
        return delete;
    }

    public static int delete(String sql) {
        // 检查只读用户
        checkIsReadOnly();
        sql = SqlManager.handleSpecialSql( sql );
        //oracle替换关键字
        sql = keyWordEqCondHandle( sql );
        logService.recordDelChange( sql );
        int delete = 0;
        try {
            String tableName = "";
            if( sql.toLowerCase().contains( " from " ) ){
                tableName = sql.toLowerCase().split(" from ")[1].trim().split(" ")[0].trim();
            }else{
                //处理"truncate table aaa"
                tableName = sql.toLowerCase().split(" table ")[1].trim();
            }
            delete = useDb( tableName ).delete(sql);
        } catch (Exception e) {
            handleException( sql, e, "" );
        }
        return delete;
    }

    public static boolean deleteById(String tableName, Object idValue) {
        // 检查只读用户
        checkIsReadOnly();
        return useDb(tableName).deleteById(tableName, idValue);
    }

    public static boolean deleteById(String tableName, String primaryKey, Object... idValue) {
        // 检查只读用户
        checkIsReadOnly();
        return useDb(tableName).deleteById(tableName, primaryKey, idValue);
    }

    /**
     * 处理关键字等于条件处理
     * where sort = xxx  =====>  where "sort" =
     * update table set sort = xxx   =====>  update table set "sort" = xxx
     * @param sql
     * @return
     */
    private static String keyWordEqCondHandle(String sql) {

        if( !isOracle() ){
            return sql;
        }
        Set<String> keyWordEqDefinSet = new HashSet<>();
        Matcher matcher = keyWordEqSqlPattern.matcher( sql );
        while (matcher.find()) {
            String group = matcher.group();
            if( group.contains("\"") ){
                continue;
            }
            keyWordEqDefinSet.add( group );
        }
        //创建别名映射sql
        Map<String,String> keyWordSqlMapping = createKeyWordSqlMapping( keyWordEqDefinSet );
        for( String keyWordEq : keyWordEqDefinSet ){
            sql = sql.replace( keyWordEq, keyWordSqlMapping.get( keyWordEq ));
        }
        return sql;
    }

    private static Map<String, String> createKeyWordSqlMapping(Set<String> keyWordEqDefinSet) {

        Map<String, String> keyWordSqlMapping = new HashMap<>();
        if( null==keyWordEqDefinSet ){
            return keyWordSqlMapping;
        }
        Set<String> keyWordsSet = OracleKeyWord.getKeyWordsSet();
        for( String keyWordEq : keyWordEqDefinSet ){
            //如果包含关键字 将关键字加引号
            String keyWordEqReplace = getKeyWordReplaceSql( keyWordEq, keyWordsSet );
            keyWordSqlMapping.put( keyWordEq, keyWordEqReplace );
        }
        return keyWordSqlMapping;
    }

    /**
     *如果包含关键字 将关键字加引号
     * @param keyWordEq  abc.a=;  abc = ;
     * @param keyWordsSet
     * @return
     */
    private static String getKeyWordReplaceSql(String keyWordEq, Set<String> keyWordsSet) {

        String noEq = keyWordEq.replace("=","");
        noEq = noEq.trim();
        if( keyWordEq.contains(".") ){
            String field = noEq.split("\\.")[1].toUpperCase();
            if( keyWordsSet.contains( field ) ){
                String keyWordEqNew = " "+noEq.split("\\.")[0]+".\""+field+"\" =";
                return keyWordEqNew;
            }
        }else{
            String field = noEq.toUpperCase();
            if( keyWordsSet.contains( field ) ){
                String keyWordEqNew = " \""+field+"\" =";
                return keyWordEqNew;
            }
        }

        return keyWordEq;
    }


    public static int[] batchUpdate(String tableName, List<Record> recordList, int batchSize) {
        // 检查只读用户
        checkIsReadOnly();

        updateKeyWords(recordList);
        int[] ints = null;
        try {
            ints=useDb( tableName ).batchUpdate(tableName, recordList, batchSize);
        } catch (Exception e) {
            handleException(tableName, e, recordList);
        }
        return ints;
    }

    public static boolean update(String tableName, Record record) {
        // 检查只读用户
        checkIsReadOnly();

        updateKeyWord(record);
        boolean update = false;
        try {
            update = useDb( tableName ).update(tableName, record);
        } catch (Exception e) {
            handleException(tableName, e, record);
        }
        return update;
    }

    public static int update(String sql, Object... paras) {
        // 检查只读用户
        checkIsReadOnly();

        sql = SqlManager.handleSpecialSql( sql );
        sql = keyWordEqCondHandle( sql );
        String tableName=null;
        List<Record> befourRecordList=null;
        List<Record> afterRecordList=null;
        try{ tableName = logService.getTableNameByUpdateSql( sql,paras );
            befourRecordList = logService.getBefourRecordListByUpdateSql(sql,paras);
        }catch ( Exception e ){
            e.printStackTrace();
            log.error(e.getMessage(),e);
        }
        int update = 0;
        try {
            update = useDb( tableName ).update(sql, paras);
        } catch (Exception e) {
            handleException(tableName, e, sql);
        }
        try{
            afterRecordList = logService.getBefourRecordListByUpdateSql(sql,paras);
            logService.recordUpdateChange( tableName,befourRecordList, afterRecordList );
        }catch ( Exception e ){
            e.printStackTrace();
            log.error(e.getMessage(),e);
        }
        return update;
    }

    public static int update(String sql) {
        // 检查只读用户
        checkIsReadOnly();

        sql = SqlManager.handleSpecialSql( sql );
        sql = keyWordEqCondHandle( sql );
        String tableName=null;
        List<Record> befourRecordList=null;
        List<Record> afterRecordList=null;
        try{ tableName = logService.getTableNameByUpdateSql( sql );
           befourRecordList = logService.getBefourRecordListByUpdateSql(sql);
        }catch ( Exception e ){
            e.printStackTrace();
            log.error(e.getMessage(),e);
        }

        int update = 0;
        try {
            update = useDb( tableName ).update(sql);
        } catch (Exception e) {
            handleException(tableName, e, sql);
        }

        try{
            afterRecordList = logService.getBefourRecordListByUpdateSql(sql);
            logService.recordUpdateChange( tableName,befourRecordList, afterRecordList );
        }catch ( Exception e ){
            e.printStackTrace();
            log.error(e.getMessage(),e);
        }
        return update;

    }

    public static Page<Record> paginate(int pageNumber, int pageSize, String select, String sqlExceptSelect, Object... paras) {
        boolean isGroupBySql = false;
        if( StringUtils.isNotBlank( sqlExceptSelect ) ){
            isGroupBySql = isContainGroupBy.matcher( sqlExceptSelect ).find();
        }
        select = SqlManager.handleSpecialSql( select );
        sqlExceptSelect = SqlManager.handleSpecialSql( sqlExceptSelect );
        if( isOracle() ){//如果是oracle缩短sql
            select = transformShortenSqlAndKey( select );
            sqlExceptSelect = transformShortenSqlAndKey( sqlExceptSelect );
        }
        Page<Record> paginate = null;
        try {
            String tableName = CommDruidParseSQLUtil.parserSqlFirstTableName( "select *  "+ sqlExceptSelect);//sqlExceptSelect.trim().split("from ")[1].trim().split(" ")[0].trim();
            paginate = useDb( tableName ).paginate(pageNumber, pageSize, isGroupBySql,select, sqlExceptSelect, paras);
        } catch (Exception e) {
           handleException( sqlExceptSelect, e, paras );
        }
        return paginate;
    }


    public static Page<Record> paginate(int pageNumber, int pageSize, boolean isGroupBySql, String select, String sqlExceptSelect, Object... paras) {
        if( StringUtils.isNotBlank( sqlExceptSelect ) ){
            isGroupBySql = isContainGroupBy.matcher( sqlExceptSelect ).find();
        }
        select = SqlManager.handleSpecialSql( select );
        sqlExceptSelect = SqlManager.handleSpecialSql( sqlExceptSelect );
        if( isOracle() ){//如果是oracle缩短sql
            select = transformShortenSqlAndKey( select );
//            if( aliasDefinSet.isEmpty() ){  //如果为空  考虑是自定义sql
//                sql = sql.replaceAll(CommonConstants.DYN_SQL_TABLE+"_\\d{1,}\\.","");
//            }
            select = select.replaceAll(CommonConstants.DYN_SQL_TABLE+"_\\d{1,}\\.",DNY_SQL_ALIAS_PRE);
            sqlExceptSelect = transformShortenSqlAndKey( sqlExceptSelect );
            sqlExceptSelect = sqlExceptSelect.replaceAll(CommonConstants.DYN_SQL_TABLE+"_\\d{1,}\\.",DNY_SQL_ALIAS_PRE);
        }
        Page<Record> paginate = null;
        try {
            String tableName = CommDruidParseSQLUtil.parserSqlFirstTableName( "select *  "+ sqlExceptSelect);//sqlExceptSelect.trim().split("from ")[1].trim().split(" ")[0].trim();
            paginate = useDb( tableName ).paginate(pageNumber, pageSize, isGroupBySql, select, sqlExceptSelect, paras);
        } catch (Exception e) {
            handleException( sqlExceptSelect, e, paras );
        }
        return paginate;
    }

    public static Page<Record> paginate(int pageNumber, int pageSize, String select, String sqlExceptSelect) {
        boolean isGroupBySql = false;
        if( StringUtils.isNotBlank( sqlExceptSelect ) ){
            isGroupBySql = isContainGroupBy.matcher( sqlExceptSelect ).find();
        }
        select = SqlManager.handleSpecialSql( select );
        sqlExceptSelect = SqlManager.handleSpecialSql( sqlExceptSelect );
        if( isOracle() ){//如果是oracle缩短sql
            select = transformShortenSqlAndKey( select );
            sqlExceptSelect = transformShortenSqlAndKey( sqlExceptSelect );
        }
        Page<Record> paginate = null;
        try {
            String tableName = CommDruidParseSQLUtil.parserSqlFirstTableName( "select * "+ sqlExceptSelect);//sqlExceptSelect.trim().split("from ")[1].trim().split(" ")[0].trim();
            paginate = useDb( tableName ).paginate(pageNumber, pageSize,isGroupBySql, select, sqlExceptSelect);
        } catch (Exception e) {
            handleException( sqlExceptSelect, e, "" );
        }
        return paginate;
    }

    protected static class Holder {
        // "order\\s+by\\s+[^,\\s]+(\\s+asc|\\s+desc)?(\\s*,\\s*[^,\\s]+(\\s+asc|\\s+desc)?)*";
        private static final Pattern ORDER_BY_PATTERN = Pattern.compile(
                "order\\s+by\\s+[^,\\s]+(\\s+asc|\\s+desc)?(\\s*,\\s*[^,\\s]+(\\s+asc|\\s+desc)?)*",
                Pattern.CASE_INSENSITIVE | Pattern.MULTILINE);
    }

    /**
     * 通过find来实现分页查询，不用jfinal提供的分页
     * 主要是程序员手写sql的调用
     * 暂时没有实现oracle的列表查询，因为没有做字段缩短处理
     * @param pageNumber
     * @param pageSize
     * @param sql
     * @return
     */
    public static Page<Record> paginateQz(String assignSource,int pageNumber, int pageSize, String sql, Object[] paraObj ) {

        if( StringUtils.isBlank(assignSource) ){
            BusinessException.throwBiz("数据源不能为空");
        }
        if (DbKit.getConfig().getDialect() instanceof OracleDialect) {
            log.warn("不能保证oracle执行正确 除非字段满足条件：sql为{}" , sql);
        }
        if( pageNumber<=0 ){
            pageNumber = 1;
        }
        if( pageSize<0 ){
            BusinessException.throwBiz("分页大小必须大于0");
        }
        //查询条数
        String tempSql = Holder.ORDER_BY_PATTERN.matcher(sql).replaceAll("");
        StringBuilder totleSqlBuilder = new StringBuilder( );
        totleSqlBuilder.append("select count(1) as ct from (").append( tempSql ).append(")xxxx");
        List<Record> totleRecords;
        if( paraObj==null ){
            totleRecords = Db.use(assignSource).find(totleSqlBuilder.toString());
        }else{
            totleRecords= Db.use(assignSource).find(totleSqlBuilder.toString(), paraObj);
        }
        log.info("解析统计条数sql为：{}  {}", totleSqlBuilder, paraObj);
        if( totleRecords.size()==0 ){
            return new Page<Record>(new ArrayList<Record>(0), pageNumber, pageSize, 0, 0);
        }
        Record record = totleRecords.get(0);
        int totalRow = record.getInt("ct");
        if( totalRow==0 ){
            return new Page<Record>(new ArrayList<Record>(0), pageNumber, pageSize, 0, 0);
        }
        //查询列表
        int start = (pageNumber - 1) * pageSize;
        int end = pageNumber * pageSize;
        //如果是mysql
        Dialect dialect = DbKit.getConfig(assignSource).getDialect();
        String paginateSqlBuilder = "";
        if ( dialect instanceof SqlServerDialect){
            StringBuilder ret = new StringBuilder();
            ret.append("SELECT * FROM ( SELECT row_number() over (order by tempcolumn) temprownumber, * FROM ");
            ret.append(" ( SELECT TOP ").append(end).append(" tempcolumn=0,");
            ret.append(sql.toString().replaceFirst("(?i)select", ""));
            ret.append(")vip)mvp where temprownumber>").append(start);
            paginateSqlBuilder = ret.toString();

        }else if(dialect instanceof OracleDialect){
            String paginateSqlBuilderTmpl = "SELECT * FROM ( SELECT TMP.*, ROWNUM ROW_ID FROM ( %s ) TMP WHERE ROWNUM <=%s) WHERE ROW_ID > %s ";
            paginateSqlBuilder = String.format( paginateSqlBuilderTmpl, sql,end,start);
        }else{
            String paginateSqlBuilderTmpl = "%s limit %s ,%s";
            paginateSqlBuilder = String.format( paginateSqlBuilderTmpl, sql,start,pageSize);
        }
        log.info("解析查询sql为：{}  {}", paginateSqlBuilder, paraObj);
        List<Record> records = Db.use(assignSource).find(paginateSqlBuilder.toString(), paraObj);
        int totalPage = (int) (totalRow / pageSize);
        if (totalRow % pageSize != 0) {
            totalPage++;
        }
        Page<Record> paginate = new Page<>(records,pageNumber,pageSize,totalPage,totalRow);
        return paginate;
    }

    public static Record findById(String tableName, Object idValue) {
        return useDb( tableName ).findById(tableName, idValue);
    }

    public static Record findById(String tableName, String primaryKey, Object... idValue) {
        return useDb( tableName ).findById(tableName, primaryKey, idValue);
    }

    public static List<Record> findByIds(String tableName, List<String> idValue ) {
        StringBuffer sql = new StringBuffer("select * from ");
        sql.append(tableName).append(" where 1=1 and id ").append( " in(" );
        sql.append(Joiner.on(",").join(idValue)).append( " )" );
        return useDb( tableName ).find(sql.toString());
    }

    public static Record findFirst(String sql, Object... paras) {
        sql = SqlManager.handleSpecialSql( sql );
        if( isOracle() ){//如果是oracle缩短sql
            sql = transformShortenSqlAndKey( sql );
        }

        Record first = null;
        try {
            String tableName = getTableNameBySelectSql(sql);
            first = useDb(tableName).findFirst(sql, paras);
//            try{
////                String selectPrefix = StringUtils.substringBefore(sql," from ");
////                String fromSuffix = StringUtils.substringAfter(sql, " from ");
////                Page<Record> paginate = Db.paginate(1, 2, selectPrefix, "from " + fromSuffix, paras);
////                if( !paginate.getList().isEmpty() ){
////                    first = paginate.getList().get(0);
////                    first.remove( "tempcolumn" );
////                    first.remove( "temprownumber" );
////                    first.remove( "rownum_" );
////                }
//                first = useDb(tableName).findFirst(sql, paras);

//            }catch (Throwable t){
//                log.error(t.getMessage());
//            }

        } catch (Exception e) {
            String[] split = sql.toLowerCase().split(" from ");
            handleException( split.length>1?split[1]:split[0] , e, paras );
        }
        return first;
    }



    public static Record findFirst(String sql) {
        sql = SqlManager.handleSpecialSql( sql );
        if( isOracle() ){//如果是oracle缩短sql
            sql = transformShortenSqlAndKey( sql );
        }
        Record first = null;
        try {
            String tableName = getTableNameBySelectSql(sql);
            first = useDb(tableName).findFirst(sql);
//            try{
//                String selectPrefix = StringUtils.substringBefore(sql," from ");
//                String fromSuffix = StringUtils.substringAfter(sql, " from ");
//                Page<Record> paginate = Db.paginate(1, 2, selectPrefix, "from " + fromSuffix);
//                if( !paginate.getList().isEmpty() ){
//                    first = paginate.getList().get(0);
//                    first.remove( "tempcolumn" );
//                    first.remove( "temprownumber" );
//                }
//                first = useDb(tableName).findFirst(sql);
//
//            }catch (Throwable t){
//                log.error(t.getMessage());
//            }

        } catch (Exception e) {
            String[] split = sql.toLowerCase().split(" from ");
            handleException( split.length>1?split[1]:split[0] , e, "" );
        }
        return first;
    }

    public static List<Record> selectByAppendInCond(String tableName, String columnName, ArrayList params) {
        if (StringUtils.isBlank(tableName)) {
            throw new BusinessException("表名不能为空。");
        }
        StringBuffer sql = new StringBuffer();
        sql.append("select * from " + tableName).append( " where 1=1 " );

        return selectByAppendInCond( sql.toString(), Lists.newArrayList(),columnName, params );
    }

    public static List<Record> selectByAppendInCond(String haveWhereSql, ArrayList whereParams , String columnName, ArrayList params) {
        if( whereParams == null ||  whereParams.isEmpty() ){
            whereParams = Lists.newArrayList( );
        }
        StringBuffer sql = new StringBuffer(haveWhereSql);
        if ( StringUtils.isBlank( columnName ) || ObjectUtils.isEmpty(params)) {
            if (whereParams.isEmpty()) {
                return DbEx.find( sql.toString() );
            }else{
                return DbEx.find(sql.toString(), whereParams.toArray());
            }
        }
        sql.append(" and ").append(columnName).append( " in(" );
        List<String> placeholder = Lists.newArrayList();
        for (Object param : params) {
            placeholder.add( "?" );
        }
        sql.append(Joiner.on(",").join(placeholder)).append( " )" );
        whereParams.addAll(params);
        return DbEx.find(sql.toString(), whereParams.toArray());
    }

    /**
     *
     * @param tablesName 表名
     * @param k1   列名
     * @param v1   列值
     * @param orderSqlPart  排序片段
     * @return
     */
    public static List<Record> selectRecord(String tablesName,List<String> cols,String k1,Object v1,String orderSqlPart ){
        return selectRecord(tablesName,cols,k1,v1,null,null,orderSqlPart);
    }

    /**
     *
     * @param tablesName 表名
     * @param k1   列名
     * @param v1   列值
     * @param orderSqlPart  排序片段
     * @return
     */
    public static List<Record> selectRecord(String tablesName,List<String> cols,String k1,Object v1,String k2,Object v2,String orderSqlPart ){
        return selectRecord(tablesName,cols,k1,v1,k2,v2,null,null,orderSqlPart);
    }

    /**
     *
     * @param tablesName 表名
     * @param k1   列名
     * @param v1   列值
     * @param orderSqlPart  排序片段
     * @return
     */
    public static List<Record> selectRecord(String tablesName,List<String> cols,String k1,Object v1,String k2,Object v2,String k3,Object v3,String orderSqlPart ){
        StringBuilder sqlBuilder = new StringBuilder();
        List<Object> params = Lists.newArrayList();
        buildSqlRel(tablesName, cols,k1, v1, k2, v2, k3, v3, sqlBuilder, params,orderSqlPart);
        if( params.isEmpty() ){
            return find(sqlBuilder.toString());
        }else{
            return find(sqlBuilder.toString(),params.toArray());
        }
    }

    /**
     *
     * @param tablesName 表名
     * @param k1   列名
     * @param v1   列值
     * @param orderSqlPart  排序片段 比如 order by id desc
     * @return
     */
    public static Record selectFristRecord(String tablesName,List<String> cols,String k1,Object v1,String orderSqlPart ){
        return selectFristRecord(tablesName,cols,k1,v1,null,null,orderSqlPart);
    }

    /**
     *
     * @param tablesName 表名
     * @param k1   列名
     * @param v1   列值
     * @param orderSqlPart  排序片段
     * @return
     */
    public static Record selectFristRecord(String tablesName,List<String> cols,String k1,Object v1,String k2,Object v2,String orderSqlPart ){
        return selectFristRecord(tablesName,cols,k1,v1,k2,v2,null,null,orderSqlPart);
    }

    /**
     *
     * @param tablesName 表名
     * @param k1   列名
     * @param v1   列值
     * @param orderSqlPart  排序片段
     * @return
     */
    public static Record selectFristRecord(String tablesName,List<String> cols,String k1,Object v1,String k2,Object v2,String k3,Object v3,String orderSqlPart ){
        StringBuilder sqlBuilder = new StringBuilder();
        List<Object> params = Lists.newArrayList();
        buildSqlRel(tablesName, cols,k1, v1, k2, v2, k3, v3, sqlBuilder, params, orderSqlPart);
        if( params.isEmpty() ){
            return findFirst(sqlBuilder.toString());
        }else{
            return findFirst(sqlBuilder.toString(),params.toArray());
        }
    }

    private static void buildSqlRel(String tablesName, List<String> cols,String k1, Object v1, String k2, Object v2, String k3, Object v3, StringBuilder sqlBuilder, List<Object> params,String orderSqlPart) {
        sqlBuilder.append("select ");
        if( cols==null || cols.isEmpty() ){
            sqlBuilder.append(" * ");
        }else{
            String colNames = Joiner.on(",").join(cols);
            sqlBuilder.append( colNames );
        }
        sqlBuilder.append( " from " ).append( tablesName ).append( " where 1=1 " );
        if(StringUtils.isNotBlank( k1 )){
            sqlBuilder.append(" and ").append(k1).append("=? ");
            params.add( v1 );
        }
        if(StringUtils.isNotBlank( k2 )){
            sqlBuilder.append(" and ").append(k2).append("=? ");
            params.add( v2 );
        }
        if(StringUtils.isNotBlank( k3 )){
            sqlBuilder.append(" and ").append(k3).append("=? ");
            params.add( v3 );
        }
        if(StringUtils.isNotBlank( orderSqlPart )){
            sqlBuilder.append(orderSqlPart);
        }
    }


    public static String getTableNameBySelectSql(String sql) {
        String[] canExistTableName = sql.toLowerCase().split(" from ");
        String existTableNameSql = "";
        for( int i=1;i<canExistTableName.length;i++ ){
            existTableNameSql = canExistTableName[i].trim();
            if( existTableNameSql.indexOf("(")!=0 ){
                break;
            }
        }
        String tableName = existTableNameSql.split(" ")[0].trim();
        tableName = tableName.replace(",","");
        return tableName;
    }

    public static List<Record> getFixSizeList( int size ){
        List<Record> fixSizeList = new ArrayList<>( size );
        for( int i=0;i<size; i++ ){
            fixSizeList.add( new Record() );
        }
        return fixSizeList;

    }

    public static String getDataSource(){
        Dialect dialect = DbKit.getConfig().getDialect();
        if ( dialect instanceof MysqlDialect){
            return JdbcConstants.MYSQL;

        }else if(dialect instanceof SqlServerDialect){
            return JdbcConstants.SQL_SERVER;

        }else if(dialect instanceof OracleDialect){
            return JdbcConstants.ORACLE;

        }
        return JdbcConstants.MYSQL;
    }

    public static  String getCharTypeByDBType(){
        if( isOracle() ){
            return "varchar2";
        }
        if( isSqlserver() ){
            return "nvarchar";
        }
        if( isMysql() ){
            return "varchar";
        }
        BusinessException.throwBiz("未知数据，不知道字符串类型");
        return "";
    }


    public static boolean updateByVersionAndId(String tableName, Record record) {
        String primaryKey = CommonConstants.IDCOLUMN + "," + CommonConstants.UP_VERSION_COLUMN_NAME;
        return CustomDbRecordUtil.updateByVersion(primaryKey, tableName, record);
    }

}
