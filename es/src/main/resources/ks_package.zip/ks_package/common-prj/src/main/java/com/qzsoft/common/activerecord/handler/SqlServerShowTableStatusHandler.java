package com.qzsoft.common.activerecord.handler;

import com.qzsoft.common.activerecord.AbstractSpecialSqlHandler;

/**
 * @author pjh
 * @Title: SqlServerShowTableStatusHandler
 * @Description: 处理特殊sql  SHOW TABLE STATUS
 * @date 2018/7/12 18:08
 */
public class SqlServerShowTableStatusHandler extends AbstractSpecialSqlHandler {

    private static final String  SEPCIAL_SQL_REGULAR = "(?i)SHOW TABLE STATUS";

    //等价sqlselect * from (SELECT  convert(varchar(100), A.name) AS Name,  convert(varchar(100), C.value)
    // AS Comment FROM sys.tables A LEFT JOIN sys.extended_properties C ON C.major_id = A.object_id AND C.minor_id = 0)a";

    private static final String  EQUIVALENCE_SQL = "select * from (SELECT  convert(varchar, A.name) AS Name,  convert(varchar, C.value) AS Comment FROM sys.tables A LEFT JOIN sys.extended_properties C ON C.major_id = A.object_id AND C.minor_id = 0)a";

    @Override
    public String handlerSQL(String sql) {

        sql = sql.replaceAll( SEPCIAL_SQL_REGULAR,EQUIVALENCE_SQL );

        return sql;
    }
}
