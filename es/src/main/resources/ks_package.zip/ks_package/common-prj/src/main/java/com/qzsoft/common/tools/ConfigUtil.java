package com.qzsoft.common.tools;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlMapFactoryBean;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * @author lihaopeng
 * @date 2015年10月8日
 * @version 1.0.0
 * @description desc
 */
@Component
public class ConfigUtil {


	private static Properties properties;
	private static Properties message;

	@Resource
	private Environment _environment;

	private static Environment environment;

	@PostConstruct
	public void transValues() {
		environment = _environment;
	}

	static{
		try {
			init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void init() throws IOException{
		InputStream inputStream = ConfigUtil.class.getResourceAsStream("/config.properties");
		if(inputStream != null){
			properties = new Properties();
			properties.load(new InputStreamReader(inputStream, "utf-8"));
		}
		
		InputStream inputStream2 = ConfigUtil.class.getResourceAsStream("/message-mapping.properties");
		if(inputStream2 != null){
			message = new Properties();
			message.load(new InputStreamReader(inputStream2, "utf-8"));
		}
		
	}
	
	
	/**
	 * 获取配置文件的值
	 * @param key
	 * @param defaultValue
	 * @return
	 */
	public static String getPropertyValue(String key,String defaultValue){
		String value = getPropertyValue(key);
		if (StringUtils.isBlank(value)) {
			return defaultValue;
		}
		return value;
	}

	/**
	 * 获取配置文件的值
	 * @param key
	 * @param
	 * @return
	 */
	public static String getPropertyValue(String key){
		Object valueObj =  environment.getProperty( key );//properties.get(key);
		if (valueObj == null) {
			return null;
		}
		
		String value = String.valueOf(valueObj);
		
		if (value.trim().equalsIgnoreCase("")) {
			return null;
		}
		
		Pattern p = Pattern.compile("\\$\\{(.*?)\\}");
		Matcher m = p.matcher(valueObj.toString());
		if(!m.find()){
			return value;
		}
		String inner = m.group();
		String innerKey = m.group(1);
		String innerValue = getPropertyValue(innerKey);
		value = value.replace(inner, innerValue);
		return value;
	}
	
	public static String getMessage(Object key, Object...objects){
		if(message == null){
			return null;
		}
		
		Object valueObj = message.get(String.valueOf(key));
		if (valueObj == null) {
			return null;
		}
		
		String value = String.valueOf(valueObj);
		
		if (value.trim().equalsIgnoreCase("")) {
			return null;
		}
		
		for(int i=0; i<objects.length; i++){
			Object obj = objects[i];
			String str = strReplaceDaoToAndAndAnd( String.valueOf(obj) );
			value = value.replaceAll("\\{"+i+"\\}", str );
			value = strReplaceAndAndAndToDao( value );
		}
		
		return value;
	}

	/**
	 * 将$替换成&&&
	 * @param str
	 * @return
	 */
	private static String strReplaceDaoToAndAndAnd(String str){

		return getChangeString(str, "\\$", "&&&");
	}

	/**
	 * 将&&&替换成$
	 * @param str
	 * @return
	 */
	private static String strReplaceAndAndAndToDao(String str){

		return getChangeString(str, "&&&", "$");
	}


	/**
	 * 将str中的original字符串替换成replace
	 * @param str
	 * @param original
	 * @param replace
	 * @return
	 */
	private static String getChangeString(String str, String original, String replace) {
		if( StringUtils.isBlank(str) ){
			return str;
		}
		String[] strArr = str.split( original );
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<strArr.length-1;i++){
			sb = sb.append(strArr[i]).append( replace );
		}
		sb.append(strArr[strArr.length-1]);
		return sb.toString();
	}


}
