package com.qzsoft.common.mvc.aspect;

import com.google.common.collect.Lists;
import com.jfinal.kit.LogKit;
import com.jfinal.plugin.activerecord.ActiveRecordException;
import com.jfinal.plugin.activerecord.NestedTransactionHelpException;
import com.qzsoft.common.activerecord.KsTransactionUtil;
import com.qzsoft.common.annotation.JFinalTx;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * JFinal 事务注解
 * @author zf
 */
@Aspect
@Order(value = -1)
@Component
public class JFinalTxAop {

    /**
     * 自定义JFinal 事务注解
     * value中的意思解释
     * @annotation 表示注解只能支持方法上
     */
    @Pointcut("@annotation(com.qzsoft.common.annotation.JFinalTx)")
    private void method() {
    }

    @Around(value = "method()", argNames = "pjp")
    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
        Object retVal = null;
        //获取所有连接
        List<Connection> connectionList = KsTransactionUtil.getExistConnectionList();

        Signature signature = pjp.getSignature();
        MethodSignature methodSignature = (MethodSignature) signature;
        Method targetMethod = methodSignature.getMethod();
        JFinalTx jFinalTx = targetMethod.getAnnotation(JFinalTx.class);
        // Nested transaction support
        if (!connectionList.isEmpty()) {
            try {
                KsTransactionUtil.updateConnByJFinalTx( jFinalTx );
                retVal = pjp.proceed();
                return retVal;
            } catch (SQLException e) {
                throw new ActiveRecordException(e);
            }
        }

        List<Connection> conns = Lists.newArrayList();
        List<Boolean> autoCommits = Lists.newArrayList();
        try {
            conns = KsTransactionUtil.createConnectionList( jFinalTx );
            autoCommits = KsTransactionUtil.getAutoCommitList( conns );
            //关闭conns自动提交
            KsTransactionUtil.updateAutoCommit( conns, false );
            retVal = pjp.proceed();
            KsTransactionUtil.commitConn( conns );
        } catch (NestedTransactionHelpException e) {
            if ( !conns.isEmpty() ) try {
                KsTransactionUtil.rollbackConn( conns );
            } catch (Exception e1) {
                LogKit.error(e1.getMessage(), e1);
            }
            LogKit.logNothing(e);
        } catch (Throwable t) {
            if (!conns.isEmpty()) try {
                KsTransactionUtil.rollbackConn( conns );
            } catch (Exception e1) {
                LogKit.error(e1.getMessage(), e1);
            }
            throw t instanceof RuntimeException ? (RuntimeException) t : new ActiveRecordException(t);
        } finally {
            try {
                if (!conns.isEmpty()) {
                    KsTransactionUtil.updateAutoCommit( conns, autoCommits );
                    KsTransactionUtil.closeConn( conns );
                }
            } catch (Throwable t) {
                LogKit.error(t.getMessage(), t);
            } finally {
                // prevent memory leak
                KsTransactionUtil.removeConfThreadLocalConn( );
            }
        }
        return retVal;
    }

}
