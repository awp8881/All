package com.qzsoft.common.annotation;

import java.lang.annotation.*;

/**
 * 请求幂等性检查
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface CheckIdempotency {
    //模块描述
    String model() default "";
    //锁失效时间
    int timeOut() default 10;
    //异常信息
    String ex() default "程序正在执行，请勿重复请求";
    //是否手动删除锁
    boolean delLock() default true;
}
