package com.qzsoft.common.ui;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.common.collect.Lists;
import com.qzsoft.common.tools.FieldUtil;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.ConfigUtil;

/**
 *
 * @author lihaopeng
 * @date 2017年9月11日
 * @version 1.0.0
 * @description desc
 */
@Slf4j
@Data
public class RequestResult<T> implements Serializable {

	private static final Pattern tbNameFieldPattern = Pattern.compile("表: ([a-zA-Z0-9_]{1,}).*'([a-zA-Z0-9_]{1,})'",Pattern.CASE_INSENSITIVE);

	private Map<String,Object> exObj; // 数据扩展对象，用于传递额外的值
	private T obj; // 第一条记录
	private List<T> list; // 记录列表
//	private int listSize;
	private long allRow; // 总记录数
	private int totalPage; // 总页数
	private int currentPage; // 当前页
	private int pageSize; // 每页记录数

//	private Boolean isFirstPage; // 是否为第一页
//	private Boolean isLastPage; // 是否为最后一页
//	private Boolean hasPreviousPage; // 是否有前一页
//	private Boolean hasNextPage; // 是否有下一页

//	private String order;
//	private String sort;

//	private int beginPage;
//	private int pageLength;

	private Boolean status = true;
	private String error;
	private String msg = ConfigUtil.getMessage(12001 );//"操作成功";
	private String redirectUrl;
	private Integer code;
	private Throwable throwable;
	private List<Map<String, Object>> prePageDatas;//上一页数据


	public RequestResult() {
	}

	public RequestResult(T obj) {
		this.obj = obj;
	}

	public RequestResult(List<T> list) {
		this.list = list;
//		if (list != null && list.size() > 0) {
//			this.listSize = list.size();
//		}
	}

	public RequestResult(List<T> list, long allRow, int currentPage, int pageSize) {
		this(list);
		this.allRow = allRow;
		this.currentPage = currentPage;
		this.pageSize = pageSize;

//		init();
	}

//	public RequestResult(List<T> list, long allRow, int currentPage, int pageSize, String order, String sort) {
//		this(list, allRow, currentPage, pageSize);
//		if(StringUtils.isNotBlank(order)){
//			this.order = order;
//		}
//		if(StringUtils.isNotBlank(sort)){
//			this.sort = sort;
//		}
//	}

	@Deprecated
	public static <T> RequestResult<T> error(String str) {
		RequestResult<T> requestResult = new RequestResult<T>();
		requestResult.setStatus(false);
		requestResult.setError(str);
		return requestResult;
	}

//	public static <T> RequestResult<T> error(Integer code, String str) {
//		RequestResult<T> requestResult = error(str);
//		requestResult.setCode(code);
//		return requestResult;
//	}

	public static <T> RequestResult<T> error(Throwable t) {
		RequestResult<T> requestResult = new RequestResult<T>();
		requestResult.setStatus(false);
		requestResult.setThrowable(t);
		Integer code = 10000;	//默认code
		String error = t.getMessage();//ConfigUtil.getMessage(code);
		if(t instanceof BusinessException){
			BusinessException be = (BusinessException) t;
			code = be.getCode();
			error = be.getMessage();
		}
		if ( StringUtils.isNotBlank(error) && ( error.contains( "Duplicate" ) ||  error.contains( "插入重复键" ) )  ) {
			error = "存在重复的数据";
		}
		if ( StringUtils.isNotBlank(error) &&  error.contains( "Data truncation:" ) ) {
			final ArrayList<String> tbNameAndField = findTbNameAndField(error);
			if( tbNameAndField.size()==2 ){
				error = FieldUtil.getFieldDesc(tbNameAndField.get(0), tbNameAndField.get(1)) +"数据过长或者不合法，请修改后继续操作";
			}
		}
		if ( StringUtils.isNotBlank(error) && ( error.contains( "Deadlock found when" )  )  ) {
			error = "正在处理该操作，稍后再试";
		}
		requestResult.setError(error);
		requestResult.setCode(code);
		return requestResult;
	}

	public static ArrayList<String> findTbNameAndField(String str ) {
		ArrayList<String> tbNameField = Lists.newArrayList();
		//提取表  字段
		try{
			Matcher matcher = tbNameFieldPattern.matcher( str );
			while (matcher.find()) {
				String tbName = matcher.group(1);
				String fieldName = matcher.group(2);
				tbNameField.add( tbName );
				tbNameField.add( fieldName );
			}
		}catch (Throwable t){
			log.error(t.getMessage(), t);
		}
		return tbNameField;
	}


	public static <T> RequestResult<T> error(Integer code, Throwable t) {
		RequestResult<T> requestResult = error(t);
		requestResult.setError(ConfigUtil.getMessage(code));
		requestResult.setCode(code);
		return requestResult;
	}


//	public void init() {
		// 计算当前页
//		countCurrentPage();
		// 计算总页数
//		countTotalPage();

//		this.isFirstPage = isFirstPage();
//		this.isLastPage = isLastPage();
//		this.hasPreviousPage = isHasPreviousPage();
//		this.hasNextPage = isHasNextPage();
		// p:9 每次显示9 个页码
		// t:20 总数
		// c:2当前页
		// b:1 开始页

		// c:18 12,13,14,15,16,17,18,19,20
		// b:20-9

		// c:5
		// b:0

		// c:6
		// b:1

		// c:16
		// b: 11,12,13
//		if (this.currentPage - 4 <= 0) {
//			this.beginPage = 1;
//		} else if (this.currentPage + 4 >= this.totalPage) {
//			this.beginPage = this.totalPage - 8;// 17 20-8=12
//												// 开始页12，那么12,13，14,15,16,17,18,19,20
//			if (beginPage <= 0) {
//				this.beginPage = 1;
//			}
//		} else {
//			// 18-5 13 13,14,15,16,17,18
//			this.beginPage = currentPage - 4;
//		}
//		this.pageLength = this.totalPage - this.beginPage; // 20-12=8
//		// pagingResult.beginPage+pagingResult.pageLength end pageLength --->end
//		if (this.pageLength >= 8) {
//			this.pageLength = 8;
//		} else if (this.pageLength < 0) {
//			this.pageLength = 0;
//		}
//	}

	public boolean isFirstPage() {
		return currentPage == 1; // 如是当前页是第1页
	}

	public boolean isLastPage() {
		return currentPage == totalPage; // 如果当前页是最后一页
	}

	public boolean isHasPreviousPage() {
		return currentPage != 1; // 只要当前页不是第1页
	}

	public boolean isHasNextPage() {
		return currentPage != totalPage; // 只要当前页不是最后1页
	}

	public void countTotalPage() {
		totalPage = (int) (allRow % pageSize == 0 ? allRow / pageSize : allRow / pageSize + 1);
	}

	public static int countOffset(final int currentPage, final int pageSize) {
		final int offset = (pageSize * (currentPage - 1));
		return offset;
	}

	public void countCurrentPage() {
		currentPage = (currentPage == 0 ? 1 : currentPage);
	}

//	public int getBeginPage() {
//		return beginPage;
//	}
//
//	public void setBeginPage(int beginPage) {
//		this.beginPage = beginPage;
//	}
//
//	public int getPageLength() {
//		return pageLength;
//	}
//
//	public void setPageLength(int pageLength) {
//		this.pageLength = pageLength;
//	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

//	public int getListSize() {
//		return listSize;
//	}
//
//	public void setListSize(int listSize) {
//		this.listSize = listSize;
//	}

	/**
	 * 生成分页查询基本参数maps
	 *
	 * @param currentPage
	 * @param pageSize
	 * @return
	 */
	public static Map<String, Object> getParamsMap(int currentPage, int pageSize) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("startIndex", countOffset(currentPage, pageSize));
		params.put("limitNum", pageSize);
		return params;
	}

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

	public Map<String,Object> getExObj() {
		return exObj;
}

	public RequestResult setExObj(Map<String,Object> exObj) {
		this.exObj = exObj;
		return this;
	}

	/**
	 * 追加扩展对象
	 * @param appendExObj
	 */
	public RequestResult appendExObj(Map<String,Object> appendExObj) {
		if( null==this.exObj ){
			this.exObj = appendExObj;
		}else{
			this.exObj.putAll( appendExObj );
		}
		return this;
	}

	/**
	 * 追加扩展对象
	 * @param key
	 * @param value
	 * @return
	 */
	public RequestResult appendExObj(String key, Object value ) {
		if( null==this.exObj ){
			this.exObj = new HashMap<>();
		}
		this.exObj.put( key, value );
		return this;
	}

}
