package com.qzsoft.common.exception;

import com.qzsoft.common.tools.ConfigUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * ks后台用户模块权限校验异常
 * 为了在全局异常获取异常相应代码
 * @author zhouyou
 * @Title: KsVerifyException
 * @Description: TODO
 * @date 2022/3/31
 */
public class KsVerifyException extends RuntimeException {

    private Integer code;

    @Override
    public String getMessage() {
        return super.getMessage();
    }

    public KsVerifyException() {
        super();
    }

    public KsVerifyException(String message, Throwable cause) {
        super(message, cause);
    }

    public KsVerifyException(String message) {
        super(message);
    }

    public KsVerifyException(Integer code, String message) {
        super(message);
        if(code != null){
            this.code = code;
        }else{
            this.code = 10001;
        }

    }
    public KsVerifyException(int code) {
        super(code+"");
    }

    public static KsVerifyException throwBiz(Integer code, String message ) {

        if(code == null){
            throw new KsVerifyException( message );
        }
        String messageTmp = ConfigUtil.getMessage(code, message);
        if(StringUtils.isBlank( messageTmp )){
            messageTmp = message;
        }
        throw new KsVerifyException( code, messageTmp );
    }

    public static KsVerifyException throwBiz(Integer code ) {
        return throwBiz( code, "" );
    }

    public static KsVerifyException throwBiz(String message ) {
        return throwBiz( null, message);
    }

    public KsVerifyException(Throwable cause) {
        super(cause);
    }

    public Integer getCode(){
        return code;
    }
}
