package com.qzsoft.common.activerecord;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author pjh
 * @Title: TargetDataSource
 * @Description: 数据源注解
 * @date 2018/7/10 16:19
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({
        ElementType.METHOD
})
public @interface TargetDataSource {

    //指定数据源  TODO还未实现  保留，现在是根据表自动去查使用哪个源
    String name() default "default";

    //读写分离时使用读模式还是写模式
    DataSourceHolder.DbModeEnum dbMode() default DataSourceHolder.DbModeEnum.write;
}