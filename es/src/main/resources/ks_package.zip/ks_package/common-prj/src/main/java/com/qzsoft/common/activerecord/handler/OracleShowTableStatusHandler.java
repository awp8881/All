package com.qzsoft.common.activerecord.handler;

import com.qzsoft.common.activerecord.AbstractSpecialSqlHandler;

/**
 * @author pjh
 * @Title: OracleShowTableStatusHandler
 * @Description: 处理特殊sql  SHOW TABLE STATUS
 * @date 2018/7/12 18:08
 */
public class OracleShowTableStatusHandler extends AbstractSpecialSqlHandler {

    private static final String  SEPCIAL_SQL_REGULAR = "(?i)SHOW TABLE STATUS";

    private static final String  EQUIVALENCE_SQL = "select LOWER(TABLE_NAME) AS \"Name\",COMMENTS AS \"Comment\" from user_tab_comments ";

    @Override
    public String handlerSQL(String sql) {

        sql = sql.replaceAll( SEPCIAL_SQL_REGULAR,EQUIVALENCE_SQL );

        return sql;
    }
}
