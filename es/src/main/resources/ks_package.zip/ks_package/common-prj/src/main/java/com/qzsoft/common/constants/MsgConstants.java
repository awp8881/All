package com.qzsoft.common.constants;

import java.util.concurrent.atomic.AtomicBoolean;

/**消息中心配置常量类
 * @author yuanj
 * 2021-12-29
 */
public class MsgConstants {

    /**
     *消息发送渠道配置表
     */
    public static final String TABLE_MSG_B = "ks_msg_channel";

    /**
     *消息模板方案配置表
     */
    public static final String TABLE_MSG_T = "ks_msg_template";

    /**
     *消息操作批次表
     */
    public static final String TABLE_MSG_O = "kb_msg_opt";
    /**
     *消息操作队列表
     */
    public static final String TABLE_MSG_Q = "kb_msg_opt_que";

    /**
     *消息接收表
     */
    public static final String TABLE_MSG_K = "kb_msg_receive";
    /**
     *成功
     */
    public static final String SUCCESS = "成功";

    /**
     *失败
     */
    public static final String LOSE = "失败";

    /**
     * 修改全局变量，告诉子线程是否中断while循环,默认false
     */
    public  static final AtomicBoolean shutdownInProgress = new AtomicBoolean(false);

    /**
     *拆分分割符
     */
    public static final String SPLITSIGN = "|";



}
