package com.qzsoft.common.exception;

import com.qzsoft.common.tools.ConfigUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.helpers.MessageFormatter;

@SuppressWarnings("serial")
public class BusinessException extends RuntimeException {
    private Integer code;

    @Override
    public String getMessage() {
    	return super.getMessage();
    }

    public BusinessException() {
        super();
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public BusinessException(String message) {
        super(message);
    }
    
    public BusinessException(Integer code, String message) {
    	super(message);
    	if(code != null){
    		this.code = code;
    	}else{
    		this.code = 10001;
    	}
    	
    }
    public BusinessException(int code) {
    	super(code+"");
    }

    public static BusinessException throwBiz( Integer code, String message ) {

        if(code == null){
            throw new BusinessException( message );
        }
        String messageTmp = ConfigUtil.getMessage(code, message);
        if(StringUtils.isBlank( messageTmp )){
            messageTmp = message;
        }
        throw new BusinessException( code, messageTmp );
    }

    public static BusinessException throwBiz( Integer code ) {
        return throwBiz( code, "" );
    }

    public static BusinessException throwBiz( String message ) {
        return throwBiz( null, message);
    }

    public static BusinessException throwBiz( String msg, Object... objs ) {
        String message = MessageFormatter.arrayFormat(msg, objs).getMessage();
        throw new BusinessException( message );
    }

    public static BusinessException buildBiz( String message ) {
        return buildBiz( null, message);
    }


    public static BusinessException buildBiz( Integer code ) {
        return throwBiz( code, "" );
    }

    public static BusinessException buildBiz( Integer code, String message ) {

        if(code == null){
            return new BusinessException( message );
        }
        String messageTmp = ConfigUtil.getMessage(code, message);
        if(StringUtils.isBlank( messageTmp )){
            messageTmp = message;
        }
        return new BusinessException( code, messageTmp );
    }
    public static BusinessException buildBiz( String msg, Object... objs ) {
        String message = MessageFormatter.arrayFormat(msg, objs).getMessage();
        return new BusinessException( message );
    }

    public BusinessException(Throwable cause) {
        super(cause);
    }
    
    public Integer getCode(){
    	return code;
    }
}
