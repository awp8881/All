package com.qzsoft.common.activerecord;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Config;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.DbKit;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DbMetaServiceImpl implements DbMetaService {


    //别名到真实名的映射
    private static final ConcurrentHashMap<String,String> aliasToRealMapping = new ConcurrentHashMap();

    //别名到真实名的映射
    private static final ConcurrentHashMap<String,String> realToAliasMapping = new ConcurrentHashMap();

    //真实字段
    private static final ConcurrentHashMap<String,String> correctRealTableFieldMap = new ConcurrentHashMap();

    @Autowired
    RedisTemplate redisTemplate;


    /**
     *
     * @param dsNames 数据源列表
     * @param tableName
     * @return  指定表的元数据
     */
    @Override
    public List<Record> getColMetaByTableName(Set<String> dsNames, String tableName) {

        List<Record> colMeta = new ArrayList<>();
        for (String dataSourceName : dsNames) {
            if( StringUtils.isBlank( dataSourceName ) ){
                colMeta = Db.find(getSingleTableColMetaSql(dataSourceName,tableName));
            }else{
                colMeta = Db.use(dataSourceName).find(getSingleTableColMetaSql(dataSourceName,tableName));
            }
            if( !colMeta.isEmpty() ){
                break;
            }
        }
        Assert.notEmpty( colMeta, "请联系管理员，发现系统存在空表："+ tableName );
        return colMeta;
    }

    private String getSingleTableColMetaSql(String dataSourceName, String tableName) {
        if( DbEx.isMysql(dataSourceName) ){
            //获取mysql对于的table_schema
            String table_schema = "";
            try {
                Config config = DbKit.getConfig(dataSourceName);
                Connection connection = config.getConnection();
                String url = connection.getMetaData().getURL();
//                jdbc:mysql://192.168.2.225:3307/ksm_dev?
                url = url.split("\\?")[0];
                table_schema = url.substring( url.lastIndexOf('/')+1 );
                config.close( connection );
            } catch (SQLException e) {
                log.error( e.getMessage(),e );
                BusinessException.throwBiz("初始化数据出错,请联系系统人员");
            }
            return DbMetaQuerySql.mysqlSingleTableColMetaSql
                    .replace("#table_schema", table_schema)
                    .replace("#table_name", tableName);
        }
        if( DbEx.isSqlserver(dataSourceName) ){
            return DbMetaQuerySql.sqlserverSingleTableColMetaSql
                    .replace("#table_name", tableName);
        }
        if( DbEx.isOracle(dataSourceName) ){
            return DbMetaQuerySql.oracleSingleTableColMetaSql
                    .replace("#table_name", tableName);
        }
        return "";
    }


    /**
     *
     * @param dsNames   数据源列表
     * @param tableName  表名
     * @param readOrWrite  读库还是写库
     * @return 表对应的数据源
     */
    @Override
    @Cacheable( value = "DataSourceName", key = "#readOrWrite+':'+#tableName",unless = "#result == null")
    public String getDataSourceNameByTableName(Set<String> dsNames, String tableName, String readOrWrite) {
        String dataSourceNameResult = null;
        for (String dataSourceName : dsNames) {
            if( StringUtils.isBlank( dataSourceName ) ){
                List<Record> records = Db.find(getSingleTableColMetaSql(dataSourceName, tableName));
                if( !records.isEmpty() ){
                    return dataSourceName;
                }
            }else{
                List<Record> records = Db.use(dataSourceName).find(getSingleTableColMetaSql(dataSourceName, tableName));
                if( !records.isEmpty() ){
                    return dataSourceName;
                }
            }
        }
        return  dataSourceNameResult;
    }

    /**
     *
     * @param dsNames
     * @return 所有表的元数据
     */
    @Override
    public List<Record> geTableMetaRecordListFromMasterDbMetas(Set<String> dsNames) {

        Set<String> repeatTable = Sets.newHashSet();
        List<Record> tableMetaRecordList = Lists.newArrayList();
        for (String dataSourceName : dsNames) {
            if( StringUtils.isBlank(dataSourceName) ){
                continue;
            }
            String colMetaSql = getTableMetaSql( dataSourceName );
            if(StringUtils.isBlank( colMetaSql )){
                continue;
            }
            List<Record> tableMetaRecords = Db.use(dataSourceName).find(colMetaSql);
            //需要按照表名去重
            tableMetaRecords = tableMetaRecords.stream().filter( record -> {
                if( repeatTable.contains( record.getStr( "Name" ) ) ){
                    return false;
                }else{
                    repeatTable.add( record.getStr( "Name" ) );
                    return true;
                }
            } ).collect(Collectors.toList());
            tableMetaRecordList.addAll( tableMetaRecords );
        }
        Assert.notEmpty( tableMetaRecordList, "请联系管理员，发现系统没有表数据源" );
        return tableMetaRecordList;
    }

    private String getTableMetaSql(String dataSourceName) {
        if( DbEx.isMysql(dataSourceName) ){
            String table_schema = "";
            try {
                String url = DbKit.getConfig().getConnection().getMetaData().getURL();
//                jdbc:mysql://192.168.2.225:3307/ksm_dev?
                url = url.split("\\?")[0];
                table_schema = url.substring( url.lastIndexOf('/')+1 );
            } catch (SQLException e) {
                log.error( e.getMessage(),e );
                BusinessException.throwBiz("初始化数据出错,请联系系统人员");
            }
            return DbMetaQuerySql.mysqlTableMetaSql.replace("#table_schema", table_schema);
        }
        if( DbEx.isSqlserver(dataSourceName) ){
            return DbMetaQuerySql.sqlserverTableMetaSql;
        }
        if( DbEx.isOracle(dataSourceName) ){
            return DbMetaQuerySql.oracleTableMetaSql;
        }
        return "";
    }

    /**
     *
     * @param dsNames
     * @return 所有列的元数据
     */
    @Override
    public List<Record> getColMetaRecordListFromMasterDbMetas(Set<String> dsNames) {

        Set<String> repeatTableCol = Sets.newHashSet();
        List<Record> colMetaRecordList = Lists.newArrayList();
        List<Record> colMeta = new ArrayList<>();
        for (String dataSourceName : dsNames) {
            if( StringUtils.isBlank( dataSourceName ) ){
                colMeta = Db.find(getColMetaSql(dataSourceName));
            }else{
                colMeta = Db.use(dataSourceName).find(getColMetaSql(dataSourceName));
            }
            //需要按照表名 列名去重
            colMeta = colMeta.stream().filter( record -> {
                if( repeatTableCol.contains( record.getStr( "TableName" ) +"@"+ record.getStr( "Field" ) ) ){
                    return false;
                }else{
                    repeatTableCol.add( record.getStr( "TableName" ) +"@"+ record.getStr( "Field" ) );
                    return true;
                }
            } ).collect(Collectors.toList());

            colMetaRecordList.addAll(colMeta);
        }
        Assert.notEmpty( colMetaRecordList, "请联系管理员，发现系统存在空数据源" );
        return colMetaRecordList;
    }

    private String getColMetaSql(String dataSourceName) {
        if( DbEx.isMysql(dataSourceName) ){
            //获取mysql对于的table_schema
            String table_schema = "";
            try {
                String url = DbKit.getConfig().getConnection().getMetaData().getURL();
//                jdbc:mysql://192.168.2.225:3307/ksm_dev?
                url = url.split("\\?")[0];
                table_schema = url.substring( url.lastIndexOf('/')+1 );
            } catch (SQLException e) {
                log.error( e.getMessage(),e );
                BusinessException.throwBiz("初始化数据出错,请联系系统人员");
            }
            return DbMetaQuerySql.mysqlColMetaSql
                    .replace("#table_schema", table_schema);
        }
        if( DbEx.isSqlserver(dataSourceName) ){
            return DbMetaQuerySql.sqlserverColMetaSql;
        }
        if( DbEx.isOracle(dataSourceName) ){
            return DbMetaQuerySql.oracleColMetaSql;
        }
        return "";
    }


    @Override
    @CacheEvict( value = "DataSourceName",allEntries = true)
    public void loadFieldMappingFromMeta(List<Record> colMetaRecordList) {
        clearMapping();
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < colMetaRecordList.size(); i++) {
            Record record = colMetaRecordList.get(i);
            buffer.setLength(0);
            String field = record.getStr("Field");
            String table_name = record.getStr("TableName");
            String realTablePointFieldName = buffer.append(table_name).append(".").append(field).toString();
            String alias = realToAliasMapping.get(realTablePointFieldName);
            if( null==alias ){
                alias = "Qz" + i;
                //纠正包含关键字的sql
                String correctRealName = realTablePointFieldName;
                Set<String> keyWordsSet = OracleKeyWord.getKeyWordsSet();
                String[] split = realTablePointFieldName.split("\\.");
                String tableName = split[0];
                String fieldName = split[1];
                if( keyWordsSet.contains(fieldName.toUpperCase()) ){
                    correctRealName = tableName+".\""+fieldName.toUpperCase()+"\"";
                }
                realToAliasMapping.put( realTablePointFieldName, alias);
                aliasToRealMapping.put( alias, realTablePointFieldName);
                correctRealTableFieldMap.put(realTablePointFieldName,correctRealName);

                redisTemplate.opsForHash().put("REAL_2_ALIAS", realTablePointFieldName, alias);
                redisTemplate.opsForHash().put("ALIAS_2_REAL", alias, realTablePointFieldName);
                redisTemplate.opsForHash().put("REAL_TABLE_FIELD", realTablePointFieldName,correctRealName );

            }
        }
        log.info("载入字段映射");
    }


    private void clearMapping() {
        aliasToRealMapping.clear();
        realToAliasMapping.clear();
        correctRealTableFieldMap.clear();
    }

    private String getCorrectRealTableField(String tablePointFieldName) {
        return StringUtil.toString( redisTemplate.opsForHash().get("REAL_TABLE_FIELD", tablePointFieldName) ) ;
    }

    private String getAliasToReal(String alias) {
        return StringUtil.toString( redisTemplate.opsForHash().get("ALIAS_2_REAL", alias) ) ;
    }


    private String getRealToAlias(String realName) {
        return StringUtil.toString( redisTemplate.opsForHash().get("REAL_2_ALIAS", realName) ) ;
    }


    /**
     *获取别名字段
     * @param originalSQLField  表名.字段名
     * @return
     */
    @Override
    public  String getAliasSqlField(String originalSQLField){
        if( StringUtils.isBlank(originalSQLField)  ){
            return originalSQLField;
        }
        if( DbEx.isOracle() ){
            return  realToAlias( originalSQLField.toLowerCase() );
        }
        return originalSQLField;
    }

    /**
     *
     * @param originalSQLField  表名.字段名
     * @return oracle可能存在关键字  需要加上引号
     */
    @Override
    public String getCorrectSqlField(String originalSQLField){
        if( StringUtils.isBlank(originalSQLField)  ){
            return originalSQLField;
        }
        if( DbEx.isOracle() ){
            return correctRealTableField( originalSQLField.toLowerCase() );
        }
        return originalSQLField;
    }


    @Override
    public String aliasToReal(String alias) {
        String real = getAliasToReal(alias);
        if( StringUtils.isBlank( real ) ){
            synchronized (this) {
                if (StringUtils.isBlank(real)) {
                    loadFieldMappingFromMeta(DataSourceHolder.getColMetaRecordListFromMasterDbMetas());
                    return getAliasToReal(alias);
                }
            }
        }
        return real;
    }

    @Override
    public String realToAlias( String realName ){
        String alias = getRealToAlias(realName);
        if( StringUtils.isBlank( alias ) ){
            synchronized (this) {
                if( StringUtils.isBlank( alias ) ){
                    loadFieldMappingFromMeta( DataSourceHolder.getColMetaRecordListFromMasterDbMetas() );
                    return getRealToAlias(realName);
                }
            }
        }
        return alias;

//        return realToAliasMapping.get( realName );
    }

    /**
     * 处理关键字后的列名
     * @param realTablePointFieldName
     * @return
     */
    @Override
    public String correctRealTableField(String realTablePointFieldName) {

        String realCorrectTableField = getCorrectRealTableField(realTablePointFieldName);
        if( StringUtils.isBlank( realCorrectTableField ) ){
            synchronized (this) {
                if (StringUtils.isBlank(realCorrectTableField)) {
                    loadFieldMappingFromMeta( DataSourceHolder.getColMetaRecordListFromMasterDbMetas() );
                    return getCorrectRealTableField(realTablePointFieldName);
                }
            }
        }
        return realCorrectTableField;


//        return correctRealTableFieldMap.get( realTablePointFieldName );
    }

}
