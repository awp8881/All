package com.qzsoft.common.tools;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Pattern;

import com.qzsoft.common.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Period;
import org.joda.time.PeriodType;

public class DateUtil {
	public static final String DATE_FORMAT_YYYYMM = "yyyyMM";
	public static final String DATE_FORMAT_YYYY_MM = "yyyy-MM";
	public static final String DATE_FORMAT_YY_MM_DD = "yy-MM-dd";
	public static final String DATE_FORMAT_YYMMDD = "yyMMdd";
	public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";
	public static final String DATE_FORMAT_YYYY1MM1DD = "yyyy/MM/dd";
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String DATE_FORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String DATE_FORMAT_HH_MM_SS = "HH:mm:ss";
	public static final String DATE_FORMAT_HH_MM = "HH:mm";
	public static final String DATE_FORMAT_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
	public static final String DATE_UTC = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'";
	public static final String SLASH_DATE_FORMAT_YYYY_MM = "yyyy/MM";
	public static final String SLASH_DATE_FORMAT_YYYY_MM_DD = "yyyy/MM/dd";
	public static final String SLASH_DATE_FORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy/MM/dd HH:mm:ss";

	public static final String DATE_FORMAT_YYYY_MM_MATCHES = "^\\d{4}-\\d{1,2}$";
	public static final String DATE_FORMAT_YYYY_MM_DD_MATCHES = "^\\d{4}-\\d{1,2}-\\d{1,2}$";
	public static final String DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MATCHES = "^\\d{4}-\\d{1,2}-\\d{1,2} {1}\\d{1,2}:\\d{1,2}:\\d{1,2}$";
	public static final String SLASH_DATE_FORMAT_YYYY_MM_MATCHES = "^\\d{4}/\\d{1,2}$";
	public static final String SLASH_DATE_FORMAT_YYYY_MM_DD_MATCHES = "^\\d{4}/\\d{1,2}/\\d{1,2}$";
	public static final String SLASH_DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MATCHES = "^\\d{4}/\\d{1,2}/\\d{1,2} {1}\\d{1,2}:\\d{1,2}:\\d{1,2}$";

	public static String getNowDate() {
		SimpleDateFormat dateFromat = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
		return dateFromat.format(new Date());
	}


	public static Date getNowDateTime() {
		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
		String dateString = formatter.format(currentTime);
		ParsePosition pos = new ParsePosition(0);
		Date currentTime_2 = formatter.parse(dateString, pos);
		return currentTime_2;
	}

	public static String getNowDateTimeStr() {
		SimpleDateFormat dateFromat = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
		return dateFromat.format(new Date());
	}

	public static String getDateYYYYMMStr() {
		SimpleDateFormat dateFromat = new SimpleDateFormat(DATE_FORMAT_YYYYMM);
		return dateFromat.format(new Date());
	}

	public static String getDateYYYYMMDDStr() {
		SimpleDateFormat dateFromat = new SimpleDateFormat(DATE_FORMAT_YYYYMMDD);
		return dateFromat.format(new Date());
	}

	public static String getFormatNowDateTime() {
		SimpleDateFormat dateFromat = new SimpleDateFormat(DATE_FORMAT_YYYYMMDDHHMMSS);
		return dateFromat.format(new Date());
	}

	public static String getNowTime() {
		SimpleDateFormat dateFromat = new SimpleDateFormat(DATE_FORMAT_HH_MM_SS);
		return dateFromat.format(new Date());
	}

	public static long getSimpleId() {
		SimpleDateFormat dateFromat = new SimpleDateFormat(DATE_FORMAT_YYYYMMDDHHMMSS);
		String format = dateFromat.format(new Date());
		return Long.parseLong(format);
	}

	/**
	 * 日期格式转换
	 * 
	 * @param dateStr
	 * @param formatStrFrom
	 * @param formatStrTo
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public static String formatDateStr(String dateStr, String formatStrFrom, String formatStrTo) {
		try {
			SimpleDateFormat sdfFrom = new SimpleDateFormat(formatStrFrom);
			Date date = sdfFrom.parse(dateStr);
			// 如果包含小时，则赋值当前时间
			if (formatStrTo != null && formatStrTo.contains("HH")) {
				Date curDate = new Date();
				date.setHours(curDate.getHours());
				date.setMinutes(curDate.getMinutes());
				date.setSeconds(curDate.getSeconds());
			}
			SimpleDateFormat sdfTo = new SimpleDateFormat(formatStrTo);
			return sdfTo.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public static String formatDateStr(String dateStr, String formatStrFrom) {
		try {
			SimpleDateFormat sdfFrom = new SimpleDateFormat(formatStrFrom);
			Date date = sdfFrom.parse(dateStr);
			return sdfFrom.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}



	public static Date getDateYYYYMM(String dateStr) {
		try {
			SimpleDateFormat sdfFrom = new SimpleDateFormat(DATE_FORMAT_YYYY_MM);
			Date date = sdfFrom.parse(dateStr);
			return date;
		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public static Date getDateByFormat(String dateStr, String format) {
		try {
			SimpleDateFormat sdfFrom = new SimpleDateFormat(format);
			Date date = sdfFrom.parse(dateStr);
			return date;
		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public static Date getDate(String dateStr) {
		try {
			SimpleDateFormat sdfFrom = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
			Date date = sdfFrom.parse(dateStr);
			return date;
		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public static Date getDateYYYYMMDDHHMMSS(String dateStr) {
		try {
			SimpleDateFormat sdfFrom = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
			Date date = sdfFrom.parse(dateStr);
			return date;
		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public static String getFormatTime(String timeStr) {
		try {
			if (null != timeStr && !"".equals(timeStr)) {
				SimpleDateFormat dateFromat = new SimpleDateFormat(DATE_FORMAT_YYYYMMDDHHMMSS);
				Date date = dateFromat.parse(timeStr);
				return dateFromat.format(date);
			} else {
				return null;
			}

		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static String getDateStrByHHMMSS(Date date) {
		return getDateStrFormat(date, DATE_FORMAT_HH_MM_SS);
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static String getDateStrByYYMMDD(Date date) {
		return getDateStrFormat(date, DATE_FORMAT_YYYY_MM_DD);
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static String getDateStr(Date date) {
		return getDateStrFormat(date, DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
	}

	/**
	 * 
	 * @param dateStr
	 * @return
	 */
	public static Calendar getCalendar(String dateStr) {
		Date date = null;
		if (dateStr.length() == 10){
			date = getDate(dateStr);
		}else {
			date = getDateYYYYMMDDHHMMSS(dateStr);
		}
		Calendar cal = Calendar.getInstance();
		cal.clear();
		cal.setTime(date);
		return cal;
	}


	/**
	 * 
	 * @param cal
	 * @return
	 */
	public static String getDateStrByCal(Calendar cal) {
		Date date = cal.getTime();
		return getDateStr(date);
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static String getDateStrFormat(Date date, String formatStr) {
		try {
			if (date == null) {
				return null;
			}
			// 默认10位日期格式
			if (formatStr == null || "".equals(formatStr)) {
				formatStr = DATE_FORMAT_YYYY_MM_DD;
			}
			SimpleDateFormat sdfFrom = new SimpleDateFormat(formatStr);
			return sdfFrom.format(date);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public static String getDateUTC(String timeStr) {
		String str = null;
		if (StringUtils.isNotEmpty(timeStr)) {
			SimpleDateFormat df = new SimpleDateFormat(DATE_UTC);
			df.setTimeZone(TimeZone.getTimeZone("UTC"));

			try {
				Date date = df.parse(timeStr);
				str = getDateStrFormat(date, DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}

		return str;
	}

	/**
	 * 计算俩个字符串时间之间的差
	 * 
	 * @return
	 */
	public static int daysBetween(String startDt, String endDt) {
		try {
			Calendar cal = getCalendar(startDt);
			long time1 = cal.getTimeInMillis();
			cal = getCalendar(endDt);
			long time2 = cal.getTimeInMillis();
			long betweenDays = (time2 - time1) / (1000 * 3600 * 24);
			return Integer.parseInt(String.valueOf(betweenDays));
		} catch (Exception e) {
			BusinessException.throwBiz("日期比较错误");
		}
		return 0;
	}

	/**
	 * 计算俩个字符串时间之间的一天小时差
	 *
	 * @return
	 */
	public static int hourOfDayBetween(String startDt, String endDt) {
		try {
			Calendar cal = getCalendar(startDt);
			int startHour = cal.get(Calendar.HOUR_OF_DAY);
			cal = getCalendar(endDt);
			int endHour = cal.get(Calendar.HOUR_OF_DAY);
			return endHour - startHour;
		} catch (Exception e) {
			BusinessException.throwBiz("日期比较错误");
		}
		return 0;
	}

	public static long monthBetween(Date startDt, Date endDt) {
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(startDt);
			int start = cal.get(Calendar.MONTH);
			cal.setTime(endDt);
			int end = cal.get(Calendar.MONTH);
			return end - start;
		} catch (Exception e) {
			BusinessException.throwBiz("日期比较错误");
		}
		return 0;
	}



	//日期比较秒数
	public static int dateCompareSecond(String startDt, String endDt) {
		try {
			Calendar cal = getCalendar(startDt);
			long time1 = cal.getTimeInMillis();
			cal = getCalendar(endDt);
			long time2 = cal.getTimeInMillis();
			long seconds = (time2 - time1) / 1000;
			return Integer.parseInt(String.valueOf(seconds));
		} catch (Exception e) {
			BusinessException.throwBiz("日期比较错误");
		}
		return 0;
	}

	public static Double countDateBigDecimal(String startDt, String endDt) {
		try {
			Calendar cal = getCalendar(startDt);
			long time1 = cal.getTimeInMillis();
			cal = getCalendar(endDt);
			long time2 = cal.getTimeInMillis();
			BigDecimal bigDecimal = NumberUtils.getBigDecimal((time2 - time1) / 1000 /60 );
			return NumberUtils.div(bigDecimal, BigDecimal.valueOf(60), 1).doubleValue();
		} catch (Exception e) {
			BusinessException.throwBiz("日期计算错误");
		}
		return Double.valueOf(0);
	}

	public static String dateAddSecond(String dateStr, int num){
		Calendar cal = getCalendar(dateStr);
		long time = cal.getTimeInMillis();
		time += num;
		return stampToDateStr(time+"", null);
	}

	/**
	 * 比较两个日期大小（yyyy-mm-dd）
	 * 
	 * @param sdate
	 * @param bdate
	 * @return
	 */
	public static int compareDateStr(String sdate, String bdate) {
		Date sDt = getDate(sdate);
		Date bDt = getDate(bdate);
		return sDt.compareTo(bDt);
	}

	/**
	 * 比较两个日期大小（yyyy-mm-dd hh:mm:ss）
	 * 
	 * @param sdate
	 * @param bdate
	 * @return
	 */
	public static int compareDateStrs(String sdate, String bdate) {
		Date sDt = getDateYYYYMMDDHHMMSS(sdate);
		Date bDt = getDateYYYYMMDDHHMMSS(bdate);
		return sDt.compareTo(bDt);
	}

	public static int compareDate(Date date, Date now) {
		return date.compareTo(now);
	}

	/**
	 * 计算俩个Date类型的日期相差的十分秒
	 * 
	 * @return
	 */
	public static String calcTime(Date bgDate, Date smDate) {
		long diff = (bgDate.getTime() - smDate.getTime()) / 1000; // 得到2个时间相差的秒数
		int day = (int) (diff / 86400);
		int hour = (int) ((diff % 86400) / 3600);
		int min = (int) ((diff % 3600) / 60);
		return day + "天" + hour + "小时" + min + "分";
	}

	/**
	 * 取两个日期间隔的秒数
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static int getRangeSeconds(Date date1, Date date2){
		DateTime begin = new DateTime(date1);
		DateTime end = new DateTime(date2);
		Period period = new Period(begin,end, PeriodType.seconds());
		return period.getSeconds();
	}

	/**
	 * 计算俩个Date类型的日期相差的小时
	 * 
	 * @return
	 */
	public static int calcTimeGetHour(Date bgDate, Date smDate) {
		long diff = (bgDate.getTime() - smDate.getTime()) / 1000; // 得到2个时间相差的秒数
		int hour = (int) (diff / 3600);
		return hour;
	}

	/**
	 * 获取SimpleDateFormat
	 * 
	 * @param parttern
	 *            日期格式
	 * @return SimpleDateFormat对象
	 * @throws RuntimeException
	 *             异常：非法日期格式
	 */
	private static SimpleDateFormat getDateFormat(String parttern) throws RuntimeException {
		return new SimpleDateFormat(parttern);
	}

	/**
	 * 将日期字符串转化为日期。失败返回null。
	 * 
	 * @param date
	 *            日期字符串
	 * @param parttern
	 *            日期格式
	 * @return 日期
	 */
	public static Date StringToDate(String date, String parttern) {
		Date myDate = null;
		if (date != null) {
			try {
				myDate = getDateFormat(parttern).parse(date);
			} catch (Exception e) {
			}
		}
		return myDate;
	}

	/**
	 * 计算该年所有周末
	 * 
	 * @param year
	 * @return
	 */
	public static List<String> getWeekends(int year) {
		List<String> list = new ArrayList<String>();
		final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
		Calendar cal = Calendar.getInstance(Locale.CHINA);
		cal.set(year, 0, 1);
		for (int day = 1; day <= cal.getActualMaximum(Calendar.DAY_OF_YEAR); day++) {
			cal.set(Calendar.DAY_OF_YEAR, day);
			int weekDay = cal.get(Calendar.DAY_OF_WEEK);
			if (weekDay == Calendar.SATURDAY || weekDay == Calendar.SUNDAY) {
				list.add(sdf.format(cal.getTime()));
			}
		}
		return list;
	}

	/**
	 * 判断日期格式是否为时分
	 * 
	 * @param dm
	 * @return
	 */
	public static boolean isDateHourse(String dm) {
		boolean isMatch = Pattern.matches("^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$", dm);
		return isMatch;
	}

	/**
	 * 获取当前时间的前num天
	 */
	public static String getBeforeDate(Integer num) {
		Date date = new Date();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.DAY_OF_MONTH, num);
			date = calendar.getTime();
			String str = formatter.format(date);
			return str;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 获取当前时间的前num月
	 */
	public static String getBeforeMonthDate(Integer num) {
		Date date = new Date();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.MONTH, num);
			date = calendar.getTime();
			String str = formatter.format(date);
			return str;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String countMonthDate(String dateStr, Integer num) {
		Date date = null;
		try {
			date = getDate( dateStr);
			SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.MONTH, num);
			date = calendar.getTime();
			String str = formatter.format(date);
			return str;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getOneDayByMonth(String dateStr, Integer num){
		Date date = getDate( dateStr);;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, num);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);

		date = calendar.getTime();
		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
		String str = formatter.format(date);
		return str;
	}

	public static String getOneDayByYear(String dateStr, Integer num){
		Date date = getDate( dateStr);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.YEAR, num);
		calendar.set(Calendar.MONTH, 0);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);

		date = calendar.getTime();
		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
		String str = formatter.format(date);
		return str;
	}

	//判断选择的日期是否是今天  
	public static boolean isToday(long time)  
    {  
       return isThisTime(time,"yyyy-MM-dd");  
    }  
    //判断选择的日期是否是本月  
    public static boolean isThisMonth(long time)  
    {  
         return isThisTime(time,"yyyy-MM");  
    }  
    private static boolean isThisTime(long time,String pattern) {  
        Date date = new Date(time);  
         SimpleDateFormat sdf = new SimpleDateFormat(pattern);  
         String param = sdf.format(date);//参数时间  
         String now = sdf.format(new Date());//当前时间  
         if(param.equals(now)){  
           return true;  
         }  
         return false;  
    }

    /* 
     * 将时间戳转换为时间
     */
    public static String stampToDateStr(String stamp, String dateType){
    	if (StringUtils.isBlank(stamp)) {
    		return null;
		}
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HH_MM_SS);
    	if((StringUtils.isNotBlank(dateType) && "date".equals(dateType)) ){
    		simpleDateFormat = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
    	}
    	
    	String dateStr = stamp;
		if( !stamp.contains("-") && StringUtil.isNum(stamp)){
            long lt = new Long(stamp);
            Date date;
			date = new Date(lt);
			dateStr = simpleDateFormat.format(date);
    	}else{
    		if (stamp.length() == 10) {
    			simpleDateFormat = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
			}
    		 Date date;
 			try {
 				date = simpleDateFormat.parse(stamp);
 				dateStr = simpleDateFormat.format(date);
 			} catch (ParseException e) {
 				e.printStackTrace();
 			} 
    	}
        return dateStr;
    }
    
    public static boolean isValidDate(String str) {
        boolean convertSuccess = true;
         SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
         try {
            format.setLenient(false);
            format.parse(str);
         } catch (ParseException e) {
             convertSuccess = false;
         } 
         return convertSuccess;
  }

	/**
	 * 获取当前时间的前后num天
	 */
	public static String getBeforeAfterDate(String dateStr, Integer num) {
		String dateFormat = DATE_FORMAT_YYYY_MM_DD_HH_MM_SS;
		Date date = null;
		if (dateStr.length() == 10){
			dateFormat = DATE_FORMAT_YYYY_MM_DD;
			date = getDate(dateStr);
		}else {
			date = getDateYYYYMMDDHHMMSS(dateStr);
		}
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.DAY_OF_MONTH, num);
			date = calendar.getTime();
			return formatter.format(date);
		} catch (Exception e) {
			BusinessException.throwBiz("日期处理出错");
		}
		return dateStr;
	}

	public static String dateHourCount(String dateStr, Integer num){
		String dateFormat = DATE_FORMAT_YYYY_MM_DD_HH_MM_SS;
		Date date = null;
		if (dateStr.length() == 10){
			dateFormat = DATE_FORMAT_YYYY_MM_DD;
			date = getDate(dateStr);
		}else {
			date = getDateYYYYMMDDHHMMSS(dateStr);
		}
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.HOUR, num);
			date = calendar.getTime();
			return formatter.format(date);
		} catch (Exception e) {
			BusinessException.throwBiz("日期处理出错");
		}
		return dateStr;
	}


	public static Date getDateByString(String time, String plan) {
		Long times = getLongTimeByString(time, plan);
		return new Date(times);
	}

	/**
	 * 获得指定时间格式的时间
	 *
	 * @param time 时间字符串
	 * @param plan 时间格式
	 * @return 时间
	 * @author wangzhe@piesat.cn
	 * @date 2018年7月21日
	 */
	public static String getStringDateByString(Date time, String plan) {
		DateFormat format = new SimpleDateFormat(plan);
		return format.format(time);
	}

	/**
	 * 获得指定时间格式的毫秒值
	 *
	 * @param time 时间字符串
	 * @param plan 时间格式
	 * @return 毫秒值
	 * @author wangzhe@piesat.cn
	 * @date 2018年7月17日
	 */
	public static Long getLongTimeByString(String time, String plan) {
		DateFormat format = new SimpleDateFormat(plan);
		Long result = null;
		try {
			result = format.parse(time).getTime();
		} catch (ParseException e) {
			BusinessException.throwBiz("日期处理出错");
		}
		return result;
	}

	public static int getYear(String dateStr, String format){
		Date date = getDateByFormat(dateStr, format);
		Calendar ca = Calendar.getInstance(Locale.CHINA);
		ca.setTime(date);
		int year = ca.get(Calendar.YEAR);
		return year;
	}

	public static int getMonth(String dateStr, String format){
		Date date = getDateByFormat(dateStr, format);
		Calendar ca = Calendar.getInstance(Locale.CHINA);
		ca.setTime(date);
		int month = ca.get(Calendar.MONTH)+1;
		return month;
	}

	public static int getDay(String dateStr){
		Date date = getDate(dateStr);
		Calendar ca = Calendar.getInstance(Locale.CHINA);
		ca.setTime(date);
		int day = ca.get(Calendar.DAY_OF_MONTH);
		return day;
	}

	public static int getDayOfYear(String dateStr){
		Date date = getDate(dateStr);
		Calendar ca = Calendar.getInstance(Locale.CHINA);
		ca.setTime(date);
		int day = ca.get(Calendar.DAY_OF_YEAR);
		return day;
	}

	public static boolean isLeapYear(int year) {
		if ((year & 3) != 0) {
			return false;
		}
		return (year%100 != 0) || (year%400 == 0);
	}

	public static int getDaysOfMonth(String dateStr){
		Date date = getDateYYYYMM(dateStr);
		Calendar ca = Calendar.getInstance(Locale.CHINA);
		ca.setTime(date);
		int days = ca.getActualMaximum(Calendar.DAY_OF_MONTH);
		return days;
	}

	public static LocalDate firstDayOfMonth(){
		LocalDate today = LocalDate.now();
		LocalDate firstday = LocalDate.of(today.getYear(), today.getMonth(),1);
		return firstday;
	}

	public static LocalDate lastDayOfMonth(){
		LocalDate today = LocalDate.now();
		LocalDate lastDay = today.with(TemporalAdjusters.lastDayOfMonth());
		return lastDay;
	}

}
