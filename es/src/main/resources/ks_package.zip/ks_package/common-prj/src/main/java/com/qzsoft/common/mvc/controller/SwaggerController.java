//package com.qzsoft.common.mvc.controller;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.qzsoft.common.mvc.service.SwaggerService;
//import com.qzsoft.common.vo.Table;
//
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//import io.swagger.annotations.ApiResponse;
//import io.swagger.annotations.ApiResponses;
//
///*API详细说明
//
//注释汇总
//-------------------------------------
//作用范围            		API	                 	使用位置
//
//对象属性	    		@ApiModelProperty	用在出入参数对象的字段上
//
//协议集描述			@Api				用于controller类上
//
//协议描述				@ApiOperation		用在controller的方法上
//
//Response集			@ApiResponses		用在controller的方法上
//
//Response			@ApiResponse		用在 @ApiResponses里边
//
//非对象参数集			@ApiImplicitParams	用在controller的方法上
//
//非对象参数描述		@ApiImplicitParam	用在@ApiImplicitParams的方法里边
//
//描述返回对象的意义	@ApiModel			用在返回对象类上
//-------------------------------------
//@RequestMapping此注解的推荐配置
//value
//method
//produces
//
//参考：http://blog.csdn.net/xupeng874395012/article/details/68946676
//*/
//
//@Controller
//@RequestMapping("swagger")
//@Api(tags="接口文档展示模型",value = "展示模型")//添加注释
//public class SwaggerController{
//
//	private static final String SWAGGER_PAGES = "common/static/swagger.jsp";
//
//	@Autowired
//	private SwaggerService swaggerService;
//
//	@ApiOperation(value="接口管理系统页面访问接口")
//	@ApiResponses({
//	@ApiResponse(code = 401, message = "资源未经授权的"),
//	@ApiResponse(code = 403, message = "权限不足"),
//    @ApiResponse(code = 404, message = "未找到资源"),
//    @ApiResponse(code = 200, message = "操作成功")
//	})
//	@RequestMapping(value="/swagger.do",method=RequestMethod.GET)
//	public String toJsp(){
//		return SWAGGER_PAGES;
//	}
//
//	@ApiOperation(value="接口管理系统测试接口")
//	@ApiResponses({
//		@ApiResponse(code = 401, message = "资源未经授权的"),
//		@ApiResponse(code = 403, message = "权限不足"),
//	    @ApiResponse(code = 404, message = "未找到资源"),
//	    @ApiResponse(code = 200, message = "操作成功")
//		})
//	@RequestMapping(value="/test.do",method=RequestMethod.GET)
//	@ResponseBody
//	public String toTest(@RequestParam(value="userId", required=false) String userId,
//			@RequestParam(value = "para", required = true) String para){
//		return userId+"testswagger"+para;
//	}
//
//	@ApiOperation(value="接口管理系统测试接口", hidden=true)
//	@RequestMapping(value="/exportWord",method=RequestMethod.GET)
//	@ResponseBody
//	public String exportWord(HttpServletRequest request, Model model){
//		try {
//			String host = getHost(request);
//			Map<String, List<Table>> map = swaggerService.tableList(host);
//			model.addAttribute("map",map);
//		} catch (Exception e) {
//			return "";
//		}
//        return "json";
//	}
//
//	@RequestMapping(value="/test",method=RequestMethod.GET)
//	public String test(HttpServletRequest request, Model model, HttpServletResponse response){
//		Map<String, Object> ji = new HashMap<>();
//		ji.put("123", "33333");
//		model.addAttribute("ji", ji);
//		response.setContentType("application/msword");
//        return "json2";
//	}
//
//
//}
