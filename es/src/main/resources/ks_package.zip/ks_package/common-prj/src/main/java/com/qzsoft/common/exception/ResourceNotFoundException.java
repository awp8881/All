package com.qzsoft.common.exception;

import org.springframework.core.io.Resource;

public class ResourceNotFoundException extends RuntimeException {

	private final String propertyName;

	private final Resource resource;

	public ResourceNotFoundException(String propertyName, Resource resource) {
		super(String.format("%s defined by '%s' does not exist", resource, propertyName));
		this.propertyName = propertyName;
		this.resource = resource;
	}

	/**
	 * Return the name of the property that defines the resource.
	 * @return the property
	 */
	public String getPropertyName() {
		return this.propertyName;
	}

	/**
	 * Return the {@link Resource}.
	 * @return the resource
	 */
	public Resource getResource() {
		return this.resource;
	}

}