package com.qzsoft.common.aspect;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.log.OptLog;
import com.qzsoft.common.log.OptLogBean;
import com.qzsoft.common.log.OptLogService;
import com.qzsoft.common.tools.DateUtil;
import com.qzsoft.common.tools.OptLogUtil;
import com.qzsoft.common.tools.StringUtil;
import com.qzsoft.common.tools.UIDGenerator;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @author pjh
 * @Title: OptLogAspect
 * @Description: 操作日志切面
 * @date 2018/11/7 14:30
 */

@Aspect
@Component
public class OptLogAspect {

    protected final Logger log = LoggerFactory.getLogger( getClass() );

    @Autowired
    OptLogService optLogService;

    @Around("@annotation(com.qzsoft.common.log.OptLog)")
    public Object caching(ProceedingJoinPoint point) throws Throwable {

        Signature signature = point.getSignature();
        MethodSignature methodSignature = (MethodSignature) signature;
        Method targetMethod = methodSignature.getMethod();
        OptLog optLog = targetMethod.getAnnotation(OptLog.class);
        if( null==optLog ){
            return point.proceed();
        }
        OptLogBean optLogBean = new OptLogBean();
        optLogBean.setBatchNo( UIDGenerator.getUID()+"" );
        optLogBean.setModule( optLog.module() );
        optLogBean.setRemark( optLog.remark() );
        optLogBean.setOptUser( optLogService.getOptUser( ) );
        optLogBean.setIsRecordOpt( false );//false 表示不记录日志
        OptLogUtil.setOptLogBean( optLogBean );
        //执行调用方法
        Object obj;
        try{
            obj = point.proceed();
        }finally {
            OptLogUtil.cleanOptLogBean( );
        }
        optLogService.analysisChange( optLogBean.getBatchNo() );

        return obj;
    }

}
