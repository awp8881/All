package com.qzsoft.common.activerecord;

/**
 * db元数据查询sql
 */
public class DbMetaQuerySql {

    //    SELECT
//    LOWER(user_tab_columns.column_name) AS "Field",
//    user_col_comments.comments AS "Comment",
//    LOWER(user_tab_columns.table_name) AS "TableName",
//            case when user_tab_columns.data_type='DATE'
//    then 'date' else CONCAT(CONCAT(CONCAT(LOWER(user_tab_columns.data_type),'('), user_tab_columns.data_length ),')') end as "Type",
//            case when user_tab_columns.nullable='N' then 'NO' else  'YES' end AS "Null",
//            case when LOWER(user_tab_columns.column_name)='id'  then 'PRI' else  '' end AS "Key"
//    user_tab_columns.data_default AS "Default",
//    user_tab_columns.DATA_SCALE AS "field_scale"
//    FROM user_tab_columns join user_col_comments
//    on user_tab_columns.table_name=user_col_comments.table_name
//    and user_tab_columns.column_name=user_col_comments.column_name and user_tab_columns.table_name='lcgl_order_b'
    protected static String oracleColMetaSql = "    SELECT\n" +
            "    LOWER(user_tab_columns.column_name) AS \"Field\",\n" +
            "    user_col_comments.comments AS \"Comment\",\n" +
            "    LOWER(user_tab_columns.table_name) AS \"TableName\",\n" +
            "            case when user_tab_columns.data_type='DATE'\n" +
            "    then 'date' else CONCAT(CONCAT(CONCAT(LOWER(user_tab_columns.data_type),'('), user_tab_columns.data_length ),')') end as \"Type\",\n" +
            "    case when user_tab_columns.nullable='N' then 'NO' else  'YES' end AS \"Null\",\n" +
            "            case when LOWER(user_tab_columns.column_name)='id'  then 'PRI' else  '' end AS \"Key\",\n" +
            "    user_tab_columns.data_default AS \"Default\",\n" +
            "    user_tab_columns.DATA_SCALE AS \"field_scale\"\n" +
            "    FROM user_tab_columns join user_col_comments\n" +
            "    on user_tab_columns.table_name=user_col_comments.table_name\n" +
            "    and user_tab_columns.column_name=user_col_comments.column_name ";

    protected static String oracleSingleTableColMetaSql = "    SELECT\n" +
            "    LOWER(user_tab_columns.column_name) AS \"Field\",\n" +
            "    user_col_comments.comments AS \"Comment\",\n" +
            "    LOWER(user_tab_columns.table_name) AS \"TableName\",\n" +
            "            case when user_tab_columns.data_type='DATE'\n" +
            "    then 'date' else CONCAT(CONCAT(CONCAT(LOWER(user_tab_columns.data_type),'('), user_tab_columns.data_length ),')') end as \"Type\",\n" +
            "    case when user_tab_columns.nullable='N' then 'NO' else  'YES' end AS \"Null\",\n" +
            "            case when LOWER(user_tab_columns.column_name)='id'  then 'PRI' else  '' end AS \"Key\",\n" +
            "    user_tab_columns.data_default AS \"Default\",\n" +
            "    user_tab_columns.DATA_SCALE AS \"field_scale\"\n" +
            "    FROM user_tab_columns join user_col_comments\n" +
            "    on user_tab_columns.table_name=user_col_comments.table_name\n" +
            "    and user_tab_columns.column_name=user_col_comments.column_name and user_tab_columns.table_name='#table_name'";


//    select convert(varchar, comm.text) as [Default], convert(varchar(128), soTb.name)  as TableName , convert(varchar(128), col.name)  as Field,
//    convert(varchar, prop.value)  as Comment,convert(varchar,case when col.is_nullable=1 then  convert(varchar,'YES')  else  convert(varchar, 'NO') end )  as [Null],
//            case when col.name=pk.column_name then  convert(varchar,'PKI')  else  convert(varchar, '') end as [Key],
//            case when c.name='date' then convert(varchar, c.name )
//    when c.name='datetime' then convert(varchar, c.name )
//    when c.name='decimal' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+','+convert(varchar, col.scale)+')') )
//    when c.name='numeric' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+','+convert(varchar, col.scale)+')') )
//            else convert(varchar, (c.name+'('+ convert(varchar, col.max_length)+')') ) end as [Type],
//    col.scale as 'field_scale'
//    from dbo.sysobjects soTb
//    INNER JOIN sys.columns col ON col.object_id = soTb.id
//    JOIN systypes c on col.system_type_id=c.xtype and c.xtype = c.xusertype
//    LEFT JOIN sys.extended_properties prop
//    ON prop.major_id = col.object_id and (prop.minor_id=col.column_id or prop.minor_id is null)
//    left join dbo.syscomments comm on col.default_object_id=comm.id
//    left join  (
//            select o.name as tbname,c.name as column_name from sysindexes i
//            join sysindexkeys k on i.id = k.id and i.indid = k.indid
//            join sysobjects o on i.id = o.id
//            join syscolumns c on i.id=c.id and k.colid = c.colid
//            where o.xtype = 'U'
//            and exists(select 1 from dbo.sysobjects where xtype = 'PK' and name = i.name)
//)pk on pk.tbname=soTb.name and pk.column_name=col.name
//    where soTb.xtype='U' and c.name!='sysname' and soTb.name='lcgl_order_b'

    protected static String sqlserverColMetaSql = "    select  convert(varchar, comm.text) as [Default], convert(varchar(128), soTb.name)  as TableName , convert(varchar(128), col.name)  as Field,\n" +
            "    convert(varchar, prop.value)  as Comment,convert(varchar,case when col.is_nullable=1 then  convert(varchar,'YES')  else  convert(varchar, 'NO') end )  as [Null],\n" +
            "            case when col.name=pk.column_name then  convert(varchar,'PKI')  else  convert(varchar, '') end as [Key],\n" +
            "            case when c.name='date' then convert(varchar, c.name )\n" +
            "    when c.name='datetime' then convert(varchar, c.name )\n" +
            "    when c.name='bigint' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+')'))\n" +
            "    when c.name='decimal' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+','+convert(varchar, col.scale)+')') )\n" +
            "    when c.name='numeric' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+','+convert(varchar, col.scale)+')') )\n" +
            "            else convert(varchar, (c.name+'('+ convert(varchar, col.max_length)+')') ) end as [Type],\n" +
            "    col.scale as 'field_scale' \n"+
            "    from dbo.sysobjects soTb\n" +
            "    INNER JOIN sys.columns col ON col.object_id = soTb.id\n" +
            "    JOIN systypes c on col.system_type_id=c.xtype and c.xtype = c.xusertype\n" +
            "    LEFT JOIN sys.extended_properties prop\n" +
            "    ON prop.major_id = col.object_id and (prop.minor_id=col.column_id or prop.minor_id is null)\n" +
            "    left join dbo.syscomments comm on col.default_object_id=comm.id\n" +
            "    left join  (\n" +
            "            select o.name as tbname,c.name as column_name from sysindexes i\n" +
            "            join sysindexkeys k on i.id = k.id and i.indid = k.indid\n" +
            "            join sysobjects o on i.id = o.id\n" +
            "            join syscolumns c on i.id=c.id and k.colid = c.colid\n" +
            "            where o.xtype = 'U'\n" +
            "            and exists(select 1 from dbo.sysobjects where xtype = 'PK' and name = i.name)\n" +
            ")pk on pk.tbname=soTb.name and pk.column_name=col.name\n" +
            "    where soTb.xtype='U' and c.name!='sysname' ";


    protected static String sqlserverSingleTableColMetaSql = "    select  convert(varchar, comm.text) as [Default], convert(varchar(128), soTb.name)  as TableName , convert(varchar(128), col.name)  as Field,\n" +
            "    convert(varchar, prop.value)  as Comment,convert(varchar,case when col.is_nullable=1 then  convert(varchar,'YES')  else  convert(varchar, 'NO') end )  as [Null],\n" +
            "            case when col.name=pk.column_name then  convert(varchar,'PKI')  else  convert(varchar, '') end as [Key],\n" +
            "            case when c.name='date' then convert(varchar, c.name )\n" +
            "    when c.name='datetime' then convert(varchar, c.name )\n" +
            "    when c.name='text' then convert(varchar, c.name )\n "+
            "    when c.name='bigint' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+')'))\n" +
            "    when c.name='decimal' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+','+convert(varchar, col.scale)+')') )\n" +
            "    when c.name='numeric' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+','+convert(varchar, col.scale)+')') )\n" +
            "            else convert(varchar, (c.name+'('+ convert(varchar, col.max_length)+')') ) end as [Type],\n" +
            "    col.scale as 'field_scale' \n"+
            "    from dbo.sysobjects soTb\n" +
            "    INNER JOIN sys.columns col ON col.object_id = soTb.id\n" +
            "    JOIN systypes c on col.system_type_id=c.xtype and c.xtype = c.xusertype\n" +
            "    LEFT JOIN sys.extended_properties prop\n" +
            "    ON prop.major_id = col.object_id and (prop.minor_id=col.column_id or prop.minor_id is null)\n" +
            "    left join dbo.syscomments comm on col.default_object_id=comm.id\n" +
            "    left join  (\n" +
            "            select o.name as tbname,c.name as column_name from sysindexes i\n" +
            "            join sysindexkeys k on i.id = k.id and i.indid = k.indid\n" +
            "            join sysobjects o on i.id = o.id\n" +
            "            join syscolumns c on i.id=c.id and k.colid = c.colid\n" +
            "            where o.xtype = 'U'\n" +
            "            and exists(select 1 from dbo.sysobjects where xtype = 'PK' and name = i.name)\n" +
            ")pk on pk.tbname=soTb.name and pk.column_name=col.name\n" +
            "    where soTb.xtype='U' and c.name!='sysname' and soTb.name='#table_name' ";

//    select table_name as 'TableName',
//    column_name as 'Field',is_nullable as 'Null',
//    collation_name as 'Collation',substring_index(column_type,' ',1) as 'Type',
//    column_key as 'Key',column_comment as 'Comment',
//    COLUMN_DEFAULT as 'Default'
//    from information_schema.COLUMNS where table_schema = 'ksm_dev' and table_name='lcgl_order_b';

    protected static String mysqlColMetaSql = "select table_name as 'TableName',\n" +
            "column_name as 'Field',is_nullable as 'Null',\n" +
            "collation_name as 'Collation',substring_index(column_type,' ',1) as 'Type',\n" +
            "column_key as 'Key',left(column_comment, 200) as 'Comment',\n" +
            "COLUMN_DEFAULT  as 'Default',\n" +
            "NUMERIC_SCALE as 'field_scale' \n"+
            "from information_schema.COLUMNS where table_schema = '#table_schema'";

    protected static String mysqlSingleTableColMetaSql = "select table_name as 'TableName',\n" +
            "column_name as 'Field',is_nullable as 'Null',\n" +
            "collation_name as 'Collation',column_type as 'Type',\n" +
            "column_key as 'Key',left(column_comment, 200) as 'Comment',\n" +
            "COLUMN_DEFAULT  as 'Default',\n" +
            "NUMERIC_SCALE as 'field_scale' \n"+
            "from information_schema.COLUMNS where table_schema = '#table_schema' and table_name='#table_name' ";

    protected static String mysqlTableMetaSql = "select table_name as 'Name' ,table_comment as 'Comment'  from information_schema.TABLES where table_schema = '#table_schema' and table_type ='BASE TABLE'";

    protected static String sqlserverTableMetaSql = "select * from (SELECT  convert(varchar(200), A.name) AS Name,  convert(varchar(200), C.value) AS Comment FROM sys.tables A LEFT JOIN sys.extended_properties C ON C.major_id = A.object_id AND C.minor_id = 0)a";

    protected static String oracleTableMetaSql = "select LOWER(TABLE_NAME) AS \"Name\",COMMENTS AS \"Comment\" from user_tab_comments ";


}
