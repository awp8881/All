//package com.qzsoft.common.activerecord;
//
//import com.google.common.collect.Lists;
//import com.google.common.collect.Maps;
//import com.google.common.collect.Sets;
//import com.jfinal.plugin.activerecord.Config;
//import com.jfinal.plugin.activerecord.Db;
//import com.jfinal.plugin.activerecord.DbKit;
//import com.jfinal.plugin.activerecord.Record;
//import com.qzsoft.common.exception.BusinessException;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang.SerializationUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.io.Serializable;
//import java.sql.SQLException;
//import java.util.*;
//import java.util.concurrent.ConcurrentHashMap;
//
///**
// * @author pjh
// * @Title: DbMeta
// * @Description: 数据库元数据，系统启动时将数据库表与列的元数据加入缓存，
// *               数据库发生变更时如刷新数据需要从新加载元数据
// * @date 2018/11/22 14:41
// */
//@Slf4j
//public class DbMeta {
//
//    private final Map<String,List<Record>> colMetaMap = new ConcurrentHashMap();
//    private final List<Record> tableMetaList = Lists.newArrayList();
//    private String dataSourceName = "";
//
//    private DbMeta(){
//
//    }
//
//    /**
//     * 列的元数据  历史遗留问题
//     * 采用mysql的show full COLUMNS from查询结果字段命名
//     * 目前存在的字段
//     * private String TableName;
//     * private String Field;
//     * private String Null;
//     * private String Collation;//对于字符集而言，目前只实现了mysql有字符集  其它未做
//     * private String Type;
//     * private String Key;
//     * private String Comment;
//     */
//    protected List<Record> getColMetaByTableName(String tableName) {
////        List<Record> cacheRecordList = colMetaMap.get(tableName);
////        List<Record> tempRecordList = new ArrayList<>();
////        if( null!=cacheRecordList ){
////            for( Record cacheRecord : cacheRecordList ){
////                tempRecordList.add((Record) SerializationUtils.clone( cacheRecord ));
////            }
////            return tempRecordList;
////        }
////        return cacheRecordList;
//        return colMetaMap.get(tableName);
//    }
//
//    protected Set<String> getTableName( ) {
//        return  Sets.newHashSet(colMetaMap.keySet());
//    }
//
//
//    protected synchronized static DbMeta createDbMetaByDataSourceName(String dataSourceName) {
//        DbMeta dbMeta = new DbMeta();
//        dbMeta.dataSourceName = dataSourceName;
//        dbMeta.initDbMeta( );
//        return dbMeta;
//    }
//
//    protected void initDbMeta( ){
//        initTableMetaMap( );
//        initColMetaMap( );
//    }
//
//    private void initTableMetaMap() {
//        String colMetaSql = getTableMetaSql( dataSourceName );
//        if(StringUtils.isBlank( colMetaSql )){
//            return ;
//        }
//        tableMetaList.addAll( Db.use(dataSourceName).find(colMetaSql) );
//    }
//
//    private String getTableMetaSql(String dataSourceName) {
//        if( DbEx.isMysql(dataSourceName) ){
//            String table_schema = "";
//            try {
//                String url = DbKit.getConfig().getConnection().getMetaData().getURL();
////                jdbc:mysql://192.168.2.225:3307/ksm_dev?
//                url = url.split("\\?")[0];
//                table_schema = url.substring( url.lastIndexOf('/')+1 );
//            } catch (SQLException e) {
//                log.error( e.getMessage(),e );
//                BusinessException.throwBiz("初始化数据出错,请联系系统人员");
//            }
//            return DbMetaQuerySql.mysqlTableMetaSql.replace("#table_schema", table_schema);
//        }
//        if( DbEx.isSqlserver(dataSourceName) ){
//            return DbMetaQuerySql.sqlserverTableMetaSql;
//        }
//        if( DbEx.isOracle(dataSourceName) ){
//            return DbMetaQuerySql.oracleTableMetaSql;
//        }
//        return "";
//    }
//
//    /**
//     * 初始化列的元数据
//     */
//    private void initColMetaMap( ) {
//        String colMetaSql = getColMetaSql( dataSourceName );
//        if(StringUtils.isBlank( colMetaSql )){
//            return ;
//        }
//        List<Record> colMetaRecordList = null;
//        if( StringUtils.isBlank( dataSourceName ) ){
//            colMetaRecordList = Db.find(colMetaSql);
//        }else{
//            colMetaRecordList = Db.use(dataSourceName).find(colMetaSql);
//        }
//        if( null==colMetaRecordList ){
//            return ;
//        }
//        Map<String,List<Record>> tempColMetaMap = new HashMap<>();
//        for( Record colMetaRecord : colMetaRecordList ){
//            String tableName = colMetaRecord.getStr("TableName");
//            List<Record> recordList = tempColMetaMap.get(tableName);
//            if( null==recordList ){
//                recordList = new ArrayList<>();
//            }
//            recordList.add( colMetaRecord );
//            tempColMetaMap.put( tableName, recordList );
//        }
//        colMetaMap.putAll( tempColMetaMap );
//        log.info("初始化列的元数据完成,元数据条数{}",colMetaMap.size());
//    }
//
//
//
//    private String getColMetaSql(String dataSourceName) {
//        if( DbEx.isMysql(dataSourceName) ){
//            //获取mysql对于的table_schema
//            String table_schema = "";
//            try {
//                String url = DbKit.getConfig().getConnection().getMetaData().getURL();
////                jdbc:mysql://192.168.2.225:3307/ksm_dev?
//                url = url.split("\\?")[0];
//                table_schema = url.substring( url.lastIndexOf('/')+1 );
//            } catch (SQLException e) {
//                log.error( e.getMessage(),e );
//                BusinessException.throwBiz("初始化数据出错,请联系系统人员");
//            }
//            return DbMetaQuerySql.mysqlColMetaSql.replace("#table_schema", table_schema);
//        }
//        if( DbEx.isSqlserver(dataSourceName) ){
//            return DbMetaQuerySql.sqlserverColMetaSql;
//        }
//        if( DbEx.isOracle(dataSourceName) ){
//            return DbMetaQuerySql.oracleColMetaSql;
//        }
//        return "";
//    }
//
//    public Map<String,List<Record>> getColMetaMap(){
////        return (Map<String, List<Record>>) SerializationUtils.clone((Serializable) colMetaMap);
//        return colMetaMap;
//    }
//    public List<Record> getTableMetaRecordList(){
////        return (List<Record>) SerializationUtils.clone((Serializable) tableMetaList);
//        return tableMetaList;
//    }
//
//}
//
