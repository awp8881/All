//package com.qzsoft.common.mvc.filter;
//
//import java.io.IOException;
//
//import javax.servlet.Filter;
//import javax.servlet.FilterChain;
//import javax.servlet.FilterConfig;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.util.ObjectUtils;
//
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONArray;
//import com.qzsoft.common.constants.CommonConstants;
//import com.qzsoft.common.tools.CurrentUser;
//import com.qzsoft.common.tools.Utils;
//
//@WebFilter(urlPatterns = "/*")
//public class NewLoginSessionFilter implements Filter {
//
//	@Autowired
//	private RedisTemplate<Object, Object> redisTemplate;
//
//	@Override
//	public void init(FilterConfig filterConfig) throws ServletException {
//		// TODO Auto-generated method stub
//
//	}
//
//	@Override
//	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
//			throws IOException, ServletException {
//		HttpServletRequest httpRequest = (HttpServletRequest) request;
//		HttpSession session = httpRequest.getSession();
//		Object username = session.getAttribute("username");
//	    Object JID = httpRequest.getParameter("JID");
//		if(JID != null && username != null){
//			Object newusername = redisTemplate.opsForValue().get(Utils.loginNameKeyOfRedis(JID.toString()));
//			if(newusername !=null && !newusername.equals(username)){
//				Object menuFeList = redisTemplate.opsForValue().get(Utils.menuFeListKeyOfRedis(newusername.toString()));
//				if(!ObjectUtils.isEmpty(menuFeList)){
//					JSONArray menu = JSON.parseArray(menuFeList.toString());
//					session.setAttribute(CommonConstants.MENU_FE_LIST_KEY, menu);
//				}
//				session.setAttribute("JID", JID.toString());
//				session.setAttribute("username", newusername.toString());
//			}else{
//				session.setAttribute("JID", JID.toString());
//				session.setAttribute("username", username.toString());
//			}
//		}
//
//		chain.doFilter(request, response);
//	}
//
//	@Override
//	public void destroy() {
//		CurrentUser.remove();
//	}
//
//}
