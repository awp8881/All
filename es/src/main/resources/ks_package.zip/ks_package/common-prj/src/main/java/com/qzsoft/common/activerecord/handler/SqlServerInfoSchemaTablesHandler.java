package com.qzsoft.common.activerecord.handler;

import com.qzsoft.common.activerecord.AbstractSpecialSqlHandler;

/**
 * @author pjh
 * @Title: SqlServerInfoSchemaTablesHandler
 * @Description: 处理特殊sql  INFORMATION_SCHEMA.TABLES
 * @date 2018/7/12 18:07
 */
public class SqlServerInfoSchemaTablesHandler extends AbstractSpecialSqlHandler {
    @Override
    public String handlerSQL(String sql) {
        return sql;
    }
}
