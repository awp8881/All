package com.qzsoft.common.tools;

import java.lang.reflect.Field;

import com.qzsoft.common.exception.BusinessException;

import com.qzsoft.common.http.QzAESCryptoUtils;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.util.Assert;

/**
 * 通过swagger注解验证字段是否必填
 * */
public class ValidateIsNullUtil {
	
	/**
	 * 注解验证是否必填
	 * */
	public static <T> void validateIsNull(Object obj){
		if(null == obj){
			BusinessException.throwBiz(11003, "参数");
		}
		Class<? extends Object> clz = obj.getClass();
        // 判断类上是否有此注解  
//        boolean clzHasAnno = clz.isAnnotationPresent(ApiModel.class);  
//        if (clzHasAnno) {  
//            // 获取类上的注解  
//        	ApiModel annotation = clz.getAnnotation(ApiModel.class);  
//            // 输出注解上的属性  
//            String value = annotation.value();  
//            String description = annotation.description();  
//        }  
        
        // 解析字段上是否有注解  
        Field[] fields = clz.getDeclaredFields();  
        for(Field field : fields){  
        	field.setAccessible(true);
            boolean fieldHasAnno = field.isAnnotationPresent(ApiModelProperty.class);
            if (!fieldHasAnno) {
				continue;
			}
        	ApiModelProperty fieldAnno = field.getAnnotation(ApiModelProperty.class);  
            //输出注解属性  
            Boolean isRequired = fieldAnno.required();  
            Object value;
			try {
				value = field.get(obj);
				String desc = fieldAnno.value();
				if(isRequired && null == value){
	              BusinessException.throwBiz(11003, desc);
	           }
			} catch (IllegalArgumentException | IllegalAccessException e) {
				BusinessException.throwBiz(10001);
			}
               
        }  
        
        
        //解析方法上的注解  
//        Method[] methods = clz.getDeclaredMethods();  
//        for(Method method : methods){  
//        }  
	}
}
