package com.qzsoft.common.tools;

import com.qzsoft.common.log.OptLogBean;

/**
 * @author pjh
 * @Title: OptLogUtil
 * @Description: TODO
 * @date 2018/11/7 15:11
 */
public class OptLogUtil {

    private static ThreadLocal<OptLogBean> optLogBeanLocal = new ThreadLocal<>();

    public static void setOptLogBean( OptLogBean optLogBean ){
        optLogBeanLocal.set( optLogBean );
    }

    public static void cleanOptLogBean( ){
        optLogBeanLocal.remove();
    }

    public static OptLogBean getOptLogBean( ){
        return optLogBeanLocal.get();
    }

}
