package com.qzsoft.common.activerecord.handler;

import com.qzsoft.common.activerecord.AbstractSpecialSqlHandler;
import org.apache.commons.lang3.StringUtils;

/**
 * @author pjh
 * @Title: SqlServerShowFullColHandler
 * @Description: 处理 特殊sql  SHOW FULL COLUMNS
 * @date 2018/7/12 18:07
 */
public class SqlServerShowFullColHandler extends AbstractSpecialSqlHandler {



//    select convert(varchar(128), col.name)  as Field,
//    convert(varchar, prop.value)  as Comment,convert(varchar,case when col.is_nullable=1 then  convert(varchar,'YES')  else  convert(varchar, 'NO') end )  as [Null],
//            case when col.name=pk.column_name then  convert(varchar,'PKI')  else  convert(varchar, '') end as [Key],
//            case when c.name='date' then convert(varchar, c.name )
//    when c.name='datetime' then convert(varchar, c.name )
//    when c.name='decimal' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+','+convert(varchar, col.scale)+')') )
//            else convert(varchar, (c.name+'('+ convert(varchar, col.max_length)+')') ) end as [Type]
//    from dbo.sysobjects soTb
//    INNER JOIN sys.columns col ON col.object_id = soTb.id
//    JOIN systypes c on col.system_type_id=c.xtype
//    LEFT JOIN sys.extended_properties prop
//    ON prop.major_id = col.object_id and (prop.minor_id=col.column_id or prop.minor_id is null)
//    left join  (
//            select o.name as tbname,c.name as column_name from sysindexes i
//            join sysindexkeys k on i.id = k.id and i.indid = k.indid
//            join sysobjects o on i.id = o.id
//            join syscolumns c on i.id=c.id and k.colid = c.colid
//            where o.xtype = 'U'
//            and exists(select 1 from dbo.sysobjects where xtype = 'PK' and name = i.name)
//)pk on pk.tbname=soTb.name and pk.column_name=col.name
//    where soTb.xtype='U' and c.name!='sysname' and soTb.name='##_##'

    private static final String  SHOW_FULL_COLUMNS_FROM = "(?i)SHOW FULL COLUMNS FROM";
    private static final String  EQUIVALENCE_SQL = "  select convert(varchar(128), col.name)  as Field,\n" +
            "    convert(varchar, prop.value)  as Comment,convert(varchar,case when col.is_nullable=1 then  convert(varchar,'YES')  else  convert(varchar, 'NO') end )  as [Null],\n" +
            "            case when col.name=pk.column_name then  convert(varchar,'PRI')  else  convert(varchar, '') end as [Key],\n" +
            "            case when c.name='date' then convert(varchar, c.name )\n" +
            "    when c.name='datetime' then convert(varchar, c.name )\n" +
            "    when c.name='bigint' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+')'))\n" +
            "    when c.name='decimal' then convert(varchar, (c.name+'('+ convert(varchar, col.precision)+','+convert(varchar, col.scale)+')') )\n" +
            "            else convert(varchar, (c.name+'('+ convert(varchar, col.max_length)+')') ) end as [Type]\n" +
            "    from dbo.sysobjects soTb\n" +
            "    INNER JOIN sys.columns col ON col.object_id = soTb.id\n" +
            "    JOIN systypes c on col.system_type_id=c.xtype\n" +
            "    LEFT JOIN sys.extended_properties prop\n" +
            "    ON prop.major_id = col.object_id and (prop.minor_id=col.column_id or prop.minor_id is null)\n" +
            "    left join  (\n" +
            "            select o.name as tbname,c.name as column_name from sysindexes i\n" +
            "            join sysindexkeys k on i.id = k.id and i.indid = k.indid\n" +
            "            join sysobjects o on i.id = o.id\n" +
            "            join syscolumns c on i.id=c.id and k.colid = c.colid\n" +
            "            where o.xtype = 'U'\n" +
            "            and exists(select 1 from dbo.sysobjects where xtype = 'PK' and name = i.name)\n" +
            ")pk on pk.tbname=soTb.name and pk.column_name=col.name\n" +
            "    where soTb.xtype='U' and c.name!='sysname' and soTb.name='##_##' ";

    @Override
    public String handlerSQL(String sql) {

        //获取查询参数
        String[] splits = sql.split(SHOW_FULL_COLUMNS_FROM);
        sql = EQUIVALENCE_SQL.replaceAll("##_##",splits[1].trim());

        return sql;
    }
}
