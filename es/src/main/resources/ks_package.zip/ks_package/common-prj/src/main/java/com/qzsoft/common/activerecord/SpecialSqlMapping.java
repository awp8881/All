package com.qzsoft.common.activerecord;

import com.google.common.base.CharMatcher;
import com.jfinal.plugin.activerecord.Config;
import com.jfinal.plugin.activerecord.DbKit;
import com.jfinal.plugin.activerecord.dialect.Dialect;
import com.jfinal.plugin.activerecord.dialect.MysqlDialect;
import com.jfinal.plugin.activerecord.dialect.OracleDialect;
import com.jfinal.plugin.activerecord.dialect.SqlServerDialect;
import com.qzsoft.common.activerecord.handler.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author pjh
 * @Title: SpecialSqlMapping
 * @Description: 将特殊sql映射到特殊sql处理器
 * @date 2018/7/12 15:40
 */
public class SpecialSqlMapping {


    private static Map<String,AbstractSpecialSqlHandler> specialSqlHandlerMap = new ConcurrentHashMap<String, AbstractSpecialSqlHandler>();


    /**
     * 初始化映射器
     * @param dataSourceList
     */
    protected static void init( List<String> dataSourceList ){
        for( String dataSource : dataSourceList ){
            Config config = DbKit.getConfig(dataSource);
            Dialect dialect = config.getDialect();
            if( dialect instanceof MysqlDialect ){
                initMysql( );
            }
            if( dialect instanceof OracleDialect){
                initOracle( );
            }
            if( dialect instanceof SqlServerDialect ){
                initSqlserver( );
            }
        }
    }

    protected static void initMysql( ){

    }

    protected static void initOracle( ){
//        specialSqlHandlerMap.put("SHOW FULL COLUMNS",new OracleShowFullColHandler());
//        specialSqlHandlerMap.put("SHOW TABLE STATUS",new OracleShowTableStatusHandler());
    }

    protected static void initSqlserver( ){
//        specialSqlHandlerMap.put("SHOW FULL COLUMNS",new SqlServerShowFullColHandler());
//        specialSqlHandlerMap.put("SHOW TABLE STATUS",new SqlServerShowTableStatusHandler());
//        specialSqlHandlerMap.put("INFORMATION_SCHEMA.TABLES",new SqlServerInfoSchemaTablesHandler());
//        specialSqlHandlerMap.put("SHOW TABLES",new SqlServerShowTablesHandler());
//        specialSqlHandlerMap.put("LOCATE(",new SqlServerLocateFunHandler());
//        specialSqlHandlerMap.put("LOCATE (",new SqlServerLocateFunHandler());
    }

    /**
     * TODO 添加特殊sql处理器
     * @param specialSql
     * @param specialSqlHandler
     */
    public static void addAbstractSpecialSqlHandler( String specialSql, AbstractSpecialSqlHandler specialSqlHandler ){

        throw new RuntimeException("暂时不提供添加处理器方法");
    }

    /**
     * 格式化成标准sql（去掉中间多余空格，保留一个空格）
     * @param sql
     * @return
     */
    private static String formatStandardSQL( String sql ){
        //去掉中间多余空格，保留一个空格
        return CharMatcher.WHITESPACE.collapseFrom( sql, ' ');
    }

    public static List<AbstractSpecialSqlHandler> getSpecialSqlHandler(String sql ){
        List specialSqlHandlerList = new ArrayList<AbstractSpecialSqlHandler>();
        Set<String> specialSqls = specialSqlHandlerMap.keySet();
        sql = formatStandardSQL( sql );
        for( String specialSql: specialSqls ){
            if( sql.toUpperCase().contains( specialSql.toUpperCase() ) ){
                specialSqlHandlerList.add( specialSqlHandlerMap.get( specialSql ) );
            }
        }
        //如果是oracle添加默认处理
        if( DbEx.isOracle() ){
            specialSqlHandlerList.add( new OracleEqualOrNotEmptyHandler() );
        }
        return specialSqlHandlerList;
    }



}
