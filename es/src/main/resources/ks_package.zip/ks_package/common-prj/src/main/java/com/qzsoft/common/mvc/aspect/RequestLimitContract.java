package com.qzsoft.common.mvc.aspect;

import com.qzsoft.common.annotation.RequestLimit;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.exception.RequestLimitException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Timer;
import java.util.TimerTask;


/**

 @author yuanjun
 @time：
 @Discription： */
@Aspect
@Component
public class RequestLimitContract {
    private static final Logger logger = LoggerFactory.getLogger("requestLimitLogger");

    @Resource(name = "stringRedisTemplate")
    private RedisTemplate<String, Object> stringRedisTemplate;

   @Before("within(@org.springframework.web.bind.annotation.RestController *) && @annotation(limit)")
    public void requestLimit(final JoinPoint joinPoint , RequestLimit limit) throws RequestLimitException {
        try {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

            if (request == null) {
                throw new RequestLimitException("方法中缺失HttpServletRequest参数");
            }
            String ip = request.getLocalAddr();
            String url = request.getRequestURL().toString();
            String key = "req_limit_".concat(url).concat(ip);
            if (stringRedisTemplate.opsForValue().get(key) == null) {
                stringRedisTemplate.opsForValue().set(key, "1");
            } else {
                stringRedisTemplate.opsForValue().set(key, String.valueOf(Integer.parseInt(stringRedisTemplate.opsForValue().get(key).toString()) + 1));
            }
            int count = Integer.valueOf(stringRedisTemplate.opsForValue().get(key).toString());
            if (count > 0) {
                //创建一个定时器
                Timer timer = new Timer();
                TimerTask timerTask = new TimerTask() {
                    @Override
                    public void run() {
                        stringRedisTemplate.delete(key);
                    }
                };
                //这个定时器设定在time规定的时间之后会执行上面的remove方法，也就是说在这个时间后它可以重新访问
                timer.schedule(timerTask, limit.time());
            }
            if (count > limit.count()) {
                logger.error("用户IP[" + ip + "]访问地址[" + url + "]超过了限定的次数[" + limit.count() + "]");
                throw new BusinessException("访问超过了限定的次数,请稍后重试");
            }
        }catch (BusinessException e){
            throw e;
        }catch (Exception e){
            logger.error("发生异常",e);
        }
    }
}