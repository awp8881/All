package com.qzsoft.common.activerecord.handler;

import com.qzsoft.common.activerecord.AbstractSpecialSqlHandler;

/**
 * @author pjh
 * @Title: SqlServerShowTablesHandler
 * @Description: 处理特殊sql SHOW TABLES
 * @date 2018/7/12 18:08
 */
public class SqlServerShowTablesHandler extends AbstractSpecialSqlHandler {

    private static final String  SEPCIAL_SQL_REGULAR = "(?i)SHOW TABLES";

    //等价sql select * from (select name tbname from sysobjects where xtype = 'U')a
    private static final String  EQUIVALENCE_SQL = "select * from (select name tbname from sysobjects where xtype = 'U')a";


    @Override
    public String handlerSQL(String sql) {
        sql = sql.replaceAll( SEPCIAL_SQL_REGULAR,EQUIVALENCE_SQL );
        return sql;
    }
}
