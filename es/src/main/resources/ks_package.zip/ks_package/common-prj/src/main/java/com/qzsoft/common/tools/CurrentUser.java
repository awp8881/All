package com.qzsoft.common.tools;

import javax.servlet.http.HttpSession;

public class CurrentUser {
	private static ThreadLocal<HttpSession> local = new ThreadLocal<>();
	
	public static void set(HttpSession session){
		local.set(session);
	}
	
	public static HttpSession get(){
		return local.get();
	}
	
	public static void remove(){
		local.remove();
	}
}
