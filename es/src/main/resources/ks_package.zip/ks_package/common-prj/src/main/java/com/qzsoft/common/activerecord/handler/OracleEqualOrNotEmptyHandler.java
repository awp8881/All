package com.qzsoft.common.activerecord.handler;

import com.qzsoft.common.activerecord.AbstractSpecialSqlHandler;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author pjh
 * @Title: OracleEqualOrNotEmptyHandler
 * @Description: TODO
 * @date 2018/11/21 9:10
 */
public class OracleEqualOrNotEmptyHandler extends AbstractSpecialSqlHandler {


    private static final Pattern equalOrNotEmptySqlPattern = Pattern.compile("[!]?\\s?=\\s?''",Pattern.CASE_INSENSITIVE);

    @Override
    public String handlerSQL(String sql) {
        sql = handlerEqualOrNotEmptyForOracle(sql);
        return sql;
    }


    /**
     * 处理oracle =''  和 !=''
     * @param sql
     * @return
     */
    private static String handlerEqualOrNotEmptyForOracle(String sql) {

        //select * from ks_menu_c  where  id=430 and m_code is not null and m_code != ''

        Set<String> equalOrNotEmptySet = new HashSet<>();
        Matcher matcher = equalOrNotEmptySqlPattern.matcher( sql );
        while (matcher.find()) {
            String group = matcher.group();
            equalOrNotEmptySet.add( group.trim() );
        }
        for( String equalOrNotEmpty : equalOrNotEmptySet ){
            if( equalOrNotEmpty.contains("!") ){
                sql = sql.replace( equalOrNotEmpty, " is not null ");
            }else{
                sql = sql.replace( equalOrNotEmpty, " is null ");
            }
        }
        return sql;
    }
}
