package com.qzsoft.common.log;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.tools.OptLogUtil;

import java.util.List;

/**
 * @author pjh
 * @Title: OptLogServiceImpl
 * @Description: TODO
 * @date 2018/11/7 14:45
 */
public class OptLogServiceImpl extends OptLogService {

    @Override
    public boolean isRecordOpt(){
        return false;
    }

    @Override
    public String getOptUser( ) {
        return "";
    }

    @Override
    public void recordChange(OptLogBean optLogBean, List<Record> befourValue, List<Record> afterValue) {

    }

    @Override
    public void analysisChange(String batchNo) {

    }
}
