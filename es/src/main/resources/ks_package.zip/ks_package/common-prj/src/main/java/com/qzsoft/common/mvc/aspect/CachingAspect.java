package com.qzsoft.common.mvc.aspect;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.BoundHashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.qzsoft.common.annotation.CacheAvl;
import com.qzsoft.common.annotation.CacheDel;
import com.qzsoft.common.tools.Utils;

@Aspect
@Component
public class CachingAspect {

	@Autowired
	private RedisTemplate<Object, Object> redisTemplate;

	@Around("@annotation(com.qzsoft.common.annotation.CacheAvl) || @annotation(com.qzsoft.common.annotation.CacheDel)")
	public Object caching(ProceedingJoinPoint point) throws Throwable {

		if( true ){
			return point.proceed();
		}

		Signature signature = point.getSignature();
		Object[] params = point.getArgs();
		MethodSignature methodSignature = (MethodSignature) signature;
		Method targetMethod = methodSignature.getMethod();
		Object obj = null;
		CacheAvl cacheAvl = targetMethod.getAnnotation(CacheAvl.class);
		CacheDel cacheDel = targetMethod.getAnnotation(CacheDel.class);
		if (cacheAvl != null) {
			String key = cacheAvl.key();
			String hKey = cacheAvl.hKey();
			String value=cacheAvl.value();
			if (null != params && params.length > 0) {
				if (StringUtils.isNotEmpty(key) && key.startsWith("#")) {
					key = String.valueOf(params[0]);
				}
			}
			long timeout = cacheAvl.timeout();
			TimeUnit unit = cacheAvl.timeUnit();
			String dateStr = cacheAvl.expireAt();
			String format = cacheAvl.format();
			if (timeout > -1 && StringUtils.isBlank(key)) {
				throw new Exception("key, timeout必须同时设置。");
			}
			if (StringUtils.isNotBlank(dateStr) && StringUtils.isBlank(key)) {
				throw new Exception("key, expireAt必须同时设置。");
			}
			if (StringUtils.isNotBlank(dateStr) && StringUtils.isBlank(format)) {
				throw new Exception("expireAt, format必须同时设置。");
			}
			if (StringUtils.isBlank(key)) {
				key = point.getTarget().getClass().getName();
			}
			if (StringUtils.isBlank(hKey)) {
				String args = Arrays.toString(point.getArgs());
				hKey = signature.toLongString() + args;
			}
			if(StringUtils.isNotBlank(value)){
				key=value+":"+key;
			}
			BoundHashOperations<Object, Object, Object> boundHashOps = redisTemplate.boundHashOps(key);

			obj = boundHashOps.get(hKey);
			if (obj == null) {
				obj = point.proceed();
				boundHashOps.put(hKey, obj);

				if (timeout > -1) {
					boundHashOps.expire(timeout, unit);
				}
				if (StringUtils.isNotBlank(dateStr)) {
					Date date = Utils.str2Date(dateStr, format);
					boundHashOps.expireAt(date);
				}
			}

			// 默认情况下每调用一次后，更新有效期。
			if (timeout <= -1) {
				// 默认有效期，7天。
				timeout = 7;
				unit = TimeUnit.DAYS;
				boundHashOps.expire(timeout, unit);
			}
		} else if (cacheDel != null) {
			obj = point.proceed();
			String key = cacheDel.key();
			String value=cacheDel.value();
			if (StringUtils.isBlank(key)) {
				key = point.getTarget().getClass().getName();
			}
			if(StringUtils.isNotBlank(value)){
				key=value+":"+key;
			}
			redisTemplate.delete(key);

		} else {
			obj = point.proceed();
		}
		return obj;
	}

}
