//package com.qzsoft.common.mvc.configuration;
//
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import com.qzsoft.common.mvc.filter.NewLoginSessionFilter;
//import com.qzsoft.common.mvc.filter.SessionFilter;
//
//@Configuration
//public class FilterConfiguration {
//
//	@Bean
//    public FilterRegistrationBean myFilterRegistration() {
//        FilterRegistrationBean registration = new FilterRegistrationBean();
//        registration.setFilter(sessionFilter());
//        registration.addUrlPatterns("/biz/*");
////        registration.setOrder(Integer.MAX_VALUE);
//        return registration;
//    }
//
//
//	@Bean
//	public SessionFilter sessionFilter(){
//		return new SessionFilter();
//	}
//
//	@Bean
//	public NewLoginSessionFilter newLoginSessionFilter(){
//		return new NewLoginSessionFilter();
//	}
//}
