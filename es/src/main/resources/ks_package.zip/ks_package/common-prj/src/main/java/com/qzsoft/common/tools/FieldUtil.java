package com.qzsoft.common.tools;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class FieldUtil {


	public static String getFieldDesc( String tbName , String fieldName ) {
		List<Record> records = DbEx.find("select field_desc from ks_table_field_c where t_name=? and field_name=? and field_desc is not null and field_desc !='' ", tbName, fieldName);
		return records.isEmpty() ? "" : records.get(0).getStr( "field_desc" );
	}


}
