package com.qzsoft.common.log;

import com.google.common.base.CharMatcher;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.constants.OptTypeEnum;
import com.qzsoft.common.tools.OptLogUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public abstract class OptLogService {


    protected static final Logger log = LoggerFactory.getLogger( OptLogService.class );
    public OptLogBean getOptLogBean(){
        return OptLogUtil.getOptLogBean();
    }

    public abstract String getOptUser( );

    /**
     * 是否记录操作日志
     * @return
     */
    public boolean isRecordOpt(){
        OptLogBean optLogBean = OptLogUtil.getOptLogBean();
        return null!=optLogBean && optLogBean.getIsRecordOpt();
    }

    public void recordChange(String tableName, OptTypeEnum optType, List<Record> befourValue, List<Record> afterValue){
        if( befourValue.isEmpty() || afterValue.isEmpty() ){
            return;
        }
        OptLogBean optLogBean = OptLogUtil.getOptLogBean();
        String batchOrder = optLogBean.getBatchOrder();
        String batchOrderNew = (Integer.parseInt(batchOrder)+1) + "";
        optLogBean.setBatchOrder( batchOrderNew );
        optLogBean.setOptType( optType.type );
        optLogBean.setOptTable( tableName );
        OptLogUtil.setOptLogBean( optLogBean );
        recordChange( optLogBean, befourValue, afterValue );

    }


    /**
     * 请使用 Db对象操作数据库  不要使用DbEx对象否则会造成死循环
     * @param optLogBean
     * @param befourValue
     * @param afterValue
     */
    public abstract void recordChange(OptLogBean optLogBean, List<Record> befourValue, List<Record> afterValue );


    /**
     * //请使用 Db对象操作数据库  不要使用DbEx对象否则会造成死循环
     * @param batchNo
     */
    public abstract void analysisChange( String batchNo );


    public final void recordInsertChange(String tableName, List<Record> objects, List<Record> records){
        try{
            OptLogBean optLogBean = OptLogUtil.getOptLogBean();
            if( null!=optLogBean && optLogBean.getIsRecordOpt() ){
                recordChange( tableName, OptTypeEnum.INSERT, objects , records );
            }
        }catch ( Exception e ){
            log.error( e.getMessage(),e );
        }

    }

    public final void recordDelChange(String delSql,Object... paras) {

        try{
            OptLogBean optLogBean = OptLogUtil.getOptLogBean();
            if( null!=optLogBean && optLogBean.getIsRecordOpt() ){
                String tableName = getTableNameByDelSql( delSql,paras );
                List<Record> befourRecordList = getBefourRecordListByDelSql( delSql, paras );
                recordChange( tableName, OptTypeEnum.DELETE, befourRecordList , DbEx.getFixSizeList(befourRecordList.size()) );
            }
        }catch ( Exception e ){
            log.error( e.getMessage(),e );
        }

    }

    private String getTableNameByDelSql(String delSql,Object... paras) {
        if( StringUtils.isBlank(delSql) ){
            return delSql;
        }
        delSql = delSql.trim();
        delSql = CharMatcher.WHITESPACE.collapseFrom(delSql, ' ');
        String[] split = delSql.split(" ");
        if( "?".equals( split[2] ) ){
            return paras[0].toString();
        }
        return split[2];
    }

    private List<Record> getBefourRecordListByDelSql(String delSql,Object... paras) {
        String del2SelectSql = getDel2SelectSql(delSql);
        return Db.find( del2SelectSql, paras );
    }


    /**
     * @param delSql
     * @return
     */
    private String getDel2SelectSql(String delSql) {

        if( StringUtils.isBlank(delSql) ){
            return delSql;
        }
        String selectSql = delSql.replaceFirst("(?i)delete from"," select * from ");
        return selectSql;
    }

    public final void recordUpdateChange(String tableName, List<Record> befourRecordList,List<Record> afterRecordList) {

        try{
            OptLogBean optLogBean = OptLogUtil.getOptLogBean();
            if( null!=optLogBean && optLogBean.getIsRecordOpt() ){
                correctMapping(befourRecordList,afterRecordList);
                recordChange( tableName, OptTypeEnum.UPDATE, befourRecordList , afterRecordList );
            }
        }catch ( Exception e ){
            log.error( e.getMessage(),e );
        }
    }

    /**
     * 纠正映射关系  保证每个小标 id=id  如果不匹配创建新值
     * TODO 未完成
     * @param befourRecordList
     * @param afterRecordList
     */
    private void correctMapping(List<Record> befourRecordList, List<Record> afterRecordList) {

        Set<String> befourIdSet = getIdSet(befourRecordList);
        Set<String> afterIdSet = getIdSet(afterRecordList);

        Set<String> totalIdSet = new TreeSet<>();
        totalIdSet.addAll( befourIdSet );
        totalIdSet.addAll( afterIdSet );
        if( totalIdSet.size()==befourIdSet.size() && afterIdSet.size()==totalIdSet.size() ){
            return;
        }

        Map<String,Record> tempBefourRecordMap = getRecordIdAsKeyMap( befourRecordList );
        Map<String,Record> tempAfterRecordList = getRecordIdAsKeyMap( befourRecordList );

        List<Record> newBefourRecordList = new ArrayList<>();
        for( String totalId : totalIdSet ){
            Record record = tempBefourRecordMap.get(totalId);
            if( null!=record ){
                newBefourRecordList.add( record );
            }else{
                newBefourRecordList.add( new Record() );
            }
        }
        befourRecordList.clear();
        befourRecordList.addAll( newBefourRecordList );

        List<Record> newAfterRecordList = new ArrayList<>();
        for( String totalId : totalIdSet ){
            Record record = tempAfterRecordList.get(totalId);
            if( null!=record ){
                newAfterRecordList.add( record );
            }else{
                newAfterRecordList.add( new Record() );
            }
        }
        newAfterRecordList.clear();
        newAfterRecordList.addAll( afterRecordList );

    }

    private Map<String, Record> getRecordIdAsKeyMap(List<Record> recordList) {

        Map<String, Record> recordIdAsKeyMap = new HashMap<>();
        for( Record record : recordList ){
            Object id = record.get("id");
            if( null==id ){
                id = record.get("ID");
                if( null==id ){
                    id = record.get("Id");
                }
            }
            if( null==id ){
                continue;
            }
            recordIdAsKeyMap.put( id.toString(), record);
        }
        return recordIdAsKeyMap;
    }

    private Set<String> getIdSet(List<Record> recordList) {
        Set<String> idSet = new TreeSet<>();
        for( Record befourRecord : recordList ){
            Object id = befourRecord.get("id");
            if( null==id ){
                id = befourRecord.get("ID");
                if( null==id ){
                    id = befourRecord.get("Id");
                }
            }
            if( null==id ){
                continue;
            }
            idSet.add( id.toString() );
        }
        return idSet;
    }


    public final String getTableNameByUpdateSql(String updateSql,Object... paras) {
        if( StringUtils.isBlank(updateSql) ){
            return updateSql;
        }
        updateSql = CharMatcher.WHITESPACE.collapseFrom( updateSql.trim(), ' ');
        String[] split = updateSql.split(" ");
        if( "?".equals( split[1] ) && !"alter".equalsIgnoreCase( split[0] ) ){
            return paras[0].toString();
        }
        if( "alter".equalsIgnoreCase( split[0] ) ){
            return split[2];
        }

        return split[1];
    }



    public List<Record> getBefourRecordListByUpdateSql(String updateSql,Object... paras) {
        if( StringUtils.isBlank(updateSql) ){
            return  new ArrayList<>();
        }
        OptLogBean optLogBean = OptLogUtil.getOptLogBean();
        if( null==optLogBean || !optLogBean.getIsRecordOpt() ){
            return new ArrayList<>();
        }
        String tableName = getTableNameByUpdateSql(updateSql, paras);

        updateSql = CharMatcher.WHITESPACE.collapseFrom( updateSql.trim(), ' ');
        updateSql = updateSql.replaceFirst("(?i)where", "##_#_##");
        String[] split = updateSql.split("##_#_##");
        StringBuffer buffer = new StringBuffer("select * from ");
        buffer.append( tableName );
        buffer.append(" where ");
        buffer.append( split[1] );
        String selectSql = buffer.toString();
        if( null!=paras && paras.length>0 ){
            //获取where条件后的？的数量
            int wenHaoCount = getWenHaoCount( split[1] );
            Object[] newParas = new Object[wenHaoCount];
            if( paras.length>=wenHaoCount ){
                System.arraycopy(paras, paras.length-wenHaoCount, newParas, 0, wenHaoCount );
                paras = newParas;
            }
        }
        List<Record> recordList = Db.find(selectSql, paras);
        return recordList;
    }

    private int getWenHaoCount(String sql) {
        if( StringUtils.isBlank( sql ) ){
            return 0;
        }
        int wenHaoCount=0;
        char[] chars = sql.toCharArray();
        for( int i=0;i<chars.length;i++ ){
            if( chars[i]=='?' ){
                wenHaoCount++;
            }
        }
        return wenHaoCount;
    }
}
