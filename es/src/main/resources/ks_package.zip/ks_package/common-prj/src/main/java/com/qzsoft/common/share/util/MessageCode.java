package com.qzsoft.common.share.util;

/**
 * 报文处理结果码
 *
 */
public enum MessageCode {
	/**
	 * 成功
	 */
	SUCCESS,

	/**
	 * 失败
	 */
	FAIL
}
