package com.qzsoft.common.mvc.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;

import com.qzsoft.common.tools.CurrentUser;
import com.qzsoft.common.tools.Utils;

@WebFilter(urlPatterns = "/*")
public class SessionFilter implements Filter {
	
	private static final Logger LOG = LoggerFactory.getLogger(SessionFilter.class);
	
	@Autowired
	private RedisTemplate<Object, Object> redisTemplate;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpSession session = httpRequest.getSession();
		Object JID = session.getAttribute("JID");
		Object username = session.getAttribute("username");
		if(JID == null || username == null){
			JID = httpRequest.getParameter("JID");
			JID = this.getJessionIDFromCookie(httpRequest, JID);//兼容同域cookie传递
			if(JID != null){
				String key = Utils.loginNameKeyOfRedis(JID.toString());
				
				username = redisTemplate.opsForValue().get(key);
				if(username != null){
					session.setAttribute("JID", JID.toString());
					session.setAttribute("username", username.toString());
				}
			}
		}
		if(username != null){
			LOG.info("username:{}", username);
			Object user = redisTemplate.opsForValue().get(username);
			if(user != null){
				LOG.info("user:{}", user);
				session.setAttribute("user", user);
				CurrentUser.set(session);
			}else {
				LOG.info("session中未能获取到{}的用户信息！", username);
			}
		}else {
			LOG.info("session获取用户名失败！");
		}
		
		chain.doFilter(request, response); 
	}
	
	private Object getJessionIDFromCookie(HttpServletRequest req,Object JID){
		if( JID != null && !"".equals(JID)){
			return JID;
		}
		Cookie[] cookies = req.getCookies();
        if(cookies !=null ){
        	for(Cookie cookie : cookies){
        		if("JID".equals(cookie.getName())){
        			return cookie.getValue();
        		}
        	}
        }
        return JID;
	}

	@Override
	public void destroy() {
		CurrentUser.remove();
	}

}
