package com.qzsoft.common.tools;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.AntPathMatcher;

import java.util.List;

/**
 * @Description:
 * @author: zhouyou
 * @date: 2022/04/25 16:24
 **/
@Slf4j
public class UrlMatchUtil {


    /**
     * 检查集合url和接口路径是否匹配
     * @param list
     * @param urlPath
     * @return
     */
    public static boolean checkPath(List<String> list, String urlPath){
        if (list == null || list.isEmpty()){
            return false;
        }
        for (String urlPattern : list) {
            if (isMatch(urlPattern,urlPath)){
                return true;
            }
        }
        return false;
    }

    /**
     *
     * @param url 父
     * @param urlPath 子
     * @return
     */
    public static boolean isMatch(String url, String urlPath) {
        AntPathMatcher matcher = new AntPathMatcher();
        return matcher.match(url, urlPath);
    }

    public static void main(String[] args) {
        System.out.println(isMatch("/ks-prj/message/*", "/ks-prj/message/deleteMessageContent"));
    }
}
