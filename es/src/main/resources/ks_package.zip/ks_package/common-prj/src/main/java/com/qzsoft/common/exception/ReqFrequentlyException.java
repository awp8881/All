package com.qzsoft.common.exception;

import com.qzsoft.common.ui.RequestResult;

public class ReqFrequentlyException extends BusinessException {

    private RequestResult requestResult;

    public ReqFrequentlyException(RequestResult requestResult) {
        this.requestResult = requestResult;
    }

    public RequestResult getRequestResult() {
        return requestResult;
    }
}
