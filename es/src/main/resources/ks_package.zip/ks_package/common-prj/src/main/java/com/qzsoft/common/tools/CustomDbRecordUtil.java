package com.qzsoft.common.tools;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.qzsoft.common.activerecord.DbEx;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.converters.BigDecimalConverter;
import org.apache.commons.beanutils.converters.DoubleConverter;
import org.apache.commons.beanutils.converters.IntegerConverter;
import org.apache.commons.beanutils.converters.LongConverter;
import org.apache.commons.beanutils.converters.ShortConverter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ObjectUtils;

import com.alibaba.druid.support.logging.Log;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.DbKit;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.exception.BusinessException;

import lombok.extern.slf4j.Slf4j;

/**
 * 针对系统需求对Jfinal Db+record的一些方法操作类
 * @author zhz
 *
 */
@Slf4j
public class CustomDbRecordUtil {
	static {  
	    ConvertUtils.register(new LongConverter(null), Long.class);  
	    ConvertUtils.register(new ShortConverter(null), Short.class);  
	    ConvertUtils.register(new IntegerConverter(null), Integer.class);  
	    ConvertUtils.register(new DoubleConverter(null), Double.class);  
	    ConvertUtils.register(new BigDecimalConverter(null), BigDecimal.class);
	    ConvertUtils.register(new Converter()
        {
             
            @SuppressWarnings("rawtypes")
            @Override
            public Object convert(Class arg0, Object arg1)
            {
                if(arg1 == null)
                {
                    return null;
                }
                String str=StringUtil.toString(arg1);
                if(!str.contains("-")){
                	str= DateUtil.stampToDateStr(str,null);
                }
                str=str.split("\\.")[0];
                if(str.trim().equals(""))
                {
                    return null;
                }

                SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                try{
                    return sd.parse(str);
                }
                catch(Exception e)
                {
                    throw new RuntimeException(e);
                }

            }
             
        }, java.util.Date.class);
	} 
	/**
	 * 拼接乐观锁Sql
	 * @param tableName 表名
	 * @param pKeys	条件列名
	 * @param ids	条件对应的值
	 * @param record record对象
	 * @param sql 返回的sql对象
	 * @param paras 返回的参数值对象
	 */
	public static void updateRecordToSql(String tableName, String[] pKeys, Object[] ids, Record record, StringBuilder sql, List<Object> paras){
		tableName = tableName.trim();
		
		DbKit.getConfig().getDialect().trimPrimaryKeys(pKeys);
		
		//拼接sql
		sql.append("update ").append(tableName).append(" set ");
		for (Entry<String, Object> e: record.getColumns().entrySet()) {
			String colName = e.getKey();
			Object value=e.getValue();
			//判断列名是否等于条件列名 否则不予添加 （乐观锁列名除外）
			if (!DbKit.getConfig().getDialect().isPrimaryKey(colName, pKeys) || CommonConstants.UP_VERSION_COLUMN_NAME.equals(colName)) {
				if (paras.size() > 0 ) {
					sql.append(", ");
				}
				sql.append(colName).append(" = ? ");
				paras.add(e.getValue());
			}
		}
		//拼接条件
		sql.append(" where ");
		for (int i=0; i<pKeys.length; i++) {
			if (i > 0) {
				sql.append(" and ");
			}
			sql.append(pKeys[i]).append(" = ?");
			paras.add(ids[i]);
		}
	}
	/**
	 * 修改数据(乐观锁)
	 * @param primaryKey 条件列名(,号拆分,默认为prn和版本号列名)
	 * @param tableName 表名
	 * @param record 操作的record对象
	 * @return
	 */
	public static boolean updateByVersion(String primaryKey,String tableName,Record record){
		//String primaryKey = "id,"+CommonConstants.UP_VERSION_COLUMN_NAME;
		if(record == null){
			throw new BusinessException("操作数据对象为空。");
		}
		//如果主键为空 默认为id列和版本号列
		if(StringUtils.isBlank(primaryKey)){
			primaryKey = "id,"+CommonConstants.UP_VERSION_COLUMN_NAME;
		}
		String[] pKeys = primaryKey.split(",");
		List<String> notNullKeys = Lists.newArrayList();
		List<Object> notNullCondition = Lists.newArrayList();
		List<Object> paras = new ArrayList<Object>();
		for (int i=0; i<pKeys.length; i++) {
			Object condition = record.get(pKeys[i].trim());	// .trim() is important!
			if( condition == null && CommonConstants.UP_VERSION_COLUMN_NAME.equals( pKeys[i].trim() ) ){
				//更新数据版本
				record.set( CommonConstants.UP_VERSION_COLUMN_NAME, 1 );
				continue;
			}else{
				if (condition == null ){
					throw new BusinessException("更新数据失败, " + pKeys[i] + " 不能为空.");
				}
				if( CommonConstants.UP_VERSION_COLUMN_NAME.equals( pKeys[i].trim() ) ){
					//更新数据版本
					int ver_up = StringUtil.toInt(record.getStr(CommonConstants.UP_VERSION_COLUMN_NAME)) + 1;
					record.set( CommonConstants.UP_VERSION_COLUMN_NAME, ver_up );
				}
			}
			notNullKeys.add( pKeys[i].trim() );
			notNullCondition.add( condition );
		}
		StringBuilder sql = new StringBuilder();
		//拼接Sql
		updateRecordToSql(tableName, notNullKeys.stream().toArray(String[]::new) ,notNullCondition.toArray(),record,sql,paras);
		return DbEx.update(sql.toString(), paras.toArray()) >= 1;
	}
	
	/**
	 * 将实体集合数据 转换成Record对象集合
	 * @param list
	 * @return
	 */
	public static List<Record> getListRecord(List<?> list){
		if(list == null || list.size() == 0){
			throw new BusinessException("数据不能为空。");
		}
		List<Record> recordList = new ArrayList<>();
		for(int i=0;i<list.size();i++){
			recordList.add(getRecord(list.get(i)));
		}
		return recordList;
	}
	/**
     * 实体对象转成Record对象
     * @param obj 实体对象
     * @return
     */
    public static Record getRecord(Object obj) {
        Map<String, Object> map = new HashMap<>();
        if (obj == null) {
            return new Record();
        }
        Class<? extends Object> clazz = obj.getClass();
        Field[] fields = clazz.getDeclaredFields();
        try {
            for (Field field : fields) {
                field.setAccessible(true);
                String name=field.getName();
                Object object=field.get(obj);
				if (object == null) {
					continue;
				}
                if(null != name && !name.equals("serialVersionUID") && !name.equals("DEFAULT_INITIAL_CAPACITY") 
                		&& !name.equals("map") && !(field.getType() == List.class) ){
                	if(null != object && (name.equals("cr_dm") || name.equals("up_dm") )){
                		object=DateUtil.stampToDateStr(StringUtil.toString(object),null);
                	}
                	map.put(name, object);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Record().setColumns(map);
    }

    public static <T>  List<T> convertRecord2Class(Class<T> clazz, List<Record> records){
    	if (null == records || records.isEmpty()){
			Collections.emptyList();
		}
		List<T> list = Lists.newArrayList();
		for (Iterator<Record> iterator = records.iterator(); iterator.hasNext(); ) {
			Record record =  iterator.next();
			T obj = converModel(clazz, record);
			list.add( obj);
		}
		return list;

	}
    
    /**
     * Record 转 任意实例类
     * @return
     */
	public static <T> T converModel(Class<T> clazz, Record record){
		
			try {
				return	 convertMap(clazz, record.getColumns());
			} catch (Exception e) { 
				 e.printStackTrace();
			} 
			
		 return null;
		}
	
	public static <T> T convertMap(Class<T> type, Map<String, Object> map)  {
		T obj = null;
		try {
			obj = type.newInstance();
		
			// 获取类属性
			BeanInfo beanInfo = Introspector.getBeanInfo(type);
			// 给 JavaBean 对象的属性赋值
			PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
			for (int i = 0; i < propertyDescriptors.length; i++) {
				PropertyDescriptor descriptor = propertyDescriptors[i];
				String propertyName = descriptor.getName();
	
				if (map.containsKey(propertyName)) {
					String value = ConvertUtils.convert(map.get(propertyName));
					if(null == value){
						value="";
					}
					if(propertyName.equals("cr_dm") || propertyName.equals("up_dm")){
						value = DateUtil.stampToDateStr(value,null);
					}
					Object arg = ConvertUtils.convert(value, descriptor.getPropertyType());
					try {
						descriptor.getWriteMethod().invoke(obj, arg);
					} catch (IllegalArgumentException | InvocationTargetException e) {
						log.error("转换实体出错");
					}
				}
			}
		} catch (InstantiationException | IllegalAccessException  | IntrospectionException  e) {
			log.error("转换实体出错");
		}
		return obj;
		
	}
	
	/**
     * 单个字段in条件拼接 
     * */
    public static String getInSql(String column,List list){
    	StringBuffer sb=new StringBuffer("");
    	if(StringUtils.isNotBlank(column) && null != list && list.size() > 0){
    		sb.append(" and ").append(column).append(" in(");
    		for(int i=0;i < list.size();i++){
    			sb.append("?");
    			if(i != list.size()-1){
    				sb.append(",");
    			}
    		}
    		sb.append(")");
    	}
		return sb.toString();
    }
	
	
}
