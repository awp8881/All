package com.qzsoft.common.mvc.service;

import java.util.List;
import java.util.Map;

import com.qzsoft.common.vo.Table;

public interface SwaggerService {
	Map<String, List<Table>> tableList(String host) throws Exception;
}
