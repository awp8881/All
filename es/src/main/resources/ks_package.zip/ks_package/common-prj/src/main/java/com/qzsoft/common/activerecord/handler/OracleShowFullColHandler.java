package com.qzsoft.common.activerecord.handler;

import com.qzsoft.common.activerecord.AbstractSpecialSqlHandler;

/**
 * @author pjh
 * @Title: OracleShowFullColHandler
 * @Description: 处理 特殊sql  SHOW FULL COLUMNS
 * @date 2018/7/12 18:07
 */
public class OracleShowFullColHandler extends AbstractSpecialSqlHandler {

    //第一版关联取主键 效率低
//    SELECT
//    LOWER(user_tab_columns.column_name) AS "Field",
//    user_col_comments.comments AS "Comment",
//    LOWER(user_tab_columns.table_name) AS "table_name",
//
//            case when user_tab_columns.data_type='DATE'
//    then 'date' else CONCAT(CONCAT(CONCAT(LOWER(user_tab_columns.data_type),'('), user_tab_columns.data_length ),')') end as "Type",
//
//    case when user_tab_columns.nullable='N' then 'NO' else  'YES' end AS "Null",
//            case when main_key.column_name is not null then 'PRI' else  '' end AS "Key"
//
//    FROM user_tab_columns join user_col_comments
//    on user_tab_columns.table_name=user_col_comments.table_name
//    and user_tab_columns.column_name=user_col_comments.column_name
//    left join (
//            select col.table_name ,col.column_name
//            from user_constraints con join  user_cons_columns col
//                    on con.constraint_name = col.constraint_name
//                    and con.constraint_type='P'
//    )main_key on main_key.table_name=user_tab_columns.table_name
//    and main_key.column_name=user_tab_columns.column_name
//    where user_tab_columns.table_name='##_##'

//第二版默认id为主键

//    SELECT
//    LOWER(user_tab_columns.column_name) AS "Field",
//    user_col_comments.comments AS "Comment",
//    LOWER(user_tab_columns.table_name) AS "TableName",
//            case when user_tab_columns.data_type='DATE'
//    then 'date' else CONCAT(CONCAT(CONCAT(LOWER(user_tab_columns.data_type),'('), user_tab_columns.data_length ),')') end as "Type",
//    case when user_tab_columns.nullable='N' then 'NO' else  'YES' end AS "Null",
//            case when LOWER(user_tab_columns.column_name)='id'  then 'PRI' else  '' end AS "Key"
//    FROM user_tab_columns join user_col_comments
//    on user_tab_columns.table_name=user_col_comments.table_name
//    and user_tab_columns.column_name=user_col_comments.column_name
//    where user_tab_columns.table_name='##_##'


    private static final String  SHOW_FULL_COLUMNS_FROM = "(?i)SHOW FULL COLUMNS FROM";
    private static final String  EQUIVALENCE_SQL = "    SELECT\n" +
            "    LOWER(user_tab_columns.column_name) AS \"Field\",\n" +
            "    user_col_comments.comments AS \"Comment\",\n" +
            "    LOWER(user_tab_columns.table_name) AS \"table_name\",\n" +
            "            case when user_tab_columns.data_type='DATE'\n" +
            "    then 'date' else CONCAT(CONCAT(CONCAT(LOWER(user_tab_columns.data_type),'('), user_tab_columns.data_length ),')') end as \"Type\",\n" +
            "    case when user_tab_columns.nullable='N' then 'NO' else  'YES' end AS \"Null\",\n" +
            "            case when LOWER(user_tab_columns.column_name)='id'  then 'PRI' else  '' end AS \"Key\"\n" +
            "    FROM user_tab_columns join user_col_comments\n" +
            "    on user_tab_columns.table_name=user_col_comments.table_name\n" +
            "    and user_tab_columns.column_name=user_col_comments.column_name\n" +
            "    where user_tab_columns.table_name='##_##'";

    @Override
    public String handlerSQL(String sql) {

        //获取查询参数
        String[] splits = sql.split(SHOW_FULL_COLUMNS_FROM);
        sql = EQUIVALENCE_SQL.replaceAll("##_##",splits[1].trim().toUpperCase());

        return sql;
    }
}
