package com.qzsoft.common.activerecord;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Config;
import com.jfinal.plugin.activerecord.DbKit;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

@Slf4j
public class KsTransactionUtil {

    private static Set<String> failConfigName = Sets.newConcurrentHashSet();

    private static AtomicBoolean existTryCon = new AtomicBoolean(false);

    static {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleAtFixedRate(() -> {
            try {
                log.info("如果失败的数据库连接存在，就清空");
                Set<Map.Entry<String, Config>> configSet = getConfigSet();
                for (Map.Entry<String, Config> connConfigEntry : configSet) {
                    Config config = connConfigEntry.getValue();
                    if( failConfigName.contains( config.getName() ) && !existTryCon.get() ){
                        try {
                            existTryCon.set(true);
                            Connection conn = config.getConnection();
                            failConfigName.remove( config.getName() );
                        } catch (SQLException throwables) {
                            log.error(throwables.getMessage(), throwables);
                        }finally {
                            existTryCon.set(false);
                        }
                    }
                }
            }catch (Throwable t){
                log.error(t.getMessage(),t);
            }
        }, 5, 30, TimeUnit.MINUTES);
    }


    public static List<Connection> getExistConnectionList() {
        List<Connection> connectionList = Lists.newArrayList();
        Set<Map.Entry<String, Config>> configSet = getConfigSet();
        for (Map.Entry<String, Config> connConfigEntry : configSet) {
            Config config = connConfigEntry.getValue();
            Connection threadLocalConnection = config.getThreadLocalConnection();
            if( null!=threadLocalConnection ){
                connectionList.add(threadLocalConnection);
            }
        }
        return connectionList;
    }

    public static List<Connection> createConnectionList( JFinalTx jFinalTx ) throws SQLException {
        List<Connection> connectionList = Lists.newArrayList();
        Set<Map.Entry<String, Config>> configSet = getConfigSet();
        for (Map.Entry<String, Config> connConfigEntry : configSet) {
            Config config = connConfigEntry.getValue();
            try{
                //目前只做到添加失败的连接  定时清空失败的线程配置
                if( failConfigName.contains( config.getName() ) ){
                    if( !DataSourceHolder.getMasterDsNames().contains( config.getName() )  ){
                        log.warn("跳过失败连接:{}", config.getName());
                        continue;
                    }
                }
                Connection conn = config.getConnection();
                conn.setReadOnly( jFinalTx.readOnly() );
                config.setThreadLocalConnection(conn);
                conn.setTransactionIsolation(getTransactionLevel(config, jFinalTx));
                connectionList.add( conn );
            }catch (Throwable e){
                failConfigName.add( config.getName() );
                log.warn("目前失败数据源有：{}", failConfigName);
                log.error(e.getMessage(),e);
            }

        }
        return connectionList;
    }


    public static Set<Map.Entry<String, Config>> getConfigSet() {
        return DbKit.getConfigSet();
//        Set<String> masterDsNames = DataSourceHolder.getMasterDsNames();
//        Set<Map.Entry<String, Config>> configSet = DbKit.getConfigSet();
//        Set<Map.Entry<String, Config>> mainConfigSet = Sets.newHashSet();
//        for (Map.Entry<String, Config> connConfigEntry : configSet) {
//            Config config = connConfigEntry.getValue();
//            String name = config.getName();
//            if (masterDsNames.contains( name )) {
//                mainConfigSet.add( connConfigEntry );
//            }
//        }
//        if( mainConfigSet.isEmpty() ){
//            BusinessException.throwBiz( "数据源必须存在" );
//        }
//        return mainConfigSet;
    }

    public static void updateConnByJFinalTx( JFinalTx jFinalTx) throws SQLException {
        log.warn("目前失败数据源有：{}", failConfigName);
        Set<Map.Entry<String, Config>> configSet = getConfigSet();
        for (Map.Entry<String, Config> connConfigEntry : configSet) {
            Config config = connConfigEntry.getValue();
            //目前只做到添加失败的连接  定时清空失败的线程配置
            if( failConfigName.contains( config.getName() ) ){
                if( !DataSourceHolder.getMasterDsNames().contains( config.getName() )  ){
                    log.warn("跳过失败连接:{}", config.getName());
                    continue;
                }
            }
            Connection conn = config.getThreadLocalConnection();
            conn.setReadOnly( jFinalTx.readOnly() );
            int transactionIsolation = conn.getTransactionIsolation();
            if ( transactionIsolation < getTransactionLevel(config, jFinalTx))
                conn.setTransactionIsolation(getTransactionLevel(config, jFinalTx));
        }
    }

    public static void commitConn( List<Connection> connectionList )throws SQLException  {
        boolean isThrowEx = false;
        SQLException ex = null;
        for (Connection conn : connectionList) {
            try {
                conn.commit();
            } catch (SQLException e) {
                isThrowEx = true;
                log.error( e.getMessage(),e );
                ex = e;
            }
        }
        if( isThrowEx ){
            throw ex;
        }
    }

    public static void rollbackConn(List<Connection> connectionList)throws SQLException {
        boolean isThrowEx = false;
        SQLException ex = null;
        for (Connection conn : connectionList) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                isThrowEx = true;
                log.error( e.getMessage(),e );
                ex = e;
            }
        }
        if( isThrowEx ){
            throw ex;
        }
    }

    public static void closeConn(List<Connection> connectionList)throws SQLException {
        boolean isThrowEx = false;
        SQLException ex = null;
        for (Connection conn : connectionList) {
            try {
                conn.close();
            } catch (SQLException e) {
                isThrowEx = true;
                log.error( e.getMessage(),e );
                ex = e;
            }
        }
        if( isThrowEx ){
            throw ex;
        }
    }

    public static void removeConfThreadLocalConn( ){
        Set<Map.Entry<String, Config>> configSet = getConfigSet();
        for (Map.Entry<String, Config> connConfigEntry : configSet) {
            Config config = connConfigEntry.getValue();
            config.removeThreadLocalConnection();
        }
    }
    /**
     * 获取配置的事务级别
     *
     * @param config
     * @return
     */
    protected static int getTransactionLevel(Config config, JFinalTx jFinalTx) {

        if( null!=jFinalTx ){
            //如果是oracle，oracle只有TRANSACTION_READ_COMMITTED  TRANSACTION_SERIALIZABLE
            if( jFinalTx.transactionLevel()<=Connection.TRANSACTION_REPEATABLE_READ && DbEx.isOracle(config.getName())){
                return Connection.TRANSACTION_READ_COMMITTED;
            }else{
                return jFinalTx.transactionLevel();
            }
        }
        return config.getTransactionLevel();
    }

    public static List<Boolean> getAutoCommitList(List<Connection> conns)throws SQLException {
        boolean isThrowEx = false;
        SQLException ex = null;
        List<Boolean> autoCommitList = Lists.newArrayList();
        for (Connection conn : conns) {
            try {
                autoCommitList.add( conn.getAutoCommit() );
            } catch (SQLException e) {
                isThrowEx = true;
                log.error( e.getMessage(),e );
                ex = e;

            }
        }
        if( isThrowEx ){
            throw ex;
        }
        return autoCommitList;
    }

    public static void updateAutoCommit(List<Connection> conns, boolean autoCommit) throws SQLException {
        boolean isThrowEx = false;
        SQLException ex = null;
        for (Connection conn : conns) {
            try {
                conn.setAutoCommit( autoCommit );
            } catch (SQLException e) {
                isThrowEx = true;
                log.error( e.getMessage(),e );
                ex = e;
            }
        }
        if( isThrowEx ){
            throw ex;
        }
    }

    public static void updateAutoCommit(List<Connection> conns, List<Boolean> autoCommit) throws SQLException {
        if( conns.size()!=autoCommit.size() ){
            BusinessException.throwBiz("联系管理员，数据库连接数不等于自动提交数");
        }
        for (int i = 0; i < conns.size(); i++) {
            conns.get(i).setAutoCommit( autoCommit.get(i) );
        }
    }

}
