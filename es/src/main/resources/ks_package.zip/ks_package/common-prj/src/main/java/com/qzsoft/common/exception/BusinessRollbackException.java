package com.qzsoft.common.exception;

import com.qzsoft.common.ui.RequestResult;

public class BusinessRollbackException extends BusinessException {

    private RequestResult requestResult;

    public BusinessRollbackException(RequestResult requestResult) {
        this.requestResult = requestResult;
    }

    public RequestResult getRequestResult() {
        return requestResult;
    }
}
