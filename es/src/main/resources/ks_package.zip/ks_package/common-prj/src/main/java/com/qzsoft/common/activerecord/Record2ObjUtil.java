package com.qzsoft.common.activerecord;

import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Description:Record数据转换为对象
 * @author: zhouyou
 * @date: 2022/02/14 10:45
 **/
@Slf4j
public class Record2ObjUtil {

    private static Pattern humpPattern = Pattern.compile("[A-Z]");


    /**
     * Record数据转换为对象
     * <li>暂时只写了Record数据中String,int,BigDecimal,boolean数据类型的转换，其它类型需要的话再加</li>
     * @param record        Record数据
     * @param clazz         实体类Class
     * @param <T>           泛型
     * @return              实体类
     * @throws Exception    抛出异常
     */
    public static <T> T parseObject(Record record, Class<T> clazz){
        if (record == null){
            return null;
        }
        T vo = null;

        try {
            vo = clazz.newInstance();
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                String fieldName = field.getName();
                field.setAccessible(true);
                //根据类型赋值
                String fieldClassName = field.getType().getSimpleName();
                Object obj = record.get(humpToLine(fieldName));
                if (obj != null) {
                    if ("String".equalsIgnoreCase(fieldClassName)) {
                        field.set(vo, obj.toString());
                    }else if ("int".equals(fieldClassName) || "Integer".equals(fieldClassName)) {
                        field.set(vo,Integer.parseInt(obj.toString()));
                    }else if ("BigDecimal".equalsIgnoreCase(fieldClassName)){
                        field.set(vo, new BigDecimal(obj.toString()));
                    }else if ("boolean".equals(fieldClassName)){
                        field.set(vo,obj);
                    }else if ("long".equals(fieldClassName) || "Long".equals(fieldClassName)) {
                        field.set(vo,Long.parseLong(obj.toString()));
                    }
                }
            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return vo;
    }

    /**
     * Record数据集合转为实体类List集合
     *
     * @param recordList        Record数据
     * @param clazz             实体类
     * @param <T>               泛型
     * @return                  实体类List集合
     * @throws Exception        抛出异常
     */
    public static <T> List<T> parseArray(List<Record> recordList, Class<T> clazz){
        if (recordList == null || recordList.size() == 0){
            return null;
        }
        List<T> list = new ArrayList<>();
        for (Record record : recordList){
            try {
                list.add(parseObject(record, clazz));
            } catch (Exception e) {
                BusinessException.throwBiz("数据转换错误,请检查");
            }
        }
        return list;
    }

    /** 驼峰转下划线 */
    public static String humpToLine(String str) {
        Matcher matcher = humpPattern.matcher(str);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            matcher.appendReplacement(sb, "_" + matcher.group(0).toLowerCase());
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

}
