package com.qzsoft.common.exception;

import com.qzsoft.common.tools.ConfigUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * @author pjh
 * @Title: NoLoginException
 * @Description: TODO
 * @date 2018/11/19 12:57
 */
public class NoLoginException  extends RuntimeException {

    private Integer code;

    @Override
    public String getMessage() {
        return super.getMessage();
    }

    public NoLoginException() {
        super();
    }

    public NoLoginException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoLoginException(String message) {
        super(message);
    }

    public NoLoginException(Integer code, String message) {
        super(message);
        if(code != null){
            this.code = code;
        }else{
            this.code = 10001;
        }

    }
    public NoLoginException(int code) {
        super(code+"");
    }

    public static NoLoginException throwBiz( Integer code, String message ) {

        if(code == null){
            throw new NoLoginException( message );
        }
        String messageTmp = ConfigUtil.getMessage(code, message);
        if(StringUtils.isBlank( messageTmp )){
            messageTmp = message;
        }
        throw new NoLoginException( code, messageTmp );
    }

    public static NoLoginException throwBiz( Integer code ) {
        return throwBiz( code, "" );
    }

    public static NoLoginException throwBiz( String message ) {
        return throwBiz( null, message);
    }

    public NoLoginException(Throwable cause) {
        super(cause);
    }

    public Integer getCode(){
        return code;
    }
}
