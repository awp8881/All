package com.qzsoft.common.http;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.SecureRandom;
import org.apache.commons.codec.binary.Base64;

/**
 * @author pjh
 * @Title: QzAESCryptoUtils
 * @Description: TODO
 * @date 2018/11/24 14:02
 */
public class QzAESCryptoUtils {

    private static final Logger log = LoggerFactory.getLogger( QzAESCryptoUtils.class );

    public static String ksToReportAESEncode( String content ){
        return AESEncode("qz~!@#soft%^&*", content);
    }

    public static String ksToReportAESDecode( String content ){
        return AESDecode("qz~!@#soft%^&*", content);
    }

    /*
     * 加密
     * 1.构造密钥生成器
     * 2.根据ecnodeRules规则初始化密钥生成器
     * 3.产生密钥
     * 4.创建和初始化密码器
     * 5.内容加密
     * 6.返回字符串
     */
    public static String AESEncode(String encodeRules,String content){
        try {
            //1.构造密钥生成器，指定为AES算法,不区分大小写
            KeyGenerator keygen=KeyGenerator.getInstance("AES");

            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");//①
            random.setSeed(encodeRules.getBytes());

            //2.根据ecnodeRules规则初始化密钥生成器
            //生成一个128位的随机源,根据传入的字节数组
            keygen.init(128, random );
            //3.产生原始对称密钥
            SecretKey original_key=keygen.generateKey();
            //4.获得原始对称密钥的字节数组
            byte [] raw=original_key.getEncoded();
            //5.根据字节数组生成AES密钥
            SecretKey key=new SecretKeySpec(raw, "AES");
            //6.根据指定算法AES自成密码器
            Cipher cipher=Cipher.getInstance("AES");
            //7.初始化密码器，第一个参数为加密(Encrypt_mode)或者解密解密(Decrypt_mode)操作，第二个参数为使用的KEY
            cipher.init(Cipher.ENCRYPT_MODE, key);
            //8.获取加密内容的字节数组(这里要设置为utf-8)不然内容中如果有中文和英文混合中文就会解密为乱码
            byte [] byte_encode=content.getBytes("utf-8");
            //9.根据密码器的初始化方式--加密：将数据加密
            byte [] byte_AES=cipher.doFinal(byte_encode);
            //10.将加密后的数据转换为字符串
            //这里用Base64Encoder中会找不到包
            //解决办法：
            //在项目的Build path中先移除JRE System Library，再添加库JRE System Library，重新编译后就一切正常了。
//            String AES_encode=new String(new BASE64Encoder().encode(byte_AES));
            String AES_encode=new String(java.util.Base64.getEncoder().encode(byte_AES));
            //11.将字符串返回
            return AES_encode.replaceAll("\r|\n", "");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        }
        return null;
    }
    /*
     * 解密
     * 解密过程：
     * 1.同加密1-4步
     * 2.将加密后的字符串反纺成byte[]数组
     * 3.将加密内容解密
     */
    public static String AESDecode(String encodeRules,String content){
        try {
            //1.构造密钥生成器，指定为AES算法,不区分大小写
            KeyGenerator keygen=KeyGenerator.getInstance("AES");
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");//①
            random.setSeed(encodeRules.getBytes());
            //2.根据ecnodeRules规则初始化密钥生成器
            //生成一个128位的随机源,根据传入的字节数组
            keygen.init(128, random);
            //3.产生原始对称密钥
            SecretKey original_key=keygen.generateKey();
            //4.获得原始对称密钥的字节数组
            byte [] raw=original_key.getEncoded();
            //5.根据字节数组生成AES密钥
            SecretKey key=new SecretKeySpec(raw, "AES");
            //6.根据指定算法AES自成密码器
            Cipher cipher=Cipher.getInstance("AES");
            //7.初始化密码器，第一个参数为加密(Encrypt_mode)或者解密(Decrypt_mode)操作，第二个参数为使用的KEY
            cipher.init(Cipher.DECRYPT_MODE, key);
            //8.将加密并编码后的内容解码成字节数组
            byte [] byte_content = java.util.Base64.getDecoder().decode( content );
//            byte [] byte_content= new BASE64Decoder().decodeBuffer(content);
            /*
             * 解密
             */
            byte [] byte_decode=cipher.doFinal(byte_content);
            String AES_decode=new String(byte_decode,"utf-8");
            return AES_decode.replaceAll("\r|\n", "");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        }

        //如果有错就返加nulll
        return null;
    }

    public static String AesBase64UrlEncodeToReport(String inStr) throws UnsupportedEncodingException {
        return new String(Base64.encodeBase64URLSafe(QzAESCryptoUtils.ksToReportAESEncode(inStr).getBytes("UTF-8")), "UTF-8");
    }

    public static String UrlDecodeBase64AesFromReport(String inStr) throws UnsupportedEncodingException {
        return QzAESCryptoUtils.ksToReportAESDecode(new String(java.util.Base64.getDecoder().decode(inStr.getBytes("UTF-8")), "UTF-8"));
    }


//    public static void main(String[] args) throws UnsupportedEncodingException {
//        String content2 = "{\"req_param_str\":\"{\\\"queryType\\\":\\\"init\\\",\\\"menuId\\\":\\\"407682261328\\\",\\\"pageNum\\\":1,\\\"pageSize\\\":50,\\\"date_range\\\":\\\"\\\",\\\"m_code\\\":\\\"m_code$422873675784\\\",\\\"m_code_type\\\":\\\"YMSJY\\\",\\\"selfSelectCode\\\":\\\"m_code$422873675784$gro_select_code$583140382176\\\",\\\"globalDicData\\\":\\\"[{\\\\\\\"button_code\\\\\\\":\\\\\\\"m_code$422873675784$button_code$640394498232\\\\\\\",\\\\\\\"but_di_cd\\\\\\\":\\\\\\\"640392947056\\\\\\\",\\\\\\\"selectList\\\\\\\":[\\\\\\\"640392947056$640393525024\\\\\\\"]}]\\\",\\\"rowDynCodes\\\":\\\"[{\\\\\\\"dynCode\\\\\\\":null,\\\\\\\"fieldName\\\\\\\":\\\\\\\"ks_tmp_b$tmp_52\\\\\\\",\\\\\\\"contType\\\\\\\":\\\\\\\"exp\\\\\\\",\\\\\\\"fieldStyle\\\\\\\":\\\\\\\"input\\\\\\\",\\\\\\\"expCode\\\\\\\":\\\\\\\"785764978832\\\\\\\"},{\\\\\\\"dynCode\\\\\\\":null,\\\\\\\"fieldName\\\\\\\":\\\\\\\"ks_tmp_b$tmp_53\\\\\\\",\\\\\\\"contType\\\\\\\":\\\\\\\"exp\\\\\\\",\\\\\\\"fieldStyle\\\\\\\":\\\\\\\"input\\\\\\\",\\\\\\\"expCode\\\\\\\":\\\\\\\"785767432712\\\\\\\"}]\\\",\\\"dynSourceDatasStr\\\":\\\"{\\\\\\\"isDynSource\\\\\\\":false}\\\",\\\"comb_find_conds\\\":\\\"\\\",\\\"mergeDatasStr\\\":\\\"{\\\\\\\"mergeRows\\\\\\\":[],\\\\\\\"mergeCols\\\\\\\":[],\\\\\\\"mergeFollows\\\\\\\":[]}\\\",\\\"isColorDatas\\\":true,\\\"isMerge\\\":false,\\\"isDynSelectQuery\\\":false,\\\"isInterLoadData\\\":false,\\\"paramReloadConfs\\\":\\\"[]\\\",\\\"JID\\\":\\\"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMSIsInVzZXJfbmFtZSI6Iuezu-e7n-euoeeQhuWRmCIsImxvZ2luX25hIjoiYWRtaW4iLCJ1c2VyX3BybiI6IjE3ODcwMjAwNzkyMSIsImlwX2FkZHIiOiIxOTIuMTY4LjQuMzMiLCJ1c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzk0LjAuNDYwNi44MSBTYWZhcmkvNTM3LjM2IFNvY2tldExvZyh0YWJpZD0yNDYmY2xpZW50X2lkPSkiLCJpYXQiOjE2MzQyNjg5NjAsImlzcyI6IlF6In0.a_bkXIcxMCILU5yXPPWJjPWgz3WzodspS5oU-cxHbKY\\\"}\",\"req_server_meth\":\"queryList\",\"req_server_class\":\"com.qzsoft.lims.ks.service.page.ListQueryService\",\"req_param_type\":\"com.qzsoft.lims.ks.dto.request.RequestListPara\"}";
//        String encodeStr = QzAESCryptoUtils.AesBase64UrlEncodeToReport(content2);
//        System.out.println("根据输入的规则加密后的明文是:"+ encodeStr);
//        System.out.println("根据输入的规则解密后的明文是:"+QzAESCryptoUtils.UrlDecodeBase64AesFromReport(encodeStr));
//        String content = "bmtxZ2w3aDF1b1I1NDBUS0lSOVdNSEVwd0ladkRHTVNCMXN3SUdOSE9Yam55dlp6Q1cyN1laYjkwdmxHMm9IcUNqZEw0aG1YNHVVbzdURjBEQTVtbWc3YW0yN0VZTXhJdkl6SGxzZituQkE2ZDgvYTk0WTJyT3E4WGdmbDgvczdEdXJIdXl2VmZ1U3BNT1BJQktBb2k2aHBkZDM0U3ZXS1lkN0lmVFhJMDd6QVVVQTZkcDc1ZUZ2Mk5kTUV6UW1mMkxNT2F3STZWTjY4V1l6SUFEbHRMbVN1bDVaVk41SHJSYk1BbkZURzlNaUp3MHdqdGRXZ0tsOEpjVFBFbU9sRVMraGJrYVpTTFhPZmMrMmRKUU94S09MWFVKUTdDN2lnR2VnSHBpRGw3Q0t6ekxwVGFYUzl5S3hQeHdjRGo0aW91QUFsS3BnWUxyeUsxUjlFNFZwbkZCU2Z4Uk1RWkE2cUVoQW04cVNHUCtmOFlyclZaYSthRmcxakdLUnJEenh3MzUvTDdhSTRIcWFwSnY4c3dHdnNuQXFIRnFLbmRmbTFuRUphbFRISWd1T3ZBZm04RkdoczdQU3N5aFpvRXFvc0gvSVlEdHRMemc4VUxZaDlxck9CWFdDNWlVakMzcGhSWW9IMmpPbG1ONFJZd1VZKzBmUnhYNmp2Rkg5WEdBV0thZW1mK25tYjROZEV2ZE9tTDNTajl5Z3Z0VEVYaEh5OFgrcmJkVTgxQjFjTkRkejliNFAyZ3JvQ3JEVWVSK0hmaEsrbUhTZkpXcXltSU4vT0RFYzg5Tm1CM3Y3YmIrUy8xRjZra3RVZkVVRmNKQTh0TlcyQ2pQOWFpVk9GWHU3RXFYR3Fid3FsQ252a1RSbXBTZmlwKzlRNDZ3a2F6U0Z5RlNUSkNKN1F0VkxVd2pWQVM5azZ5ekZxdm15UjVyWnlOOVdnT3lORXFFd1greGhOVXcrdWdCdktMT1k5S3dhV09xc0RQZGFLVFB6TjhWUGJDNjIvQmZhVGd1ZjRYUklVeEExaXVMMlJueTRhcjlwUEJNbC9GNnhYU2pzYmZ1Yy9oU0M3c3UyaGhPdm1LUGFtNnNjWVlEU1J0cFlVVjJVRkRhdXBZUHZ5VmhFeVRZVW96ayt1WHlPZ3NSMWpHLzZBM3hGTTJ5SkxTOHFnTXhVZzdGMGovUEhSd3c5ckVMQmtnbFprc2VIZnhua2Q5TEpKalhERUpZQzA0VTUwLzBidWtJbjFSNmplVG9UM0RpTmJ0VlhrRnM3U3Q0K0tFMU9DN0RpVFd3UXhud3BRL0R5bWxwZVF5Ykw4djVERmNSMkJyNGVaOVZnUE1Obk5tUGRtK1hnWTRZcEVaWkRSTEdaSjBEMnFEOE9id0ZCRFRVZWJ4RFRIYktuVHhyS2V5Y2wvQmFqc2doTHVHNGwzSDBwYzZYeFRXT3FRS1pkR1VCQW5LSXl2d1NHUU1yRDRweEZZOE5KRGR5MU5aTk5vOWdpa0NUeW1DQjZQWkdjY0F0aHJCNWdxRm1jQ2VOL0I5SG5iRGZNRlEvdE90aklyVmtUM0trT0FobUJhdUdvYWdOdUFUVG1NWXlOT3p2U29jOTlVWlFQa005SVlzMlkvbGxpTWRhSW1La3BKZ2YwSi9Idllrak1kRlQ1SVpCRTNOakRFaFVVbHBwb1BIRy9FY1VvRVFMd2VaTWxsMjhxNHBCTVJIaHVOeTlseFhCMGZBNXN5UU5ub0JqdGo1dVVaWnd5K3dYakMybkZIZlRDVGFVUnFwU2VyYTFJdVRwSkRqTFlLVGVlRGRtNlQybDZqbmlkTSs1R3YzR2N0NGVLNlRqOW9LRGZlUjRJMDk1d3RlejgreVM2WWZaSWZRa3lobTM4bzdvcEUwS0lZbnlycnJOVzhYbHZlM2hIczRZK1dWTlBHK1pVT2xDTk12UVR4OHVYRkdORWlUSFFVbWEweVk4Z2NEUmEvc0lQMjFFQ3BNT3BndFlubVB2SXVsa2J3OEVsaHFjV3JYUDYyalNiaVFJVlFKTjFxd1lNOHQwYkdIRE9ZYnYzWHE1Y1g5ejIwZk9BRzRLcE1jUUxUeDNnR2tTaitOT1Q4UzZPTCtVTTltZGY5clZkN0ViYlFycEkrZHFVTktBd0EzWDI2NGlrV3E0T0tBVkxHcHBlbVorZUxOV3ZWbTAzZGMwVzIvSUJRNThRT3NITzZQZFZ3RFFNVjVLemhwMDlNaTJxbHJPaVIxZG9QeUVPa01UUXduSHpuTzd2ejBUWkF0dnNEd0JucTZKSDlTRktYRHFraUFtS1NXZmlHYlNDZXByQXlXeWtFSWhVQnVkQWZmOEo4d2ZrenRwZ2xPUVd6Qm5GNWRUSVc3YmpMY2hFNWZJMnZMcG15dWtGOXEvOXcwM1U3dUhyRFVSRm9WYnJVZy9mLzRZY1hBbHVuc3pTVHRjTDg0WWo3Q2RqTTVXb1QxbVdjd1pyRVFWSmRFS0NJVEk1NVZJelN0dVVtSHBEUG40b0s5b28zbnRITUxiY0RsS2R4bUZHK2lCK2tGbTdvQUtab0ZCNG96QWk5OUFva05CbE90UTBsRzJBY0pGSnNZV21NNmlJSkZpZEZDV3A5MHQvTllqNVVNZ1ZZQS9xUVE1ZGxZRktXUU1ocy9BMXRoaitzVjVHQ1NIcERiaGVCTHpnYWlMVDVYamZSN0Q5U1ZlbG8wR2ZNb292Q2ZiZnFaV09kYkIvUVg5ZklxMU9YVThGcUdUaFhvQzZOczYzcHZ5cFA0azNyT1F1RmV3aTVoWkRDSFV4Z3FRb0VDYlJKcTVtUmRNcVF0SStYaDNqc2FCeld1RG9MZmc2dEhMQlJMOGREQ210U1NJWTd0bmRNTzI5VnRneTVEcFVXa0hnc203OTFBd0p3QUxweXh1ZmJxMi96MHpKOE5UampnTUFOYllDOHI5anY1d1I0NTYzNXE4K3BEUFJQUzhBY0t2aU5mM2hteC9Ia2RSK3dSVzJMR1NHVlRRV1FLU05ucGhQdENqZlVRREZHRFltQUpWY1o4UDcvL0duYUxqd1FGVElFYXRndVNjbTVIWUowK254NksybDdYbkx0OUNnOGF4YzU3VTRFOC9iSkhIZnlXeWIxdURHS2l0UT0";
//        System.out.println("根据输入的规则解密后的明文是:"+QzAESCryptoUtils.UrlDecodeBase64AesFromReport(content));
//    }

}
