//package com.qzsoft.common.tools;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
//import com.qzsoft.common.exception.BusinessException;
////import com.qzsoft.common.http.HttpUtils;
////import com.qzsoft.common.http.HttpUtils.HttpResult;
//import com.qzsoft.common.http.callback.HttpSendCallback;
//
//import okhttp3.Response;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//@Component
//public class LoginTokenUtil {
//
//
//	public static String getUserInfo(String userInfoUrl,String JID) {
//		Map<String,String> params = new HashMap<String,String>();
//		params.put("JID", JID);
////		HttpResult<String> httpPost = HttpUtils.httpPost(ConfigUtil.getPropertyValue("http.tu.getUserInfo"), params, new HttpSendCallback<String>() {
////
////			@Override
////			public String onResponse(Response response) throws Exception {
////				if (!response.isSuccessful()) {
////					throw new BusinessException("请求响应失败，code: " + response.code() + ". message: "
////							+ response.message() + ". url: " + response.request().url().url());
////				}
////				String value = response.body().string();
////				return value;
////			}
////
////		});
////		String value = "";
////		try {
////			value = httpPost.getValue();
////		} catch (Exception e) {
////			throw BusinessException.buildBiz( e.getMessage() );
////		}
//		String value = HttpRequestUtil.sendPost( userInfoUrl, params, 5000);
//		return value;
//	}
//}
