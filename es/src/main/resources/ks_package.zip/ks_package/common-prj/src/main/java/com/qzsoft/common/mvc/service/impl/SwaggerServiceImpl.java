//package com.qzsoft.common.mvc.service.impl;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.stereotype.Service;
//
//import com.alibaba.fastjson.JSON;
//import com.qzsoft.common.exception.BusinessException;
//import com.qzsoft.common.http.HttpUtils;
//import com.qzsoft.common.http.HttpUtils.HttpResult;
//import com.qzsoft.common.http.callback.HttpSendCallback;
//import com.qzsoft.common.mvc.service.SwaggerService;
//import com.qzsoft.common.vo.Request;
//import com.qzsoft.common.vo.Response;
//import com.qzsoft.common.vo.Table;
//
//@Service
//public class SwaggerServiceImpl implements SwaggerService {
//
//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	@Override
//	public Map<String, List<Table>> tableList(String host) throws Exception {
//
//		String json = getSwaggerApi(host);
//
//		//解析paths
//    	Map<String, List<Table>> map = new HashMap<>();
//    	Map<String, Object> MAP = JSON.parseObject(json, Map.class);
//        Map<String, Map> paths = (Map) MAP.get("paths");
//        if (paths != null) {
//            Iterator<Map.Entry<String, Map>> iterator = paths.entrySet().iterator();
//            while (iterator.hasNext()) {
//                Table table = new Table();
//                List<Request> requestList = new LinkedList<>();
//                List<Response> responseList = new LinkedList<>();
//
//                String requestForm = ""; //请求参数格式，类似于 multipart/form-data
//                String responseForm = ""; //响应参数格式
//                String requestType = ""; //请求方式，类似为 get/post/delete/put 这样
//                String url; //请求路径
//                String title; //大标题（类说明）
//                String tag; //小标题 （方法说明）
//
//                Map.Entry<String, Map> next = iterator.next();
//                url = next.getKey();
//
//                Map<String, Map> value = next.getValue();
//                Set<String> requestTypes = value.keySet();
//                for (String str : requestTypes) {
//                    requestType += str + "、";
//                }
//
//                Iterator<Map.Entry<String, Map>> iterator2 = value.entrySet().iterator();
//                //不管有几种请求方式，都只解析第一种
//                Map.Entry<String, Map> get = iterator2.next();
//                Map getValue = get.getValue();
//                title = (String) ((List) getValue.get("tags")).get(0);
//                List<Table> tables = map.get(title);
//                if(tables == null){
//                	tables = new ArrayList<>();
//                	map.put(title, tables);
//                }
//
//                List<String> consumes = (List) getValue.get("consumes");
//                if (consumes != null && consumes.size() > 0) {
//                    for (String consume : consumes) {
//                        requestForm += consume + "、";
//                    }
//                }
//                List<String> produces = (List) getValue.get("produces");
//                if (produces != null && produces.size() > 0) {
//                    for (String produce : produces) {
//                        responseForm += produce + "、";
//                    }
//                }
//
//                tag = String.valueOf(getValue.get("summary"));
//                //请求体
//                List parameters = (List) getValue.get("parameters");
//                if (parameters != null && parameters.size() > 0) {
//                    for (int i = 0; i < parameters.size(); i++) {
//                        Request request = new Request();
//                        Map<String, Object> param = (Map) parameters.get(i);
//                        request.setName(String.valueOf(param.get("name")));
//                        request.setType(param.get("type") == null ? "Object" : param.get("type").toString());
//                        request.setParamType(String.valueOf(param.get("in")));
//                        request.setRequire((Boolean) param.get("required"));
//                        request.setRemark(String.valueOf(param.get("description")));
//                        requestList.add(request);
//                    }
//                }
//                //返回体
//                Map<String, Object> responses = (Map) getValue.get("responses");
//                Iterator<Map.Entry<String, Object>> iterator3 = responses.entrySet().iterator();
//                while (iterator3.hasNext()) {
//                    Response response = new Response();
//                    Map.Entry<String, Object> entry = iterator3.next();
//                    String status = entry.getKey(); //状态码 200 201 401 403 404 这样
//                    Map<String, Object> statusInfo = (Map) entry.getValue();
//                    String statusDescription = (String) statusInfo.get("description");
//                    response.setName(status);
//                    response.setDescription(statusDescription);
//                    response.setRemark(null);
//                    responseList.add(response);
//                }
//
//                //封装Table
//                table.setTitle(title);
//                table.setUrl(url);
//                table.setTag(tag);
//                table.setRequestForm(StringUtils.removeEnd(requestForm, "、"));
//                table.setResponseForm(StringUtils.removeEnd(responseForm, "、"));
//                table.setRequestType(StringUtils.removeEnd(requestType, "、"));
//                table.setRequestList(requestList);
//                table.setResponseList(responseList);
//                tables.add(table);
//            }
//        }
//        return map;
//    }
//
//
//	private String getSwaggerApi(String host) throws Exception{
//		String swaggerApiUrl = host+"/v2/api-docs?group=接口文档";
//		HttpResult<String> httpGet = HttpUtils.httpGet(swaggerApiUrl, new HttpSendCallback<String>() {
//
//			@Override
//			public String onResponse(okhttp3.Response response) throws Exception {
//				if(!response.isSuccessful()){
//					throw new BusinessException(swaggerApiUrl+" 接口返回失败！");
//				}
//				return response.body().string();
//			}
//		});
//
//		return httpGet.getValue();
//	}
//
//}
