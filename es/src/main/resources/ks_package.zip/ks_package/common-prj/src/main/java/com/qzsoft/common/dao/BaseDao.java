package com.qzsoft.common.dao;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;

/**
 * 公用Dao层方法
 * 注：默认主键列名为id,如果主键列名非id或多个主键则需自己新增方法
 * @author zhz
 *
 */
public interface BaseDao {
	
	/**
	 * 新增一条数据
	 * @param record
	 * @return
	 */
	Boolean save(Record record);
	/**
	 * 新增一条数据 带乐观锁
	 * @param record
	 * @return
	 */
	Boolean saveAndUpVer(Record record);
	/**
	 * 新增多条数据
	 * @param record
	 * @return
	 */
	Boolean saveList(List<Record> record);
	/**
	 * 新增多条数据对应tableName表
	 * @param record
	 * @return
	 */
	Boolean saveList(String tableName,List<Record> record);
	/**
	 * 新增一条对应tableName表数据 带乐观锁
	 * @param tableName 表名
	 * @param record
	 * @return
	 */
	Boolean saveAndUpVer(String tableName,Record record);
	/**
	 * 新增一条对应tableName表数据
	 * @param tableName 表名
	 * @param record
	 * @return
	 */
	Boolean save(String tableName,Record record);
	/**
	 * 修改一条数据
	 * @param record
	 * @return
	 */
	Boolean update(Record record);
	/**
	 * 修改一条对应tableName表数据
	 * @param tableName 表名
	 * @param record
	 * @return
	 */
	Boolean update(String tableName,Record record);
	/**
	 * 修改多条数据
	 * @param record
	 * @return
	 */
	Boolean updateList(List<Record> recordList);
	/**
	 * 修改多条对应tableName表数据
	 * @param tableName 表名
	 * @param record
	 * @return
	 */
	Boolean updateList(String tableName,List<Record> recordList);
	/**
	 * 根据条件列名修改一条数据
	 * 备注：	1.逗号拼接(例如:id,user_id)
	 * 		2条件列名 会拼接到where 后面 值为record对象里面对应键的值
	 * @param primaryKey 条件列名
	 * @param record
	 * @return
	 */
	Boolean updateByPrimaryKey(String primaryKey,Record record);
	/**
	 * 根据条件列名修改一条对应tableName表数据
	 * 备注：	1.逗号拼接(例如:id,user_id)
	 * 		2条件列名 会拼接到where 后面 值为record对象里面对应键的值
	 * @param tableName 表名
	 * @param primaryKey 条件列名
	 * @param record
	 * @return
	 */
	Boolean updateByPrimaryKey(String tableName,String primaryKey,Record record);
	/**
	 * 修改(乐观锁)带条件列名
	 * 备注：	1.逗号拼接(例如:id,user_id)
	 * 		2条件列名 会拼接到where 后面 值为record对象里面对应键的值
	 * @param primaryKey 条件列名
	 * @param record
	 * @return
	 */
	Boolean updateByVersionAndPrimaryKey(String primaryKey,Record record);
	/**
	 * 修改(乐观锁)带条件列名
	 * 备注：	1.逗号拼接(例如:id,user_id)
	 * 		2条件列名 会拼接到where 后面 值为record对象里面对应键的值
	 * @param tableName 表名
	 * @param primaryKey 条件列名
	 * @param record
	 * @return
	 */
	Boolean updateByVersionAndPrimaryKey(String tableName,String primaryKey,Record record);
	/**
	 * 根据ID删除数据
	 * @param id
	 * @return
	 */
	Boolean deleteById(Long id);
	/**
	 * 根据ID删除对应tableName表数据
	 * @param tableName 表名
	 * @param id
	 * @return
	 */
	Boolean deleteById(String tableName,Long id);
	/**
	 * 根据自定义列名删除数据
	 * @param tableName 表名
	 * @param id
	 * @return
	 */
	Boolean deleteByCustom(String customColumns,Object... objects);
	/**
	 * 根据自定义列名删除对应tableName表数据
	 * @param tableName 表名
	 * @param id
	 * @return
	 */
	Boolean deleteByCustom(String tableName,String customColumns,Object... objects);


	/**
	 * 根据自定义列名批量删除对应tableName表数据
	 * @param tableName 表名
	 * @param customColumns 字段名
	 * @param values 字段值
	 * @return
	 */
	Boolean deleteByCustom(String tableName,String customColumns,List<String> values);
	/**
	 * 分页查询数据
	 * @param page 页数
	 * @param pageSize 每页显示条数
	 * @return
	 */
	Page<Record> getPageList(Integer page,Integer pageSize);
	/**
	 * 分页查询对应tableName表数据
	 * @param tableName 表名
	 * @param page 页数
	 * @param pageSize 每页显示条数
	 * @return
	 */
	Page<Record> getPageList(String tableName,Integer page,Integer pageSize);
	
	/**
	 * 根据ID查询数据
	 * @param id
	 * @return
	 */
	Record selectById(Long id);
	/**
	 * 根据ID查询对应tableName表数据
	 * @param tableName 表名
	 * @param id
	 * @return
	 */
	Record selectById(String tableName,Long id);
	/**
	 * 添加数据库列
	 * @param columnName 列名
	 * @param type	类型
	 * @param length 长度
	 * @return
	 */
	Boolean addColumn(String columnName,String type,Integer length);
	/**
	 * 添加对应tableName数据库列
	 * @param tableName 表名
	 * @param columnName 列名
	 * @param type	类型
	 * @param length 长度
	 * @return
	 */
	Boolean addColumn(String tableName,String columnName,String type,Integer length);
	/**
	 * 修改数据库列
	 * @param columnName 列名
	 * @param type 类型
	 * @param length 长度
	 * @return
	 */
	Boolean updateColumn(String columnName,String type,Integer length);
	/**
	 * 修改对应tableName表列
	 * @param tableName 表名
	 * @param columnName 列名
	 * @param type 类型
	 * @param length 长度
	 * @return
	 */
	Boolean updateColumn(String tableName,String columnName,String type,Integer length);
	
	/**
	 * 通过字段查询
	 * 
	 * @param tableName 表名
	 * @param customColumnName 列名的","分隔字符串
	 * @param object 列值
	 * @param 主键id
	 * @return
	 */
	List<Record> selectListByCustom(String tableName, String customColumnName, Long id,Object... object);

	/**
	 * 通过字段查询
	 *
	 * @param tableName 表名
	 * @param customColumnName 列名的","分隔字符串
	 * @param object 列值
	 * @return
	 */
	List<Record> selectListByCustom(String tableName, String customColumnName,Object... object);


	/**
	 *修改-通过版本和主键
	 * @param tableName 表名
	 * @param record
	 * @return
	 */
	Boolean updateByVersionAndId(String tableName, Record record);
	Boolean updateByVersionAndId(Record record);
	/**
	 * 复杂分页查询
	 */
	Page<Record> getPageList(String select, String from, String where, Integer pageNum, Integer pageSize);

	Page<Record> getPageList(String select, String from, String where, Integer pageNum, Integer pageSize, boolean isGroupBySql, Object... paras);


	/**
	 * @Author: pzq
	 * @Date: 2018/5/16
	 * @Description 是否存在某个表
	 */
	boolean isExistTable(String table);
	
//	/**
//	 * @Author： lzy
//	 * @Date： 2018年6月13日
//	 * @Description：取数据库所有表
//	 * @Return List<Record>
//	 */
//	List<Record> getTableInfo();

	/**
	 * 查询所有
	 * @param table
	 * @param sort
	 * @return
	 */
	List<Record> findAll(String table,String sort);
	

	/**
	 * 通过表名获取表字段信息
	 * @return
	 */
	List<Record> getTableField(String tableName);
	
	/**
	 * 通过某个字段判断是否存在记录
	 * @param tableName
	 * @param column
	 * @param value
	 * @return
	 */
	Boolean isExistRecord(String tableName,String column,String value);
	
	/**
	 * 根据字段获取一行
	 * @param tableName
	 * @param customColumnName
	 * @param object
	 * @return
	 */
	Record getOneByColumn(String tableName,String customColumnName ,Object... object);
	
	/**
	 * 根据字段获取一行
	 * @param customColumnName
	 * @param object
	 * @return
	 */
	Record getOneByColumn(String customColumnName ,Object... object);
	
	/**
	 * 根据某个字段批量删除
	 * @param tableName
	 * @param column
	 * @param list
	 * @return
	 */
	Boolean batchDelete(String tableName,String column,List<String> list);
	
	/**
	 * 删除b、c表
	 * @param m_code
	 * @param isBC
	 * @param tableB
	 * @param tableC
	 * @return
	 */
	Boolean deleteByMcode(String m_code,String isBC,String tableB,String tableC);

	void clearDataByTable(String tableName);

	/**
	 * 通过字段查询排序 
	 * @param tableName
	 * @param customColumnNam
	 * @param sortColumn
	 * @param isDesc  true为倒序desc
	 * @param object
	 * @return
	 */
	List<Record> selectListByCustomAndSort(String tableName, String customColumnName,String sortColumn,Boolean isDesc,Object... object);
	
	/**
	 * 通过字段模糊查询排序
	 * @param tableName
	 * @param customColumnNam
	 * @param sortColumn
	 * @param isDesc  true为倒序desc
	 * @param search 查询字符串
	 * @param searchColumn 待查询的字段名称，以逗号分隔
	 * @param object
	 * @return
	 */
	List<Record> selectListByCustomAndSortSearch(String tableName, String customColumnName,String sortColumn,Boolean isDesc,String search,String searchColumn,Object... object); 
	
	
	/**
	 * 通过字段集合获取数据
	 * @param column
	 * @param fieldList
	 * @return
	 */
	List<Record> getByColumnList(String column,List<String> fieldList);

	List<Record> selectListBySql(String sql, Object... object );

	Record selectFirstOneBySql(String sql,  Object... object );
	
	List<Record> selectListByCustom(String customColumnName ,Object... object);
	
	/**
	 *  通过字段集合获取数据
	 * @param tableName
	 * @param column
	 * @param fieldList
	 * @return
	 */
	List<Record> getByColumnList(String tableName,String column, List<String> fieldList);
	
	/**
	 * 环境变量条件
	 * @param table
	 * @param button_code
	 * @param para_type_k
	 * @param para_type
	 * @param m_code
	 * @return
	 */
	List<Record> getEnvWhereList(String table,String para_type_k,String para_type,String button_code,String m_code,String info_code);
	
	Boolean updateBySql(String sql, Object... object);
	
	List<Record> selectListBySqlNoParas( String sql );
	
	Record getMaxColumnRecord( String table, String column);

    Boolean batchDeleteOfMany(String tableName,Map<String,List> map);
}
