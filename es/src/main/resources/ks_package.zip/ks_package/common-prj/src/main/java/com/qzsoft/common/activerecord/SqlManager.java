package com.qzsoft.common.activerecord;


import com.jfinal.plugin.activerecord.Config;
import com.jfinal.plugin.activerecord.DbKit;
import com.jfinal.plugin.activerecord.dialect.Dialect;
import com.jfinal.plugin.activerecord.dialect.MysqlDialect;
import com.jfinal.plugin.activerecord.dialect.OracleDialect;
import com.jfinal.plugin.activerecord.dialect.SqlServerDialect;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @author pjh
 * @Title: SqlManager
 * @Description: sql管理器  处理sql函数  特殊表 特殊语句
 * @date 2018/7/12 15:38
 */
@Slf4j
public class SqlManager {




    //根据配置的数据源 初始化特殊sql映射器
    public static void initSpecialSqlMapping( List<String> dataSourceList ){
        SpecialSqlMapping.init( dataSourceList );
    }

    /**
     * 处理特殊sql
     * @param sql
     * @return
     */
    public static String handleSpecialSql( String sql ){
        if( getDialect().equals( com.qzsoft.jdialects.Dialect.MySQL5Dialect  )  ){
            return sql;
        }
        List<AbstractSpecialSqlHandler> specialSqlHandlerList = SpecialSqlMapping.getSpecialSqlHandler(sql);
        for( AbstractSpecialSqlHandler specialSqlHandler : specialSqlHandlerList ){
            sql = specialSqlHandler.handler( sql );
        }
        String trans = sql;
        try{
            trans = getDialect().trans(sql);
        }catch (Exception e){
            //如果函数转换出错，使用原来的sql进行返回
            log.warn(e.getMessage(), e);
        }
        return trans;
    }

    /**
     * 获取转换sql的方言
     * @return
     */
    public static com.qzsoft.jdialects.Dialect getDialect(){
        com.qzsoft.jdialects.Dialect transDialect = com.qzsoft.jdialects.Dialect.MySQL5Dialect;
        Config config = DbKit.getConfig();
        Dialect dialect = config.getDialect();
        if( dialect instanceof OracleDialect) {
            transDialect = com.qzsoft.jdialects.Dialect.Oracle10gDialect;
        }
        if( dialect instanceof SqlServerDialect){
            transDialect = com.qzsoft.jdialects.Dialect.SQLServerDialect;
        }
        return  transDialect;
    }

}
