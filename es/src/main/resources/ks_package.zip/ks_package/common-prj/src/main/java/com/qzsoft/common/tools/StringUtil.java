package com.qzsoft.common.tools;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.qzsoft.common.constants.RegexConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Slf4j
public class StringUtil {
    
	public static String toString(Object o) {
		if (o == null)
			return "";
		else
			return o.toString();
	}

	/**
	 * 去除各式各样的空白串
	 * 
	 * @param str
	 * @return
	 */
	public static String trimAll(String str) {
		String dest = "";
		if (str != null) {
			// 倒数第二个空格与空格键打出来的空格不一样！
			Pattern p = Pattern.compile(RegexConstant.blank);
			Matcher m = p.matcher(str);
			dest = m.replaceAll("");
		}
		return dest;
	}

	/**
	 * 去除头尾的空白串加强
	 * 
	 * @param str
	 * @return
	 */
	public static String trim(String str) {
		return Pattern.compile("^(" + RegexConstant.blank + ")|(" + RegexConstant.blank + ")$").matcher(str)
				.replaceAll("");
	}

	/**
	 * 所有空格替换为标准空格
	 * 
	 * @param str
	 * @return
	 */
	public static String replaceNomalBlank(String str) {
		String dest = "";
		if (str != null) {
			// 倒数第二个空格与空格键打出来的空格不一样！
			Pattern p = Pattern.compile(RegexConstant.blank);
			Matcher m = p.matcher(str);
			dest = m.replaceAll(" ");
		}
		return dest;
	}

	public static String jointDoubanUrl(String doubanId) {
		return "https://movie.douban.com/subject/" + doubanId + "/";
	}

	/**
	 * 去除字符串的“-”和空串
	 * 
	 * @param str
	 * @return
	 */
	public static String replaceBlank2(String str) {
		String dest = "";
		if (str != null) {
			Pattern p = Pattern.compile("-|\\s");
			Matcher m = p.matcher(str);
			dest = m.replaceAll("");
		}
		return dest;
	}

	public static String randomString(int len) {
		String randomSource = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < len; i++) {
			int number = new Random().nextInt(62);
			sb.append(randomSource.charAt(number));
		}
		return sb.toString();
	}

	public static String StringLimit(String str, int limit) {
		int strLen = str.length();

		double count = 0.0d;
		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < strLen; i++) {
			int asciicode = str.codePointAt(i);
			if (asciicode > 255) {
				count = count + 1.0d;
			} else {
				count = count + 0.5d;
			}
			if (count > limit) {
				sb.append("...");
				break;
			}
			sb.append(str.charAt(i));
		}
		return sb.toString();
	}

	/**
	 * 转换为Double类型
	 */
	public static Double toDouble(Object val) {
		if (val == null) {
			return 0D;
		}
		try {
			return Double.valueOf(trim(val.toString()));
		} catch (Exception e) {
			return 0D;
		}
	}

	/**
	 * 转换为Long类型
	 */
	public static Long toLong(Object val) {
		return toDouble(val).longValue();
	}

	/**
	 * 字符串转换为字符串数组
	 */
	public static String[] toArr(String sendee) {
		String[] toArr = null;
		if (StringUtils.isBlank(sendee) || sendee.equals("NULL")){
			return toArr;
		}
		if (sendee.contains(",")) {
			toArr = sendee.split(",");
		} else {
			toArr = new String[] { sendee };
		}
		return toArr;
	}

	/**
	 * 将long集合转换为字符串
	 * 
	 * @param list
	 * @param sp
	 *            拆分符
	 * @return
	 */
	public static String longListToStr(List<Long> list, String sp) {
		StringBuffer sb = new StringBuffer("");
		for (Long temp : list) {
			sb.append(temp + sp);
		}
		if (sb.length() > 0) {
			sb.substring(0, sb.length() - 1);
		}
		return sb.toString();
	}

	/**
	 * 是否可转化为数字
	 * 
	 * @return
	 */
	public static boolean isNum(Object obj) {
		if (null == obj) {
			return false;
		}
		try {
			new BigDecimal(obj.toString());
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/**
	 * 转化为int型数字, 不可转化时返回0
	 * 
	 * @return
	 */
	public static int toInt(Object obj) {
		if (isNum(obj)) {
			return new Integer(obj.toString());
		} else {
			return 0;
		}
	}

	public static Boolean toBoolean(Object obj) {
		String str = toString(obj);
		return Boolean.valueOf(str);
	}
	
	/**
	 * 去除所有标点符号和空格符
	 * @param str
	 * @return
	 */
	public static String removeSpacesAndSymbols(String str) {
		//1.清除所有标点 符号,只留下字母 数字  汉字  共3类
		String str2 = str.replaceAll("[\\pP\\p{Punct}]","");
		
		//2.去除空格
		//可以替换大部分空白字符， 不限于空格 . 说明:\s 可以匹配空格、制表符、换页符等空白字符的其中任意一个
		String str3 = str2.replaceAll("\\s*",""); 
		
		return str3;
	}
	
	public static Object removeSpacesAndSymbols(Object obj) {
		String str=toString(obj);
		//1.清除所有标点 符号,只留下字母 数字  汉字  共3类
		String str2 = str.replaceAll("[\\pP\\p{Punct}]","");
		
		//2.去除空格
		//可以替换大部分空白字符， 不限于空格 . 说明:\s 可以匹配空格、制表符、换页符等空白字符的其中任意一个
		String str3 = str2.replaceAll("\\s*",""); 
		
		return str3;
	}
	
	public static Object removeBlank(Object obj) {
		String str = toString(obj).trim();
		String resultStr = str.replaceAll("'", "").replaceAll("\"", "");
		return resultStr;
	}
	
	public static <T> String listTOString(List<T> list ) {
		String str = "" ;
		if (null == list || list.isEmpty()) {
			return str;
		}
		str = Joiner.on(",").join(list);
		return str;
	}
	
	public static List<String> strToList(String str){
		List<String> list = Lists.newArrayList();
		if (StringUtils.isBlank(str)) {
			return list;
		}
		try {
			list = Splitter.on(",").omitEmptyStrings().splitToList(str);
		} catch (Exception e) {
			log.error(str+"该数据不是逗号分隔字符串");
			return list;
		}
		return list;
		
	}

	/**
	 * 将str按照固定长度切分成数组，最后一个不足长度不做填充
	 * @param str
	 * @param step
	 * @return
	 */
	public static List<String> subFixedLength( String str, int step ){
		List<String> strList = Lists.newArrayList();
		if( 0==step ){
			strList.add( str );
			return strList;
		}
		if( org.apache.commons.lang3.StringUtils.isEmpty( str ) ){
			return strList;
		}
		int length = str.length();
		int count = length%step==0 ? length/step : length/step+1;
		for (int i = 0; i < count; i++) {
			int endIdx = (i + 1) * step;
			if( endIdx > length ){
				endIdx = length;
			}
			String subStr = str.substring(i * step, endIdx );
			strList.add( subStr );
		}
		return strList;
	}



}

