package com.qzsoft.common.mvc.controller;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import io.swagger.annotations.Api;

@Controller
@RequestMapping("/mapping")
@Api(tags="配置信息")
public class MessageMappingController {

	@PostMapping("/properties")
	@ResponseBody
	public byte[] getProperties() throws IOException{
		InputStream inputStream = this.getClass().getResourceAsStream("/message-mapping.properties");
        return IOUtils.toByteArray(inputStream);
	}
}
