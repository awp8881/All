package com.qzsoft.common.log;

import java.lang.annotation.*;

@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface OptLog {


    //模块
    String module() default "";

    //备注
    String remark() default "";


}