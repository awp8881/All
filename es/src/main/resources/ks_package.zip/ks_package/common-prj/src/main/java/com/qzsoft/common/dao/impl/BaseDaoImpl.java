package com.qzsoft.common.dao.impl;

import com.google.common.base.Joiner;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.activerecord.DbEx;
import com.qzsoft.common.annotation.JFinalTx;
import com.qzsoft.common.constants.CommonConstants;
import com.qzsoft.common.constants.TableBCEnum;
import com.qzsoft.common.dao.BaseDao;
import com.qzsoft.common.exception.BusinessException;
import com.qzsoft.common.tools.CustomDbRecordUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 公用Dao实现
 * 注：子类继承使用某些方法需要重新赋值tableName为对应的表名
 *
 * @author zhz
 */
@Repository
public class BaseDaoImpl implements BaseDao {

    protected final Logger log = LoggerFactory.getLogger(getClass());

    /**
     * 对应表名
     */
    public String tableName = "";

    @Override
    public Boolean save(Record record) {
        return DbEx.save(tableName, record);
    }

    @Override
    public Boolean save(String tableName, Record record) {
        return DbEx.save(tableName, record);
    }

    @Override
    public Boolean update(Record record) {
        return DbEx.update(tableName, record);
    }

    @Override
    public Boolean update(String tableName, Record record) {
        return DbEx.update(tableName, record);
    }

    @Override
    public Boolean deleteById(Long id) {
        return DbEx.deleteById(tableName, id);
    }

    @Override
    public Boolean deleteById(String tableName, Long id) {
        return DbEx.deleteById(tableName, id);
    }

    @Override
    public Boolean deleteByCustom(String tableName, String customColumns, List<String> values) {
        StringBuffer sql = new StringBuffer("delete from ");
        sql.append(tableName).append(" where 1=1 and ").append(customColumns).append(" in(");
        sql.append(Joiner.on(",").join(values)).append(" )");
        return DbEx.delete(sql.toString()) == values.size() ? true : false;
    }

    @Override
    public Page<Record> getPageList(Integer page, Integer pageSize) {
        return DbEx.paginate(page, pageSize, "select *", "from " + tableName);
    }

    @Override
    public Page<Record> getPageList(String tableName, Integer page, Integer pageSize) {
        return DbEx.paginate(page, pageSize, "select *", "from " + tableName);
    }

    @Override
    public Record selectById(Long id) {
        return DbEx.findById(tableName, id);
    }

    @Override
    public Record selectById(String tableName, Long id) {
        return DbEx.findById(tableName, id);
    }

    @Override
    public Boolean addColumn(String columnName, String type, Integer length) {
        return DbEx.update("alter table " + tableName + " add " + columnName + " " + type + "(" + length + ")") > 0;
    }

    @Override
    public Boolean addColumn(String tableName, String columnName, String type, Integer length) {
        return DbEx.update("alter table " + tableName + " add " + columnName + " " + type + "(" + length + ")") > 0;
    }

    @Override
    public Boolean updateColumn(String columnName, String type, Integer length) {
        return DbEx.update("alter table " + tableName + " MODIFY " + columnName + " " + type + "(" + length + ")") > 0;
    }

    @Override
    public Boolean updateColumn(String tableName, String columnName, String type, Integer length) {
        return DbEx.update("alter table " + tableName + " MODIFY " + columnName + " " + type + "(" + length + ")") > 0;
    }


    @Override
    public Boolean updateByVersionAndPrimaryKey(String primaryKey, Record record) {
        if (StringUtils.isNotBlank(primaryKey)) {
            throw new BusinessException("条件列名不能为空");
        }
        if (!primaryKey.endsWith(",")) {
            primaryKey += ",";
        }
        primaryKey += CommonConstants.UP_VERSION_COLUMN_NAME;
        return CustomDbRecordUtil.updateByVersion(primaryKey, tableName, record);
    }

    @Override
    public Boolean updateByVersionAndPrimaryKey(String tableName, String primaryKey, Record record) {
        if (StringUtils.isBlank(primaryKey)) {
            throw new BusinessException("条件列名不能为空");
        }
        if (!primaryKey.endsWith(",")) {
            primaryKey += ",";
        }
        primaryKey += CommonConstants.UP_VERSION_COLUMN_NAME;
        return CustomDbRecordUtil.updateByVersion(primaryKey, tableName, record);
    }

    /**
     * 修改-通过版本和主键
     *
     * @param
     * @param record
     * @return
     */
    @Override
    public Boolean updateByVersionAndId(String tableName, Record record) {
        String primaryKey = CommonConstants.IDCOLUMN + "," + CommonConstants.UP_VERSION_COLUMN_NAME;
        return CustomDbRecordUtil.updateByVersion(primaryKey, tableName, record);
    }

    @Override
    public Boolean updateByVersionAndId(Record record) {
        String primaryKey = CommonConstants.IDCOLUMN + "," + CommonConstants.UP_VERSION_COLUMN_NAME;
        return CustomDbRecordUtil.updateByVersion(primaryKey, tableName, record);
    }

    @Override
    public Boolean updateByPrimaryKey(String primaryKey, Record record) {
        if (StringUtils.isBlank(primaryKey)) {
            throw new BusinessException("条件列名不能为空");
        }
        return DbEx.update(tableName, primaryKey, record);
    }

    @Override
    public Boolean updateByPrimaryKey(String tableName, String primaryKey, Record record) {
        if (StringUtils.isBlank(primaryKey)) {
            throw new BusinessException("条件列名不能为空");
        }
        return DbEx.update(tableName, primaryKey, record);
    }

    @Override
    public Boolean saveAndUpVer(Record record) {
        if (record == null) {
            throw new BusinessException("操作数据对象不能为空。");
        }
        record.set(CommonConstants.UP_VERSION_COLUMN_NAME, 1);
        return DbEx.save(tableName, record);
    }

    @Override
    public Boolean saveAndUpVer(String tableName, Record record) {
        if (record == null) {
            throw new BusinessException("操作数据对象不能为空。");
        }
        record.set(CommonConstants.UP_VERSION_COLUMN_NAME, 1);
        return DbEx.save(tableName, record);
    }

    @JFinalTx
    @Override
    public Boolean saveList(List<Record> recordList) {
        if (recordList == null || recordList.size() == 0) {
            throw new BusinessException("批量添加的数据不能为空。");
        }
        buildListColumn(recordList);
        boolean isSucuess = DbEx.tx(new IAtom() {
            @Override
            public boolean run() {
                return DbEx.batchSave(tableName, recordList, recordList.size()).length == recordList.size();
            }
        });
        return isSucuess;
    }

    @JFinalTx
    @Override
    public Boolean saveList(String tableName, List<Record> recordList) {
        if (recordList == null || recordList.size() == 0) {
            throw new BusinessException("批量添加的数据不能为空。");
        }
        buildListColumn(recordList);
        boolean isSucuess = DbEx.tx(new IAtom() {
            @Override
            public boolean run() {
                return DbEx.batchSave(tableName, recordList, recordList.size()).length == recordList.size();
            }
        });
        return isSucuess;
    }

    private void buildListColumn(List<Record> recordList) {
        DbEx.alignOfColumn(recordList);
    }

    @JFinalTx
    @Override
    public Boolean updateList(List<Record> recordList) {
        if (recordList == null || recordList.size() == 0) {
            throw new BusinessException("批量添加的数据不能为空。");
        }
        buildListColumn(recordList);
        boolean isSucuess = DbEx.tx(new IAtom() {
            @Override
            public boolean run() {
                return DbEx.batchUpdate(tableName, recordList, recordList.size()).length == recordList.size();
            }
        });
        return isSucuess;
    }

    @JFinalTx
    @Override
    public Boolean updateList(String tableName, List<Record> recordList) {
        if (recordList == null || recordList.size() == 0) {
            throw new BusinessException("批量添加的数据不能为空。");
        }
        buildListColumn(recordList);
        boolean isSucuess = DbEx.tx(new IAtom() {
            @Override
            public boolean run() {
                return DbEx.batchUpdate(tableName, recordList, recordList.size()).length == recordList.size();
            }
        });
        return isSucuess;
    }

    @Override
    public Boolean deleteByCustom(String customColumns, Object... objects) {
        return DbEx.deleteById(tableName, customColumns, objects);
    }

    @Override
    public Boolean deleteByCustom(String tableName, String customColumns, Object... objects) {
        return DbEx.deleteById(tableName, customColumns, objects);
    }

    /**
     * 通过字段查询
     *
     * @param tableName        表名
     * @param customColumnName 列名的","分隔字符串
     * @param object           列值
     * @return
     */
    @Override
    public List<Record> selectListByCustom(String tableName, String customColumnName, Long id, Object... object) {
        if (StringUtils.isBlank(tableName)) {
            throw new BusinessException("表名不能为空。");
        }
        StringBuffer sb = new StringBuffer();
        sb.append("select * from " + tableName);
        if (StringUtils.isBlank(customColumnName) || ObjectUtils.isEmpty(object)) {
            return DbEx.find(sb.toString());
        }
        sb.append(" where 1=1 ");
        String[] columnNames = customColumnName.split(",");
        for (int i = 0; i < columnNames.length; i++) {
            sb.append(" and ");
            sb.append(columnNames[i] + " = ? ");

        }
        if (!ObjectUtils.isEmpty(id)) {
            sb.append(" and " + CommonConstants.IDCOLUMN).append(" != ").append(id);
        }
        return DbEx.find(sb.toString(), object);
    }

    /**
     * 通过字段查询
     *
     * @param tableName        表名
     * @param customColumnName 列名的","分隔字符串
     * @param object           列值
     * @return
     */
    @Override
    public List<Record> selectListByCustom(String tableName, String customColumnName, Object... object) {
        return selectListByCustom(tableName, customColumnName, null, object);
    }

    /**
     * 通过字段查询
     */
    @Override
    public List<Record> selectListByCustom(String customColumnName, Object... object) {
        return selectListByCustom(tableName, customColumnName, null, object);
    }

    /**
     * 复杂分页查询
     *
     * @param select
     * @param from
     * @param where
     * @param pageNum
     * @param pageSize
     */

    @Override
    public Page<Record> getPageList(String select, String from, String where, Integer pageNum, Integer pageSize) {
        String sqlExceptSelect = " from " + from;
        if (StringUtils.isNotBlank( where)){
            sqlExceptSelect += " where " + where;
        }
        Page<Record> recordPage = DbEx.paginate(pageNum, pageSize, "select " + select, sqlExceptSelect);
        return recordPage;
    }

    @Override
    public Page<Record> getPageList(String select, String from, String where, Integer pageNum, Integer pageSize, boolean isGroupBySql, Object... paras) {
        select = "select " + select;
        String sqlExceptSelect = " from " + from;
        if (StringUtils.isNotBlank( where)){
            sqlExceptSelect += " where " + where;
        }
        Page<Record> recordPage = DbEx.paginate(pageNum, pageSize, false, select, sqlExceptSelect, paras);
        return recordPage;
    }

    /**
     * 是否存在某个表
     */
    @Override
    public boolean isExistTable(String table) {
        List<Record> tableField = getTableField(table);
        return tableField != null && !tableField.isEmpty();
    }

//	 /**
//     * 取数据库所有表
//     * @author lzy
//     * @date
//     * @parameter
//     */
//	@Override
//    public List<Record> getTableInfo() {
//	    使用DataSourceHolder.geTableMetaRecordListFromMasterDbMetas替换DbEx.find("show table status")
//    	return  DbEx.find("show table status");
//    }

    /**
     * 查询所有
     */
    @Override
    public List<Record> findAll(String table, String sort) {
        String sql = "select * from " + table;
        if (StringUtils.isNotBlank(sort)) {
            sql += " order by " + sort + " desc";
        }
        List<Record> recordList = DbEx.find(sql);
        return recordList;
    }


    /**
     * 通过表名获取表字段信息
     */
    @Override
    public List<Record> getTableField(String tableName) {
        List<Record> recordList = DbEx.getColMetaByTableName(tableName);
        return recordList;
    }

    /**
     * 通过某个字段判断是否存在记录
     */
    @Override
    public Boolean isExistRecord(String tableName, String column, String value) {
        String sql = "select id from " + tableName + " where " + column + " =?";
        Record record = DbEx.findFirst(sql, value);
        return null != record;
    }

    /**
     * 根据某个字段获取一行
     */
    @Override
    public Record getOneByColumn(String tableName, String customColumnName, Object... object) {
        if (StringUtils.isBlank(tableName)) {
            throw new BusinessException("表名不能为空。");
        }
        StringBuffer sb = new StringBuffer();
        sb.append("select * from " + tableName);
        if (StringUtils.isBlank(customColumnName) || ObjectUtils.isEmpty(object)) {
            return DbEx.findFirst(sb.toString());
        }
        sb.append(" where 1=1 ");
        String[] columnNames = customColumnName.split(",");
        for (int i = 0; i < columnNames.length; i++) {
            sb.append(" and ");
            sb.append(columnNames[i] + " = ? ");

        }
        return DbEx.findFirst(sb.toString(), object);
    }

    /**
     * 根据某个字段获取一行
     */
    @Override
    public Record getOneByColumn(String customColumnName, Object... object) {
        return getOneByColumn(tableName, customColumnName, object);
    }

    /**
     * 根据某个字段批量删除
     */

    @JFinalTx
    @Override
    public Boolean batchDelete(String tableName, String column, List<String> list) {
        if (StringUtils.isNotBlank(tableName) && StringUtils.isNotBlank(column) && null != list && list.size() > 0) {
            StringBuffer sb = new StringBuffer();
            sb.append(" and ").append(column).append(" in(");
            for (int i = 0; i < list.size(); i++) {
                sb.append("?");
                if (i != list.size() - 1) {
                    sb.append(",");
                }
            }
            sb.append(")");
            String sql = "delete from " + tableName + " where 1=1 ";
            sql += sb.toString();
            DbEx.delete(sql, list.toArray());
        }
        return true;
    }

    /**
     * 删除b、c表
     */
    @JFinalTx
    @Override
    public Boolean deleteByMcode(String m_code, String isBC, String tableB, String tableC) {
        if (StringUtils.isNotBlank(m_code) && StringUtils.isNotBlank(isBC)) {
            String table = isBC.equals(TableBCEnum.b.name()) ? tableB : tableC;
            return deleteByCustom(table, "m_code", m_code);
        }
        return true;
    }

    /**
     * @Author: pzq
     * @Date: 2018/5/22
     * @Params: [tableName]
     * @Description: 清空表数据
     */
    @Override
    public void clearDataByTable(String tableName) {
        DbEx.delete("delete from " + tableName);
    }

    /**
     * 通过字段查询排序
     */
    @Override
    public List<Record> selectListByCustomAndSort(String tableName, String customColumnName, String sortColumn, Boolean isDesc, Object... object) {
        if (StringUtils.isBlank(tableName)) {
            throw new BusinessException("表名不能为空。");
        }
        StringBuffer sb = new StringBuffer();
        sb.append("select * from " + tableName);
        if (StringUtils.isBlank(customColumnName) || ObjectUtils.isEmpty(object)) {
            return DbEx.find(sb.toString());
        }
        sb.append(" where 1=1 ");
        String[] columnNames = customColumnName.split(",");
        for (int i = 0; i < columnNames.length; i++) {
            sb.append(" and ");
            sb.append(columnNames[i] + " = ? ");

        }
        if (isDesc) {//倒序
            sb.append(" order by ").append(sortColumn).append(" desc ");
        } else {
            sb.append(" order by ").append(sortColumn);
        }
        return DbEx.find(sb.toString(), object);
    }

    /**
     * 通过字段模糊查询排序
     */
    @Override
    public List<Record> selectListByCustomAndSortSearch(String tableName, String customColumnName, String sortColumn, Boolean isDesc, String search, String searchColumn, Object... object) {
        if (StringUtils.isBlank(tableName)) {
            throw new BusinessException("表名不能为空。");
        }
        StringBuffer sb = new StringBuffer();
        sb.append("select * from " + tableName);
        if ((StringUtils.isBlank(customColumnName) || ObjectUtils.isEmpty(object)) &&
                (StringUtils.isBlank(search) || StringUtils.isBlank(searchColumn))) {
            return DbEx.find(sb.toString());
        }
        sb.append(" where 1=1 ");

        if (!StringUtils.isBlank(customColumnName) && !ObjectUtils.isEmpty(object)) {
            String[] columnNames = customColumnName.split(",");
            for (int i = 0; i < columnNames.length; i++) {
                sb.append(" and ");
                sb.append(columnNames[i] + " = ? ");

            }
        }

        List<String> searchList = new ArrayList<>();
        if (!StringUtils.isBlank(search) && !StringUtils.isBlank(searchColumn)) {
            String[] searchColumnNames = searchColumn.split(",");

            StringBuffer searchWhere = new StringBuffer();
            for (int i = 0; i < searchColumnNames.length; i++) {
                searchWhere.append(" locate(?," + searchColumnNames[i] + ")>0 or ");
                searchList.add(search);
            }
            String sb1 = searchWhere.substring(0, searchWhere.lastIndexOf("or"));
            sb.append("  and ( ");
            sb.append(sb1);
            sb.append("  ) ");
        }

        if (isDesc) {//倒序
            sb.append(" order by ").append(sortColumn).append(" desc ");
        } else {
            sb.append(" order by ").append(sortColumn);
        }

        List<Object> paras = new ArrayList<Object>();
        Object[] paras1 = object.clone();
        if (paras1 != null && paras1.length > 0) {
            for (Object para1 : paras1) {
                paras.add(para1);
            }
        }
        if (searchList != null && searchList.size() > 0) {
            for (Object search1 : searchList) {
                paras.add(search1);
            }
        }

        List<Record> recs = DbEx.find(sb.toString(), paras.toArray());
        return recs;
    }

    /**
     * 通过字段集合获取数据
     */
    @Override
    public List<Record> getByColumnList(String column, List<String> fieldList) {
        if (StringUtils.isNotBlank(column) && null != fieldList && fieldList.size() > 0) {
            String inSql = CustomDbRecordUtil.getInSql(column, fieldList);
            String sql = "select * from " + tableName + " where 1=1 " + inSql;
            List<Record> recordList = DbEx.find(sql, fieldList.toArray());
            return recordList;
        }
        return null;
    }

    @Override
    public List<Record> getByColumnList(String tableName, String column, List<String> fieldList) {
        if (StringUtils.isNotBlank(column) && null != fieldList && fieldList.size() > 0) {
            String inSql = CustomDbRecordUtil.getInSql(column, fieldList);
            String sql = "select * from " + tableName + " where 1=1 " + inSql;
            sql += " order by cr_dm desc";
            List<Record> recordList = DbEx.find(sql, fieldList.toArray());
            return recordList;
        }
        return null;
    }

    @Override
    public List<Record> selectListBySql(String sql, Object... object) {
        return DbEx.find(sql, object);
    }

    @Override
    public Record selectFirstOneBySql(String sql, Object... object) {
        return DbEx.findFirst(sql, object);
    }


    /**
     * 环境变量条件
     */
    @Override
    public List<Record> getEnvWhereList(String table, String para_type_k, String para_type, String button_code, String m_code, String info_code) {
        String sql = "select para_type_k,para_name,para_val,para_type,sql_type,sql_do,group_type,group_no from " + table + " where 1=1 ";
        List<String> list = new ArrayList<>();
        if (StringUtils.isNotBlank(para_type_k)) {
            sql += " and para_type_k=? ";
            list.add(para_type_k);
        }
        if (StringUtils.isNotBlank(para_type)) {
            sql += " and para_type=? ";
            list.add(para_type);
        }
        if (StringUtils.isNotBlank(button_code)) {
            sql += " and button_code=? ";
            list.add(button_code);
        }
        if (StringUtils.isNotBlank(m_code)) {
            sql += " and m_code=? ";
            list.add(m_code);
        }
        if (StringUtils.isNotBlank(info_code)) {
            sql += " and info_code=? ";
            list.add(info_code);
        }
        return DbEx.find(sql, list.toArray());
    }

    @Override
    public Boolean updateBySql(String sql, Object... object) {
        return DbEx.update(sql, object) >= 0;
    }

    @Override
    public List<Record> selectListBySqlNoParas(String sql) {
        return DbEx.find(sql);
    }

    @Override
    public Record getMaxColumnRecord(String table, String column) {
        String sql = "select max(" + column + "+0) as " + column + " from " + table;
        return DbEx.findFirst(sql);
    }


    /**
     *根據多個字段批量删除
     * @param tableName
     * @param map -----> key is column  value is List<params>
     * @return
     */
    @JFinalTx
    @Override
    public Boolean batchDeleteOfMany(String tableName, Map<String, List> map) {
        StringBuffer sb = new StringBuffer();
        if (map != null && !map.isEmpty() && StringUtils.isNotBlank(tableName)) {
            Set<String> keys = map.keySet();
            for (String column : keys) {
                if(StringUtils.isBlank(column))
                    continue;
                List list = map.get(column);
                if (list != null && list.size() > 0) {
                    sb.append(" and ").append(column).append(" in( ");
                    for (int i = 0; i < list.size(); i++) {
                        sb.append("'"+list.get(i)+"'");
                        if (i == list.size() - 1) {
                            sb.append(" )");
                        } else {
                            sb.append(",");
                        }
                    }
                }
            }
            if(sb.length() > 0){
                String sql = "delete from "+tableName;
                sql += sb.toString().replaceFirst("and","where");
                DbEx.delete(sql);
            }
        }
        return true;
    }
}
