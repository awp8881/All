package com.qzsoft.jdialects.hibernatesrc;

/**
 * All .java files in this "hibernate" folder are copied from Hibernate
 * 5.2.9.Final, some are made some tiny modifications - Yong Zhu
 */
public class PackageInfo {// NOSONAR
}
