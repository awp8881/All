package com.qzsoft.common.activerecord;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.jfinal.plugin.activerecord.Record;
import com.qzsoft.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author pjh
 * @Title: DataSourceHolder
 * @Description: 数据源帮助类,本类设计有缺陷，使用时必须先调用init方法进行服务初始化，用时先注意
 * @date 2018/7/10 16:19
 */
@Slf4j
@Component
public class DataSourceHolder {



    public enum DbModeEnum{
        read,
        write,
        //指定模式
        assign
    }

    //线程本地环境
    private static final ThreadLocal<DbModeEnum> dbModeHolders = new ThreadLocal<DbModeEnum>();
    private static final ThreadLocal<String> dbNameHolders = new ThreadLocal<String>();
    private static final ThreadLocal<Map<String,Object>> dbPropertyHolders = new ThreadLocal<Map<String,Object>>();
    //设置数据源
    public static void setDbMode(DbModeEnum dbModeEnum) {
        dbModeHolders.set(dbModeEnum);
    }

    /**
     * 设定数据源模式
     * @param dbModeEnum
     * @param sourceName 数据源名称
     */
    public static void setDbMode(DbModeEnum dbModeEnum,String sourceName) {
        dbModeHolders.set( dbModeEnum );
        dbNameHolders.set( sourceName );
    }
    //获取数据源
    public static DbModeEnum getDbMode() {
        return  dbModeHolders.get();
    }
    //清除数据源
    public static void clearDbMode() {
        dbModeHolders.remove();
        dbNameHolders.remove();
    }
    private static String getAssignDbName(){
        return dbNameHolders.get();
    }
    //获取配置
    public static void setDbPropertyHolders(Map<String,Object> property){
        dbPropertyHolders.set(property);
    }
    public static Map<String,Object> getDbProperty(){
        return dbPropertyHolders.get();
    }

    //持有的数据源名称
    private static Set<String> masterDsNames = new TreeSet<>();
    //持有的数据源名称
    private static Set<String> slaveDsNames = new TreeSet<>();
    //持有的三方数据源名称 不参与库的加载，列表展示
    private static Set<String> outerDsNames = new TreeSet<>();

    private static DbMetaService dbMetaService;

    public static Set<String> getMasterDsNames(){
        return new TreeSet<>( masterDsNames );
    }

    public static boolean checkDataSource(String dataSource) {
        return masterDsNames.contains( dataSource ) || slaveDsNames.contains( dataSource ) || outerDsNames.contains( dataSource ) ;
    }

    public static void init( DbMetaService dbMetaService ){
        DataSourceHolder.dbMetaService = dbMetaService;
    }


    public static void reloadDataSource() {
        Set<String> masterDsNameSet = masterDsNames ;
        for (String dataSourceName : masterDsNameSet) {
            addMasterDataSource(dataSourceName);
        }
        Set<String> slaveDsNameSet = slaveDsNames ;
        for (String dataSourceName : slaveDsNameSet) {
            addSlaveDataSource(dataSourceName);
        }
    }

    /**
     * 加载主数据源
     * @param dataSourceName
     */
    public static void addMasterDataSource(String dataSourceName) {
        masterDsNames.add( dataSourceName );
    }

    /**
     * 加载从数据源
     * @param dataSourceName
     */
    public static void addSlaveDataSource(String dataSourceName) {
        slaveDsNames.add( dataSourceName );
    }

    /**
     * 添加三方库
     * @param dataSourceName
     */
    public static void addOuterDataSource(String dataSourceName) {
        outerDsNames.add( dataSourceName );
    }


    protected static List<Record> getColMetaByTableName( String tableName ){
        return dbMetaService.getColMetaByTableName( Sets.newTreeSet( masterDsNames )  , tableName );
    }


    public static String getDataSourceNameByTableName(String tableName) {

        if( DbModeEnum.assign.equals( getDbMode() ) ){
            //如果是指定模式  指定数据源不能为空
            if( StringUtils.isBlank( getAssignDbName() ) ){
                BusinessException.throwBiz( "数据源不能为空" );
            }
            return getAssignDbName();
        }else if (DbModeEnum.read.equals( getDbMode() )) {
            if( slaveDsNames.size() == 1 ){
                return slaveDsNames.iterator().next();
            }
            return dbMetaService.getDataSourceNameByTableName(  Sets.newTreeSet( slaveDsNames ), tableName, DbModeEnum.read.name() );
        }else{
            if( masterDsNames.size() == 1 ){
                return masterDsNames.iterator().next();
            }
            return dbMetaService.getDataSourceNameByTableName( Sets.newTreeSet( masterDsNames ), tableName, DbModeEnum.write.name() );
        }

    }

    public static List<Record> geTableMetaRecordListFromMasterDbMetas(){
        return dbMetaService.geTableMetaRecordListFromMasterDbMetas( Sets.newTreeSet( masterDsNames ) );
    }

    public static List<Record> getColMetaRecordListFromMasterDbMetas(){
        return dbMetaService.getColMetaRecordListFromMasterDbMetas( Sets.newTreeSet( masterDsNames ) );
    }



}
