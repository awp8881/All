package com.qzsoft.common.mvc.configuration;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.net.UnknownHostException;
import java.time.Duration;
import java.util.Map;
import java.util.Set;

@Configuration
public class RedisConfiguration {


//	@Bean
//	public RedisTemplate<Object, Object> redisTemplate(
//			RedisConnectionFactory redisConnectionFactory) throws UnknownHostException {
//		RedisTemplate<Object, Object> template = new RedisTemplate<>();
//		template.setConnectionFactory(redisConnectionFactory);
//		template.setKeySerializer(new StringRedisSerializer());
//		template.setValueSerializer(new JdkSerializationRedisSerializer());
//		template.setHashKeySerializer(new StringRedisSerializer());
//		template.setHashValueSerializer(new JdkSerializationRedisSerializer());
//		template.setConnectionFactory(redisConnectionFactory);
//		return template;
//	}


//	@Bean(name="stringRedisTemplate")
//	public RedisTemplate<Object, Object> stringRedisTemplate(
//			RedisConnectionFactory redisConnectionFactory)
//			throws UnknownHostException {
//		RedisTemplate<Object, Object> template = new RedisTemplate<Object, Object>();
//		template.setKeySerializer(new StringRedisSerializer());
//		template.setValueSerializer(new StringRedisSerializer());
//		template.setConnectionFactory(redisConnectionFactory);
//		return template;
//	}


//	@Bean(name="redisCacheManager")
//	public RedisCacheManager redisCacheManager(RedisTemplate<Object, Object> redisTemplate){
//		RedisCacheManager redisCacheManager = new RedisCacheManager(redisTemplate);
//		redisCacheManager.setUsePrefix(true);
//		Map<String, Long> expires = new LinkedHashMap<>();
////		expires.put(shiroVars.activeSessionsCacheName, shiroVars.sessionTimeout);
//		expires.put("CACHE_RESET_LOGIN_PWD_VFCODE", 3600l);
//		expires.put("SensJidAndMcode", 60*60*8L);
//		redisCacheManager.setExpires(expires);
//		redisCacheManager.setDefaultExpiration(shiroVars.defaultExpireTime);
//		return redisCacheManager;
//	}

	@Bean
	@ConditionalOnMissingBean(RedisSerializer.class)
	public RedisSerializer<Object> redisSerializer() {
		return new RedisObjectSerializer();
	}


	@Bean
	public RedisTemplate<Object, Object> redisTemplate(
			RedisConnectionFactory redisConnectionFactory, RedisSerializer<Object> redisObjSerializer) throws UnknownHostException {
		RedisTemplate<Object, Object> template = new RedisTemplate<>();
		template.setConnectionFactory(redisConnectionFactory);
		template.setKeySerializer(new StringRedisSerializer());
		template.setValueSerializer(new JdkSerializationRedisSerializer());
		template.setHashKeySerializer(new StringRedisSerializer());
		template.setHashValueSerializer(new JdkSerializationRedisSerializer());
		template.setConnectionFactory(redisConnectionFactory);
		return template;
	}




	@Bean
	public RedisCacheManager redisCacheManager(RedisConnectionFactory factory){
		RedisCacheConfiguration commonCacheConfig =  RedisCacheConfiguration.defaultCacheConfig();
		commonCacheConfig = commonCacheConfig.computePrefixWith( cacheName -> cacheName+":" );

		Set<String> specialCacheConfigSet = Sets.newHashSet();
		specialCacheConfigSet.add( "SensJidAndMcode" );
		// 对每个缓存空间应用不同的配置
		Map<String, RedisCacheConfiguration> specialCacheConfigMap = Maps.newHashMap();
		specialCacheConfigMap.put("SensJidAndMcode", commonCacheConfig.entryTtl(Duration.ofHours(8L)));
		specialCacheConfigMap.put("LIST_QUERY_SQL", commonCacheConfig.entryTtl(Duration.ofHours(1L)));
		specialCacheConfigMap.put("sysConfigInfo", commonCacheConfig.entryTtl(Duration.ofSeconds(-1L)));


		RedisCacheManager redisCacheManager =  RedisCacheManager.builder(factory)
				.cacheDefaults(commonCacheConfig)
				.initialCacheNames( specialCacheConfigSet )
				.withInitialCacheConfigurations( specialCacheConfigMap )
				.build();
		return redisCacheManager;
	}


//	@Bean
//	RedisMessageListenerContainer redisMessageListenerContainer(MessageListenerAdapter listenerAdapter,
//																RedisConnectionFactory redisConnectionFactory) {
//		RedisMessageListenerContainer container = new RedisMessageListenerContainer();
//		container.setConnectionFactory(redisConnectionFactory);
//		container.addMessageListener(listenerAdapter, Arrays.asList(new PatternTopic("notify_refresh_list"),
//				new PatternTopic("notify_sse_msg"),
//				new PatternTopic("scheduler_pause"),
//		new PatternTopic("scheduler_resume"),
//		new PatternTopic("scheduler_delete"),
//		new PatternTopic("qz_api")));
//		return container;
//	}

}
