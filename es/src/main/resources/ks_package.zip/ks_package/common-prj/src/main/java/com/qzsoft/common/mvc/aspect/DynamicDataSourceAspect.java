package com.qzsoft.common.mvc.aspect;

import com.qzsoft.common.activerecord.DataSourceHolder;
import com.qzsoft.common.activerecord.TargetDataSource;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * @author pjh
 * @Title: DynamicDataSourceAspect
 * @Description: 动态数据源切换切面
 * @date 2018/7/10 16:19
 */
@Aspect
@Order(-1)// 保证该AOP在@Transactional之前执行
@Component
@Slf4j
public class DynamicDataSourceAspect {


    @Before("@annotation(ds)")
    public void changeDataSource(JoinPoint point, TargetDataSource ds) throws Throwable {
//        String dsId = ds.name();
//        if (!DataSourceHolder.containsDataSource(dsId)) {
//            log.error("dataSource[{}]not exist，will use default dataSource > {}", ds.name(), point.getSignature());
//        } else {
//            log.info("Use dataSource : {} dataSource when {} starting", ds.name(), point.getSignature());
//        }
        log.info("设置数据库读写操作为: {}",ds.dbMode().toString() );
        DataSourceHolder.setDbMode( ds.dbMode() );
    }

    @After("@annotation(ds)")
    public void restoreDataSource(JoinPoint point, TargetDataSource ds) {
//        log.info("Revert dataSource : {} dataSource -> {} dataSource when {} finish", ds.name(), "default" ,point.getSignature());
        log.info("清除数据库操作模式{}",ds.dbMode().toString() );
        DataSourceHolder.clearDbMode();
    }

}