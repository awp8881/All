package com.qzsoft.common.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;
import java.util.Set;

/**
 * @Description:保存ks用户请求对象
 * @author: zhouyou
 * @date: 2022/02/14 15:43
 **/
@Data
@ApiModel(description = "ks用户信息")
public class KsUserInfo implements Serializable {

    private static final long serialVersionUID = 914558577507108953L;

    @ApiModelProperty(value = "用户id", dataType = "String")
    private String id;

    @ApiModelProperty(value = "用户token", dataType = "String")
    private String token;

    @ApiModelProperty(value = "登录账号", dataType = "String")
    @NotBlank
    private String user_name;

    @ApiModelProperty(value = "真实名称", dataType = "String")
    private String real_name;

    @ApiModelProperty(value = "用户密码", dataType = "String")
    private String password;

    @ApiModelProperty(value = "用户类型:0-普通用户,1-只读用户", dataType = "String")
    private String user_type;

    @ApiModelProperty(value = "用户描述", dataType = "String")
    private String user_desc;

    @ApiModelProperty(value = "用户组id", dataType = "String")
    private String group_id;

    @ApiModelProperty(value = "用户组类型", dataType = "String")
    private String group_type;


    private String requestURI;

    @ApiModelProperty(value = "资源id", dataType = "String")
    private List<String> res_id;

    @ApiModelProperty(value = "资源url", dataType = "String")
    private List<String> res_url;
}
