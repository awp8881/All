package com.qzsoft.common.activerecord.handler;

import com.qzsoft.common.activerecord.AbstractSpecialSqlHandler;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author pjh
 * @Title: SqlServerLocateFunHandler
 * @Description: 处理mysql locate函数模糊查询
 * @date 2018/7/16 10:44
 */
public class SqlServerLocateFunHandler extends AbstractSpecialSqlHandler {


//    str.replaceAll( "locate[\\s\\S]*\\(\\s*(['\"]?)(\\S*)(\\1)\\s*,([\\s\\S]*)\\)"," $4 like $2 " );

    private static final String  SEPCIAL_SQL_REGULAR = "locate\\s*\\(\\s*(['\"]?)([_ % # ? a-z A-Z 0-9]*)(\\1)\\s*,([_ a-z A-Z 0-9]*)\\)";

    //等价sql where locate(?,res_na)  = 》 where res_na like ?

    @Override
    public String handlerSQL(String sql) {

        return locateToLike( sql );
    }


    private static String locateToLike(String str) {

        str = str.replaceAll("\\?","##0##");
        Pattern pattern = Pattern.compile("locate\\s*\\(\\s*(['\"]?)([\\s\\S]*)(\\1)\\s*,([\\s\\S]*)\\)");
        Matcher matcher = pattern.matcher( str );
        while (matcher.find()) {
            String likeWhere = matcher.group(2);
            String qianyinhao = matcher.group(1);
            String houyinhao = matcher.group(3);
            String tmp = likeWhere;
            //如果没有引号包裹  去掉查询条件两边空格
            if( StringUtils.isEmpty(qianyinhao) && StringUtils.isEmpty(houyinhao) ){
                tmp = tmp.trim();
                str = str.replace( likeWhere,tmp );
            }
            if( likeWhere.contains("%") ){
                tmp = tmp.replaceAll("%", "\\%");
                str = str.replaceAll( likeWhere ,tmp );
            }

        }
        str = str.replaceAll("##0##","?");
        String likeSql = str.replaceAll( "locate\\s*\\(\\s*(['\"]?)([\\s\\S]*)(\\1)\\s*,([\\s\\S]*)\\)"," $4 like '%' + $2 + '%' " );
        return likeSql;
    }

}
