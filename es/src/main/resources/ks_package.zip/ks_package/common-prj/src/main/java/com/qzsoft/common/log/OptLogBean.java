package com.qzsoft.common.log;

import lombok.Data;

/**
 * @author pjh
 * @Title: OptLogBean
 * @Description: TODO
 * @date 2018/11/7 15:13
 */
@Data
public class OptLogBean {

    private Boolean isRecordOpt=false;

    private String module;

    private String remark;

    private String batchNo;

    private String optUser;

    private String optTable;

    private String optType;

    private String batchOrder="0";
}
