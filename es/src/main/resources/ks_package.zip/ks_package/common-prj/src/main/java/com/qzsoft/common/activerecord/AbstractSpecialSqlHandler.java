package com.qzsoft.common.activerecord;

import com.google.common.base.CharMatcher;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author pjh
 * @Title: AbstractSpecialSqlHandler
 * @Description: 特殊sql处理器
 * @date 2018/7/12 15:41
 */
public abstract class AbstractSpecialSqlHandler {

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     *
     * @param sql 要处理的sql
     * @return 返回处理后的sql
     */
    public String handler( String sql ){
        if( StringUtils.isEmpty(sql) ){
            return sql;
        }
        //去掉中间多余空格，保留一个空格
        sql = CharMatcher.whitespace().collapseFrom(sql, ' ');
        String oldSql = sql;
        sql = handlerSQL(sql);
        logger.debug("use {} handler Special Sql----->:{},handler result Sql ---->{} ", getClass().getSimpleName(), oldSql, sql );

        return sql;
    }


    /**
     *
     * @param sql 标准sql（去掉中间多余空格，保留一个空格）
     * @return 返回处理后的sql
     */
    public abstract String handlerSQL( String sql );

}
