package com.qzsoft.common.constants;

import com.google.common.collect.Sets;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CommonConstants {
	// 生成文件名和唯一ID标识
	public static final String CERT_S = "c";
	public static final String PIC_S = "p";
	public static final String DOC_S = "d";
	public static final String OTH_S = "o";
	public static final String INST_S = "i";
	public static final int ICON_WIDTH = 300;
	public static final int ICON_HEIGHT = 500;

	// 基础服务根编号
	public static final String TREE_ROOT = "-1";
	public static final String PIC_ROOT = "0";
	public static final String TREE_CODE = "ROOT";

	// 分页参数
	public static final String PAGE_NUM = "1";
	public static final String PAGE_SIZE = "10";

	// loginnamekey
	public static final String LOGIN_NAME_KEY = "GET_LOGINNAME_BY_JID";

	// 当前用户可以访问的前端菜单列表，从session中取
	public static final String MENU_FE_LIST_KEY = "MENU_FE_LIST";

	public static final String MENU_ALL_ROLL_LIST_KEY = "MENU_ALL_ROLE_LIST";

	// 系统机器人
	public static final String ROBOT = "robot";
	// tu系统返回码
	public static final String SUCUSS_CODE = "suc";

	// lims分页参数
	public static final Integer NUM = 1;
	public static final Integer SIZE = 100;

	/**
	 * 乐观锁数据库列名
	 */
	public static final String UP_VERSION_COLUMN_NAME = "up_ver";
	/**
	 * prn数据库列名
	 */
	public static final String PRN = "prn";

	/**
	 * 主键id
	 * */
	public static final String IDCOLUMN = "id";

	/**
	 * 菜单根目录
	 * */
	public static final String MENU_ROOT = "菜单管理";

	/**
	 * 字典根目录
	 * */
	public static final String DICD_ROOT = "字典管理";

	public static final String TABLE_PRE = "ks_";

	public static final Integer DEF_WIDTH=120;//字段显示默认宽度

	public static final String KS_CREATE_TIME="cr_dm";
	public static final String OTHER_CREATE_TIME="create_time";
	public static final String KS_UPDATE_TIME="up_dm";
	public static final String BIZ_TENANT_ID="tenant_id";
	public static final String OTHER_UPDATE_TIME="update_time";

	public static final String CREATE_USER_LNAME="create_user_lname";
	public static final String CREATE_USER_NAME="create_user_name";
	public static final String UPDATE_USER_LNAME="update_user_lname";
	public static final String UPDATE_USER_NAME="update_user_name";

	public static final String CREATE_LNAME="create_lname";
	public static final String CREATE_NAME="create_name";
	public static final String UPDATE_LNAME="update_lname";
	public static final String UPDATE_NAME="update_name";

	public static final String OK="ok";

	//业务排序字段
	public static String BIZ_ORDER_ID= "id";
	public static String JID= "jid";
	public static String BIZ_ORDER_PRN = "prn";
	public static String BIZ_ORDER_TIME = "create_time";
	public static String BIZ_ORDER_DISP_OR = "disp_or";

	public static Set<String> SysInnerFieldSets = Sets.newHashSet();
	static {
		SysInnerFieldSets.add( KS_CREATE_TIME );
		SysInnerFieldSets.add( OTHER_CREATE_TIME );
		SysInnerFieldSets.add( KS_UPDATE_TIME );
		SysInnerFieldSets.add( BIZ_TENANT_ID );
		SysInnerFieldSets.add( OTHER_UPDATE_TIME );
		SysInnerFieldSets.add( CREATE_USER_LNAME );
		SysInnerFieldSets.add( CREATE_USER_NAME );
		SysInnerFieldSets.add( UPDATE_USER_LNAME );
		SysInnerFieldSets.add( CREATE_LNAME );
		SysInnerFieldSets.add( CREATE_NAME );
		SysInnerFieldSets.add( UPDATE_LNAME );
		SysInnerFieldSets.add( UPDATE_NAME );
		SysInnerFieldSets.add( BIZ_ORDER_PRN );
		SysInnerFieldSets.add( BIZ_ORDER_TIME );
		SysInnerFieldSets.add( BIZ_ORDER_DISP_OR );

	}

	public static String LOGIC_PRE_SHOW_KEY = "is_logic_pre_show";


	public static final String CONTROL="control";//组件标识


	public static final String V1_VIEW_TALBE="V1_CFTestItem";

	public static final String V_VIEW_TALBE="V_CFTestItem";

	public static final String LIST_INFO="list_info";//小列表综合属性列表详情

	public static final String ADMIN="admin";//登录账号admin

	public static final String KS_CONFIG_DATAS ="KS_CONFIG_DATAS"; //redis缓存目录

	public static final String GET_LOGINNAME_BY_JID ="GET_LOGINNAME_BY_JID"; //redis缓存目录

	public static final String SENS_JID_AND_MCODE ="SensJidAndMcode"; //redis缓存目录

	public static final String SHIRO_ACTIVE_SESSION_CACHE ="shiro-activeSessionCache"; //redis缓存目录

	public static final String TU_ENV ="TU_ENV"; //redis缓存目录

	//动态sql表
	public static String DYN_SQL_TABLE = "ks_dyn_s";

	//请求元参数
	public static final String REQ_META_PARAM="req_meta_param";

	//请求元参数详细信息
	public static final String REQ_SERVER_CLASS="req_server_class";   //类方法
	public static final String REQ_SERVER_METH="req_server_meth";   //类方法
	public static final String REQ_PARAM_TYPE="req_param_type";//参数类型
	public static final String REQ_PARAM_STR="req_param_str";  //参数字符串

	//是否是业务基础字段
	public static boolean isBizBaseField( String field ){
		if (BIZ_ORDER_ID.equalsIgnoreCase( field ) || KS_CREATE_TIME.equalsIgnoreCase( field ) || KS_UPDATE_TIME.equalsIgnoreCase( field ) ||
				UP_VERSION_COLUMN_NAME.equalsIgnoreCase( field ) || BIZ_ORDER_DISP_OR.equalsIgnoreCase( field ) || OTHER_CREATE_TIME.equalsIgnoreCase( field )
				|| OTHER_UPDATE_TIME.equalsIgnoreCase( field ) || BIZ_ORDER_PRN.equalsIgnoreCase( field )){
			return true;
		}
		return false;

	}

	//全局参数
	public static final String MENU_ID = "MENU_ID";

	public static final String SELECT_QUERY_JID_BUT = "selectQueryJIDandBut";

	//第三方登录配置
	public static  final String OTHER_NAME_BEIJIN="BEIJIN";
}
